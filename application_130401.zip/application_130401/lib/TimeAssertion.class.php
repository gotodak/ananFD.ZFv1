<?php
/**
 * アサーションクラス TimeAssersion 
 */

require_once 'Zend/Acl/Assert/Interface.php';

// TimeAssersion を定義する
class TimeAssertion implements Zend_Acl_Assert_Interface {
	
	// アクセス権限付加の是非を判定する assert メソッドを定義
	
	public function assert(
		Zend_Acl $acl, 
		Zend_Acl_Role_Interface $role = NULL,
		Zend_Acl_Resource_Interface $resource = NULL, 
		$privilege = NULL) 
	{
		
		// 時刻が９～１７時の場合のみ TRUE を返す
		$hour = date('H');
		//return ($hour >=9 && $hour <=17);
		//return ($hour >=9 && $hour <=14);		//9:00～14:59
		return ($hour >=10 && $hour <=14);		//9:00～14:59
	}
}
