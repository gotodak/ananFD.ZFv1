<?

		define("HOSTNAME1", "localhost");	
		define("HOSTNAME2", "localhost");	
		define("USERNAME1", "root");				//"tmuser"
		define("USERNAME2", "root");				//"tmuser"
		define("PASSWORD1", "gotoda");			//"technomobile"
		define("PASSWORD2", "gotoda");			//"technomobile"

		define("MODULE", "vers/default");
//		define("MODULE", "vers/ver2012");
	
		define("MUSTKEY", "16520");					//"16520"
		define("GIFTKEY", "gift");					
		define("HITKEY", 	1);								

?>