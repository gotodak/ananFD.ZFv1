<?php
/**
 * ラーニングモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';




class learnModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    public function getLearnPage( $memberId, $find )
    {
				
        // ユーザ情報を取得する
				$select = $this->_db->select();
				
				$column = array( 't1.learn_id', 't1.member_id', 't1.date', 't1.hours', 't1.place', 't1.club_1', 't1.club_2', 't1.club_3', 
													't1.study', 't1.status', 't1.coach', 't1.user_1', 't1.user_2', 't1.delete_flg', 't1.modified_date',
													't1.recommend', 't1.wish_1', 't1.wish_2', 't1.wish_3', 't1.wish_4'   );
				$table  = array( 't1' => 'm_learning' );
				$select->from( $table );
				
				$column = array( 't2.subject', 't2.memo', 't2.status' );
				$table  = array( 't2' => 't_learnsupport' );
				
				$column = array( 't3.lesson', 't3.require' );
				$table  = array( 't3' => 't_learnrequire' );
				
				$column = array( 't4.employ' );
				$table  = array( 't4' => 't_learnemploy' );
				
				$select->where( 't1.delete_flg  = ?', '0' );
				
        if ($memberId != null)
					$select->where( 't1.member_id  = ?', $memberId );
						
        if ($find != null)
				{
						
        }
				
				
				
				$select->order( 'date DESC' );		// DESC
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				$userInfo = $select;
				
				
				return $userInfo;
		}




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getLearnId( $learnId, $userId = null )
    {
				
        if ($learnId === null) {
					$learnInfo = array();
					$learnInfo['learn_id'] = 0;
					
				}
				else{
					// Zend_Db_Selectオブジェクトを作成する
					$select = $this->_db->select();
					// from() メソッドを追加する
					$select = $select->from( 'm_learning' );
					$select->where( 'delete_flg  = ?', '0' );	
					$select->where( 'learn_id  = ?', $learnId );
	        $learnInfo = $this->_db->fetchRow( $select );
					
					if( $userId != null ){
						if( $userId != $learnInfo['user_1'] && 
								$userId != $learnInfo['user_2'] ){
									$learnInfo['learn_id'] = -1;
						}
					}
				}
				
        return $learnInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registLearn( $info, $memberId, $deleteType )
    {
				$lastId = 0;
				
 				if( $memberId == "" ){
            return $lastId;
        }

				
        // 登録データを連想配列にする
				
        $data = array(
											'member_id'		=> $memberId,
											'number'			=> $info['number'],
											'grade'				=> $info['grade'],
											'date'				=> $info['date'],
											'hours'				=> $info['hours'],
											'place'				=> $info['place'],
											
											'club_1'			=> $info['club1'],
											'club_2'			=> $info['club2'],
											'club_3'			=> $info['club3'],
											'study'				=> $info['study'],
											'status'			=> $info['status'],
											'coach'				=> $info['coach'],
											'user_1'			=> $info['user1'],
											'user_2'			=> $info['user2'],
											'comments'		=> $info['comments'],

											'recommend'		=> $info['recom'],
											'wish_1'			=> $info['wish1'],
											'wish_2'			=> $info['wish2'],
											'wish_3'			=> $info['wish3'],
											'wish_4'			=> $info['wish4'],

											'delete_flg'	=> $deleteType
                );
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_learning', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }






    /**-------------------------------------------------------------------------------------------
     * 学習支援情報を新規登録する（未使用未完）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registLearnNew( $info, $groupArray, $userArray, $term, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['code'] == "" ){
            return $lastId;
        }

       	// 重複チェック
        if ($this->isRegisteredSubject($info['code']) == true)
				{
            return $lastId;
        }

				
        // 登録データを連想配列にする
				
        $data = array(
											'code'				=> $info['code'],
											'name'				=> $info['name'],
											'units'				=> $info['units'],
											
											'grade'				=> $info['grade'],
											'require'			=> $info['require'],
											'term'				=> $info['term'],				//$term,
											'start_year'	=> $info['start_year'],
											'end_year'		=> $info['end_year'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_subject', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									foreach( $groupArray as $group ){
									
							        // 登録データを連想配列にする
							        $subgroup = array(
																		'code'				=> $info['code'],
																		'group_id'		=> $group,		//+1,	
																		'grade'				=> $info['grade'],
																		'require'			=> $info['require'],
																		'term'				=> $info['term'],			//$term,
																		'start_year'	=> $info['start_year'],
																		'end_year'		=> $info['end_year'],

																		'recommend'		=> $info['recom'],
																		'wish_1'			=> $info['wish1'],
																		'wish_2'			=> $info['wish2'],
																		'wish_3'			=> $info['wish3'],
																		'wish_4'			=> $info['wish4'],

																		'delete_flg'	=> $deleteType
							                );
											$this->_db->insert('t_subgroup', $subgroup );
									}

									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }





    /**-------------------------------------------------------------------------------------------
     * ★☆学習支援情報を更新する★☆
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearn( $info, $learnId, $deleteType)
    {

				$lastId = 0;
				
 				if( $learnId == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
				
        $data = array(
											'member_id'		=> $info['member'],
											'date'				=> $info['date'],
											'hours'				=> $info['hours'],
											'place'				=> $info['place'],
											
											'club_1'			=> $info['club1'],
											'club_2'			=> $info['club2'],
											'club_3'			=> $info['club3'],
											'study'				=> $info['study'],
											'status'			=> $info['status'],
											'coach'				=> $info['coach'],
											'user_1'			=> $info['user1'],
											//'user_2'			=> $info['user2'],
											'comments'		=> $info['comments'],

											'recommend'		=> $info['recom'],
											'wish_1'			=> $info['wish1'],
											'wish_2'			=> $info['wish2'],
											'wish_3'			=> $info['wish3'],
											'wish_4'			=> $info['wish4'],

											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						$target = array(
													'learn_id = ' . $learnId
										);
	        	// データを更新する
   					$this->_db->update( 'm_learning', $data, $target );
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }



    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属する教員情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearnAdduser( $learnId, $userArray )
    {
				
				$lastId = 0;
				
 				if( $learnId == "" ){
            return $lastId;
        }
       	// 重複チェック
 				if( count($userArray) != 1 )
				{
            return $lastId;
        }
				$user = $userArray[0];
				{
				
        	// 登録データを連想配列にする
					
        		$data = array(
											'user_2'			=> $user
                );
						
						
						
						// トランザクションの開始する
						$this->_db->beginTransaction();
						// トランザクション内での処理内容を定義する
						try {
								
								$target = array(
															'learn_id = ' . $learnId
												);
			        	// データを更新する
		   					$this->_db->update( 'm_learning', $data, $target );
								
								// 成功したらコミットする
								$this->_db->commit();
											
							// エラーが発生したらロールバックする
							} catch (Exception $e ) {
										$this->_db->rollBack();
										echo '処理が失敗したのでキャンセルしました。';
							}
							
			        return $lastId;
				}
				
				
    }







    /**-------------------------------------------------------------------------------------------
     * 学習支援情報を削除する（未使用未完）
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteLearn( $learn, $userId=null )
    {
				$retval = 0;
				
				if( $userId != null ){
					
					// Zend_Db_Selectオブジェクトを作成する
					$select = $this->_db->select();
					// from() メソッドを追加する
					$select = $select->from( 'm_learning' );
					$select->where( 'delete_flg  = ?', '0' );	
					$select->where( 'learn_id  = ?', $learn );
	        $learnInfo = $this->_db->fetchRow( $select );
					
					$max = $this->countMemberLearn( $learnInfo['member_id'] );
					
					if( $userId != $learnInfo['user_1'] && 
							$userId != $learnInfo['user_2'] ){
								$retval = -1;
								return $retval;
					}elseif( $max > $learnInfo['number']){
								$retval = -2;
								return $retval;
					}
				}
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
					         // 更新データを連想配列にする
					        $data = array(
					                      'delete_flg'	=> '1'
					                );
									$target = array(
																'learn_id = ' . $learn 
													);
									
					        // データを更新する
					        $this->_db->update( 'm_learning', $data, $target );
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				return $retval;

   }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援面接に属する支援授業科目情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedEmployId($learnId)
    {
        // ユーザ情報を取得する
        if ($learnId === null) {
						$select = $this->_db->select()->from( 't_learnemploy' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 't_learnemploy' );
						$select->where( 'learn_id  = ?', $learnId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo = $this->_db->fetchAll($select);
        }
				
				
        return $userInfo;
				
    }





    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援面接に属する支援授業科目情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedSupportId( $learnId )
    {
				
				$select = $this->_db->select();
				$select->from( 't_learnsupport' );
				$select->where( 'learn_id  = ?', $learnId );
				$select->where( 'delete_flg  = ?', '0' );
        $userInfo = $this->_db->fetchAll( $select );
        return $userInfo;
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援面接に属する要望授業科目情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedRequireId( $learnId )
    {
				
				$select = $this->_db->select();
				$select->from( 't_learnrequire' );
				$select->where( 'learn_id  = ?', $learnId );
				$select->where( 'delete_flg  = ?', '0' );
        $userInfo = $this->_db->fetchAll( $select );
        return $userInfo;
				
				
    }





    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属するサポート情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearnAddsupport( $info, $supportArray, $deleteType)
    {
				
				
        $learn		= $info['learn'];
        $member		= $info['member'];
        $date			= $info['date'];
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									foreach( $supportArray as $str )
									{
											//$group = $groupArray[$key];
											if( substr_count( $str, ':')==2 )
											{
												$res	=  explode(":", $str);	//split
												$support = $res[0];
												$group 	 = $res[1];
												$grade 	 = $res[2];
											}else{
												$support = $str;
												$group  =  0;
												$grade 	 = 0;
											}
       								// 重複チェック
											if( $this->isRegisteredLearnsupport( $learn,$support ) == true )
											{
													
													if( $this->isRegisteredLearnsupportDeleteFlg( $learn,$support ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
																						'date'				=> $date,	
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'learn_id = '   . $learn ,
																						'subject_id = ' . $support,
																						'group_id = '   . $group,
																						'member_id = '  . $member
																			);
															
											        // データを更新する
											        $this->_db->update( 't_learnsupport', $data, $target );
															
													}
											}else
											{
											        // 登録データを連想配列にする
											        $data = array(
																						'learn_id'		=> $learn,
																						'subject_id'	=> $support,	
																						'group_id'    => $group,
																						'grade_at'		=> $grade,
																						'member_id'		=> $member,	
																						'date'				=> $date,	
																						
																						'delete_flg'	=> $deleteType
											                );
															$this->_db->insert('t_learnsupport', $data );
											}
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属するサポート情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearnDelsupport( $learn, $support, $deleteType)
    {
				
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				$target = array(
											'learn_id = ' . $learn ,
											'id = ' . $support
								);
				
        // データを更新する
        $this->_db->update( 't_learnsupport', $data, $target );

		
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属するサポート情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearnAddrequire( $info, $requireArray, $deleteType )
    {
				
        $learn		= $info['learn'];
        $member		= $info['member'];
        $date			= $info['date'];
        $comments = $info['comments'];
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									foreach( $requireArray as $str )
									{
											if( substr_count( $str, ':')==2 )
											{
												$res	=  explode(":", $str);	//split
												$subject = $res[0];
												$group 	 = $res[1];
												$grade 	 = $res[2];
											}else{
												$subject = $str;
												$group  =  0;
												$grade  =  0;
											}
       								// 重複チェック
											if( $this->isRegisteredLearnrequire( $learn,$subject ) == true )
											{
													
													if( $this->isRegisteredLearnrequireDeleteFlg( $learn,$subject ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
																						//×'require' => $this->_db->quote($comments) ,
																						'require' 		=> $comments,
																						'date'				=> $date,			
																						'member_id'		=> $member,			//必要？
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'learn_id = '  . $learn ,
																						'subject_id = '. $subject,
																						'group_id = '  . $group
																			);
															
											        // データを更新する
											        $this->_db->update( 't_learnrequire', $data, $target );
															
													}
											}else
											{
											        // 登録データを連想配列にする
											        $subuser = array(
																						'learn_id'		=> $learn,
																						'member_id'		=> $member,		//必要？
																						'date'				=> $date,			
																						'subject_id'	=> $subject,	
																						'group_id'		=> $group,	
																						'grade_at'		=> $grade,	
																						'require' 		=> $comments,
																						
																						'delete_flg'	=> $deleteType
											                );
															$this->_db->insert('t_learnrequire', $subuser );
											}
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属するサポート情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearnDelrequire( $learn, $require, $deleteType)
    {
				
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				$target = array(
											'learn_id = ' . $learn ,
											'id = ' . $require
								);
				
        // データを更新する
        $this->_db->update( 't_learnrequire', $data, $target );

		
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属する就職情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    //public function updateLearnAddemploy( $learn, $member, $employArray, $date, $deleteType)
		public function updateLearnAddemploy( $info, $employArray, $deleteType )
    {
				
				
        $learn		= $info['learn'];
        $member		= $info['member'];
        $date			= $info['date'];
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									foreach( $employArray as $employ ){
									
       								// 重複チェック
											if( $this->isRegisteredLearnemploy( $learn,$employ ) == true )
											{
													
													if( $this->isRegisteredLearnemployDeleteFlg( $learn,$employ ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
																						'date'				=> $date,			//必要？
																						'member_id'		=> $member,			//必要？
											                      'delete_flg'	=> '0'
											                );
											        $data = array(
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'learn_id = ' . $learn ,
																						'employ_id = ' . $employ 
																			);
															
											        // データを更新する
											        $this->_db->update( 't_learnemploy', $data, $target );
															
													}
											}else
											{
											        // 登録データを連想配列にする
											        $subuser = array(
																						'learn_id'		=> $learn,
																						'date'				=> $date,			//必要？
																						'member_id'		=> $member,			//必要？
																						'employ_id'   => $employ, 
																					
																						//'date'				=> $date,
																						'delete_flg'	=> $deleteType
											                );
															$this->_db->insert('t_learnemploy', $subuser );
											}
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報に属する就職情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLearnDelemploy( $learn, $employId, $deleteType)
    {
				
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				$target = array(
											'learn_id = ' . $learn ,
											'id = '   . $employId
								);
				
        // データを更新する
        $this->_db->update( 't_learnemploy', $data, $target );

		
    }




    /**-------------------------------------------------------------------------------------------
     * 学習支援情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getLearnMemberNumber( $memberId, $number = 1 )
    {
				
        if ($memberId === null) {
					$learnInfo = array();
					$learnInfo['learn_id'] = 0;
					
				}
				else{
					// Zend_Db_Selectオブジェクトを作成する
					$select = $this->_db->select();
					// from() メソッドを追加する
					$select = $select->from( 'm_learning' );
					$select->where( 'delete_flg  = ?', '0' );	
					$select->where( 'member_id  = ?', $memberId );
					$select->where( 'number  = ?', $number );
	        $learnInfo = $this->_db->fetchRow( $select );
					
				}
				
        return $learnInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援面接の合計数を返す
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function countMemberLearn( $member )
    {
				
				$select = $this->_db->select();
				$select->from( 'm_learning', 'COUNT(*) AS cnt' );
				$select->where( 'member_id  = ?', $member );
				$select->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchRow($select);
        return $result['cnt'];
        
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学年の学習支援面接の合計数を返す
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function countMemberLearnGrade( $member, $gradeArray )
    {
				
				$select = $this->_db->select();
				$select->from( 'm_learning', 'COUNT(*) AS cnt' );
				$select->where( 'member_id  = ?', $member );
				$select->where( 'grade IN (?)', $gradeArray );
				$select->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchRow($select);
        return $result['cnt'];
        
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援面接が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearn( $learn )
    {
				
        // 登録済みかチェックする
				$select = $this->_db->select();
				$select->from( 'm_learning', 'COUNT(*) AS cnt' );
				$select->where( 'learn_id  = ?', $learn );
        $result = $this->_db->fetchRow($select);
				
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援面接に属するサポート情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnsupport( $learn,$subject )
    {
				
        // 登録済みかチェックする
				$select = $this->_db->select();
				$select->from( 't_learnsupport', 'COUNT(*) AS cnt' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'subject_id  = ?', $subject );
        $result = $this->_db->fetchRow($select);
				
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援のサポート情報の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnsupportDeleteFlg( $learn,$subject )
    {
				
				$select = $this->_db->select();
				$select->from( 't_learnsupport', 'delete_flg' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'subject_id  = ?', $subject );
        $result = $this->_db->fetchRow($select);
				
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援に属するリクエスト情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnrequire( $learn,$subject )
    {
				
        // 登録済みかチェックする
				$select = $this->_db->select();
				$select->from( 't_learnrequire', 'COUNT(*) AS cnt' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'subject_id  = ?', $subject );
        $result = $this->_db->fetchRow($select);
				
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援に属するリクエスト情報に削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnrequireDeleteFlg( $learn,$subject )
    {
				
				$select = $this->_db->select();
				$select->from( 't_learnrequire', 'delete_flg' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'subject_id  = ?', $subject );
        $result = $this->_db->fetchRow($select);
				
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }



    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援に属するリクエスト情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnemploy( $learn,$employ )
    {
				
        // 登録済みかチェックする
				$select = $this->_db->select();
				$select->from( 't_learnemploy', 'COUNT(*) AS cnt' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'employ_id  = ?', $employ );
        $result = $this->_db->fetchRow($select);
				
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援に属するリクエスト情報に削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnemployDeleteFlg( $learn,$employ )
    {
				
				$select = $this->_db->select();
				$select->from( 't_learnemploy', 'delete_flg' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'employ_id  = ?', $employ );
        $result = $this->_db->fetchRow($select);
				
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }










    /**-------------------------------------------------------------------------------------------
     * 追加教員１を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getLearnUser1($learn)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_learning', 'user_1' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }



    /**-------------------------------------------------------------------------------------------
     * 面接日時を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getLearnDate($learn)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_learning', 'date' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }






    /**-------------------------------------------------------------------------------------------
     * 面接学年を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getLearnGrade($learn)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_learning', 'grade' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 0;
				
    }






    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserName($userId)
    {


        // グループ名称を取得する
        if ($userId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						$sql->where( 'user_id  = ?', $userId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
		
    }



    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザが登録されているかチェックする
     * 
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isAllowLearnuser( $userId, $result )
    {
				
 				if( $result == null || $userId == null ){
            return false;
        }
            return true;
    }



    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($groupName)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_group', 'group_id' );
				$select->where( 'group_name  = ?', $groupName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : STAFF_ID;				//staff

    }



    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }












}