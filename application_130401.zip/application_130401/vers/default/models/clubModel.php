<?php
/**
 * クラブモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';




class clubModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }




    /**-------------------------------------------------------------------------------------------
     * グループ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getClubPage( $find )
    {
				
        // ユーザ情報を取得する
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select = $select->from( 'm_club' );
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
						
								// Zend_Db_Selectオブジェクトを作成する
								$select = $this->_db->select();
								// from() メソッドを追加する
								$select = $select->from( 'm_club' );
						
						if( $find['s_keyword'] !='' )
								$select->where( 'club_name LIKE ?',   "%{$find['s_keyword']}%" );
						
						if( $find['s_kind'] !='0' )
								$select->where( 'kind  = ?', $find['s_kind'] );
						
						
						$userInfo = $select;
						
        }	
			
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $userInfo = $this->_db->fetchAll($userInfo);
				
				return $userInfo;
			

		}



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getClubId($clubId)
    {
        // ユーザ情報を取得する
        if ($clubId === null) {
						$select = $this->_db->select()->from( 'm_club' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 'm_club' );
						$select->where( 'club_id  = ?', $clubId );
		        $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registClub( $info, $clubId, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['name'] == '' ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredClub($info['name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('club_name' 	=> $info['name'],
                      'club_kana'		=> $info['kana'],
                      'kind'				=> $info['kind'],
                      'delete_flg'	=> $deleteType
                );
				
				
				// ユーザ情報を登録する
				$this->_db->insert('m_club', $data );
			  // 登録したデータの user_id を取得する
				$lastId = $this->_db->lastInsertId();
				
	      return $lastId;
		
    }


    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を新規登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registClubNew( $info, $clubId, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['name'] == "" ){
            return $lastId;
        }
				
       	// 重複チェック
        if ($this->isRegisteredClub($info['name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
				
         $data = array('club_name' 	=> $info['name'],
                       'club_kana'	=> $info['kana'],
                       'kind'				=> $info['kind'],
                       'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_club', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }






    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateClub( $info, $clubId, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array('club_name' 	=> $info['name'],
                      'club_kana'		=> $info['kana'],
                      'kind'				=> $info['kind'],
                      'delete_flg'	=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 'm_club', $data, 'club_id = ' . $clubId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteClub($clubId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 'm_club', $data, 'club_id = ' . $clubId );
				
   }








    /**-------------------------------------------------------------------------------------------
     * 指定されたフィードURLが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredClub($clubName)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_club', 'COUNT(*) AS cnt' );
				$select->where( 'club_name  = ?', $clubName );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($groupName)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_group', 'group_id' );
				$select->where( 'group_name  = ?', $groupName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : STAFF_ID;				//staff

    }



    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }








}