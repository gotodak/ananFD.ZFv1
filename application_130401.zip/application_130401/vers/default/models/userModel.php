<?php
/**
 * ユーザモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';
require_once 'Zend/Config/Ini.php';

require_once 'Zend/Captcha/Dumb.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';




class userModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
			
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
		 *
		 * SubjectControllerでも使用しているので仕様変更時には対応が必要（=>getUser2Pageとして分離）
     */
    public function getUserPage( $find )
    {
				
        // ユーザ情報を取得する
        //if ($find == null)
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select = $select->from( 'm_user' );
						$select->where( 'delete_flg  = ?', '0' );
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
						
								$select = $this->_db->select();
						
						if( $find['s_comm'] =='0' )					///SubjectControllerでも使用
						{
								// from() メソッドを追加する
								$select = $select->from( 'm_user' );
								$select->where( 'delete_flg  = ?', '0' );				// AND
							
							if( $find['s_group'] !='0' )
									$select->where( 'group_id  = ?', $find['s_group'] );
							if( $find['s_job'] !='0' )
									$select->where( 'job_id  = ?',   $find['s_job'] );
							if( $find['s_kind'] !='0' )
									$select->where( 'kind  = ?', $find['s_kind'] );
									
							$strReg = getRegStr($find['s_kana']);
							if( $strReg != '' ) {
									$select->where( 'user_kana REGEXP ?', $strReg );		// AND
									$select->order( 'user_kana' );
							}
							
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='user_name' || $find['s_field'] =='user_kana' )
									$select->where(  $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							}
						}
/**/
						else{
							
							$column = array( 't1.user_id', 't1.user_name', 't1.user_kana', 't1.group_id', 't1.job_id', 't1.email', 't1.tel', 't1.modified_date'  );
							$table  = array( 't1' => 'm_user' );
							$select->from( $table, $column );
							
							$column = array( 't2.comm_id'  );
							$table  = array( 't2' => 't_commuser' );
							$select->joinLeft( $table, 't1.user_id = t2.user_id', $column );
							
							$select->where( 't1.delete_flg  = ?', '0' );
							$select->where( 't2.delete_flg  = ?', '0' );
							
							if( $find['s_comm'] !='0' ){
									$select->where( 't2.comm_id  = ?', $find['s_comm'] );
									$select->order( 't1.user_id' );
							}
							
							if( $find['s_group'] !='0' )
									$select->where( 't1.group_id  = ?', $find['s_group'] );
							if( $find['s_job'] !='0' )
									$select->where( 't1.job_id  = ?',   $find['s_job'] );
							if( $find['s_kind'] !='0' )
									$select->where( 't1.kind  = ?', $find['s_kind'] );
									
							$strReg = getRegStr($find['s_kana']);
							if( $strReg != '' ) {
									$select->where( 't1.user_kana REGEXP ?', $strReg );		// AND
									$select->order( 't1.user_kana' );
							}
							
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='user_name' || $find['s_field'] =='user_kana' )
									$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							}
						}
/**/
						
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
						
						$userInfo = $select;
						
        }
				
				return $userInfo;
		}



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getUserId($userId)
    {
 				
 				if( $userId == null ){
            return null;
            //return array();
        }
				
        // ユーザ情報を取得する
				$select = $this->_db->select();
				$select = $select->from( 'm_user' );
				$select->where( 'user_id  = ?', $userId );
				//$sql->where( 'delete_flg  = ?', '0' );
        $userInfo = $this->_db->fetchRow($select);
        return $userInfo;
        
				
				
				
    }

    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserNameId($userName)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_user', 'user_id' );
				$select->where( 'user_name  = ?', $userName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 0;			//NoFind


    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ名を取得する
     *
     * @param	 int		$userId			ユーザ名ＩＤ
     * @return string $userName		ユーザ名
     *
     */
    public function getUserName($userId)
    {
				
				$userName = null;
        // 職名を取得する
        if ($userId != null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						$sql->where( 'user_id  = ?', $userId );
						
        		$userName = $this->_db->fetchOne($sql);
						
        }
        return $userName;
				
    }








    /**-------------------------------------------------------------------------------------------
     * ユーザ情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registUser( $info, $groupId, $jobId, $role, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['email'] == "" ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredUser($info['email']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('user_name'   => $info['user_name'],
                      'user_kana'   => $info['user_kana'],
                 	    'group_id' 		=> $groupId,	
                  	  'job_id'      => $jobId,	
                      'email'       => $info['email'],
                      'tel'         => $info['tel'],
                      'kind'        => $info['kind'],
                      'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_user', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									// ログイン情報を登録する
									$email = $data['email'];
									$logName = strtok($email, '@');
									$logName2 = md5( $logName );
									$login = array(
															'login_id'		=> $logName,
															'password'		=> $logName2,
															'role'				=> $role,
															'user_name'		=> $data['user_name'],
															'user_id'			=> $lastId,
															'delete_flg'	=> '0'
													);
									$this->_db->insert('t_user', $login );
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }




    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateUser( $info, $userId, $commArray, $session =null )
    {
		
				$lastId = 0;
				
 				if( $userId == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
				
        $data = array('user_name' 	=> $info['user_name'],
                      'user_kana' 	=> $info['user_kana'],
                      'email' 			=> $info['email'],
                      'tel'       	=> $info['tel'],
                      'kind'       	=> $info['kind'],
                      'group_id'  	=> $info['group_id'],
                      'job_id'  		=> $info['job_id'],
                      'delete_flg'	=> $info['delete_flg']
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						$target = array(
													'user_id = ' . $info['user_id']
										);
	        	// データを更新する
   					$this->_db->update( 'm_user', $data, $target );

						if( !is_null($session) ){
								if( $session->userId == $info['user_id'] ) {
							  		$session->userName		= $info['user_name'];
								}
						}

						
						
						
						$this->checkCommittee( $info['user_id'], $commArray );
						
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;


		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteUser($userId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 'm_user', $data, 'user_id = ' . $userId );
        $this->_db->update( 't_user', $data, 'user_id = ' . $userId );
				
   }




    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザに属する委員会情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedCommId($userId)
    {
				
 				if( $userId == null ){
            return null;
        }
				
        // ユーザ情報を取得する
				$sql = $this->_db->select()->from( 't_commuser', 'comm_id' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'delete_flg  = ?', '0' );
        $commInfo = $this->_db->fetchAll($sql);
       	return $commInfo;
        
				
    }









    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に登録されているかチェックする（委員会のみ）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function checkCommittee( $userId, $commArray )
    {
				$commScan = $this->getCommArrayId( COMM_KIND_USER );		//'3'

				$idx = 0;
				
				foreach( $commScan as $scan )
				{
					
					$bFind =false;
					foreach( $commArray as $comm )
					{
						if( $scan == $comm )
						{
								$bFind =true;
								break;
						}
					}
					
					
					
					if( $bFind )
					{
		       		// 有無チェック
							if( $this->isRegisteredCommittee( $userId,$scan ) == true )
							{
							    // 登録データを連想配列にする
							    $data = array(
																		'delete_flg'	=> '0'
									            );
									$target = array(
																		'user_id = ' . $userId,
																		'comm_id = ' . $scan
																);
									$this->_db->update('t_commuser', $data, $target );
							}else
							{
							    // 登録データを連想配列にする
							    $data = array(
																		'user_id'		 => $userId,
																		'comm_id'		 => $scan,
																		'delete_flg' => '0'
										            );
									$this->_db->insert('t_commuser', $data );
							}
					}else 
					{
	       			// 有無チェック
							if( $this->isRegisteredCommittee( $userId, $scan ) == true )
							{
								   // 更新データを連想配列にする
								  $data = array(
								                'delete_flg'	=> '1'
								          );
									$target = array(
																'user_id = ' . $userId,
																'comm_id = ' . $scan
													);
								  // データを更新する
								  $this->_db->update( 't_commuser', $data, $target );
									
							}
					}
					
					
					
					
					
				}
				
			}



    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無 
     */
    public function isRegisteredCommittee( $userId,$commId )
    {
				
				$sql = $this->_db->select()->from( 't_commuser', 'COUNT(*) AS cnt' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'comm_id  = ?', $commId );
        $result = $this->_db->fetchRow($sql);
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
        
    }


    /**-------------------------------------------------------------------------------------------
     * 委員会情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    private function getCommArrayId( $commKind )
    {
				
				$sql = $this->_db->select()->from( 'm_committee', 'comm_id' );
				$sql->where( 'comm_kind  = ?', $commKind );
				$sql->where( 'delete_flg  = ?', '0');
        //$commInfo = $this->_db->fetchAll($sql);
        $commInfo = $this->_db->fetchCol($sql);
        return $commInfo;
        
    }











    /**-------------------------------------------------------------------------------------------
     * ユーザ情報に属する委員会情報を追加する（未使用、MultiCheckbox利用で）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateUserAddcomm( $info, $code, $userArray, $deleteType)
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									foreach( $userArray as $user ){
									
       								// 重複チェック
											if( $this->isRegisteredUsercomm( $code,$user ) == true )
											{
													
													if( $this->isRegisteredUsercommDeleteFlg( $code,$user ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'user_id = ' . $code ,
																						'comm_id = ' . $user
																			);
															
											        // データを更新する
											        $this->_db->update( 't_commuser', $data, $target );
															
													}
											}else
											{
											        // 登録データを連想配列にする
											        $userComm = array(
																						'user_id'			=> $code,
																						'comm_id'			=> $user,	
																						
																						'delete_flg'	=> $deleteType
											                );
															$this->_db->insert('t_commuser', $userComm );
											}
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報に属する委員会情報を削除する（未使用、MultiCheckbox利用で）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateUserDelcomm( $info, $userId, $commId, $deleteType)
    {
				
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				$target = array(
											'user_id = ' . $userId,
											'comm_id = ' . $commId
								);
				
        // データを更新する
        $this->_db->update( 't_commuser', $data, $target );
		
    }


    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザ情報に属する委員会情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredUsercomm( $userId,$commId )
    {
				
        // 登録済みかチェックする
				$sql = $this->_db->select()->from( 't_commuser', 'COUNT(*) AS cnt' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'comm_id  = ?', $commId );
        $result = $this->_db->fetchRow($sql);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
        
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された委員会情報の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredUsercommDeleteFlg( $userId,$commId )
    {
				
				$sql = $this->_db->select()->from( 't_commuser', 'delete_flg' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'comm_id  = ?', $commId );
        $result = $this->_db->fetchRow($sql);
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
        
    }


    /**-------------------------------------------------------------------------------------------
     * 委員会名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getCommName($commId)
    {


        // グループ名称を取得する
        if ($commId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_committee', 'comm_name' );
						
						$commName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_committee', 'comm_name' );
						$sql->where( 'comm_id  = ?', $commId );
						
        		$commName = $this->_db->fetchOne($sql);
						
        }
        return $commName;

    }
















    /**-------------------------------------------------------------------------------------------
     * ログイン情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLoginUserName( $userId, $userName, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array(
                      'user_name' 	=> $userName,
                      'delete_flg'	=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 't_user', $data, 'user_id = ' . $userId );
		
    }




    /**-------------------------------------------------------------------------------------------
     * ログイン情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateUserPassword( $userId, $password, $session =null )
    {
				$password2 = md5( $password );
        // 更新データを連想配列にする
        $data = array(
											'password' 		=> $password2
                );
				$target = array(
											'user_id = ' . $this->_db->quote($userId)
								);
        // データを更新する
        $this->_db->update( 't_user', $data, $target );
				
				
				$sql = $this->_db->select()->from( 't_user', 'role' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'delete_flg  = ?', '0' );
        $role = $this->_db->fetchOne($sql);
				if( !is_null($role) ){
						$loginId	= $this->getLoginId( $userId );
				}
				if( !is_null($session) ){
						$session->userLevel = $role;
				}
				return $role;
    }




    /**-------------------------------------------------------------------------------------------
     * ログイン情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLoginPassword( $loginId, $password )
    {
				$password2 = md5( $password );
        // 更新データを連想配列にする
        $data = array(
											'password' 		=> $password2
                );
				$target = array(
											'login_id = ' . $this->_db->quote($loginId)
								);
				
        // データを更新する
        $this->_db->update( 't_user', $data, $target );


		
    }




    /**-------------------------------------------------------------------------------------------
     * パスワード情報を初期化する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function initPassword( $userId, $session =null )
    {
				
 				if( $userId == null ){
            return false;
        }
				

		        // Dumbオブジェクトを生成する
		        $captcha = new Zend_Captcha_Dumb();
		        // Captchaの内部名を設定する
		        $captcha->setName('captcha');
		        // Captcha文字列を生成する
		        $captcha->generate();
		        // 生成したCaptcha文字列をビュースクリプトに貼り付ける
		        $captcha = $captcha->render();

				
				$pos = strpos( $captcha, ':' ) + 5;			// 'Please type this word backwards:  <b>'
				$password = substr($captcha, $pos, 8 );
				
				if( !is_null($password) ){
						
						$password2 = md5( $password );
		        // 更新データを連想配列にする
		        $data = array(
													'password' 		=> $password2
		                );
						$target = array(
													'user_id = ' . $this->_db->quote($userId)
										);
		        // データを更新する
		        $this->_db->update( 't_user', $data, $target );
						
						
						
						
				}
				//return true;
				return $password;
		
    }




    /**-------------------------------------------------------------------------------------------
     * ログイン情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateLoginRole( $userId, $role )
    {
        // 更新データを連想配列にする
        $data = array(
											'role' 		=> $role
                );
				
        // データを更新する
        $this->_db->update( 't_user', $data, 'user_id = ' . $userId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function geLoginRole( $loginId )
    {
				
 				if( $userId == null ){
            return false;
        }
				
				$sql = $this->_db->select()->from( 't_user', 'role' );
				$sql->where( 'login_id  = ?', $loginId );
				$sql->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchOne($sql);
       	return $result;
    }



    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredUser($email)
    {
				
				$sql = $this->_db->select()->from( 'm_user', 'COUNT(*) AS cnt' );
				$sql->where( 'email  = ?', $email );
        $result = $this->_db->fetchRow($sql);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
        
    }



    /**-------------------------------------------------------------------------------------------
     *  指定されたユーザが教員、または、指定された権限の委員会に属するメンバーかどうかチェックする
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isTeacherCommUsers( $userId, $commArray )
    {
				
 				if( $userId == null ){
            return false;
        }
				
 				if( $commArray != null ){
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select->from( 't_commuser', 'id' );
						$select->where( 'user_id  = ?', $userId );
						$select->where( 'comm_id IN (?)', $commArray );
						$select->where( 'delete_flg  = ?', '0' );
				    $result = $this->_db->fetchCol( $select );
				   	if ( count($result)  ) {
				    		return true;
				    }
				}
				
				$sql = $this->_db->select()->from( 'm_user', 'kind' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'delete_flg  = ?', '0' );
        $ret = $this->_db->fetchOne($sql);
        return ($ret == 1) ? true : false;
        
    }





    /**-------------------------------------------------------------------------------------------
     *  指定されたユーザが教員、または、チーフに属するメンバーかどうかチェックする
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isChiefCommUsers( $userId, $commArray )
    {
				
 				if( $userId == null ){
            return false;
        }
				
 				if( $commArray != null ){
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select->from( 't_commuser', 'id' );
						$select->where( 'user_id  = ?', $userId );
						$select->where( 'comm_id IN (?)', $commArray );
						$select->where( 'delete_flg  = ?', '0' );
				    $result = $this->_db->fetchCol( $select );
				   	if ( count($result)  ) {
				    		return true;
				    }
				}
				
				
				$minId =10;
				$maxId =39;
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 't_commuser', 'id' );
				$select->where( 'user_id  = ?', $userId );
				$select->where( 'comm_id >= ?', $minId );
				$select->where( 'comm_id <= ?', $maxId );
				$select->where( 'delete_flg  = ?', '0' );
		    $result = $this->_db->fetchCol( $select );
		   	if ( count($result)  ) {
		    		return true;
		    }
				
				return false;
				
    }





    /**-------------------------------------------------------------------------------------------
     *  指定されたユーザが教員、または、指定された権限の委員会に属するメンバーかどうかチェックする（未使用）
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isTeacherLevelUsers( $userId, $commArray )
    {
				
 				if( $userId == null ){
            return false;
        }
				
 				if( $commArray != null ){
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select->from( 'm_committee', 'comm_id' );
						$select->where( 'comm_level IN (?)', $commArray );
						$select->where( 'delete_flg  = ?', '0' );
				    $comm2Array = $this->_db->fetchCol( $select );
						if( is_array($comm2Array) ){
								// Zend_Db_Selectオブジェクトを作成する
								$select = $this->_db->select();
								$select->from( 't_commuser', 'id' );
								$select->where( 'user_id  = ?', $userId );
								$select->where( 'comm_id IN (?)', $comm2Array );
								$select->where( 'delete_flg  = ?', '0' );
						    $result = $this->_db->fetchCol( $select );
						   	if ( count($result)  ) {
						    		return true;
						    }
						}
				}
				
				$sql = $this->_db->select()->from( 'm_user', 'kind' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'delete_flg  = ?', '0' );
        $ret = $this->_db->fetchOne($sql);
        return ($ret == 1) ? true : false;
        
    }






    /**-------------------------------------------------------------------------------------------
     * ユーザ認証を行う（未使用）
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isAuthValid( $userId, $password )
    {
				
				$sql = $this->_db->select()->from( 't_user', 'role' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'password  = ?', $password );
				$sql->where( 'delete_flg  = ?', '0' );
        $ret = $this->_db->fetchOne($sql);
        return ($ret != null) ? $ret : false;
        
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function getLoginId( $userId )
    {
				
 				if( $userId == null ){
            return null;
        }
				
				$sql = $this->_db->select()->from( 't_user', 'login_id' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchOne($sql);
       	return $result;
        
    }






    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($groupName)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_group', 'group_id' );
				$select->where( 'group_name  = ?', $groupName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : STAFF_ID;					//staff

    }



    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }






    /**-------------------------------------------------------------------------------------------
     * 職名ＩＤを取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getJobId($jobName)
    {
				
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_job', 'job_id' );
				$select->where( 'job_name  = ?', $jobName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;						//default:1:staff
				
    }


    /**-------------------------------------------------------------------------------------------
     * 職名を取得する
     *
     * @param	 int		$jobId			職名ＩＤ
     * @return string $jobName		職名
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getJobName($jobId)
    {
				
				
        // 職名を取得する
        if ($jobId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_job', 'job_name' );
						
						$jobName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_job', 'job_name' );
						$sql->where( 'job_id  = ?', $jobId );
						
        		$jobName = $this->_db->fetchOne($sql);
						
        }
        return $jobName;
				
    }







    /**-------------------------------------------------------------------------------------------
     *  指定されたユーザがチーフに属するメンバーかどうかチェックする
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isChiefUser( $session =null, $commArray )
    {
				
				$userId = $session->userId;
 				if( $userId == null ){
            return false;
        }
				
				//委員会のメンバーならば、制限なし
 				if( $commArray != null ){
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select->from( 't_commuser', 'id' );
						$select->where( 'user_id  = ?', $userId );
						$select->where( 'comm_id IN (?)', $commArray );
						$select->where( 'delete_flg  = ?', '0' );
				    $result = $this->_db->fetchCol( $select );
				   	if ( count($result)  ) {
				    		return false;
				    }
				}
				
				
				$minId =10;
				$maxId =39;
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 't_commuser', 'id' );
				$select->where( 'user_id  = ?', $userId );
				$select->where( 'comm_id >= ?', $minId );
				$select->where( 'comm_id <= ?', $maxId );
				$select->where( 'delete_flg  = ?', '0' );
		    $result = $this->_db->fetchCol( $select );
		   	if ( count($result)  ) {
						//'chief'登録されていれば、参照する（'admin'ロール権限であっても）
		    		return true;
		    }
				
				
				return false;
				
        
    }



    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザが属する委員会のチーフ情報を取得する
     *
     * @param	 int		$userId				userID
     * @return array	$commInfo			chief情報
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserChiefInfo( $session =null )
    {
				$chiefInfo = array();
					$chiefInfo['group'] = 0;	//'-1' では選択項目が矛盾する
					$chiefInfo['grade'] = 0;
					$chiefInfo['class'] = 0;
				
				$userId = $session->userId;
 				if( $userId == null ){
        	return $chiefInfo;
        }
				
				
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$column = array( 'MIN(t1.chief_type) AS min', 'COUNT(*) AS cnt' );
				$table  = array( 't1' => 't_commgroup' );
				$select->from( $table, $column );
				/**/
				$column = array( 't2.user_id' );
				$table  = array( 't2' => 't_commuser' );
				$select->joinLeft( $table, 't1.comm_id = t2.comm_id', $column );
				/**/
				$select->where( 't2.user_id  = ?', $userId );
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $result = $this->_db->fetchRow( $select );			//$result['cnt']
				
				$type	= 0;
				if( $result['cnt'] > 0 ){				// 委員会設定無し $result['min']=NULL
						$type = $result['min'];
				}else{
        		return $chiefInfo;
        }




				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$column = array( 't1.chief_type', 't1.chief_id' );
				$table  = array( 't1' => 't_commgroup' );
				$select->from( $table, $column );
				/**/
				$column = array( 't2.comm_id' );
				$table  = array( 't2' => 't_commuser' );
				$select->joinLeft( $table, 't1.comm_id = t2.comm_id', $column );
				/**/
				$select->where( 't2.user_id  = ?', $userId );
				$select->where( 't1.chief_type  = ?', $type );
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
        $result = $this->_db->fetchRow( $select );			//$result['cnt']


				if( isset($result['chief_type']) ){
						
						switch($result['chief_type']){
							case CHIEF_KIND_GROUP:
								$chiefInfo['group'] = $result['chief_id'];	break;
							case CHIEF_KIND_GRADE:
								$chiefInfo['grade'] = $result['chief_id'];	break;
							case CHIEF_KIND_CLASS:
								$chiefInfo['class'] = $result['chief_id'];	break;
							case CHIEF_KIND_CHECK:
							default:
								break;
						}
					
				}
        return $chiefInfo;
        
				
    }









}