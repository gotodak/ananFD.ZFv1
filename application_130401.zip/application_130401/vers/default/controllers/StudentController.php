<?php
/**
 * Studentコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */


setlocale(LC_ALL, 'ja_JP.UTF-8');


// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する


// モデルをロードする
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/menuModel.php';

// モジュールをロードする
require_once '../application/lib/functions.php';



class StudentController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_member;					// メンバーモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');
				
        // ユーザモデルのインスタンスを生成する
        $this->_member = new memberModel('../application/lib/member.db');
        $this->_menu 	 = new menuModel('../application/lib/user.db');
				
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['student']['sGroup']	= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['student']['sGrade']	= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['student']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['student']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['student']['sClass']	= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['student']['sKeyword']= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['student']['sField']	= $this->getRequest()->getParam('s_field');
				} else {
						if( !isset($this->_userspace->search['student']['sGroup']) )
							$this->_userspace->search['student']['sGroup']	= '0';
						if( !isset($this->_userspace->search['student']['sGrade']) )
							$this->_userspace->search['student']['sGrade']	= '0';
						if( !isset($this->_userspace->search['student']['sStyear']) )
							$this->_userspace->search['student']['sStyear']	= '0';
						if( !isset($this->_userspace->search['student']['sKana']) )
							$this->_userspace->search['student']['sKana']		= '0';
						if( !isset($this->_userspace->search['student']['sClass']) )
							$this->_userspace->search['student']['sClass']	= '0';
						if( !isset($this->_userspace->search['student']['sKeyword']) )
							$this->_userspace->search['student']['sKeyword']= '';
						if( !isset($this->_userspace->search['student']['sField']) )
							$this->_userspace->search['student']['sField']	= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['student']['sGroup'];	
				$sGrade		= $this->_userspace->search['student']['sGrade'];	
				$sStyear	= $this->_userspace->search['student']['sStyear'];
				$sKana		= $this->_userspace->search['student']['sKana'];	
				$sClass		=	$this->_userspace->search['student']['sClass'];	
				$sKeyword	=	$this->_userspace->search['student']['sKeyword'];
				$sField		=	$this->_userspace->search['student']['sField'];	
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0" 
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_member->getMemberPage( $findArray );
						
				} else 
				{
						
						$select = $this->_member->getMemberPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );

				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;




				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$student2index	= $this->view->modulePath.'student/index'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生管理'		,'url'=>$student2index ),
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$student2new			= $this->view->modulePath.'student/new'			.$this->view->sid;
				$student2import		= $this->view->modulePath.'student/import'	.$this->view->sid;
				$promotion2index	= $this->view->modulePath.'promotion/index'	.$this->view->sid;
				$dormitory2index	= $this->view->modulePath.'dormitory/index'	.$this->view->sid;
				$director2index		= $this->view->modulePath.'director/index'	.$this->view->sid;
				$contact2index		= $this->view->modulePath.'contact/index'		.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成'	,'url'=>$student2new			,'onclick'=>'' ),
									array('name'=>'一括読込'	,'url'=>$student2import		,'onclick'=>'' ),
									array('name'=>'一括進級'	,'url'=>$promotion2index	,'onclick'=>'' ),
									array('name'=>'separator' ,'url'=>$urlNon      			,'onclick'=>'' ),
									array('name'=>'寮生管理'	,'url'=>$dormitory2index	,'onclick'=>'' ),
									array('name'=>'役員寮生'	,'url'=>$director2index		,'onclick'=>'' ),
									array('name'=>'学生連絡先','url'=>$contact2index 		,'onclick'=>'' )
									);
							break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'寮生管理'	,'url'=>$dormitory2index	,'onclick'=>'' ),
									array('name'=>'役員寮生'	,'url'=>$director2index		,'onclick'=>'' ),
									array('name'=>'学生連絡先','url'=>$contact2index 		,'onclick'=>'' )
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$member_id = $this->getRequest()->getParam('member_id');
						if( $member_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_member->getMemberId( $member_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['member_id'] != 0 ){
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';

											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
											$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
											$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
											$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
											$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null );
											$this->view->sexArray			= $this->_menu->getSexList( null, null );
										
										$this->view->selSex = $result['sex'];
										$this->view->attribs = array( 	'disabled'	=>  'disabled');
										$this->view->options = null;
									}
						}
				}
				else{
				}
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$student2index	= $this->view->modulePath.'student/index'	.$this->view->sid;
				$student2item		= $this->view->modulePath.'student/item/member_id/'.$result['member_id'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生管理'		,'url'=>$student2index ),
									array('name'=>$result['member_name']		,'url'=>$student2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$student2index	= $this->view->modulePath.'student/index'.$this->view->sid;
				$student2edit		= $this->view->modulePath.'student/edit/member_id/'.$result['member_id'].$this->view->sid;
				$student2delete	= $this->view->modulePath.'student/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$student2index	,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$student2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$student2delete ,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'student/delete/member_id/'.$result["member_id"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$student2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }





    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->sexArray			= $this->_menu->getSexList( null, null );
				$this->view->conditionArray	= $this->_menu->getConditionList( $menu_mode, null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$member_id = $this->getRequest()->getParam('member_id');
						if( $member_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_member->getMemberId( $member_id );
									
									if( $result['member_id'] != 0 ){
											
											$this->view->member_id		= $result['member_id'];
											$member_name	= 
											$this->view->member_name	= $result['member_name'];
											$this->view->member_kana	= $result['member_kana'];
											$this->view->school_name	= $result['school_name'];	
											$this->view->selSex 			= $result['sex'];
											$this->view->selCondition	= $result['conditions'];
												$this->_userspace->search['student']['group']		= 
											$this->view->selGroup			= $result['group_id'];	
												$this->_userspace->search['student']['grade']		= 
											$this->view->selGrade			= $result['grade'];	
												$this->_userspace->search['student']['class']		= 
											$this->view->selClass			= $result['class_id'];	
											$this->view->selStyear		= substr($result['start_year'],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
												$this->_userspace->search['student']['styear']	= $this->view->selStyear;
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
												$this->_userspace->search['student']['edyear']	= $this->view->selEdyear;
									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$member_id 	= $this->getRequest()->getParam('member_id');
						$member_name= $this->getRequest()->getParam('member_name');
						$member_kana= $this->getRequest()->getParam('member_kana');
						$group_id 	= $this->getRequest()->getParam('group_id');
						$grade 			= $this->getRequest()->getParam('grade');
						$class_id		= $this->getRequest()->getParam('class_id');
						$styear 		= $this->getRequest()->getParam('styear');
						$edyear 		= $this->getRequest()->getParam('edyear');
						$school_name= $this->getRequest()->getParam('school_name');
						$sex				= $this->getRequest()->getParam('sex');
						
						$member_name= trim($member_name);								//半角スペースのみ
						$member_kana= trim($member_kana);								//半角スペースのみ
						$school_name= trim($school_name);								//半角スペースのみ
						
						
	      		
						$msgs = validateStringFull( 3, 30, '氏名', $member_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringKana( 3, 30, 'よみがな', $member_kana);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( 'グループ', $group_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '学年', $grade);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( 'クラス名称', $class_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '入学年度', $styear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								if( $edyear != 0 ){
									if( $edyear <= $styear ){
											
											array_push($errors, array('卒業年度が、入学年度より過去に設定されています。') );
											
									}
								}
						}
						
						$msgs = validateStringFull( 2, 5, '出身学校', $school_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
// upgradeCheck_start
						$kind = '0';
						if( $edyear != 0 ){
								
								$styear2 = $this->_userspace->search['student']['styear'];
								$edyear2 = $this->_userspace->search['student']['edyear'];
								$group2  = $this->_userspace->search['student']['group'];
								$grade2  = $this->_userspace->search['student']['grade'];
								$class2  = $this->_userspace->search['student']['class'];
								
							//卒業年度Check（５学年）
								//$year2 = $edyear - $styear2;
								if( ($edyear - $styear2) < 5 ) {
										array_push($errors, array('卒業年度が適切ではありません。') );
								}
						//５学年Check
								if ( 5 == $grade2 && 21<= $class2 && $class2 < 26 ) { 
									$kind  = '1';
									$grade = '6';
								} else {
									array_push($errors, array('卒業するグループ、学年、クラス名称の組み合わせが適切ではありません。') );
								}
							
						} else {
								
								if ( 1 == $group_id ){
									//１学年Check
									if ( 1 == $grade && 1<= $class_id && $class_id < 6 ) { }
									else {
										array_push($errors, array('グループ、学年、クラス名称の組み合わせが適切ではありません。') );
									}
								} elseif ( 1 < $group_id && $group_id <= 5 ){
									//２学年以上Check
									if ( 2 == $grade &&  6<= $class_id && $class_id < 11 ) { }
									else if ( 3 == $grade && 11<= $class_id && $class_id < 16 ) { }
									else if ( 4 == $grade && 16<= $class_id && $class_id < 21 ) { }
									else if ( 5 == $grade && 21<= $class_id && $class_id < 26 ) { }
									else {
										array_push($errors, array('グループ、学年、クラス名称の組み合わせが適切ではありません。') );
									}
								}
								
						}
// upgradeCheck_end	
						
						
						if (count($errors) == 0){
								
								$data = array(
													'member_name'	=>	$member_name,
													'member_kana'	=>	$member_kana,
													'group_id'		=>	$group_id,
													'grade'		  	=>	$grade,
													'class_id'	 	=>	$class_id,
													'start_year'	=>	$styear,
													'end_year'		=>	$edyear,
													'school_name'	=>	$school_name,
													'sex'					=>	$sex,
													'kind'				=>  $kind,		//'0',
													'state'				=> '0',
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								if( $data['start_year'] == '0' )		$data['start_year'] = '0000';
								if( $data['end_year'] == '0' )			$data['end_year'] 	= '0000';
								
								$data['start_year'] = $data['start_year'].'-04-01';
								$data['end_year'] 	= $data['end_year'].'-04-01';
								
								$member_id	= $this->getRequest()->getParam('member_id');
								$group_id	= $data['group_id'];	
								$grade		= $data['grade'] ;	
								if( $member_id != NULL ){
										
			    					$this->_member->updateMember( $data, $member_id, $group_id, $grade, '0' );
										
						        // ビュースクリプトが表示されます
								    $targetUrl = '/student/index/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->member_id		= $member_id;
								$this->view->member_name	= $member_name;
								$this->view->member_kana	= $member_kana;
								$this->view->school_name	= $school_name;	
								$this->view->selSex 			= $sex;
								$this->view->selGroup			= $group_id;	
								$this->view->selClass			= $class_id;	
								$this->view->selGrade			= $grade;	
								$this->view->selStyear		= $styear;	
								$this->view->selEdyear		= $edyear;	
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$student2index	= $this->view->modulePath.'student/index'	.$this->view->sid;
				$student2item		= $this->view->modulePath.'student/item/member_id/'.$this->view->member_id.$this->view->sid;
				$student2edit		= $this->view->modulePath.'student/edit/member_id/'.$this->view->member_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生管理'		,'url'=>$student2index ),
									array('name'=>$this->view->member_name	,'url'=>$student2item ),
									array('name'=>'編集'				,'url'=>$student2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$student2index	= $this->view->modulePath.'student/index'.$this->view->sid;
				$student2item		= $this->view->modulePath.'student/item/member_id/'.$this->view->member_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$student2index	,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$student2item		,'onclick'=>'' ),
									);
							break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$student2index	,'onclick'=>'' )
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				
				if( $this->getRequest()->isPost() )
						{
						
						$member_id = $this->getRequest()->getParam('member_id');
						if( $member_id != NULL ){
									
									// 1レコードの削除
									$result = $this->_member->deleteMember( $member_id );
						}
				}
				else{
				}
        // ビュースクリプトが表示されます
				$targetUrl = '/student/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);
    }





   /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				
				if ($this->getRequest()->isPost())
				{
						
						$member_id 	= $this->getRequest()->getParam('member_id');
						$member_name= $this->getRequest()->getParam('member_name');
						$member_kana= $this->getRequest()->getParam('member_kana');
						$group_id 	= $this->getRequest()->getParam('group_id');
						$grade 			= $this->getRequest()->getParam('grade');
						$class_id 	= $this->getRequest()->getParam('class_id');
						$styear 		= $this->getRequest()->getParam('styear');
						$edyear 		= $this->getRequest()->getParam('edyear');
						$sex		 		= $this->getRequest()->getParam('sex');
						$school_name= $this->getRequest()->getParam('school_name');
						
						$member_name= trim($member_name);								//半角スペースのみ
						$member_kana= trim($member_kana);								//半角スペースのみ
						$school_name= trim($school_name);								//半角スペースのみ
						
						$msgs = validateStringNumber( 7, 7, '学籍番号', $member_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複番号チェック
			  	  else if ( $this->_member->isRegisteredMember($member_id) == true )	{
								array_push($errors, array('この学籍番号は、既に登録されています。') );
			      	}
						
						$msgs = validateStringFull( 3, 30, '氏名', $member_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringKana( 3, 30, 'よみがな', $member_kana);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( 'グループ', $group_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '学年', $grade);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( 'クラス名称', $class_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '入学年度', $styear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								if( $edyear != 0 ){
									if( $edyear <= $styear ){
											
											array_push($errors, array('卒業年度が、入学年度より過去に設定されています。') );
											
									}
								}
						}
						
						$msgs = validateStringFull( 2, 5, '出身学校', $school_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '性別', $sex);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
					
						if (count($errors) == 0){
								$data = array(
													'member_id'		=>	$this->getRequest()->getParam('member_id'),
													'member_name'	=>	$this->getRequest()->getParam('member_name'),
													'member_kana'	=>	$this->getRequest()->getParam('member_kana'),
													'group_id'		=>	$this->getRequest()->getParam('group_id'),
													'grade'				=>	$this->getRequest()->getParam('grade'),
													'class_id'		=>	$this->getRequest()->getParam('class_id'),
													'start_year'	=>	$this->getRequest()->getParam('styear').'-04-01',
													'end_year'		=>	$this->getRequest()->getParam('edyear').'-04-01',
	                      	'school_name' =>  $this->getRequest()->getParam('school_name'),
	                      	'sex' 				=>  $this->getRequest()->getParam('sex'),
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								if( $data['start_year'] == '0-04-01' )		$data['start_year'] = '0000-00-00';
								if( $data['end_year'] 	== '0-04-01' )		$data['end_year'] 	= '0000-00-00';
								
								
								// グループＩＤを取得する
								$groupId = $data['group_id'];
								$classId = $this->_member->getClassId( $data['grade'], $groupId, null );
								$grade	 = $data['grade'];
								$deleteType = '0';
								
		    				if( $this->_member->registMember( $data, $groupId, $classId, $grade, $deleteType ) == 0 ){
										echo '中止 ';
								}
							$targetUrl = '/student/index/sid/'.$this->_sid;
							return $this->_redirect($targetUrl);
						}else{
							
							$this->view->member_id		= $member_id;		
							$this->view->member_name	= $member_name;	
							$this->view->member_kana	= $member_kana;	
							
							$this->view->selGroup			= $group_id;		
							$this->view->selClass			= $class_id;		
							$this->view->selGrade			= $grade;				
							$this->view->selStyear		= $styear;			
							$this->view->selEdyear		= $edyear;			
							$this->view->selSex 			= $sex;
							$this->view->school_name	= $school_name;
						}
				}
				else{
						
						
						$this->view->member_id		= '';	
						$this->view->member_name	= '';	
						$this->view->member_kana	= '';	
						$this->view->selGrade			= 0;	
						$this->view->selClass			= 0;	
						$this->view->selStyear		= 0;	
						$this->view->selEdyear		= 0;	//substr($result["end_year"],0,4);	
						$this->view->selSex 			= 0;
						$this->view->school_name	= '';
				}
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->sexArray			= $this->_menu->getSexList( null, null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$student2index	= $this->view->modulePath.'student/index'	.$this->view->sid;
				$student2new		= $this->view->modulePath.'student/new'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生管理'		,'url'=>$student2index ),
									array('name'=>'新規作成'		,'url'=>$student2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$student2index		= $this->view->modulePath.'student/index'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧','url'=>$student2index 		,'onclick'=>'' )
									);
							break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
    }





    /**-------------------------------------------------------------------------------------------
     * importアクション
     */
    public function importAction()
    {
        // ビュースクリプトが表示されます


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$student2index	= $this->view->modulePath.'student/index'	.$this->view->sid;
				$student2import	= $this->view->modulePath.'student/import'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生管理'		,'url'=>$student2index ),
									array('name'=>'一括読込'		,'url'=>$student2import )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$student2index		= $this->view->modulePath.'student/index'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧','url'=>$student2index 		,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }





    /**-------------------------------------------------------------------------------------------
     * uploadアクション
     */
    public function uploadAction()
    {
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="学年" ) continue;
						if( $str[4]==null ) continue;
						
						$sex = '0';
						if( $str[5] == '男' )					$sex = '1';
						else if( $str[5] == '女' )		$sex = '2';
						
						$data = array(
											'member_id'		=> $str[4],
											'member_name'	=> $str[3],
											'member_kana'	=> $str[7].'　'.$str[8],
											'class_name'	=> $str[1],								//class...1,E
											'grade'				=> $str[0],
											'start_year'	=> $str[11],							//'2011-04-01',
											'end_year'		=> '0000-00-00',
											'sex'				  => $sex,
											'school_name'	=> $str[6],
											'delete_flg'	=> '0',
											'create_date'	=> NULL
											);
						
						
						if( $data['member_name'] == null )	$data['member_name'] = '!!nonName!!';
						
						// グループＩＤを取得する
						$groupId = $this->_member->getGroupId( $data['class_name'] );
						$classId = $this->_member->getClassId( $data['grade'], $groupId, $data['class_name'] );
						$grade	 = $data['grade'];
						$deleteType = '0';
						
   				if( $this->_member->registMember( $data, $groupId, $classId, $grade, $deleteType ) == 0 ){
								echo '中止 ';
						}
				} 
				
		    $targetUrl = '/student/index/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




























    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }



}
