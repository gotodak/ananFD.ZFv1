<?php
/**
 * Learningコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する
Zend_Loader::loadClass('Zend_Pdf'); // 追加する

// モデルをロードする
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/subjectModel.php';
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/learnModel.php';
require_once '../application/vers/default/models/employModel.php';
require_once '../application/vers/default/models/supportModel.php';
require_once '../application/vers/default/models/requireModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class LearningController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_learn;					// ラーニングモデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
    private $_member;					// メンバーモデルのインスタンス
    private $_subject;				// サブジェクトモデルのインスタンス
    private $_employ;					// エンプロイモデルのインスタンス
    private $_support;				// サポートモデルのインスタンス
    private $_require;				// リクイァモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		


    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{
				
        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');
				
        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');
				
        // ユーザモデルのインスタンスを生成する
        $this->_learn  	= new learnModel('../application/lib/member.db');
        $this->_subject	= new subjectModel('../application/lib/member.db');
        $this->_user 		= new userModel('../application/lib/user.db');
        $this->_member 	= new memberModel('../application/lib/member.db');
        $this->_employ	= new employModel('../application/lib/user.db');
        $this->_support	= new supportModel('../application/lib/user.db');
        $this->_require	= new requireModel('../application/lib/user.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				
				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
					        //$this->view->userId		 = $this->_userspace->userId;			//$_SESSION[$this->_sid]['userId'];			//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				




				//指定されたユーザが教員、または指定された権限の委員会に属するメンバーを許可する
				$permissionArray	= array( COMM_EXECUTIVE,COMM_ASSISTANCE );
				{
					if( isset($this->_config->allowComm->learning) ) {
		        Zend_Registry::set('permission', $this->_config->allowComm->learning->toArray());
		        if (Zend_Registry::isRegistered('permission')) {
								//$permissionArray = Zend_Registry::get('permissionArray');
								$permissionArray = $this->_config->allowComm->learning->toArray();
							}
					}
				}
				$userId	= $this->_userspace->userId;
				if( $this->_user->isTeacherCommUsers( $userId, $permissionArray ) == false ){	
						
						if( true )
						{
								$this->_forward( 'error', 'Error', null, 
																	getFatalError( FATAL_TEACHER_ACCESS,$this->view )				//'教員ではありません。
																);	
						}
						
				}



        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['learning']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['learning']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['learning']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['learning']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['learning']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['learning']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['learning']['sField']		= $this->getRequest()->getParam('s_field');
				} else {
						if( !isset($this->_userspace->search['learning']['sGroup']) )
							$this->_userspace->search['learning']['sGroup']		= '0';
						if( !isset($this->_userspace->search['learning']['sGrade']) )
							$this->_userspace->search['learning']['sGrade']		= '0';
						if( !isset($this->_userspace->search['learning']['sStyear']) )
							$this->_userspace->search['learning']['sStyear']	= '0';
						if( !isset($this->_userspace->search['learning']['sKana']) )
							$this->_userspace->search['learning']['sKana']		= '0';
						if( !isset($this->_userspace->search['learning']['sClass']) )
							$this->_userspace->search['learning']['sClass']		= '0';
						if( !isset($this->_userspace->search['learning']['sKeyword']) )
							$this->_userspace->search['learning']['sKeyword']	= '';
						if( !isset($this->_userspace->search['learning']['sField']) )
							$this->_userspace->search['learning']['sField']		= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['learning']['sGroup'];		
				$sGrade		= $this->_userspace->search['learning']['sGrade'];		
				$sStyear	= $this->_userspace->search['learning']['sStyear'];		
				$sKana		= $this->_userspace->search['learning']['sKana'];		
				$sClass		=	$this->_userspace->search['learning']['sClass'];	
				$sKeyword	=	$this->_userspace->search['learning']['sKeyword'];
				$sField		=	$this->_userspace->search['learning']['sField'];	
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0"  
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_member->getMember2Page( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_member->getMember2Page( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupSelect	= 
				$this->view->groupList		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeSelect	= 
				$this->view->gradeList		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearSelect	= 
				$this->view->styearList		= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classSelect	= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaSelect		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldSelect	= $this->_menu->getField4List( null, null );
				
				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }


    /**-------------------------------------------------------------------------------------------
     * memberアクション
     */
    public function memberAction()
    {
				
				$memberId 	= $this->getRequest()->getParam('member_id');
				
				$select = $this->_learn->getLearnPage( $memberId, null );
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( 1 );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( 10 );							// 表示するページネーション範囲（default:10）
				$this->view->assign( 'paginator', $paginator );
				
				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->placeArray		= $this->_menu->getPlaceList( '', null );
				$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
				$this->view->studyArray		= $this->_menu->getStudyList( null, null );
				$this->view->statusArray	= $this->_menu->getStatusList( null, null );
				$this->view->coachArray		= $this->_menu->getCoachList( null, null );
				
					$menu_find['s_kind']='1';
				$this->view->club1Array		= $this->_menu->getClubList( $menu_mode, $menu_find );
					$menu_find['s_kind']='2';
				$this->view->club2Array		= $this->_menu->getClubList( $menu_mode, $menu_find );
					$menu_find['s_kind']='3';
				$this->view->club3Array		= $this->_menu->getClubList( $menu_mode, $menu_find );
				
				$this->view->member				= $memberId;
				$this->view->name					= $this->_member->getMemberName($memberId);
				
				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$memberId.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>$this->view->name		,'url'=>$learning2member )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
				$learning2new	= $this->view->modulePath.'learning/new/member_id/'		.$memberId	.$this->view->sid;
				$pdf2index		= $this->view->modulePath.'pdf/enrollpage/member_id/'	.$memberId	.$this->view->sid;
				$learning2enrollpage	= $this->view->modulePath.'learning/enrollpage/member_id/'		.$memberId	.$this->view->sid;

			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'新規作成'  		,'url'=>$learning2new		,'onclick'=>'' ),
									array('name'=>'separator' 		,'url'=>$urlNon    			,'onclick'=>'' ),
									array('name'=>'ＰＤＦ作成'  	,'url'=>$pdf2index			,'onclick'=>'' ),
									array('name'=>'ＰＤＦ'  	,'url'=>$learning2enrollpage			,'onclick'=>'' )
	
									);
					break;
				case 'admin':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }




    /**-------------------------------------------------------------------------------------------
     * userアクション
     */
    public function userAction(  )
    {
				$errors = array();
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['learning2']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['learning2']['sJob']			= $this->getRequest()->getParam('s_job');
						$this->_userspace->search['learning2']['sKana']			= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['learning2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['learning2']['sField']		= $this->getRequest()->getParam('s_field');
						$this->_userspace->search['learning2']['sKind']			= $this->getRequest()->getParam('s_kind');
						
						$member	 	= $this->getRequest()->getParam('member_id');
						$learn		= $this->getRequest()->getParam('learn_id');
				}
				else {
						if( !isset($this->_userspace->search['learning2']['sGroup']) )
							$this->_userspace->search['learning2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['learning2']['sJob']) )
							$this->_userspace->search['learning2']['sJob']			= '0';
						if( !isset($this->_userspace->search['learning2']['sKana']) )
							$this->_userspace->search['learning2']['sKana']			= '0';
						if( !isset($this->_userspace->search['learning2']['sKeyword']) )
							$this->_userspace->search['learning2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['learning2']['sField']) )
							$this->_userspace->search['learning2']['sField']		= '0';
						if( !isset($this->_userspace->search['learning2']['sKind']) )
							$this->_userspace->search['learning2']['sKind']			= '0';
						
						$member		= $this->getRequest()->getParam('member_id');
						$learn 		= $this->getRequest()->getParam('learn_id');
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加教員は、既に登録されています。') );
						}
						else if( $error ==2 ){
							
							array_push($errors, array('追加教員は、１名のみ選択してください。') );
						}
				}
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['learning2']['sGroup'];		
				$sJob			= $this->_userspace->search['learning2']['sJob'];			
				$sKana		= $this->_userspace->search['learning2']['sKana'];		
				$sKeyword	= $this->_userspace->search['learning2']['sKeyword'];	
				$sField		= $this->_userspace->search['learning2']['sField'];		
				$sKind		=	$this->_userspace->search['learning2']['sKind'];
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sKind	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  $sKind,
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
					
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				$this->view->roleArray		= $this->_menu->getRoleList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selKind		= $sKind;
				
				//$this->view->name			= $name;
				$this->view->name				= $this->_member->getMemberName($member);
				$this->view->member			= $member;
				$this->view->learn			= $learn;
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
				$learning2item	= $this->view->modulePath.'learning/item/learn_id/'		.$learn.$this->view->sid;
				$learning2edit	= $this->view->modulePath.'learning/edit/learn_id/'		.$learn.$this->view->sid;
				$learning2user	= $this->view->modulePath.'learning/user/learn_id/'.$learn.'/member_id/'.$member	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>$this->view->name		,'url'=>$learning2member ),
									array('name'=>$date								,'url'=>$learning2item ),
									array('name'=>'編集'							,'url'=>$learning2edit ),
									array('name'=>'教員追加'					,'url'=>$learning2user )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * adduserアクション
     */
    public function adduserAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$learn	 		= $this->getRequest()->getParam('learn_id');
						$userArray	= $this->getRequest()->getParam('user_id');
				}
				
				if( count($userArray) >= 2 ){
		        $targetUrl = '/learning/user/learn_id/'. $learn. '/member_id/'. $member .'/error/2/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($userArray) == 1 ){
						
						$user1 = $this->_learn->getLearnUser1($learn);
						if( $user1 == $userArray[0] ){
							
			        $targetUrl = '/learning/user/learn_id/'. $learn. '/member_id/'. $member .'/error/1/sid/'.$this->_sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
							
						} else if( $learn != null ){
							
			    		$this->_learn->updateLearnAdduser( $learn, $userArray );
							
			        // ビュースクリプトが表示されます
			        $targetUrl = '/learning/edit/learn_id/'. $learn. '/sid/'.$this->_sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
				}
				
				
    }







    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
					  // 前アクションでエラーならメッセージを表示する
					  $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
						$msg		= getDispMessage( $noMsg,$this->view ) ;
						if( !is_null($msg) ){
								array_push( $errors,array($msg) );
						}
						$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				if( $this->getRequest()->isGet() )
						{
						
						$learn_id 	= $this->getRequest()->getParam('learn_id');
						if( $learn_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_learn->getLearnId( $learn_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['learn_id'] != 0 ){
											
												$date = '';
												$str 	= $result['date'];
												if( substr_count( $str, ':')==2 )
												{
													$res	=  explode(":", $str);	//split
													$date	= $res[0] .':' . $res[1];
												}else{
													$date = $str;
												}
											
											$this->view->date		= $date;

											$date2		= $result['date'];
										  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date2, $m)) {
													$date2 = $m[1] .'-'. $m[2] .'-'. $m[3] ;
													$this->view->date2		= $date2;
										  }

											
											$this->view->learn			= $result['learn_id'];
											$this->view->member			= $result['member_id'];
											$this->view->number			= $result['number'];
											$this->view->name				= $this->_member->getMemberName($result['member_id']);
											$this->view->grade			= $this->_member->getMemberGrade($result['member_id']);
											
											$this->view->selPlace		= $result['place'];
											$this->view->selHours		= $result['hours'];
											$this->view->selStudy		= $result['study'];
											$this->view->selStatus	= $result['status'];
											$this->view->selCoach		= $result['coach'];
											
											$this->view->selClub1		= $result['club_1'];
											$this->view->selClub2		= $result['club_2'];
											$this->view->selClub3		= $result['club_3'];
											
											$this->view->selRecom		= $result['recommend'];
											$this->view->selWish1		= $result['wish_1'];
											$this->view->selWish2		= $result['wish_2'];
											$this->view->selWish3		= $result['wish_3'];
											$this->view->selWish4		= $result['wish_4'];
											
											$this->view->userName1	= $this->_user->getUserName($result['user_1']);
											$this->view->userName2	= $this->_user->getUserName($result['user_2']);
											
											$this->view->comments		= $result['comments'];
											
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->placeArray		= $this->_menu->getPlaceList( '', null );
											$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
											$this->view->studyArray		= $this->_menu->getStudyList( null, null );
											$this->view->statusArray	= $this->_menu->getStatusList( null, null );
											$this->view->coachArray		= $this->_menu->getCoachList( null, null );
																	$groupList		= $this->_menu->getGroupList( null, $menu_findArray );
																	$groupList[1] = "-";
											$this->view->groupList		= $groupList;
											
												$menu_findArray['s_kind']='1';
											$this->view->club1Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
												$menu_findArray['s_kind']='2';
											$this->view->club2Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
												$menu_findArray['s_kind']='3';
											$this->view->club3Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
											
											
											// 1レコードの取得
											$employArray = array();
											$employ = $this->_learn->chargedEmployId( $learn_id );
											foreach( $employ as $row ){
												$name = $this->_employ->getEmployName($row['employ_id']);
												array_push( $employArray, array("employ_id"=>$row['id'],"name"=>$name ) );
											}
											$this->view->employ	= $employArray;

											// 1レコードの取得
											$supportArray = array();
											$support = $this->_learn->chargedSupportId( $learn_id );
											foreach( $support as $row ){
												$name = $this->_subject->getSubjectName($row['subject_id']);
												array_push( $supportArray, array("support_id"=>$row['id'],"name"=>$name ) );
											}
											$this->view->support	= $supportArray;
											
											// 1レコードの取得
											$requireArray = array();
											$require = $this->_learn->chargedRequireId( $learn_id );
											foreach( $require as $row ){
												$name = $this->_subject->getSubjectName($row['subject_id']);
												array_push( $requireArray, 
																	array("require_id"=>$row['id'],"name"=>$name,"memo"=>$row['require']) );
											}
											$this->view->require	= $requireArray;
											

											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}
				else{
				}
				
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$result['member_id'].$this->view->sid;
				$learning2item	= $this->view->modulePath.'learning/item/learn_id/'		.$result['learn_id'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>$this->view->name		,'url'=>$learning2member ),
									array('name'=>$this->view->date2	,'url'=>$learning2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$learning2index		= $this->view->modulePath.'learning/index'.$this->view->sid;
				$learning2edit		= $this->view->modulePath.'learning/edit/learn_id/'.$result['learn_id'].$this->view->sid;
				$learning2delete	= $this->view->modulePath.'learning/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$learning2member	,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$learning2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$learning2delete 	,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'learning/delete/learn_id/'.$result["learn_id"].'/member_id/'.$result["member_id"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'admin':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$learning2member		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

				
    }



    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->placeArray		= $this->_menu->getPlaceList( '', null );
				$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
				$this->view->studyArray		= $this->_menu->getStudyList( null, null );
				$this->view->statusArray	= $this->_menu->getStatusList( null, null );
				$this->view->coachArray		= $this->_menu->getCoachList( null, null );
										$groupList		= $this->_menu->getGroupList( null, $menu_findArray );
										$groupList[1] = "-";
				$this->view->groupList		= $groupList;
				
					$menu_findArray['s_kind']='1';
				$this->view->club1Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
					$menu_findArray['s_kind']='2';
				$this->view->club2Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
					$menu_findArray['s_kind']='3';
				$this->view->club3Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
				
					$employArray = array();
				$this->view->employ			= $employArray;
					$supportArray = array();
				$this->view->support		= $supportArray;
					$requireArray = array();
				$this->view->require		= $requireArray;
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$member		= $this->getRequest()->getParam('member_id');
						$learn = $this->getRequest()->getParam('learn_id');
						if( $learn != NULL ){
									
									// 1レコードの取得
									$userId	= $this->_userspace->userId;
									$result = $this->_learn->getLearnId( $learn, $userId );
				          $this->view->result  = $result;					//１つの変数を設定する
									if( $result['learn_id'] < 0 ){
											
									    $targetUrl = '/learning/item'. $this->view->sid .'/learn_id/'.$learn .'/'.DISP_MESSAGE.'/'.ERR_EDIT_NORIGHT;	//'編集権がありません。
									    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
									}
									elseif( $result != null && $result['learn_id'] != 0 ){
											
											
												$date = '';
												$str 	= $result['date'];
												if( substr_count( $str, ':')==2 )
												{
													$res	=  explode(":", $str);
													$date	= $res[0] .':' . $res[1];
												}else{
													$date = $str;
												}
											$this->view->date		= $date;
											
											$date2		= $result['date'];
										  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date2, $m)) {
													$date2 = $m[1] .'-'. $m[2] .'-'. $m[3] ;
													$this->view->date2		= $date2;
										  }
											
											$this->view->learn			= $result['learn_id'];
											$this->view->member			= $result['member_id'];
											$this->view->number			= $result['number'];
											$this->view->grade			= $result['grade'];
											
											$this->view->name				= $this->_member->getMemberName($result['member_id']);
											
											$this->view->selPlace		= $result['place'];
											$this->view->selHours		= $result['hours'];
											$this->view->selStudy		= $result['study'];
											$this->view->selStatus	= $result['status'];
											$this->view->selCoach		= $result['coach'];
											
											$this->view->selClub1		= $result['club_1'];
											$this->view->selClub2		= $result['club_2'];
											$this->view->selClub3		= $result['club_3'];
											
											$this->view->selRecom		= $result['recommend'];
											$this->view->selWish1		= $result['wish_1'];
											$this->view->selWish2		= $result['wish_2'];
											$this->view->selWish3		= $result['wish_3'];
											$this->view->selWish4		= $result['wish_4'];
											
											$this->view->userName1	= $this->_user->getUserName($result['user_1']);
											$this->view->userName2	= $this->_user->getUserName($result['user_2']);
											
											$this->view->comments		= $result['comments'];
											
											// 1レコードの取得
											$employArray = array();
											$employ = $this->_learn->chargedEmployId( $learn );
											foreach( $employ as $row ){
												$name = $this->_employ->getEmployName($row['employ_id']);
												array_push( $employArray, array("employ_id"=>$row['id'],"name"=>$name ) );
											}
											$this->view->employ	= $employArray;

											// 1レコードの取得
											$supportArray = array();
											$support = $this->_learn->chargedSupportId( $learn );
											foreach( $support as $row ){
												$name = $this->_subject->getSubjectName($row['subject_id']);
												array_push( $supportArray, array("support_id"=>$row['id'],"name"=>$name ) );
											}
											$this->view->support	= $supportArray;
											
											// 1レコードの取得
											$requireArray = array();
											$require = $this->_learn->chargedRequireId( $learn );
											foreach( $require as $row ){
												$name = $this->_subject->getSubjectName($row['subject_id']);
												array_push( $requireArray, 
																	array("require_id"=>$row['id'],"name"=>$name,"memo"=>$row['require']) );
											}
											$this->view->require	= $requireArray;
											
										}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$learn 		= $this->getRequest()->getParam('learn');
						$member		= $this->getRequest()->getParam('member');
						$date 		= $this->getRequest()->getParam('date');
						$hours		= $this->getRequest()->getParam('hours');
						$place		= $this->getRequest()->getParam('place');
						$club1 		= $this->getRequest()->getParam('club1');
						$club2 		= $this->getRequest()->getParam('club2');
						$club3 		= $this->getRequest()->getParam('club3');
						$study		= $this->getRequest()->getParam('study');
						$status		= $this->getRequest()->getParam('status');
						$coach		= $this->getRequest()->getParam('coach');
						$comments	= $this->getRequest()->getParam('comments');
						
						$recom 		= $this->getRequest()->getParam('recom');
						$wish1 		= $this->getRequest()->getParam('wish1');
						$wish2 		= $this->getRequest()->getParam('wish2');
						$wish3 		= $this->getRequest()->getParam('wish3');
						$wish4 		= $this->getRequest()->getParam('wish4');
						
						$user1		= $this->_userspace->userId;
						$user2		= $this->getRequest()->getParam('user2');
						$grade		= $this->getRequest()->getParam('grade');
						$date2		= $this->getRequest()->getParam('date2');
						
						
						$comments	= trim($comments);			//半角スペースのみ
						$date			= trim($date);					//半角スペースのみ
						
						
						
						
/**/
						if (!isset($date) || (trim($date) == '') ){
								array_push($errors, array('面接日時は、設定されていません。') );
						}						
						else if (isset($date) && (trim($date) != '')) {
						  // check the date format
						  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d):(\d\d)$/', $date, $m)) {
									
									$date = $m[1] .'-'. $m[2] .'-'. $m[3] .' '. sprintf("%02d",$m[4]) .':'. $m[5];
						  }

							if (!preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $date, $m)) {
									array_push($errors, array('面接日時は、書式フォーマットが不正です（"yyyy-mm-dd HH:nn"）。') );
						  } else {
						    // make sure the date provided is a validate date
						    if (!mktime($m[4], $m[5], 0, $m[2], $m[3], $m[1])) {
									array_push($errors, array('面接日時は、値が不正です。') );
						    }
						  }
						}

						$msgs = validateSelect( '面接時間', $hours);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '面接場所', $place);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '出席状況について', $status, -1);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '生活指導', $coach, -1);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						if( $grade==1 )
						{
								$msgs = validateSelect( '希望学科＜推薦学科＞', $recom, 0);
								if( count($msgs) != 0 ){
										array_push( $errors,$msgs );
								}
								$bWish = true;
								$value = $wish1 * $wish2 * $wish3 * $wish4 ;
								if( $value != 1 ){
										$msgs = validateSelect( '希望学科＜希望１＞', $wish1, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										$msgs = validateSelect( '希望学科＜希望２＞', $wish2, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										$msgs = validateSelect( '希望学科＜希望３＞', $wish3, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										$msgs = validateSelect( '希望学科＜希望４＞', $wish4, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										if ( $bWish ){
											$value = $wish1 * $wish2 * $wish3 * $wish4 ;
											if( $value != 120 && $value != 1 )
												array_push( $errors, array('希望学科＜希望１〜４＞において、重複選択されています。') );
										}
								}
						}else{
								$recom = $wish1 = $wish2 = $wish3 = $wish4 = 1;
						}
						

						if (count($errors) == 0){
								
								$data = array(
													'learn'				=>	$learn,
													'member'			=>	$member,
													'date'				=>	$date,
													'hours'				=>	$hours,
													'place'				=>	$place,
													'club1'				=>	$club1,
													'club2'				=>	$club2,
													'club3'				=>	$club3,
													'study'				=>	$study,
													'status'			=>	$status,
													'coach'				=>	$coach,
													'comments'		=>	$comments,
													'user1'				=>	$user1,
												//	'user2'				=> 	$user2,
													'delete_flg'	=> '0',

													'recom'				=>	$recom,
													'wish1'				=>	$wish1,
													'wish2'				=>	$wish2,
													'wish3'				=>	$wish3,
													'wish4'				=>	$wish4,

													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $learn != NULL ){
										
			    					$this->_learn->updateLearn( $data, $learn, $deleteType );
										
						        // ビュースクリプトが表示されます
						        $targetUrl = '/learning/item/learn_id/'.$learn. '/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else 
						{
								
						
								$this->view->learn			= $learn;
								$this->view->member			= $member;
								$this->view->date				= $date;
								$this->view->name				= $this->_member->getMemberName($member);
								$this->view->grade			= $grade;	//this->_member->getMemberGrade($member);
								$this->view->date2			= $date2;
								
								$this->view->selPlace		= $place;
								$this->view->selHours		= $hours;
								$this->view->selClub1		= $club1;
								$this->view->selClub2		= $club2;
								$this->view->selClub3		= $club3;
								$this->view->selStudy		= $study;
								$this->view->selStatus	= $status;
								$this->view->selCoach		= $coach;
								$this->view->comments 	= $comments;
								
								$this->view->selRecom		= $recom;
								$this->view->selWish1		= $wish1;
								$this->view->selWish2		= $wish2;
								$this->view->selWish3		= $wish3;
								$this->view->selWish4		= $wish4;
								
								$this->view->user1 			= $user1;
								$this->view->user2		 	= $user2;
								$this->view->grade		 	= $grade;
								$this->view->userName1		= $this->_user->getUserName($user1);
								
									$employArray = array();
								$this->view->employ			= $employArray;
									$supportArray = array();
								$this->view->support		= $supportArray;
									$requireArray = array();
								$this->view->require		= $requireArray;
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$this->view->member.$this->view->sid;
				$learning2item	= $this->view->modulePath.'learning/item/learn_id/'		.$this->view->learn	.$this->view->sid;
				$learning2edit	= $this->view->modulePath.'learning/edit/learn_id/'		.$this->view->learn	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>$this->view->name		,'url'=>$learning2member ),
									array('name'=>$this->view->date2	,'url'=>$learning2item ),
									array('name'=>'編集'		,'url'=>$learning2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$learning2index		= $this->view->modulePath.'learning/index'					.$this->view->sid;
				$learning2item		= $this->view->modulePath.'learning/item/learn_id/'	.$this->view->learn	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$learning2member	,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$learning2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

				
    }





    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->placeArray		= $this->_menu->getPlaceList( '', null );
				$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
				$this->view->studyArray		= $this->_menu->getStudyList( null, null );
				$this->view->statusArray	= $this->_menu->getStatusList( null, null );
				$this->view->coachArray		= $this->_menu->getCoachList( null, null );
										$groupList		= $this->_menu->getGroupList( null, $menu_findArray );
										$groupList[1] = "-";
				$this->view->groupList		= $groupList;
				
					$menu_findArray['s_kind']='1';
				$this->view->club1Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
					$menu_findArray['s_kind']='2';
				$this->view->club2Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
					$menu_findArray['s_kind']='3';
				$this->view->club3Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
				
					$employArray = array();
				$this->view->employ			= $employArray;
					$supportArray = array();
				$this->view->support		= $supportArray;
					$requireArray = array();
				$this->view->require		= $requireArray;
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				$this->view->selStatus	= -1;
				$this->view->selCoach		= -1;
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() ) {
						
						$member 	= $this->getRequest()->getParam('member_id');
						$this->view->member			= $member;
						$this->view->name				= $this->_member->getMemberName($member);
						$grade									= 
						$this->view->grade			= $this->_member->getMemberGrade($member);
						
						$number									= 
						$this->view->number			= $this->_learn->countMemberLearn( $member ) +1;
				}
				else if( $this->getRequest()->isPost() ){
						
						$grade		= $this->getRequest()->getParam('grade');
						$number		= $this->getRequest()->getParam('number');
						$member		= $this->getRequest()->getParam('member_id');
						$date 		= $this->getRequest()->getParam('date');
						$hours		= $this->getRequest()->getParam('hours');
						$place		= $this->getRequest()->getParam('place');
						$club1 		= $this->getRequest()->getParam('club1');
						$club2 		= $this->getRequest()->getParam('club2');
						$club3 		= $this->getRequest()->getParam('club3');
						$study		= $this->getRequest()->getParam('study');
						$status		= $this->getRequest()->getParam('status');
						$coach		= $this->getRequest()->getParam('coach');
						$comments	= $this->getRequest()->getParam('comments');
						
						$recom 		= $this->getRequest()->getParam('recom');
						$wish1 		= $this->getRequest()->getParam('wish1');
						$wish2 		= $this->getRequest()->getParam('wish2');
						$wish3 		= $this->getRequest()->getParam('wish3');
						$wish4 		= $this->getRequest()->getParam('wish4');
						
						$user1		= $this->_userspace->userId;
						
						$this->view->member			= $member;
						$this->view->name				= $this->_member->getMemberName($member);
						$this->view->grade			= $this->_member->getMemberGrade($member);
						
						$this->view->number			= $number;
						
						$comments	= trim($comments);			//半角スペースのみ
						$date			= trim($date);					//半角スペースのみ
						
						
/**/
						if (!isset($date) || (trim($date) == '') ){
								array_push($errors, array('面接日時は、設定されていません。') );
						}						
						else if (isset($date) && (trim($date) != '')) {
						  // check the date format
						  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d):(\d\d)$/', $date, $m)) {
									
									$date = $m[1] .'-'. $m[2] .'-'. $m[3] .' '. sprintf("%02d",$m[4]) .':'. $m[5];
						  }

							if (!preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $date, $m)) {
									array_push($errors, array('面接日時は、書式フォーマットが不正です（"yyyy-mm-dd HH:nn"）。') );
						  } else {
						    // make sure the date provided is a validate date
						    if (!mktime($m[4], $m[5], 0, $m[2], $m[3], $m[1])) {
									array_push($errors, array('面接日時は、値が不正です。') );
						    }
						  }
						}
						

						$msgs = validateSelect( '面接時間', $hours);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '面接場所', $place);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '出席状況について', $status, -1);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '生活指導', $coach, -1);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						if( $grade==1 )
						{
								$msgs = validateSelect( '希望学科＜推薦学科＞', $recom, 0);
								if( count($msgs) != 0 ){
										array_push( $errors,$msgs );
								}
								$bWish = true;
								$value = $wish1 * $wish2 * $wish3 * $wish4 ;
								if( $value != 1 ){
										$msgs = validateSelect( '希望学科＜希望１＞', $wish1, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										$msgs = validateSelect( '希望学科＜希望２＞', $wish2, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										$msgs = validateSelect( '希望学科＜希望３＞', $wish3, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										$msgs = validateSelect( '希望学科＜希望４＞', $wish4, 1);
										if( count($msgs) != 0 ){
												array_push( $errors,$msgs );
												$bWish = false;
										}
										if ( $bWish ){
											$value = $wish1 * $wish2 * $wish3 * $wish4 ;
											if( $value != 120 && $value != 1 )
												array_push( $errors, array('希望学科＜希望１〜４＞において、重複選択されています。') );
										}
								}
						}else{
								$recom = $wish1 = $wish2 = $wish3 = $wish4 = 1;
						}

						if (count($errors) == 0){
								
								$data = array(
													'member'			=>	$member,
													'number'			=>	$number,
													'grade'				=>	$grade,
													'date'				=>	$date,
													'hours'				=>	$hours,
													'place'				=>	$place,
													'club1'				=>	$club1,
													'club2'				=>	$club2,
													'club3'				=>	$club3,
													'study'				=>	$study,
													'status'			=>	$status,
													'coach'				=>	$coach,
													'comments'		=>	$comments,
													'user1'				=>	$user1,
													'user2'				=> '0',
													'delete_flg'	=> '0',

													'recom'				=>	$recom,
													'wish1'				=>	$wish1,
													'wish2'				=>	$wish2,
													'wish3'				=>	$wish3,
													'wish4'				=>	$wish4,

													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $member != NULL ){
										
			    					$learn = $this->_learn->registLearn( $data, $member, $deleteType );
										
										if( $learn != 0 ){
							        // ビュースクリプトが表示されます
							        $targetUrl = '/learning/user/member_id/' . $member. '/sid/'.$this->_sid;
							        $targetUrl = '/learning/edit/learn_id/' . $learn . '/member_id/'. $member .'/sid/'.$this->_sid;
							        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}else if ( $learn == 0 ){
							        // 登録失敗
							        $targetUrl = '/learning/user/member_id/' . $member. '/sid/'.$this->_sid;
							        $targetUrl = '/learning/new/member_id/' . $member. '/sid/'.$this->_sid;
							        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}
								}
						} 
						else 
						{
								
								$this->view->member			= $member;
								$this->view->grade			= $grade;
								$this->view->date				= $date;
								
								$this->view->selPlace		= $place;
								$this->view->selHours		= $hours;
								$this->view->selClub1		= $club1;
								$this->view->selClub2		= $club2;
								$this->view->selClub3		= $club3;
								$this->view->selStudy		= $study;
								$this->view->selStatus	= $status;
								$this->view->selCoach		= $coach;
								$this->view->comments 	= $comments;
								
								$this->view->selRecom		= $recom;
								$this->view->selWish1		= $wish1;
								$this->view->selWish2		= $wish2;
								$this->view->selWish3		= $wish3;
								$this->view->selWish4		= $wish4;
								
									$employArray = array();
								$this->view->employ			= $employArray;
									$supportArray = array();
								$this->view->support		= $supportArray;
									$requireArray = array();
								$this->view->require		= $requireArray;
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
								$this->view->learn			= '';
								$this->view->member			= '';
								$this->view->grade			= '';
								$this->view->date				= '';
								
								$this->view->selPlace		= 0;
								$this->view->selHours		= 0;
								$this->view->selClub1		= 0;
								$this->view->selClub2		= 0;
								$this->view->selClub3		= 0;
								$this->view->selStudy		= 0;
								$this->view->selStatus	= 0;
								$this->view->selCoach		= 0;
								$this->view->comments 	= 0;
								
								$this->view->selRecom		= 0;
								$this->view->selWish1		= 0;
								$this->view->selWish2		= 0;
								$this->view->selWish3		= 0;
								$this->view->selWish4		= 0;
								
									$employArray = array();
								$this->view->employ			= $employArray;
									$supportArray = array();
								$this->view->support		= $supportArray;
									$requireArray = array();
								$this->view->require		= $requireArray;
				}
				
				
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
				$learning2new		= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>$this->view->name		,'url'=>$learning2member ),
									array('name'=>'新規作成'					,'url'=>$learning2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
				$learning2member	= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  		,'url'=>$learning2member		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						if( $learn != null ){
								$info 	= array();
								$styear = '2009-04-01';
								$deleteType = '1';
								
								$userId	= $this->_userspace->userId;
		   					$ret = $this->_learn->deleteLearn( $learn, $userId );
								if( $ret < 0 ){
										
										if( $ret == -2 ){
											$targetUrl = '/learning/item'. $this->view->sid .'/learn_id/'.$learn .'/'.DISP_MESSAGE.'/'.ERR_DELETE_LEARN;	//最新の面接記録でないので削除はできません。
											return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}else{
											$targetUrl = '/learning/item'. $this->view->sid .'/learn_id/'.$learn .'/'.DISP_MESSAGE.'/'.ERR_DELETE_NORIGHT;	//'削除権がありません。
											return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}
								}
						}
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/member/member_id/'. $member. '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }



    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function jobAction()
    {
				$learn		= $this->getRequest()->getParam('learn');
				$member		= $this->getRequest()->getParam('member');
				$name			= $this->_member->getMemberName($member);
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}
				
				if( $this->getRequest()->isGet() )
						{
						
						$employ = $this->getRequest()->getParam('employ');
						if( $employ != NULL ){
									
									// 1レコードの取得
									$result = $this->_employ->getEmployId( $employ );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['employ'] != 0 ){
											
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
											$menu_mode ='';					//select
											$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
											
											$this->view->comments		= $result['comments'];
											
											// 1レコードの取得
											$group = $this->_employ->chargedGroupId( $employ );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );
											}
											$this->view->selGroup		= $groupArray;
											
											
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
											
											$this->view->learn				= $learn;
											$this->view->member				= $member;
											$this->view->name					= $name;
										}
						}
				}
				else{
				}
				
				
				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
				$learning2item	= $this->view->modulePath.'learning/item/learn_id/'		.$learn.$this->view->sid;
				$learning2edit	= $this->view->modulePath.'learning/edit/learn_id/'		.$learn.$this->view->sid;
				$learning2employ= $this->view->modulePath.'learning/employ/learn_id/'	.$learn.$this->view->sid;
				$learning2job		= $this->view->modulePath.'learning/job/employ/'.$employ.'/learn/'.$learn.'/member/'.$member.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'							,'url'=>$top2index ),
									array('name'=>'学習支援'				,'url'=>$learning2index ),
									array('name'=>$name							,'url'=>$learning2member ),
									array('name'=>$date							,'url'=>$learning2item ),
									array('name'=>'編集'						,'url'=>$learning2edit ),
									array('name'=>'進路希望追加'		,'url'=>$learning2employ ),
									array('name'=>'詳細'						,'url'=>$learning2job )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }







    /**-------------------------------------------------------------------------------------------
     * employアクション
     */
    public function employAction()
    {
				
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['job']['sGroup']	= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['job']['sArea']		= $this->getRequest()->getParam('s_area');
						$this->_userspace->search['job']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['job']['sKeyword']= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['job']['sField']	= $this->getRequest()->getParam('s_field');
						
						$learn		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$name			= $this->_member->getMemberName($member);
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['job']['sGroup']) )
							$this->_userspace->search['job']['sGroup']		= '0';
						if( !isset($this->_userspace->search['job']['sArea']) )
							$this->_userspace->search['job']['sArea']			= '0';
						if( !isset($this->_userspace->search['job2']['sKana']) )
							$this->_userspace->search['job']['sKana']			= '0';
						if( !isset($this->_userspace->search['job']['sKeyword']) )
							$this->_userspace->search['job']['sKeyword']	= '';
						if( !isset($this->_userspace->search['job']['sField']) )
							$this->_userspace->search['job']['sField']		= '0';
						
						$learn		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$name			= $this->_member->getMemberName($member);
						
				}
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}


				$bFind = true;	


				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['job']['sGroup'];		
				$sArea		= $this->_userspace->search['job']['sArea'];		
				$sKana		= $this->_userspace->search['job']['sKana'];		
				$sKeyword	= $this->_userspace->search['job']['sKeyword'];	
				$sField		= $this->_userspace->search['job']['sField'];		
				if( $sGroup 	=== null 
					||	$sArea	=== null 
					|| 	$sKana	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sArea   == "0" 
					&& $sKana   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_area'		=>  $sArea,	
																	's_kana'	  =>  $sKana,	
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_employ->getEmployPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_employ->getEmployPage( null );
						
				}
				
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );
				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getFieldList( null, null );
				$menu_mode ='-';
				$this->view->headArray		= $this->_menu->getAreaList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selArea		= $sArea;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
				$this->view->learn				= $learn;
				$this->view->member				= $member;
				$this->view->name					= $name;
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
				
				
				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
				$learning2item	= $this->view->modulePath.'learning/item/learn_id/'		.$learn.$this->view->sid;
				$learning2edit	= $this->view->modulePath.'learning/edit/learn_id/'		.$learn.$this->view->sid;
				$learning2employ= $this->view->modulePath.'learning/employ/learn_id/'	.$learn.'/member_id/'.$member.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'							,'url'=>$top2index ),
									array('name'=>'学習支援'				,'url'=>$learning2index ),
									array('name'=>$name							,'url'=>$learning2member ),
									array('name'=>$date							,'url'=>$learning2item ),
									array('name'=>'編集'						,'url'=>$learning2edit ),
									array('name'=>'進路希望追加'		,'url'=>$learning2employ )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }


    /**-------------------------------------------------------------------------------------------
     * addemployアクション
     */
    public function addemployAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$employArray	= $this->getRequest()->getParam('employ_id');
				}
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
						$data = array(
											'learn'				=>	$learn,
											'member'			=>	$member,
											'date'				=>	$date,
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);
						$deleteType = '0';
						
		    		$this->_learn->updateLearnAddemploy( $data, $employArray, $deleteType);
				}
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/edit/learn_id/'. $learn .'/member_id/'. $member . '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * delemployアクション
     */
    public function delemployAction()
    {
				if( $this->getRequest()->isGet() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$employ		= $this->getRequest()->getParam('employ_id');
				}
				
				if( $employ != null ){
						$deleteType = '1';
						
   					$this->_learn->updateLearnDelemploy( $learn, $employ, $deleteType);
				}
				
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/edit/learn_id/'. $learn .'/member_id/'. $member . '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }





    /**-------------------------------------------------------------------------------------------
     * supportアクション
     */
    public function supportAction()
    {
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['learning3']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['learning3']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['learning3']['sStyear']		= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['learning3']['sReq']			= $this->getRequest()->getParam('s_req');
						$this->_userspace->search['learning3']['sTerm']			= $this->getRequest()->getParam('s_term');
						$this->_userspace->search['learning3']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['learning3']['sField']		= $this->getRequest()->getParam('s_field');
						
						$learn		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						//$name			= $this->getRequest()->getParam('name');
						$name			= $this->_member->getMemberName($member);
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['learning3']['sGroup']) )
							$this->_userspace->search['learning3']['sGroup']		= '0';
						if( !isset($this->_userspace->search['learning3']['sGrade']) )
							$this->_userspace->search['learning3']['sGrade']		= '0';
						if( !isset($this->_userspace->search['learning3']['sStyear']) )
							$this->_userspace->search['learning3']['sStyear']		= '0';
						if( !isset($this->_userspace->search['learning3']['sReq']) )
							$this->_userspace->search['learning3']['sReq']			= '0';
						if( !isset($this->_userspace->search['learning3']['sTerm']) )
							$this->_userspace->search['learning3']['sTerm']			= '0';
						if( !isset($this->_userspace->search['learning3']['sKeyword']) )
							$this->_userspace->search['learning3']['sKeyword']	= '';
						if( !isset($this->_userspace->search['learning3']['sField']) )
							$this->_userspace->search['learning3']['sField']		= '0';
						
						$learn		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$name			= $this->_member->getMemberName($member);
				}




/**	fixedSearch	(supportAction)	**/
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupList		= 
				$this->view->groupSelect	= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeList		= 
				$this->view->gradeSelect	= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearList		= 
				$this->view->styearSelect	= $this->_menu->getYearList( $menu_mode, null );
				
				$this->view->reqList			= 
				$this->view->reqSelect		= $this->_menu->getReqList( $menu_mode, null );
				$this->view->termList			= 
				$this->view->termSelect		= $this->_menu->getTermList( $menu_mode, null );
				$this->view->fieldSelect	= $this->_menu->getField2List( null, null );
				
				if( $member != 0 )	{
					
					$result = $this->_member->getMemberId( $member );
					if( $result['member_id'] != 0 ){
						
						$m_group = $result['group_id'];
						if( $learn != null ){
							$m_grade = $this->_learn->getLearnGrade($learn);
							if( $m_grade == 0 )
								$m_grade = $result['grade'];
						}
						else
							$m_grade = $result['grade'];
						
						$m_year = '-1';								// 授業科目適応入学年度　未完
						
							$menu_findArray['s_group']= $m_group;	//'2';
						$this->view->groupSelect	= $this->_menu->getGroupList( null, $menu_findArray );
							$menu_findArray['s_grade']= $m_grade;	//'2';
						$this->view->gradeSelect	= $this->_menu->getGradeList( null, $menu_findArray );
							$menu_findArray['s_year']	= $m_year;	//'-1';	//'2010';
						$this->view->styearSelect	= $this->_menu->getYearList( null, $menu_findArray );
						
						$this->_userspace->search['learning3']['sGroup']	= $m_group;
						$this->_userspace->search['learning3']['sGrade']	= $m_grade;
					}
				}
/****/



				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['learning3']['sGroup'];		
				$sGrade		= $this->_userspace->search['learning3']['sGrade'];		
				$sStyear	= $this->_userspace->search['learning3']['sStyear'];	
				$sReq			= $this->_userspace->search['learning3']['sReq'];			
				$sTerm		= $this->_userspace->search['learning3']['sTerm'];		
				$sKeyword	= $this->_userspace->search['learning3']['sKeyword'];	
				$sField		= $this->_userspace->search['learning3']['sField'];		
				if( $sGroup 	=== null 
					||	$sGrade	=== null 
					|| 	$sStyear=== null 
					||	$sReq		=== null 
					||	$sTerm	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sReq		== "0"  
					&& $sTerm		== "0"  
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_req'			=>  $sReq,
																	's_term'		=>  $sTerm,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
					
						
						$select = $this->_subject->getSubjectPage( $findArray );
						
				} else 
				{
						
						$select = $this->_subject->getSubjectPage( null );
						
				}
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );
				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selReq			= $sReq;
				$this->view->selTerm		= $sTerm;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
				$this->view->learn			= $learn;
				$this->view->member			= $member;
				$this->view->name				= $name;
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}
				
				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index		= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member	= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
				$learning2item		= $this->view->modulePath.'learning/item/learn_id/'		.$learn.$this->view->sid;
				$learning2edit		= $this->view->modulePath.'learning/edit/learn_id/'		.$learn.$this->view->sid;
				 $learning2support	= $this->view->modulePath.'learning/support/learn_id/'.$learn.'/member_id/'.$member.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'							,'url'=>$top2index ),
									array('name'=>'学習支援'				,'url'=>$learning2index ),
									array('name'=>$name							,'url'=>$learning2member ),
									array('name'=>$date							,'url'=>$learning2item ),
									array('name'=>'編集'						,'url'=>$learning2edit ),
									array('name'=>'学習支援追加'		,'url'=>$learning2support )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * addsupportアクション
     */
    public function addsupportAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$subjectArray	= $this->getRequest()->getParam('subject_id');
				}
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
						$data = array(
											'learn'				=>	$learn,
											'member'			=>	$member,
											'date'				=>	$date,
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);
						$deleteType = '0';
						
		    		$this->_learn->updateLearnAddsupport( $data, $subjectArray, $deleteType);
				}
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/edit/learn_id/'. $learn .'/member_id/'. $member . '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * delsupportアクション
     */
    public function delsupportAction()
    {
				if( $this->getRequest()->isGet() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$supportId		= $this->getRequest()->getParam('support_id');
				}
				
				if( $learn != null ){
						$deleteType = '1';
						
   					$this->_learn->updateLearnDelsupport( $learn, $supportId, $deleteType);
				}
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/edit/learn_id/'. $learn .'/member_id/'. $member . '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }







    /**-------------------------------------------------------------------------------------------
     * requireアクション
     */
    public function requireAction()
    {
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['learning4']['sGroup']	= $this->getRequest()->getParam('s_group'	,'0');
						$this->_userspace->search['learning4']['sGrade']	= $this->getRequest()->getParam('s_grade'	,'0');
						$this->_userspace->search['learning4']['sStyear']	= $this->getRequest()->getParam('s_styear','0');
						$this->_userspace->search['learning4']['sReq']		= $this->getRequest()->getParam('s_req'		,'0');
						$this->_userspace->search['learning4']['sTerm']		= $this->getRequest()->getParam('s_term'	,'0');
						$this->_userspace->search['learning4']['sKeyword']= $this->getRequest()->getParam('s_keyword','');
						$this->_userspace->search['learning4']['sField']	= $this->getRequest()->getParam('s_field'	,'0');
						
						$learn		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$name			= $this->_member->getMemberName($member);
				}
				else if( $this->getRequest()->isGet() ){
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						
						if( !isset($this->_userspace->search['learning4']['sGroup']) )
							$this->_userspace->search['learning4']['sGroup']	= '0';
						if( !isset($this->_userspace->search['learning4']['sGrade']) )
							$this->_userspace->search['learning4']['sGrade']	= '0';
						if( !isset($this->_userspace->search['learning4']['sStyear']) )
							$this->_userspace->search['learning4']['sStyear']	= '0';
						if( !isset($this->_userspace->search['learning4']['sReq']) )
							$this->_userspace->search['learning4']['sReq']		= '0';
						if( !isset($this->_userspace->search['learning4']['sTerm']) )
							$this->_userspace->search['learning4']['sTerm']		= '0';
						if( !isset($this->_userspace->search['learning4']['sKeyword']) )
							$this->_userspace->search['learning4']['sKeyword']= '';
						if( !isset($this->_userspace->search['learning4']['sField']) )
							$this->_userspace->search['learning4']['sField']	= '0';
						
						$learn		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$name			= $this->_member->getMemberName($member);
						
				}
				


/**	fixedSearch	(requireAction)	**/
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupList		= 
				$this->view->groupSelect	= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeList		= 
				$this->view->gradeSelect	= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearList		= 
				$this->view->styearSelect	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->reqList			= 
				$this->view->reqSelect		= $this->_menu->getReqList( $menu_mode, null );
				$this->view->termList			= 
				$this->view->termSelect		= $this->_menu->getTermList( $menu_mode, null );
				$this->view->fieldSelect	= $this->_menu->getField2List( null, null );
				
				if( $member != 0 )	{
					
					$result = $this->_member->getMemberId( $member );
					if( $result['member_id'] != 0 ){
						
						$m_group = $result['group_id'];
						if( $learn != null ){
							$m_grade = $this->_learn->getLearnGrade($learn);
							if( $m_grade == 0 )
								$m_grade = $result['grade'];
						}
						else
							$m_grade = $result['grade'];
						
						$m_year = '-1';								// 授業科目適応入学年度　未完
						
						$menu_findArray['s_group']= $m_group;	//'2';
						$this->view->groupSelect	= $this->_menu->getGroupList( null, $menu_findArray );
						$menu_findArray['s_grade']= $m_grade;	//'2';
						$this->view->gradeSelect	= $this->_menu->getGradeList( null, $menu_findArray );
						$menu_findArray['s_year']	= $m_year;	//'-1';	//'2010';
						$this->view->styearSelect	= $this->_menu->getYearList( null, $menu_findArray );
						
						
						$sGroup		= $this->_userspace->search['learning4']['sGroup']		= $m_group;
						$sGrade		= $this->_userspace->search['learning4']['sGrade']		= $m_grade;
					}
				}
/***/

				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['learning4']['sGroup'];		
				$sGrade		= $this->_userspace->search['learning4']['sGrade'];		
				$sStyear	= $this->_userspace->search['learning4']['sStyear'];	
				$sReq			= $this->_userspace->search['learning4']['sReq'];			
				$sTerm		= $this->_userspace->search['learning4']['sTerm'];		
				$sKeyword	= $this->_userspace->search['learning4']['sKeyword'];	
				$sField		= $this->_userspace->search['learning4']['sField'];		
				if( $sGroup 	=== null 
					||	$sGrade	=== null 
					|| 	$sStyear=== null 
					||	$sReq		=== null 
					||	$sTerm	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sReq		== "0"  
					&& $sTerm		== "0"  
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_req'			=>  $sReq,
																	's_term'		=>  $sTerm,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
					
						
						$select = $this->_subject->getSubjectPage( $findArray );
						
				} else 
				{
						
						$select = $this->_subject->getSubjectPage( null );
						
				}
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );
				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				

				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selReq			= $sReq;
				$this->view->selTerm		= $sTerm;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
				$this->view->learn			= $learn;
				$this->view->member			= $member;
				$this->view->name				= $name;
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
						//$date		= '2011-04-01 16:34:00';
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}
				
				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index		= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member	= $this->view->modulePath.'learning/member/member_id/'.$member.$this->view->sid;
				$learning2item		= $this->view->modulePath.'learning/item/learn_id/'		.$learn.$this->view->sid;
				$learning2edit		= $this->view->modulePath.'learning/edit/learn_id/'		.$learn.$this->view->sid;
				$learning2require	= $this->view->modulePath.'learning/require/learn_id/'.$learn.'/member_id/'.$member.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'							,'url'=>$top2index ),
									array('name'=>'学習支援'				,'url'=>$learning2index ),
									array('name'=>$name							,'url'=>$learning2member ),
									array('name'=>$date							,'url'=>$learning2item ),
									array('name'=>'編集'						,'url'=>$learning2edit ),
									array('name'=>'要望追加'				,'url'=>$learning2require )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }




    /**-------------------------------------------------------------------------------------------
     * addrequireアクション
     */
    public function addrequireAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$subjectArray	= $this->getRequest()->getParam('subject_id');
						$comments		= $this->getRequest()->getParam('comments');
				}
				
				if( $learn != null ){
						$date = $this->_learn->getLearnDate($learn);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
						$data = array(
											'learn'				=>	$learn,
											'member'			=>	$member,
											'date'				=>	$date,
											'comments'		=>	$comments,
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);
						$deleteType = '0';
						
		    		$this->_learn->updateLearnAddrequire( $data, $subjectArray, $deleteType );
				}
				
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/edit/learn_id/'. $learn .'/member_id/'. $member . '/sid/'.$this->_sid ;
	      return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * delrequireアクション
     */
    public function delrequireAction()
    {
				if( $this->getRequest()->isGet() ) {
						
						$learn 		= $this->getRequest()->getParam('learn_id');
						$member		= $this->getRequest()->getParam('member_id');
						$requireId	= $this->getRequest()->getParam('require_id');
				}
				
				if( $learn != null ){
						$deleteType = '1';
						
   					$this->_learn->updateLearnDelrequire( $learn, $requireId, $deleteType);
				}
				
        // ビュースクリプトが表示されます
        $targetUrl = '/learning/edit/learn_id/'. $learn .'/member_id/'. $member . '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }












    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }




    /**-------------------------------------------------------------------------------------------
     * enrollpageアクション（表pdf作成）２・３年生
     *--------------------------------------------------------------------------------------------
     */
    public function enrollpageAction( )
    {
				
				$memberId 	= $this->getRequest()->getParam('member_id');
				
				$select = $this->_learn->getLearnPage( $memberId, null );
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( 1 );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( 10 );							// 表示するページネーション範囲（default:10）
				$this->view->assign( 'paginator', $paginator );
				
				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->placeArray		= $this->_menu->getPlaceList( '', null );
				$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
				$this->view->studyArray		= $this->_menu->getStudyList( null, null );
				$this->view->statusArray	= $this->_menu->getStatusList( null, null );
				$this->view->coachArray		= $this->_menu->getCoachList( null, null );
				
					$menu_find['s_kind']='1';
				$this->view->club1Array		= $this->_menu->getClubList( $menu_mode, $menu_find );
					$menu_find['s_kind']='2';
				$this->view->club2Array		= $this->_menu->getClubList( $menu_mode, $menu_find );
					$menu_find['s_kind']='3';
				$this->view->club3Array		= $this->_menu->getClubList( $menu_mode, $menu_find );
				
				$this->view->member				= $memberId;
				$this->view->name					= $this->_member->getMemberName($memberId);
				
				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$learning2member= $this->view->modulePath.'learning/member/member_id/'.$memberId.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>$this->view->name		,'url'=>$learning2member )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
				$learning2new	= $this->view->modulePath.'learning/new/member_id/'		.$memberId	.$this->view->sid;
				$pdf2index		= $this->view->modulePath.'pdf/enrollpage/member_id/'	.$memberId	.$this->view->sid;
				$learning2pdf	= $this->view->modulePath.'learning/enrollpage/member_id/'		.$memberId	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'新規作成'  		,'url'=>$learning2new		,'onclick'=>'' ),
									array('name'=>'separator' 		,'url'=>$urlNon    			,'onclick'=>'' ),
									array('name'=>'ＰＤＦ作成'  	,'url'=>$pdf2index			,'onclick'=>'' )									);
					break;
				case 'admin':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array();
					break;
				}
    setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);







if( true ){
				
    if( $this->getRequest()->isGet() ){
					
	$memberId = $this->getRequest()->getParam('member_id','0');
					
	$maxNumber = $this->_learn->countMemberLearn( $memberId );
					
    }
    $fileName = $memberId .'.pdf';
    $fileName = 'ananfd_'. $memberId .'.pdf';
				
    // 文字コードをUTF-8に設定する
    iconv_set_encoding('internal_encoding', 'UTF-8');				
    // インスタンスを生成する
    $pdf = new Zend_Pdf();
		
    $maxBrock	= $this->_member->getMemberGrade($memberId);
    //$maxBrock = 3;
    for( $brock = 1; $brock <= $maxBrock; $brock++ ){
	if( $brock == 1 ){
								 	     /** １ブロック（ 1〜 4回目) */
									    $brock 	= 1;
									    $gradeArray = array();
									    $number = 1;
									    $max = $this->_learn->countMemberLearnGrade( $memberId, array( $brock ) );
									    if( $max > 4 )	$max = 4;

	    $this->enrollframeAction( $pdf, $brock, true );
									} else {
									    /** ２ブロック（ 5〜 8回目) */
									    /** ３ブロック（ 9〜12回目) */
								  	    /** ４ブロック（13〜16回目) */
									    /** ５ブロック（17〜20回目) */
									    array_push( $gradeArray, ($brock-1) );
									    $number = $this->_learn->countMemberLearnGrade( $memberId, $gradeArray ) +1;
									    $max  = $this->_learn->countMemberLearnGrade( $memberId, array( $brock ) );
									    if( $max > 4 )	$max = 4;

	    //$this->enrollframeAction( $pdf, $brock );
									}
    
    }  // for_brock
					
  }  // if_false

}





    /**-------------------------------------------------------------------------------------------
     * enrollframeアクション（フレーム作成）
     *--------------------------------------------------------------------------------------------
     */
    public function enrollframeAction( $pdf, $brock, $bFresh =false )
    {

				$page		= ($brock -1) * 2 ;
				$number	= ($brock -1) * 4 + 1;
				
					// メタデータ 
					$pdf->properties['Title'] 	= 'タイトル'; 
					$pdf->properties['Subject'] = 'サブジェクト';
					$pdf->properties['Keywords'] = 'キーワード';
					$pdf->properties['Author']	= 'gotodak'; 
					$pdf->properties['CreationDate'] = "D:200903101345+09'00'";

			/** 1ページ目 */
			// 1ページを作成
					// ページを新規作成する
					$pdf->pages[] = $pdf->newPage(Zend_Pdf_Page::SIZE_A4);
					
					$font = Zend_Pdf_Font::fontWithPath('../application/lib/IPAfont00203/ipamp.ttf');			// 明朝体p
					
					// フォントを適用する
					// フォントサイズ
					$fontSize = 11;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
					// ページのサイズを取得する
					$pageHeight = $pdf->pages[$page]->getHeight();
					$pageWidth  = $pdf->pages[$page]->getWidth();
					
					// 矩形を描画する
					$color1 = new Zend_Pdf_Color_Html('black');
					$color2 = new Zend_Pdf_Color_Html('darkseagreen');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color3);
					$pdf->pages[$page]->setFillColor($color3);
					
					
					// 描画矩形の座標
					$wakuArea = array('start' => array(80,  10),
					                  'end'   => array(585, 832)
											);
					$pdf->pages[$page]->drawRectangle($wakuArea['start'][0], $wakuArea['start'][1],
					                           			   $wakuArea['end'][0], 	 $wakuArea['end'][1]
																						);
					
					$pdf->pages[$page]->setLineColor($color1);
					$pdf->pages[$page]->setFillColor($color3);
					$textColor = new Zend_Pdf_Color_Html('black');
					
					// フォントサイズ
					$fontSize = 16;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
//$text = '学習支援ミーティング記録簿 （'	.$brock. '年）';
//$textArea = array('start' => array(0, 0),	'end'   => array(2,147)  );

$fontSize = 11;	//max:15
$text = '回';
$textArea = array('start' => array(5, 0),	'end'   => array(6, 10)  );
$text = '実施日';
$textArea = array('start' => array(5, 10),	'end'   => array(6, 35)  );
$text = '実施時間';
$textArea = array('start' => array(5, 35),	'end'   => array(6, 75)  );
$text = ' 模擬結果';
$textArea = array('start' => array(49,152),	'end'   => array(50,170)	);
$text	= ' 2012/01/01';
$textArea = array('start' => array(49, 10),	'end'   => array(50, 35)  );


$this->drawTextAreaPdfX( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 2 );

					
				
				return $pdf;
				
			}



    /**-------------------------------------------------------------------------------------------
		 * drawTextAreaPdfX
		 * ：文字列を矩形内に描画する
		 *
		 * @param  object $page     ページオブジェクト
		 * @param  array  $position 描画矩形の座標
		 * @param  string $text     文字列
		 * @param  int    $size     フォントサイズ
		 * @param  object $font     フォントオブジェクト
		 * @param  object $color    色オブジェクト
		 * @param  bool   $drawRect 枠描画の有無
		 * @return void
		 */
		function drawTextAreaPdfX( $page, $pdf, $position, $text, $size, $font, $color, $maxColumn = 4, $divNum = 0  ) 
		{
			
			$HEIGHT		= 822 ;
			$WIDTH  	= 505 ;
			$MAXHEIGHT= 832 ;
			$MINWIDTH =  80 ;		//80+505+10
			$MAXLINE 	=  54 ;
			$drawRect = false;
			if( ($page % 2 ) == 1 )		$MINWIDTH =  10 ;
			
		  // 描画矩形の情報を整理する
			$startPosX = $MINWIDTH  + $WIDTH * $position['start'][1] / $maxColumn	;		//array(4, 0)
			$startPosY = $MAXHEIGHT - $HEIGHT* $position['start'][0] / $MAXLINE		;   //array(5, 4)
			$endPosX	 = $MINWIDTH  + $WIDTH * $position['end'][1]   / $maxColumn	;
			$endPosY	 = $MAXHEIGHT - $HEIGHT* $position['end'][0]   / $MAXLINE		;
			
		    $text = str_replace("\r\n", "\n", $text);
				
				// 矩形を描画する
				if( $drawRect )
				{
					$color1 = new Zend_Pdf_Color_Html('black');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color1);
					$pdf->pages[$page]->drawRectangle(	$position['start'][0],$position['start'][1],
						             							      	$position['end'][0],	$position['end'][1]
						             							   		);
				}
				
		    // 幅と高さを算出する
		    $areaWidth  = abs($endPosX - $startPosX) ;
		    $areaHeight = abs($endPosY - $startPosY) ;
		    $tmpWidth = 0;
				
		    $i = 0;
		    $textCnt = mb_strlen($text, "utf-8");
		    $lines   = array();

if( !$this->_config->global->debugOn ){
	var_dump($textCnt);
	var_dump($text);
	var_dump($areaHeight);
	var_dump($areaWidth);
	var_dump($size);
}

//$textCnt =0;
				
		    $tmpHeight = 0;
		    // 1文字ずつ処理していく
		    while ($i < $textCnt) {
						
		        $tmpWidth = 0;
		        $lineText = '';
						
		        $tmpHeight += $size;
			      // 矩形の幅を超えていれば次の行へ
			      if ($tmpHeight > $areaHeight) {

if( !$this->_config->global->debugOn ){
	var_dump('overHeight');

}
			          break;
			      }
						
			      // 1行分の文字列を算出する
			      while ($tmpWidth < $areaWidth) {
								
			          // 1文字取り出す
			          $tmpChar = mb_substr($text, $i, 1, "utf-8");
								
			          // 改行コードの場合は次の行へ
			          if ($tmpChar == "\n") {
			              $i++;
			              break;
			          }
								
			          // 文字のグリフ番号を取得する
			          //$glyph = intval(bin2hex(mb_convert_encoding($tmpChar, 'UTF-16', 'UTF-8')), 16);
								
			          // 文字の幅を取得する
			          //$charWidth = $font->widthForGlyph($glyph) / $font->getUnitsPerEm() * $size;
			          //$tmpWidth += (float)$charWidth;

						    // テキストの幅の計算には元のフォントを使用します
        	      $glyph = $font->glyphNumberForCharacter($tmpChar);
                $glyph = 0x0020;
			          $glyph = intval(bin2hex(mb_convert_encoding($tmpChar, 'UTF-16', 'UTF-8')), 16);
        	      $glyph2 =$font->glyphNumberForCharacter($glyph);
						    $width = $font->widthForGlyph(
        	           //$font->glyphNumberForCharacter($tmpChar)
                     $glyph2
									   );
						    $charWidth = $width / $font->getUnitsPerEm() * $size;
			          $tmpWidth += (float)$charWidth;

								
if( !$this->_config->global->debugOn ){
	var_dump($tmpChar);
	var_dump($glyph);
	var_dump($glyph2);
	var_dump($charWidth);

}

			          // 矩形の幅を超えていれば次の行へ
			          if ($tmpWidth > $areaWidth) {
			              break;
			          }
			          $lineText .= $tmpChar;
			          $i++;
				if( $textCnt <= $i){
				     break;
				}

			      }
						
		        $lines[] = $lineText;
		    }
				if( count($lines) == 1 )
				{
if( !$this->_config->global->debugOn ){

	var_dump($areaWidth);
	var_dump($tmpWidth);

}
						
						if( $divNum != 0 ){
		    			//$startPosX = $startPosX + ( $areaWidth / 2 ) - ( $tmpWidth / $divNum ) ;
		    			$startPosX = $startPosX + ( ( $areaWidth - $tmpWidth  ) / $divNum )  ;
						}
						else
			    		$startPosX = $startPosX ;		//+ ( $areaWidth / 2 );
						
				}
				
		    // 色設定を適用する
		    $pdf->pages[$page]->setFillColor($color);
				
		    $posY = $startPosY;
				
		    // 1行ずつ描画する
		    foreach ($lines as $line) {
						
		        // 文字列を描画する
		        $pdf->pages[$page]->drawText($line, $startPosX, $posY - $size, 'UTF-8');
		        $posY -= $size;
		    }
			
			return $i;
			
		}









}
