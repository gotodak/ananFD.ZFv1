<?php
/**
 * Clubコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Paginator'); 							// 追加する


// モデルをロードする
require_once '../application/vers/default/models/clubModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';



class ClubController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_club;						// クラブモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // クラブモデルのインスタンスを生成する
        $this->_club	= new clubModel('../application/lib/user.db');
        $this->_menu 	= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
				$this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['club']['sKind']		= $this->getRequest()->getParam('s_kind');		
						$this->_userspace->search['club']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
				}else{
						
						if( !isset($this->_userspace->search['club']['sKind']) )
							$this->_userspace->search['club']['sKind']		= '0';
						if( !isset($this->_userspace->search['club']['sKeyword']) )
							$this->_userspace->search['club']['sKeyword']	= '';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sKind		= $this->_userspace->search['club']['sKind'];		
				$sKeyword	= $this->_userspace->search['club']['sKeyword'];
				if( $sKind 	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				if( $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_kind'	  =>  $sKind,	
																	's_keyword'	=>  $sKeyword
																);
						
						$select = $this->_club->getClubPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_club->getClubPage( null );
						
				}
				
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );
				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='すべて';					//select
				$this->view->kindArray	= $this->_menu->getClubKindList( $menu_mode, null );

				
				$this->view->selKind		= $sKind;
				$this->view->selKeyword	= $sKeyword;
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);




				$top2index				= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'	.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$club2import			= $this->view->modulePath.'club/index'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生情報'		,'url'=>$information2index ),
									array('name'=>'クラブ管理'	,'url'=>$club2import )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon			= '#';
				$club2new		= $this->view->modulePath.'club/new'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成','url'=>$club2new 		,'onclick'=>'' )
									);
							break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='';					//select
				$this->view->kindArray	= $this->_menu->getClubKindList( $menu_mode, null );
				
				
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				
				
				if ($this->getRequest()->isPost()){
						
						$name 		= $this->getRequest()->getParam('name');
						$kana			= $this->getRequest()->getParam('kana','');
						$adviser	= $this->getRequest()->getParam('adviser');
						$kind 		= $this->getRequest()->getParam('kind');
						
						$name 	= trim($name);								//半角スペースのみ
						$kana 	= trim($kana);								//半角スペースのみ
						
						
						
						$msgs = validateStringFull( 3, 30, 'クラブ名称', $name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複チェック
			  		else if ( $this->_club->isRegisteredClub($name) == true )	{
								array_push($errors, array('このクラブ名称は、既に登録されています。') );
			      }
						
						
						
						$msgs = validateSelect( '分類', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
					
					
					if (count($errors) == 0){
							$data = array(
												'name'				=>	$name,
												'kana'				=>	$kana,
												'adviser'			=>	$adviser,
												'kind'				=>	$kind,
												'delete_flg'	=> '0',
												'create_date'	=> NULL
											);
							
							
							// グループＩＤを取得する
							$deleteType = '0';
							$term = 1;
							$user = 1;
							
	    				if( $this->_club->registClub( $data, $group, $user, $term, $deleteType ) == 0 ){
								echo '中止 ';
							}
					  $targetUrl = '/club/index'. '/sid/'.$this->_sid;
					  return $this->_redirect($targetUrl);		//DebugMessage 表示不可
					}
					else{
						
						$this->view->name				= $name;
						$this->view->kana				= $kana;
						$this->view->adviser		= $adviser;
						$this->view->selKind	 	= $kind;
						
						}
				}
				else{
						
						$this->view->name			= ''; 		
						$this->view->kana			= ''; 		
						$this->view->adviser	= 0; 		
						
						$this->view->selKind 	= 0;
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要


				$top2index				= $this->view->modulePath.'top/index'					.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'			.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$club2index				= $this->view->modulePath.'club/index'				.$this->view->sid;
				$club2new					= $this->view->modulePath.'club/new'					.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生情報'		,'url'=>$information2index ),
									array('name'=>'クラブ管理'	,'url'=>$club2index ),
									array('name'=>'新規作成'		,'url'=>$club2new )
									);
				//$this->view->assign('navi',$data);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$club2index		= $this->view->modulePath.'club/index'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧','url'=>$club2index 		,'onclick'=>'' )
									);
					break;
				}
				//$this->view->assign('actionMenu',$data);
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$club_id = $this->getRequest()->getParam('club');
						if( $club_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_club->getClubId( $club_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['club_id'] != 0 ){
											
											$this->view->selKind			= $result["kind"];	
											
											$menu_mode ='';					//select
											$this->view->kindArray	= $this->_menu->getClubKindList( $menu_mode, null );
											
											
											// 1レコードの取得
											if( $result['adviser_id'] != 0 ){
												$this->view->user  = '後藤田';		//$user;					//１つの変数を設定する
											}else{
												
												$this->view->user  = '後藤田_0';					//１つの変数を設定する
											}
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}
				else{
				}
				


				$top2index				= $this->view->modulePath.'top/index'					.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'			.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$club2index				= $this->view->modulePath.'club/index'				.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生情報'		,'url'=>$information2index ),
									array('name'=>'クラブ管理'	,'url'=>$club2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$club2index		= $this->view->modulePath.'club/index'			.$this->view->sid;
				$club2edit		= $this->view->modulePath.'club/edit/club/'	.$result['club_id'].$this->view->sid;
				$club2delete	= $this->view->modulePath.'club/index'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$club2index		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$club2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$club2delete 	,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'club/delete/club/'.$result["club_id"].$this->view->sid.'";f.submit();};return false;' )
									);
							break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$club2index	,'onclick'=>'' )
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
			
    }




    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='';					//select
				$this->view->kindArray	= $this->_menu->getClubKindList( $menu_mode, null );
				
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$club_id = $this->getRequest()->getParam('club');
						if( $club_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_club->getClubId( $club_id );
									
									if( $result['club_id'] != 0 ){
											
												$club_id = 
											$this->view->club			= $result['club_id'];
												$this->_userspace->search['club']['name'] = 
												$name = 
											$this->view->name			= $result['club_name'];
											$this->view->kana			= $result['club_kana'];
											
											$this->view->selKind	= $result['kind'];
											$this->view->adviser	= $result['adviser_id'];	
											
											
											
											// 1レコードの取得
											if( $result['adviser_id'] != 0 ){
												$this->view->user  = '後藤田';		//$user;					//１つの変数を設定する
											}else{
												
												$this->view->user  = '後藤田_0';					//１つの変数を設定する
											}
											$this->view->assign('errors',$errors);			// 追加後に再設定必要
									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$club_id	= $this->getRequest()->getParam('club');
						$name			= $this->getRequest()->getParam('name');
						$kana			= $this->getRequest()->getParam('kana',"");
						$kind			= $this->getRequest()->getParam('kind');
						$adviser	= $this->getRequest()->getParam('adviser');
						
						
						$name	= trim($name);								//半角スペースのみ
						$kana	= trim($kana);								//半角スペースのみ
						
						
						$msgs = validateStringFull( 3, 30, 'クラブ名称', $name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複チェック
						elseif ( $this->_userspace->search['club']['name'] != $name ){
			  				if ( $this->_club->isRegisteredClub($name) == true )	{
									array_push($errors, array('このクラブ名称は、既に登録されています。') );
			      		}
						}
						
						
						$msgs = validateSelect( '分類', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						if (count($errors) == 0){
								
								$data = array(
													'club'				=>	$club_id,
													'name'				=>	$name,
													'kana'				=>	$kana,
													'kind'				=>	$kind,
													'adviser'			=>	$adviser,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $club_id != NULL ){
										
			    					$this->_club->updateClub( $data, $club_id, $deleteType );
										
						        // ビュースクリプトが表示されます
						        $targetUrl = '/club/index'. '/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->club				= $club_id;
								$this->view->name				= $name;
								$this->view->kana				= $kana;
								$this->view->selKind 		= $kind;
								$this->view->adviser	 	= $adviser;
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				


				$top2index				= $this->view->modulePath.'top/index'					.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'			.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$club2index				= $this->view->modulePath.'club/index'				.$this->view->sid;
				$club2item				= $this->view->modulePath.'club/item/club/'	.$this->view->club.$this->view->sid;
				$club2edit				= $this->view->modulePath.'club/edit/club/'	.$this->view->club.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'							,'url'=>$top2index ),
									array('name'=>'マスタ設定'			,'url'=>$master2index ),
									array('name'=>'学生情報'				,'url'=>$information2index ),
									array('name'=>'クラブ管理'			,'url'=>$club2index ),
									array('name'=>$this->view->name	,'url'=>$club2item ),
									array('name'=>'編集'						,'url'=>$club2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$club2index	= $this->view->modulePath.'club/index'			.$this->view->sid;
				$club2item	= $this->view->modulePath.'club/item/club/'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$club2index		,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$club2item		,'onclick'=>'' )
									);
							break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$club2index	,'onclick'=>'' )
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);				
    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$clubId 		= $this->getRequest()->getParam('club');
				}
				
				if( $code != null ){
						$info 	= array();
						$deleteType = '1';
						
   					$this->_club->deleteClub( $clubId );
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/club/index'. '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }

























    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
