<?php
/**
 * Jobコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

setlocale(LC_ALL, 'ja_JP.UTF-8');

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Paginator'); 							// 追加する

// モデルをロードする
require_once '../application/vers/default/models/employModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';





class JobController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_employ;					// エンプロイモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // エンプロイモデルのインスタンスを生成する
        $this->_employ	= new employModel('../application/lib/user.db');
        $this->_menu		= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= '/ananfd/';
				$this->view->modulePath = '/ananfd/';
				$this->view->debugOn 		= false;
				$debugOn 								= false;
				$sessionSec 						= 300;
				$countPerPage						= 10;
				$pageRange							= 10;
				$this->view->userId			= '';
				if( isset($this->_config->global) ){
					if( isset($this->_config->global->basePath) )
						$this->view->basePath		= $this->_config->global->basePath;
					if( isset($this->_config->global->modulePath) )
						$this->view->modulePath = $this->_config->global->modulePath;
					if( isset($this->_config->global->debugOn) )
						$debugOn 								= 
						$this->view->debugOn 		= $this->_config->global->debugOn;
					if( isset($this->_config->global->sessionSec) )
						$sessionSec 						= $this->_config->global->sessionSec;
				}
				if( isset($this->_config->view) ){
					if( isset($this->_config->view->countPerPage) )
						$countPerPage 		= $this->_config->view->countPerPage;
					if( isset($this->_config->view->pageRange) )
						$pageRange 				= $this->_config->view->pageRange;
				}



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;		//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				
				


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);




		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['job']['sGroup']	= $this->getRequest()->getParam('s_group');		
						$this->_userspace->search['job']['sArea']		= $this->getRequest()->getParam('s_area');		
						$this->_userspace->search['job']['sKana']		= $this->getRequest()->getParam('s_kana');		
						$this->_userspace->search['job']['sKeyword']= $this->getRequest()->getParam('s_keyword');	
						$this->_userspace->search['job']['sField']	= $this->getRequest()->getParam('s_field');		
				} else {
						if( !isset($this->_userspace->search['job']['sGroup']) )
							$this->_userspace->search['job']['sGroup']	= '0';
						if( !isset($this->_userspace->search['job']['sArea']) )
							$this->_userspace->search['job']['sArea']		= '0';
						if( !isset($this->_userspace->search['job']['sKana']) )
							$this->_userspace->search['job']['sKana']		= '0';
						if( !isset($this->_userspace->search['job']['sKeyword']) )
							$this->_userspace->search['job']['sKeyword']= '';
						if( !isset($this->_userspace->search['job']['sField']) )
							$this->_userspace->search['job']['sField']	= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['job']['sGroup'];		
				$sArea		= $this->_userspace->search['job']['sArea'];		
				$sKana		= $this->_userspace->search['job']['sKana'];		
				$sKeyword	= $this->_userspace->search['job']['sKeyword'];	
				$sField		= $this->_userspace->search['job']['sField'];		
				if( $sGroup 	=== null 
					||	$sArea	=== null 
					|| 	$sKana	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sArea   == "0" 
					&& $sKana   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_area'		=>  $sArea,	
																	's_kana'	  =>  $sKana,	
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_employ->getEmployPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_employ->getEmployPage( null );
						
				}
				
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );
				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getFieldList( null, null );
				$menu_mode ='-';
				$this->view->headArray		= $this->_menu->getAreaList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selArea		= $sArea;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);




				$top2index				= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'	.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$job2item					= $this->view->modulePath.'job/index'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生情報'		,'url'=>$information2index ),
									array('name'=>'就職先管理'	,'url'=>$job2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$job2new		= $this->view->modulePath.'job/new'			.$this->view->sid;
				$job2import	= $this->view->modulePath.'job/import'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成'  	,'url'=>$job2new		,'onclick'=>'' ),
									array('name'=>'separator' 	,'url'=>$urlNon     ,'onclick'=>'' ),
									array('name'=>'一括読込'		,'url'=>$job2import	,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }




    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
				$menu_mode ='';					//select
				$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
				
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				
				
				if ($this->getRequest()->isPost()){
						
						$name 		= $this->getRequest()->getParam('name');
						$kana			= $this->getRequest()->getParam('kana');
						$area		 	= $this->getRequest()->getParam('area');
						$url		 	= $this->getRequest()->getParam('url');
						$comments	= $this->getRequest()->getParam('comments');
						$group 		= $this->getRequest()->getParam('group');
						
						$name 	= trim($name);								//半角スペースのみ
						$kana 	= trim($kana);								//半角スペースのみ
						$area 	= trim($area);								//半角スペースのみ
						$url 		= trim($url);									//半角スペースのみ
						$comments	= trim($comments);					//半角スペースのみ
						
						
						
						$msgs = validateStringFull( 3, 30, '会社名称', $name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複チェック
			  		else if ( $this->_employ->isRegisteredEmployname($name) == true )	{
								array_push($errors, array('この会社名称は、既に登録されています。') );
			      }
						
						$msgs = validateStringKana( 3, 30, 'よみがな', $kana);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
/*area_check len5*/		
						$msgs = validateSelect( '本社', $area);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

/*url_check*/					
/*meme_check */				
						
						
						
						$msgs = validateSelect( 'グループ', $group );
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
					
					if (count($errors) == 0){
							$data = array(
												'name'				=>	$name,
												'kana'				=>	$kana,
												'area'				=>	$area,
												'url'					=>	$url,
												'comments'		=>	$comments,
												'delete_flg'	=> '0',
												'create_date'	=> NULL
											);
							
							
							// グループＩＤを取得する
							$deleteType = '0';
							
	    				if( $this->_employ->registEmployNew( $data, $group, $deleteType ) == 0 ){
								echo '中止 ';
							}
					  $targetUrl = '/job/index'. '/sid/'.$this->_sid;
					  return $this->_redirect($targetUrl);		//DebugMessage 表示不可
					}
					else{
						
						$this->view->name				= $name;
						$this->view->kana				= $kana;
						$this->view->url			 	= $url;
						$this->view->comments 	= $comments;
						$this->view->selGroup 	= $group;
						$this->view->selArea			= $area;
						
						}
				}
				else{
						
						$this->view->name			= ''; 		
						$this->view->kana			= ''; 		
						$this->view->area			= ''; 		
						$this->view->url			= ''; 		
						$this->view->comments	= ''; 		
						
						$this->view->selGroup		= array(  );
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
		
		


				$top2index				= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'	.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$job2item					= $this->view->modulePath.'job/index'			.$this->view->sid;
				$job2new					= $this->view->modulePath.'job/new'				.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生情報'		,'url'=>$information2index ),
									array('name'=>'就職先管理'	,'url'=>$job2item ),
									array('name'=>'新規作成'		,'url'=>$job2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$job2index		= $this->view->modulePath.'job/index'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'		,'url'=>$job2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$employ = $this->getRequest()->getParam('employ');
						if( $employ != NULL ){
									
									// 1レコードの取得
									$result = $this->_employ->getEmployId( $employ );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['employ'] != 0 ){
											
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
											$menu_mode ='';					//select
											$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
											
											$this->view->comments		= $result['comments'];
											
											// 1レコードの取得
											$group = $this->_employ->chargedGroupId( $employ );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );
											}
											$this->view->selGroup		= $groupArray;
											
											
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}
				else{
				}
				


				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'		.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'.$this->view->sid;
				$job2index				= $this->view->modulePath.'job/index'				.$this->view->sid;
				$job2item					= $this->view->modulePath.'job/item/employ/'.$result['employ'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'学生情報'			,'url'=>$information2index ),
									array('name'=>'就職先管理'		,'url'=>$job2index ),
									array('name'=>$result['name']	,'url'=>$job2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$job2index	= $this->view->modulePath.'job/index'.$this->view->sid;
				$job2edit		= $this->view->modulePath.'job/edit/employ/'.$result['employ'].$this->view->sid;
				$job2delete	= $this->view->modulePath.'job/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$job2index	,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$job2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$job2delete ,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'job/delete/employ/'.$result["employ"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$job2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
			
    }







    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$employ		= $this->getRequest()->getParam('employ');
				}
				
				if( $employ != null ){
						$info 	= array();
						$deleteType = '1';
						
   					$this->_employ->deleteEmploy( $employ );
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/job/index'. '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }





    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
				$menu_mode ='';					//select
				$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
				
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$employ = $this->getRequest()->getParam('employ');
						if( $employ != NULL ){
									
									// 1レコードの取得
									$result = $this->_employ->getEmployId( $employ );
									
									if( $result['employ'] != 0 ){
											
											$this->view->employ			= $result['employ'];
												$this->_userspace->search['job']['name']	= 
											$this->view->name				= $result['name'];
											$this->view->kana				= $result['kana'];
											$this->view->area				= $result['area'];
											$this->view->url				= $result['url'];
											$this->view->comments		= $result['comments'];
											
											// 1レコードの取得
											$group = $this->_employ->chargedGroupId( $employ );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );
											}
											$this->view->selGroup		= $groupArray;
											$this->view->selArea		= $result['area'];
											
											$this->view->assign('errors',$errors);			// 追加後に再設定必要
									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$employ 	= $this->getRequest()->getParam('employ');
						$name			= $this->getRequest()->getParam('name');
						$kana 		= $this->getRequest()->getParam('kana');
						$area			= $this->getRequest()->getParam('area');
						$url 			= $this->getRequest()->getParam('url');
						$comments	= $this->getRequest()->getParam('comments');
						
						$group		= $this->getRequest()->getParam('group');
						
						
						$name		= trim($name);								//半角スペースのみ
						$kana		= trim($kana);								//半角スペースのみ
						$url		= trim($url);									//半角スペースのみ
						$comments	= trim($comments);					//半角スペースのみ
						
						
						
						$msgs = validateStringFull( 3, 30, '会社名称', $name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複チェック
						elseif( $this->_userspace->search['job']['name'] != $name ){ 
			  				if ( $this->_employ->isRegisteredEmployname($name) == true )	{
									array_push($errors, array('この会社名称は、既に登録されています。') );
			      		}
						}
						
						$msgs = validateStringKana( 3, 30, 'よみがな', $kana);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
/*area_check len5*/		
						$msgs = validateSelect( '本社', $area);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

/*url_check*/					
/*meme_check */				
						
						$msgs = validateSelect( 'グループ', $group );
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						if (count($errors) == 0){
								
								$data = array(
													'employ'			=>	$employ,
													'name'				=>	$name,
													'kana'				=>	$kana,
													'area'				=>	$area,
													'url'					=>	$url,
													'comments'		=>	$comments,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $employ != NULL ){
										
			    					$this->_employ->updateEmploy( $data, $employ, $group, $deleteType );
										
						        // ビュースクリプトが表示されます
						        $targetUrl = '/job/index'. '/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->employ			= $employ;
								$this->view->name				= $name;
								$this->view->kana				= $kana;
								$this->view->url			 	= $url;
								$this->view->comments 	= $comments;
								
								$this->view->selGroup 	= $group;
								$this->view->selArea		= $area;
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				


				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'		.$this->view->sid;
				$information2index= $this->view->modulePath.'informatin/index'.$this->view->sid;
				$job2index				= $this->view->modulePath.'job/index'				.$this->view->sid;
				$job2item					= $this->view->modulePath.'job/item/employ/'.$this->view->employ.$this->view->sid;
				$job2edit					= $this->view->modulePath.'job/edit/employ/'.$this->view->employ.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'学生情報'			,'url'=>$information2index ),
									array('name'=>'就職先管理'		,'url'=>$job2index ),
									array('name'=>$this->view->name	,'url'=>$job2item ),
									array('name'=>'編集'					,'url'=>$job2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$job2index	= $this->view->modulePath.'job/index'.$this->view->sid;
				$job2item		= $this->view->modulePath.'job/item/employ/'.$this->view->employ.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$job2index	,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$job2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }




    /**-------------------------------------------------------------------------------------------
     * importアクション
     */
    public function importAction()
    {
        // ビュースクリプトが表示されます


				$top2index				= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'	.$this->view->sid;
				$information2index= $this->view->modulePath.'information/index'	.$this->view->sid;
				$job2item					= $this->view->modulePath.'job/index'			.$this->view->sid;
				$job2import				= $this->view->modulePath.'job/import'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生情報'		,'url'=>$information2index ),
									array('name'=>'就職先管理'	,'url'=>$job2item ),
									array('name'=>'一括読込'		,'url'=>$job2import )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$job2index	= $this->view->modulePath.'job/index'			.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'		,'url'=>$job2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }




    /**-------------------------------------------------------------------------------------------
     * uploadアクション
     */
    public function uploadAction()
    {
				$listArray = array();
				
					$listArray['1']	 = '北海道';
					$listArray['2']  = '青森';
					$listArray['3']  = '岩手';
					$listArray['4']  = '宮城';
					$listArray['5']  = '秋田';
					$listArray['6']  = '山形';
					$listArray['7']  = '福島';
					
					$listArray['8']  = '茨城';
					$listArray['9']  = '栃木';
					$listArray['10'] = '群馬';
					$listArray['11'] = '埼玉';
					$listArray['12'] = '千葉';
					$listArray['13'] = '東京';
					$listArray['14'] = '神奈川';
					
					$listArray['15'] = '新潟';
					$listArray['16'] = '富山';
					$listArray['17'] = '石川';
					$listArray['18'] = '福井';
					$listArray['19'] = '山梨';
					$listArray['20'] = '長野';
					$listArray['21'] = '岐阜';
					$listArray['22'] = '静岡';
					$listArray['23'] = '愛知';
					$listArray['24'] = '三重';
					
					$listArray['25'] = '滋賀';
					$listArray['26'] = '京都';
					$listArray['27'] = '大阪';
					$listArray['28'] = '兵庫';
					$listArray['29'] = '奈良';
					$listArray['30'] = '和歌山';
					
					$listArray['31'] = '鳥取';
					$listArray['32'] = '島根';
					$listArray['33'] = '岡山';
					$listArray['34'] = '広島';
					$listArray['35'] = '山口';
					
					$listArray['36'] = '徳島';
					$listArray['37'] = '香川';
					$listArray['38'] = '愛媛';
					$listArray['39'] = '高知';
					
					$listArray['40'] = '福岡';
					$listArray['41'] = '佐賀';
					$listArray['42'] = '長崎';
					$listArray['43'] = '熊本';
					$listArray['44'] = '大分';
					$listArray['45'] = '宮崎';
					$listArray['46'] = '鹿児島';
					$listArray['47'] = '沖縄';
					
				
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];


				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="会社名" ) continue;
						if( $str[0]=="" ) 		continue;
						if( $str[4]=="" ) 		continue;
						
						$area = array_search($str[3],$listArray);
						
						$data = array(
											'employ_name'		=> $str[0],
											'employ_kana'		=> $str[1],
											'url'						=> $str[2],
											'area'					=> $area,		//$str[3],
											'employ_group'	=> $str[4],
											'comments'			=> '',
											'employ_group'	=> $str[4],
											'delete_flg'		=> '0',
											'create_date'		=> NULL
											);
						
						
						// グループＩＤを取得する
						$groupId 	='0';
						$employId ='0';
						$deleteType = '0';
						
	 		     	// 重複チェック
						{
    					if( $this->_employ->registEmploy( $data, $groupId, $employId, $deleteType ) == 0 ){
									echo '中止 ';
							}
						}
				} 
				fclose($file);


				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="会社名" ) continue;
						if( $str[0]=="" ) 		continue;
						if( $str[4]=="" ) 		continue;
						
						$data = array(
											'employ_name'		=> $str[0],
											'employ_kana'		=> $str[1],
											'url'						=> $str[2],
											'area'					=> $str[3],
											'employ_group'	=> $str[4],
											'delete_flg'		=> '0',
											'create_date'		=> NULL
											);
						
						
						// グループＩＤを取得する
						$employId	= $this->_employ->getEmploymentId( $data['employ_name'] );
						$groupId	= $this->_employ->getGroupId( $data['employ_group'] );
						$deleteType = '0';
						
	 		     	// 重複チェック
						if ( $this->_employ->isRegisteredEmploy2( $groupId, $employId ) == true )	
						{
	    				if( $this->_employ->registEmploy2( $data, $groupId, $employId, $deleteType ) == 0 ){
									echo '中止 ';
							}
						}
				} 
				fclose($file);


				
				
				$targetUrl = '/job/index'. '/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }



    /**-------------------------------------------------------------------------------------------
     * upload2アクション
     */
    private function importData( $fileName )
		{
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="会社名" ) continue;
						if( $str[0]=="" ) 		continue;
						if( $str[4]=="" ) 		continue;
						
						$area = array_search($str[3],$listArray);
						
						$data = array(
											'employ_name'		=> $str[0],
											'employ_kana'		=> $str[1],
											'url'						=> $str[2],
											'area'					=> $area,		//$str[3],
											'employ_group'	=> $str[4],
											'comments'			=> '',
											'employ_group'	=> $str[4],
											'delete_flg'		=> '0',
											'create_date'		=> NULL
											);
						
						
						// グループＩＤを取得する
						$groupId 	='0';
						$employId ='0';
						$deleteType = '0';
						
    				if( $this->_employ->registEmploy( $data, $groupId, $employId, $deleteType ) == 0 ){
								echo '中止 ';
						}
				} 
				
				fclose($file);
		
		}



    /**-------------------------------------------------------------------------------------------
     * upload2アクション
     */
    private function importData2( $fileName )
		{
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="会社名" ) continue;
						if( $str[0]=="" ) 		continue;
						if( $str[4]=="" ) 		continue;
						
						$data = array(
											'employ_name'		=> $str[0],
											'employ_kana'		=> $str[1],
											'url'						=> $str[2],
											'area'					=> $str[3],
											'employ_group'	=> $str[4],
											'delete_flg'		=> '0',
											'create_date'		=> NULL
											);
						
						
						// グループＩＤを取得する
						$employId	= $this->_employ->getEmploymentId( $data['employ_name'] );
						$groupId	= $this->_employ->getGroupId( $data['employ_group'] );
						$deleteType = '0';
						
    				if( $this->_employ->registEmploy2( $data, $groupId, $employId, $deleteType ) == 0 ){
								echo '中止 ';
						}
				} 
				
				fclose($file);
		
		}




    /**-------------------------------------------------------------------------------------------
     * upload2アクション
     */
    public function upload2Action()
    {
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="会社名" ) continue;
						if( $str[0]=="" ) 		continue;
						if( $str[4]=="" ) 		continue;

						$data = array(
											'employ_name'		=> $str[0],
											'employ_kana'		=> $str[1],
											'url'						=> $str[2],
											'area'					=> $str[3],
											'employ_group'	=> $str[4],
											'delete_flg'		=> '0',
											'create_date'		=> NULL
											);
						
						
						// グループＩＤを取得する
						$employId	= $this->_employ->getEmploymentId( $data['employ_name'] );
						$groupId	= $this->_employ->getGroupId( $data['employ_group'] );
						$deleteType = '0';

						
    				if( $this->_employ->registEmploy2( $data, $groupId, $employId, $deleteType ) == 0 ){
								echo '中止 ';
						}
				} 
				fclose($file);
				
				
				$targetUrl = '/job/index'. '/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * upload3アクション
     */
    public function upload3Action()
    {
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="課程" ) continue;
						if( $str[3]=="" ) 		continue;

						$data = array(
											'adapted_group'		=> $str[0],
											'adapted_grade'		=> $str[1],
											'subject_require'	=> $str[2],
											'subject_code'		=> $str[3],
											'subject_name'		=> $str[4],
											'subject_units'		=> $str[6],
											'subject_kind'		=> $str[7],
											'start_year'			=> $str[10] . '-04-01',
											'end_year'				=> $str[11] . '-04-01',
											'delete_flg'			=> '0',
											'create_date'			=> NULL
											);
						
						
						// グループＩＤを取得する
						$deleteType = '0';
						$req = 0;
						switch($str[2]){
							case '1':		$req = 1;	break;		//'必修'
							case '0':		$req = 2;	break;		//'選択'
							default:		$req = 0;	break;
						}
						$term = 0;
						switch($str[7]){
							case '通年':		$term = 1;	break;
							case '前期':		$term = 2;	break;
							case '後期':		$term = 3;	break;
							default:				$term = 0;	break;
						}
						
				} 
				
				
				$targetUrl = '/job/index'. '/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




















    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
