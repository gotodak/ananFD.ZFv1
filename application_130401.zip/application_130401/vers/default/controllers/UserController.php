<?php
/**
 * Userコントローラ
 *
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */


setlocale(LC_ALL, 'ja_JP.UTF-8');


// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db');
Zend_Loader::loadClass('Zend_File_Transfer');
Zend_Loader::loadClass('Zend_Debug');
Zend_Loader::loadClass('Zend_Paginator'); 							// 追加する


// モデルをロードする
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/commModel.php';
require_once '../application/vers/default/models/menuModel.php';

// モジュールをロードする
require_once '../application/lib/functions.php';


class UserController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_user;						// ユーザモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
    private $_namespace;
    private $_userspace;


    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        $this->_user = new userModel('../application/lib/user.db');
        $this->_comm = new commModel('../application/lib/user.db');
        $this->_menu = new menuModel('../application/lib/user.db');



        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin

				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';




				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長

					        $this->view->userLevel = $this->_userspace->userLevel;		//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;			//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;
									$this->view->ssid 		 = $this->_sid;
									$this->view->loginUrl  = 'login/logout';
									$this->view->loginName = 'ログアウト';
							}else{
									// sid 破棄
					        $targetUrl = 'login/index2';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}



        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);


        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);




		}




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {


				if( $this->getRequest()->isPost() ) {

						$this->_userspace->search['user']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['user']['sJob']			= $this->getRequest()->getParam('s_job');
						$this->_userspace->search['user']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['user']['sComm']		= $this->getRequest()->getParam('s_comm');
						$this->_userspace->search['user']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['user']['sField']		= $this->getRequest()->getParam('s_field');
				} else {
						if( !isset($this->_userspace->search['user']['sGroup']) )
							$this->_userspace->search['user']['sGroup']		= '0';
						if( !isset($this->_userspace->search['user']['sJob']) )
							$this->_userspace->search['user']['sJob']			= '0';
						if( !isset($this->_userspace->search['user']['sKana']) )
							$this->_userspace->search['user']['sKana']		= '0';
						if( !isset($this->_userspace->search['user']['sComm']) )
							$this->_userspace->search['user']['sComm']		= '0';
						if( !isset($this->_userspace->search['user']['sKeyword']) )
							$this->_userspace->search['user']['sKeyword']	= '';
						if( !isset($this->_userspace->search['user']['sField']) )
							$this->_userspace->search['user']['sField']		= '0';
				}


				$bFind = true;

				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['user']['sGroup'];
				$sJob			= $this->_userspace->search['user']['sJob'];
				$sKana		= $this->_userspace->search['user']['sKana'];
				$sComm		= $this->_userspace->search['user']['sComm'];
				$sKeyword	= $this->_userspace->search['user']['sKeyword'];
				$sField		= $this->_userspace->search['user']['sField'];
				if( $sGroup 	=== null
					||	$sJob		=== null
					|| 	$sKana	=== null
					|| 	$sComm	=== null
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0"
					&& $sJob	  == "0"
					&& $sKana   == "0"
					&& $sComm   == "0"
					&& $sKeyword== ""
					)	{
							$bFind = false;
				}


				if ( $bFind ){

						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_comm'	  =>  $sComm,
																	's_keyword'	=>  $sKeyword,
																	's_kind'		=>  '0',
																	's_field'		=>  $sField
																);

						$select = $this->_user->getUserPage( $findArray );

				} else
				{


						$select = $this->_user->getUserPage( null );

				}


				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）

				$this->view->assign( 'paginator', $paginator );


        // ビュースクリプトが表示されます

        $page  = $this->getRequest()->getParam('page');
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
									// 's_kind'		=>  '1'
									 's_kind'		=>  '3'
									);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->jobList			= $this->_menu->getJobList( '', null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$menu_commArray	= array( COMM_KIND_EXPERT,COMM_KIND_USER );
	   		$this->view->commArray		= $this->_menu->getCommitteeList( $menu_mode, $menu_commArray );
	   		$this->view->committeeList= $this->_menu->getCommitteeList( $menu_mode, $menu_commArray );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );

				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selComm		= $sComm;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;


				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$user2index		= $this->view->modulePath.'user/index'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'									,'url'=>$top2index ),
									array('name'=>'マスタ設定'					,'url'=>$master2index ),
									array('name'=>'ユーザ管理'					,'url'=>$user2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$user2new			= $this->view->modulePath.'user/new'		.$this->view->sid;
				$user2import	= $this->view->modulePath.'user/import'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成'  ,'url'=>$user2new			,'onclick'=>'' ),
									array('name'=>'separator' ,'url'=>$urlNon     	,'onclick'=>'' ),
									array('name'=>'一括読込'	,'url'=>$user2import	,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);




if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }





    /**-------------------------------------------------------------------------------------------
    /**
     * index2アクション
     */
    public function index2Action()
    {
        // ビュースクリプトが表示されます
				$menu_mode ='すべて';		//search
				$this->view->groupArray	= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray		= $this->_menu->getJobList( $menu_mode, null );


				// 全レコードの取得
				$result = $this->_user->getUserId( null );

       	$this->view->assign( 'result', $result );	//複数の変数（連想配列）を一度に設定する。




    }


    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function new2Action()
    {

        // ビュースクリプトが表示されます
		}




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{

						$user_id = $this->getRequest()->getParam('user_id');
						if( $user_id != NULL ){

									// 1レコードの取得
									$result = $this->_user->getUserId( $user_id );
				          $this->view->result  = $result;					//１つの変数を設定する

									if( $result['user_id'] != 0 ){

											$menu_mode ='';					//select
											$this->view->groupArray	= $this->_menu->getGroupList( $menu_mode, null );
											$this->view->jobArray		= $this->_menu->getJobList( $menu_mode, null );
   										$this->view->roleArray	= $this->_menu->getRoleList( $menu_mode, null );

											$menu_findArray = array(
																								's_kind'		=>  '3'
																							);
											$menu_commArray	= array( COMM_KIND_USER );
											$commList2		= $this->_menu->getCommitteeList( null, $menu_commArray );
										    if (count($commList2) > 5) {
										        $columns = array_chunk($commList2, 4, true); //four columns
										    } else {
										        $columns = array($commList2);
										    }
											$this->view->committeeLists		= $columns;

											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
											$this->view->listsep =' ';

											// 1レコードの取得
											$comm = $this->_user->chargedCommId( $user_id );
											$commArray = array();
											foreach( $comm as $row ){
												array_push( $commArray, $row['comm_id'] );
											}
											$this->view->selCommittee = $commArray;

									}
						}
				}
				else{
				}




				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$user2index		= $this->view->modulePath.'user/index'	.$this->view->sid;
				$user2item		= $this->view->modulePath.'user/item/user_id/'.$result['user_id'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'									,'url'=>$top2index ),
									array('name'=>'マスタ設定'					,'url'=>$master2index ),
									array('name'=>'ユーザ管理'					,'url'=>$user2index ),
									array('name'=>$result['user_name']	,'url'=>$user2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$user2index		= $this->view->modulePath.'user/index'.$this->view->sid;
				$user2edit		= $this->view->modulePath.'user/edit/user_id/'.$result['user_id'].$this->view->sid;
				$user2delete	= $this->view->modulePath.'user/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$user2index		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$user2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$user2delete 	,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'user/delete/user_id/'.$result["user_id"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$user2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }






    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();

				$this->view->assign('errors',$errors);			// 追加後に再設定必要

				$menu_mode ='';					//select
				$this->view->groupArray	= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray		= $this->_menu->getJobList( $menu_mode, null );
   			$this->view->roleArray	= $this->_menu->getRoleList( $menu_mode, null );

				$menu_findArray = array(
									 's_kind'		=>  '3'
								);
				$menu_commArray	= array( COMM_KIND_USER );
				$commList2		= $this->_menu->getCommitteeList( null, $menu_commArray );
				  if (count($commList2) > 5) {
				      $columns = array_chunk($commList2, 4, true); //four columns
				  } else {
				      $columns = array($commList2);
				  }
				$this->view->committeeLists		= $columns;

				$this->view->listsep 	= "<br />";
				$this->view->listsep 	= null;
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep =' ';

				if ($this->getRequest()->isPost()){

						$user_name 	= $this->getRequest()->getParam('user_name');
						$user_kana 	= $this->getRequest()->getParam('user_kana');
						$tel 				= $this->getRequest()->getParam('tel');
						$email 			= $this->getRequest()->getParam('email');
						$group_id 	= $this->getRequest()->getParam('group_id');
						$job_id 		= $this->getRequest()->getParam('job_id');
						$role				= $this->getRequest()->getParam('role');
						$committee	= $this->getRequest()->getParam('committee');
						$expert			= $this->getRequest()->getParam('expert');

						$user_name 	= trim($user_name);								//半角スペースのみ
						$user_kana 	= trim($user_kana);								//半角スペースのみ
						$tel			 	= trim($tel);											//半角スペースのみ
						$email		 	= trim($email);										//半角スペースのみ



						$msgs = validateStringFull( 3, 30, '氏名', $user_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateStringKana( 3, 30, 'よみがな', $user_kana);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( 'グループ', $group_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '職名', $job_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '教職員の種別', $role);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						} elseif( $kind==1 ) {
							if( STAFF_ID<=$group_id ) {
								array_push($errors, array('このグループでは、教員に設定できません。') );
							} elseif ( KIFU_ID<=$group_id && $group_id < STAFF_ID ) {
								if( $job_id <= 1 ){
									array_push($errors, array('この職名では、教員に設定できません。') );
								}
							}
						}

						$msgs = validateStringEmail( 30, 'E-mail', $email);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								//'@anan-nct.ac.jp'ドメイン名チェック
								$email = strtolower($email);
								$pos 	 = strpos( $email, '@' );
								$domain= substr( $email, $pos );
								// 新規登録で、ログイン名を自動作成しているために、ドメイン名チェックをする
								// メールアドレスを変更したい場合には、ユーザ情報編集で行う
								if( $domain != '@anan-nct.ac.jp' ){
									array_push($errors, array('このE-mailは、ドメイン名（@anan-nct.ac.jp）が異なります。') );
				 				}
	 		     		// 重複チェック
			  			  else if ( $this->_user->isRegisteredUser($email) == true )	{
									array_push($errors, array('このE-mailは、既に登録されています。') );
			        	}
						}

						$msgs = validateStringTel( 3, 30, 'ＴＥＬ', $tel);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}



					if (count($errors) == 0){
							$data = array(
												'user_name'		=>	$user_name,
												'user_kana'		=>	$user_kana,
												'group_id'		=>	$group_id,
												'email'				=>	$email,
												'job_id'			=>	$job_id,
												'tel'					=>	$tel,
												'kind'				=>	$role,
												'delete_flg'	=> '0',
												'create_date'	=> NULL
											);


							// グループＩＤを取得する
							$groupId = $data['group_id'];
							$jobId	 = $data['job_id'];
							$deleteType = '0';


							$menu_find['s_role']= $role;
							$roleName = $this->_menu->getRoleList( null, $menu_find );
	    				if( $this->_user->registUser( $data, $groupId, $jobId, $roleName, $deleteType ) == 0 )
							{
									echo '中止 ';
							}
						$targetUrl = '/user/index/sid/'.$this->_sid;
						return $this->_redirect($targetUrl);
					}
					else{

						$this->view->user_name	= $user_name;
						$this->view->user_kana	= $user_kana;
						$this->view->tel				= $tel;
						$this->view->email			= $email;
						$this->view->selGroup		= $group_id;
						$this->view->selJob			= $job_id;
						$this->view->selRole		= $role;
						$this->view->selCommittee	= $committee;
						$this->view->selExpert		= $expert;

						}
				}
				else{

						$this->view->user_name	= '';
						$this->view->user_kana	= '';
						$this->view->tel				= '';
						$this->view->email			= '';
						$this->view->selGroup		= 0;
						$this->view->selJob			= 0;
						$this->view->selRole		= 0;
						$this->view->selCommittee	= 0;
						$this->view->selExpert	= 0;

				}

        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要



				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$user2index		= $this->view->modulePath.'user/index'		.$this->view->sid;
				$user2new			= $this->view->modulePath.'user/new'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'ユーザ管理'		,'url'=>$user2index ),
									array('name'=>'新規作成'			,'url'=>$user2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$user2index		= $this->view->modulePath.'user/index'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'	,'url'=>$user2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }





    /**-------------------------------------------------------------------------------------------
     * addアクション
     */
    public function addAction()
    {
				if( $this->getRequest()->isPost() ){

						$data = array(
											'user_name'		=>	$this->getRequest()->getParam('user_name'),
											'user_kana'		=>	$this->getRequest()->getParam('user_kana'),
											'group_name'	=>	$this->getRequest()->getParam('group_name'),
											'email'				=>	$this->getRequest()->getParam('email'),
											'job_name'		=>	$this->getRequest()->getParam('job_name'),
											'tel'					=>	$this->getRequest()->getParam('tel'),
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);


						// グループＩＤを取得する
						$groupId = $this->_user->getJobId( $data['group_name'] );
						$jobId	 = $this->_user->getJobId( $data['job_name'] );
						$deleteType = '0';

    				if( $this->_user->registUser( $data, $groupId, $jobId, 'staff', $deleteType ) == 0 ){
								echo '中止 ';
						}
				}


        // ビュースクリプトが表示されます
				$targetUrl = '/user/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);
  }





    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {

				if( $this->getRequest()->isPost() )
						{

						$user_id = $this->getRequest()->getParam('user_id');
						if( $user_id != NULL ){

									// 1レコードの削除
									$result = $this->_user->deleteUser( $user_id );
						}
				}
				else{
				}
        // ビュースクリプトが表示されます
				$targetUrl = '/user/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);
    }





    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要

				$menu_mode ='';					//select
				$this->view->groupArray	= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray		= $this->_menu->getJobList( $menu_mode, null );
				$this->view->roleArray	= $this->_menu->getRoleList( $menu_mode, null );

				$menu_findArray = array(
									 's_kind'		=>  '3'
								);
				$menu_commArray	= array( COMM_KIND_USER );
				$commList2		= $this->_menu->getCommitteeList( null, $menu_commArray );
				  if (count($commList2) > 5) {
				      $columns = array_chunk($commList2, 4, true); //four columns
				  } else {
				      $columns = array($commList2);
				  }
				$this->view->committeeLists		= $columns;
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep =' ';

				// データの初期読込
				if( $this->getRequest()->isGet() )
						{

						$user_id = $this->getRequest()->getParam('user_id');
						if( $user_id != NULL ){

									// 1レコードの取得
									$result = $this->_user->getUserId( $user_id );
				          $this->view->result  = $result;					//１つの変数を設定する

									if( $result['user_id'] != 0 ){

											$this->view->user_id		= $user_id;
											$user_name 							=
											$this->view->user_name	= $result['user_name'];
											$this->view->user_kana	= $result['user_kana'];
												$this->_userspace->search['user']['emailp']	=
											$this->view->email			= $result['email'];
											$this->view->tel				= $result['tel'];
											$this->view->selGroup		= $result["group_id"];
											$this->view->selJob			= $result["job_id"];
											$this->view->selKind		= $result["kind"];



											// 1レコードの取得
											$comm = $this->_user->chargedCommId( $user_id );
											$commArray = array();
											foreach( $comm as $row ){
												array_push( $commArray, $row['comm_id'] );
											}
											$this->view->selCommittee= $commArray;



									}
						}
				}
				else if( $this->getRequest()->isPost() ){


						$user_id 		= $this->getRequest()->getParam('user_id');
						$user_name 	= $this->getRequest()->getParam('user_name');
						$user_kana 	= $this->getRequest()->getParam('user_kana');
						$tel 				= $this->getRequest()->getParam('tel');
						$email 			= $this->getRequest()->getParam('email');
						$kind				= $this->getRequest()->getParam('kind');
						$group_id 	= $this->getRequest()->getParam('group_id');
						$job_id			= $this->getRequest()->getParam('job_id');
						$committee	= $this->getRequest()->getParam('committee');
						$expert			= $this->getRequest()->getParam('expert');

						$user_name 	= trim($user_name);								//半角スペースのみ
						$user_kana 	= trim($user_kana);								//半角スペースのみ
						$tel			 	= trim($tel);											//半角スペースのみ
						$email		 	= trim($email);										//半角スペースのみ



						$msgs = validateStringFull( 2, 30, '氏名', $user_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateStringKana( 3, 30, 'よみがな', $user_kana);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( 'グループ', $group_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '職名', $job_id);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '教職員の種別', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						} elseif( $kind==1 ) {
							if( STAFF_ID<=$group_id ) {
								array_push($errors, array('このグループでは、教員に設定できません。') );
							} elseif ( KIFU_ID<=$group_id && $group_id < STAFF_ID ) {
								if( $job_id <= 1 ){
									array_push($errors, array('この職名では、教員に設定できません。') );
								}
							}
						}

						$msgs = validateStringEmail( 30, 'E-mail', $email);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								//'@anan-nct.ac.jp'ドメイン名チェック
								$email = strtolower($email);
								$pos 	 = strpos( $email, '@' );
								$domain= substr( $email, $pos );
								// 新規登録で、ログイン名を自動作成しているために、ドメイン名チェックをする
								// メールアドレスを変更したい場合には、ユーザ情報編集で行う
								if( $domain != '@anan-nct.ac.jp' ){
									array_push($errors, array('このE-mailは、ドメイン名（@anan-nct.ac.jp）が異なります。') );
				 				}
	 		     			// 重複チェック
								elseif( $this->_userspace->search['user']['emailp']	!= $email ){
			  						if ( $this->_user->isRegisteredUser($email) == true )	{
											array_push($errors, array('このE-mailは、既に登録されています。') );
			        			}
								}
						}

						$msgs = validateStringTel( 3, 30, 'ＴＥＬ', $tel);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}


						if (count($errors) == 0){

								$data = array(
													'user_id'			=>  $user_id,			//for checkCommittee()
													'user_name'		=>	$user_name,
													'user_kana'		=>	$user_kana,
													'group_id'		=>	$group_id,
													'job_id'	  	=>	$job_id,
													'email'				=>	$email,
													'tel'					=>	$tel,
													'kind'				=>	$kind,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);

								$user_id	= $this->getRequest()->getParam('user_id');
								$group_id	= $data['group_id'];
								$job_id		= $data['job_id'] ;
								if( $user_id != NULL ){

		    					$this->_user->updateUser( $data, $user_id, $committee, $this->_userspace );

									if( $this->view->userName != $data['user_name'] ){

		    							$this->_user->updateLoginUserName( $user_id, $data['user_name'], '0' );

											$this->view->userName	= $data['user_name'];

									}

					        // ビュースクリプトが表示されます
								  $targetUrl = '/user/index/sid/'.$this->_sid;
						      return $this->_redirect($targetUrl);		//DebugMessage 表示不可

								}
						}
						else{

								$this->view->user_id		= $user_id;
								$this->view->user_name	= $user_name;
								$this->view->user_kana	= $user_kana;
								$this->view->email			= $email;
								$this->view->tel				= $tel;
								$this->view->selGroup			= $group_id;
								$this->view->selJob				= $job_id;
								$this->view->selCommittee	= $committee;
								$this->view->selExpert		= $expert;
								$this->view->selKind			= $kind;

						}

				}
				else{
				}

        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。



				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$user2index		= $this->view->modulePath.'user/index'		.$this->view->sid;
				$user2item		= $this->view->modulePath.'user/item/user_id/'.$this->view->user_id.$this->view->sid;
				$user2edit		= $this->view->modulePath.'user/edit/user_id/'.$this->view->user_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'									,'url'=>$top2index ),
									array('name'=>'マスタ設定'					,'url'=>$master2index ),
									array('name'=>'ユーザ管理'					,'url'=>$user2index ),
									array('name'=>$this->view->user_name	,'url'=>$user2item ),
									array('name'=>'編集'								,'url'=>$user2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$user2index		= $this->view->modulePath.'user/index'.$this->view->sid;
				$user2item		= $this->view->modulePath.'user/item/user_id/'.$this->view->user_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$user2index		,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$user2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }






    /**-------------------------------------------------------------------------------------------
     * commアクション（未使用）
     *   委員会のリスト表示時の選択画面
     */
    public function commAction()
    {



				if( $this->getRequest()->isPost() ) {

						$this->_userspace->search['user2']['sKind']			= $this->getRequest()->getParam('s_kind');
						$this->_userspace->search['user2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');

						$user_name	= $this->getRequest()->getParam('user_name');
						$user_id		= $this->getRequest()->getParam('user_id');
				}
				else {
						if( !isset($this->_userspace->search['user2']['sKind']) )
							$this->_userspace->search['user2']['sKind']			= '0';
						if( !isset($this->_userspace->search['user2']['sKeyword']) )
							$this->_userspace->search['user2']['sKeyword']	= '';

						$user_name	= $this->getRequest()->getParam('user_name');
						$user_id		= $this->getRequest()->getParam('user_id');

				}


				$bFind = true;

				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sKind		= $this->_userspace->search['user2']['sKind'];
				$sKeyword	= $this->_userspace->search['user2']['sKeyword'];
				if( $sKind 	=== null
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sKind   == "0"
					&& $sKeyword== ""
					)	{
							$bFind = false;
				}


				if ( $bFind ){

						$findArray = array( 	's_kind'		=>  $sKind,
																	's_keyword'	=>  $sKeyword
																);


						$select = $this->_comm->getCommPage( $findArray );

				} else
				{

						$select = $this->_comm->getCommPage( null );

				}


				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）

				$this->view->assign( 'paginator', $paginator );


        // ビュースクリプトが表示されます

        $page  = $this->getRequest()->getParam('page');
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( $menu_mode, null );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '-', null );

				$this->view->selKind		= $sKind;
				$this->view->selKeyword	= $sKeyword;

				$this->view->user_name	= $user_name;
				$this->view->user_id		= $user_id;



				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$user2index		= $this->view->modulePath.'user/index'		.$this->view->sid;
				$user2item		= $this->view->modulePath.'user/item/user_id/'		.$user_id.$this->view->sid;
				$user2edit		= $this->view->modulePath.'user/edit/user_id/'		.$user_id.$this->view->sid;
				$user2addcomm	= $this->view->modulePath.'user/addcomm/user_id/'	.$user_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'ユーザ管理'		,'url'=>$user2index ),
									array('name'=>$user_name			,'url'=>$user2item ),
									array('name'=>'編集'					,'url'=>$user2edit ),
									array('name'=>'委員会追加'		,'url'=>$user2addcomm )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$user2index		= $this->view->modulePath.'user/index'.$this->view->sid;
				$user2item		= $this->view->modulePath.'user/item/user_id/'.$user_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * addcommアクション
     */
    public function addcommAction()
    {
				if( $this->getRequest()->isPost() ) {

						$userId 		= $this->getRequest()->getParam('user_id');
						$commArray	= $this->getRequest()->getParam('comm_id');
				}

				if( $userId != null ){
						$info 	= array();
						$deleteType = '0';

		    		$this->_user->updateUserAddcomm( $info, $userId, $commArray, $deleteType);
				}


        // ビュースクリプトが表示されます
        $targetUrl = '/user/edit/user_id/'. $userId. '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * delcommアクション
     */
    public function delcommAction()
    {
				if( $this->getRequest()->isGet() ) {

						$userId 	= $this->getRequest()->getParam('user_id');
						$commId		= $this->getRequest()->getParam('comm_id');
				}

				if( $userId != null ){
						$info 	= array();
						$deleteType = '1';

   					$this->_user->updateUserDelcomm( $info, $userId, $commId, $deleteType);
				}


        // ビュースクリプトが表示されます
        $targetUrl = '/user/edit/user_id/'. $userId. '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }










    /**-------------------------------------------------------------------------------------------
     * importアクション
     */
    public function importAction()
    {
        // ビュースクリプトが表示されます


				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$user2index		= $this->view->modulePath.'user/index'		.$this->view->sid;
				$user2import	= $this->view->modulePath.'user/import'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'ユーザ管理'		,'url'=>$user2index ),
									array('name'=>'一括読込'			,'url'=>$user2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$user2index		= $this->view->modulePath.'user/index'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'	,'url'=>$user2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }




    /**-------------------------------------------------------------------------------------------
     * uploadアクション
     */
    public function uploadAction()
    {



//var_dump("upload_1");
        // ビュースクリプトが表示されます

				define('UPLOAD_ERROR_OK', '0');

        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"]))
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"]))
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}

				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
//var_dump("upload_2");
//var_dump($fileName);
				while(!feof($file)){

				    $str = fgetcsv($file);
//var_dump($str);
						if( $str[0]=="氏名" ) continue;
						if( $str[3]=="" ) 		continue;

						$data = array(
											'user_name'		=> $str[0],
											'user_kana'		=> $str[1],
											'group_name'	=> $str[3],
											'job_name'		=> $str[4],
											'tel'					=> $str[5],
											'email'				=> $str[7],
											'kind'				=> '0',
											'delete_flg'	=> '0',
											'create_date'	=> NULL
											);

						// グループＩＤを取得する
						$groupId = $this->_user->getGroupId( $data['group_name'] );
						if( $groupId <= 6 ){
								$data['kind'] = '1';
						}else{
								$data['kind'] = '2';
						}
						$jobId	 = $this->_user->getJobId( $data['job_name'] );
						$role		 = $str[9];
						$deleteType = '0';
//var_dump($grouId);
//var_dump($jobId);
//var_dump($data);

    				if( $this->_user->registUser( $data, $groupId, $jobId, $role, $deleteType ) == 0 ){
								echo '中止 ';
						}
				}


				 // menuが、二重化する？
		     $targetUrl = '/user/index/sid/'.$this->_sid;
         return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }
























    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }




}
