<?php
/**
 * メンバーモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';




class memberModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);
				
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * メンバー情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getMemberPage( $find, $bGraduate = false )
    {
				
        // ユーザ情報を取得する
        //if ($find == null)
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select = $select->from( 'm_member' );
						$select->where( 'delete_flg  = ?', '0' );
						if( $bGraduate )
								$select->where( 'kind = ?', '1' );				// AND
						else
								$select->where( 'kind = ?', '0' );				// AND
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
								// Zend_Db_Selectオブジェクトを作成する
								$select = $this->_db->select();
								// from() メソッドを追加する
								$select = $select->from( 'm_member' );
								$select->where( 'delete_flg  = ?', '0' );				// AND
								if( $bGraduate )
										$select->where( 'kind = ?', '1' );				// AND
								else
										$select->where( 'kind = ?', '0' );				// AND
						
						if( $find['s_group'] !='0' )
								$select->where( 'group_id  = ?', $find['s_group'] );
						if( $find['s_grade'] !='0' )
								$select->where( 'grade  = ?',   $find['s_grade'] );
						if( $find['s_class'] !='0' )
								$select->where( 'class_id  = ?',   $find['s_class'] );
						if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$select->where( 'start_year = ?', $styear );
						}
						if( isset($find['s_edyear']) && $find['s_edyear'] !='0' ){
								$edyear = $find['s_edyear']+1;
								$edyear = $edyear.'-03-31';
								$select->where( 'end_year = ?', $edyear );
						}
						if( isset($find['s_state']) && $find['s_state'] !='0' ){
								$select->where( 'conditions = ?', $find['s_state'] );
						}
						
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='member_name' || $find['s_field'] =='member_kana' )
									$select->where( $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
								if( $find['s_field'] =='member_id'  )
									$select->where( $find['s_field'] .' = ?',   $find['s_keyword'] );
							}
						
						$strReg = getRegStr($find['s_kana']);
						if( $strReg != '' ) {
								$select->where( 'member_kana REGEXP ?', $strReg );		// AND
								$select->order( 'member_kana' );
						}

        }	
				
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
				$userInfo = $select;
				
				
				return $userInfo;
			

		}



    /**-------------------------------------------------------------------------------------------
     * メンバー情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getMember2Page( $find, $bGraduate = false )
    {
				
        // ユーザ情報を取得する
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();

				
				$column = array( 't1.member_id', 't1.member_name', 't1.group_id', 't1.grade', 't1.start_year', 'MAX(t2.date) AS count'   );
				$table  = array( 't1' => 'm_member' );
				$select->from( $table, $column );
				

				$column = array( 't2.modified_date'  );
				$table  = array( 't2' => 'm_learning' );
				$select->joinLeft( $table, 't1.member_id = t2.member_id', $column );

				$select->group( 't2.member_id' );
				$select->group( 't1.member_name' );

				$select->where( 't1.delete_flg  = ?', '0' );
				if( $bGraduate )
						$select->where( 'kind = ?', '1' );				// AND
				else
						$select->where( 'kind = ?', '0' );				// AND

				$select->order( 't1.member_id' );

				
				
        if ($find != null)
				{
        // 検索項目が指定されていれば条件指定
						
						
						if( $find['s_group'] !='0' )
								$select->where( 't1.group_id  = ?', $find['s_group'] );
						if( $find['s_grade'] !='0' )
								$select->where( 't1.grade  = ?',   $find['s_grade'] );
						if( $find['s_class'] !='0' )
								$select->where( 't1.class_id  = ?',   $find['s_class'] );
						if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$select->where( 't1.start_year = ?', $styear );
						}
						
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='member_name' || $find['s_field'] =='member_kana' )
									$select->where( 't1.'.$find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							}
						
						$strReg = getRegStr($find['s_kana']);
						if( $strReg != '' ) {
								$select->where( 't1.member_kana REGEXP ?', $strReg );		// AND
								$select->order( 't1.member_kana' );
						}
						
						
        }	


						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}

				
				$userInfo = $select;
				
				
				
				return $userInfo;
			

		}




    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getMemberId($memberId)
    {
        // ユーザ情報を取得する
        if ($memberId === null) {
						$select = $this->_db->select()->from( 'm_member' );
		        $userInfo = $this->_db->fetchAll($select);
						
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 'm_member' );
						$select->where( 'member_id  = ?', $memberId );
		        $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registMember( $info, $groupId, $classId, $grade, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['member_id'] == null ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredMember($info['member_id']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('member_id'   => $info['member_id'],
                      'member_name' => $info['member_name'],
                      'member_kana' => $info['member_kana'],
                      'group_id' 		=> $groupId,
                      'class_id'    => $classId,
                      'grade'       => $grade,
                      'start_year'  => $info['start_year'],
                      'end_year'    => $info['end_year'],
                      'school_name' => $info['school_name'],
                      'sex' 				=> $info['sex'],
                      'delete_flg'	=> $deleteType
                );
				
				
				// ユーザ情報を登録する
				$this->_db->insert('m_member', $data );
			  // 登録したデータの member_id を取得する
				$lastId = $this->_db->lastInsertId();
				
	      return $lastId;
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteMember($userId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 'm_member', $data, 'member_id = ' . $userId );
				
   }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateMember( $info, $memberId, $groupId, $grade, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array('member_name' 	=> $info['member_name'],
                      'member_kana' 	=> $info['member_kana'],
                      'start_year'		=> $info['start_year'],
                      'end_year'     	=> $info['end_year'],
                      'group_id'  		=> $groupId,
                      'grade' 	 			=> $grade,
                      'school_name' 	=> $info['school_name'],
                      'sex' 					=> $info['sex'],
 							        'kind'					=> $info['kind'],
							        'conditions'		=> $info['state'],
                			'delete_flg'		=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 'm_member', $data, 'member_id = ' . $memberId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を一括進級する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function upgradeMember( $info, $memberArray, $deleteType )
    {
        // 更新データを連想配列にする
        $grade			= $info['grade'];			
        $condition	= $info['state'];	
				
				if( $grade == '6' ){
						$kind			= '1';
						
						foreach( $memberArray as $member ){
									
							$data = array(
                     			  'end_year'  	=> $info['end_year'],
							              'kind'				=> $kind,			
							              'grade'				=> $grade,		
							              'conditions'	=> $condition	
							        );
							$target = array(
														'member_id = '	 . $member
											);
							
							// データを更新する
							$this->_db->update( 'm_member', $data, $target );
						}
				} elseif ( $grade == '2' ){
						foreach( $memberArray as $member ){
									
							$data = array(
							              'grade'				=> $grade,		
							              'group_id'		=> $info['group'],	
							              'class_id'		=> $info['class'],	
							              'conditions'	=> $condition	
							        );
							$target = array(
														'member_id = '	 . $member
											);
							
							// データを更新する
							$this->_db->update( 'm_member', $data, $target );
						}
				} else {
						foreach( $memberArray as $member ){
									
							$data = array(
							              'grade'				=> $grade,		
							              'conditions'	=> $condition	
							        );
							$target = array(
														'member_id = '	 . $member
											);
							
							// データを更新する
							$this->_db->update( 'm_member', $data, $target );
						}
				}
		
    }








    /**-------------------------------------------------------------------------------------------
     * 指定されたフィードURLが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredMember($memberId)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_member', 'COUNT(*) AS cnt' );
				$select->where( 'member_id  = ?', $memberId );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * ユーザ認証を行う（未使用）
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isAuthValid($userId, $password)
    {
				
				$sql = $this->_db->select()->from( 't_user', 'role' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'password  = ?', $password );
				$sql->where( 'delete_flg  = ?', '0' );
        $ret = $this->_db->fetchOne($sql);
        return ($ret != null) ? $ret : false;
        
    }







    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getClassId( $grade,$groupId,$classId=null )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_class', 'class_id' );
				$select->where( 'group_id  = ?', $groupId );
				$select->where( 'grade  = ?', $grade );
				if( $grade ==1 && $classId != null ){
					$select->where( 'class_id  = ?', $classId );
				}
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
			
    }





    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($className)
    {
				
				$groupId = STAFF_ID;				//staff
				switch( $className ){
					case 'M':
						$groupId = 2;		break;
					case 'E':
						$groupId = 3;		break;
					case 'S':
						$groupId = 4;		break;
					case 'C':
						$groupId = 5;		break;
					default:
						$groupId = 1;		break;
				}
				return $groupId;
			
    }



    /**-------------------------------------------------------------------------------------------
     * メンバーの名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getMemberName($memberId)
    {


        // グループ名称を取得する
        if ($memberId === null) {
						
						$groupName = 'noFindName';
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_member', 'member_name' );
						$sql->where( 'member_id  = ?', $memberId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }






    /**-------------------------------------------------------------------------------------------
     * メンバーの学年を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getMemberGrade($memberId)
    {
        // 学年を取得する
        if ($memberId === null) {
						
						$grade = '0';
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_member', 'grade' );
						$sql->where( 'member_id  = ?', $memberId );
						
        		$grade = $this->_db->fetchOne($sql);
						
        }
        return $grade;

    }






    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }




    /**-------------------------------------------------------------------------------------------
     * 職名ＩＤを取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getJobId($jobName)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_job', 'job_id' );
				$select->where( 'job_name  = ?', $jobName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }


    /**-------------------------------------------------------------------------------------------
     * 職名を取得する
     *
     * @param	 int		$jobId			職名ＩＤ
     * @return string $jobName		職名
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getJobName($jobId)
    {
				
        // 職名を取得する
        if ($jobId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_job', 'job_name' );
						
						$jobName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_job', 'job_name' );
						$sql->where( 'job_id  = ?', $jobId );
						
        		$jobName = $this->_db->fetchOne($sql);
						
        }
        return $jobName;
				
    }




    /**-------------------------------------------------------------------------------------------
     *  指定されたユーザが利用できる検索条件に妥当なメンバーかどうかチェックする
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isValidateMember( $userId, $chiefArray )
    {
				
 				if( $userId == null || $chiefArray == null ){
            return false;
        }
				
				
		    		return true;
        
    }





}