<?php
/**
 * Loginコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Auth_Adapter_DbTable'); 
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Session'); 
Zend_Loader::loadClass('Zend_Registry'); 
Zend_Loader::loadClass('Zend_Session_Exception'); 


// モデルをロードする
require_once '../application/vers/default/models/aclModel.php';


// モジュールをロードする





class LoginController extends Zend_Controller_Action
{
    const ACL_RESOURCE = 'adminPage'; // このページのACLリソース定義
    private $_isLogin;                // ログインフラグ
    private $_config;                 // システム設定情報
    private $_sessionId;    					// セッションID
    private $_sid;

    private $_acl;                   	// aclモデルのインスタンス
    private $_namespace;
    private $_session;

    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{
        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');
				
        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');
				
        // ACL情報管理モデルのインスタンスを生成する
        $this->_acl = new aclModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel 	= $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  	= $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
		}




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
        // 初期化処理
        $isError  = false;
        $errorMsg = '';
        $errMsg = array();

        // 前アクションでエラーならメッセージを表示する
        if ($this->_getParam('errorMsg') != '') {
            $isError  = true;
            $errorMsg = $this->_getParam('errorMsg');
						$errMsg[] = $errorMsg;
        }
        $this->view->isError   = $isError;
        $this->view->errorMsg  = $errMsg;

				
				array_push($errors, $errMsg );
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。

				$this->view->user_id		= '';
				$this->view->password		= '';

				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
   }




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function index2Action()
    {
				$errors = array();
        // 初期化処理
        $isError  = false;
        $errorMsg = '';
        $errMsg = array();

        // 前アクションでエラーならメッセージを表示する
        if ($this->_getParam('errorMsg') != '') {
            $isError  = true;
            $errorMsg = $this->_getParam('errorMsg');
						$errMsg[] = $errorMsg;
        }
        $this->view->isError   = $isError;
        $this->view->errorMsg  = $errMsg;

				
				array_push($errors, $errMsg );
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。

				$this->view->user_id		= '';
				$this->view->password		= '';

				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
   }




    /**-------------------------------------------------------------------------------------------
     * authアクション
     * ：ユーザー認証を行なう
     */
    public function authAction()
    {
        // パラメータからデータを取得する
        $userId    = $this->_getParam('input_username');
        $password  = $this->_getParam('input_password');
        $targetUrl = 'top';
				
				$this->view->user_id		= $userId;
        // エラーなら入力画面にもどる
        if ($userId == '' || $password == '') {
						
            $this->_setParam('errorMsg', 'ユーザーIDまたはパスワードが違います。　　　　　　');
            $this->_forward('index');
            return;
        }



        // データベースの接続パラメータを定義する
        $params = array('host'     => $this->_config->datasource->database->host,
                        'username' => $this->_config->datasource->database->username,
                        'password' => $this->_config->datasource->database->password,
                        'dbname'   => $this->_config->datasource->database->name
                  );
				
        // データベースアダプタを作成する
        $db = Zend_Db::factory($this->_config->datasource->database->type, $params);
				$db->query("set names 'utf8'");
				
        // データベース認証アダプタを作成する
        $auth = new Zend_Auth_Adapter_DbTable($db, 't_user', 'login_id', 'password','MD5(?)');
				
        // 認証処理を実行する
        $auth->setIdentity($userId);
        $auth->setCredential($password);
        $result = $auth->authenticate();
        // 認証失敗であれば入力画面にもどる
        if (!$result->isValid()) {
					
			    $errCode = $result->getCode();
			    switch ($errCode) {
			        case Zend_Auth_Result::FAILURE_IDENTITY_NOT_FOUND:
			            $contents = 'このユーザは存在しません　　　　　　　　　　　　　　　　';
			            break;
							
			        case Zend_Auth_Result::FAILURE_CREDENTIAL_INVALID:
			            $contents = 'パスワードが間違っている可能性があります　　　　　　　　';
			            break;
							
			        default:
			            $contents = 'ユーザ認証に失敗しました　　　　　　　　　　　　　　　　';
			            break;
			    }
				
            $this->_setParam('errorMsg', $contents );
            $this->_forward('index');
            return;
        }
				
   		  $userData = $auth->getResultRowObject('delete_flg');
        if( $userData->delete_flg != '0' ) {
			     $contents = 'このユーザは存在しません　　　　　　　　　　　　　　　　';
						
           $this->_setParam('errorMsg', $contents );
            $this->_forward('index');
            return;
				}
				
				
   		  	$userData = $auth->getResultRowObject('user_id');
					$user_id = $userData->user_id;
				
					// ログインユーザ情報のチェック
					if( $this->_acl->isLoginUser($user_id) )
					{
			     	$contents = 'このユーザは既にログインしています_'. $user_id;
           	$this->_setParam('errorMsg', $contents );
           	$this->_forward('index');
            return;
					}

				Zend_Session::regenerateId();
				$sid = 's'.Zend_Session::getId();								// 'Session namespace must not start with a number'
        $session2 = new Zend_Session_Namespace($sid);
				$session2->setExpirationSeconds( $this->_config->global->sessionSec );
				
   		  	$userData = $auth->getResultRowObject('user_id');
					$user_id = $userData->user_id;
        $this->_namespace->userId   = $userData->user_id;
        $session2->userId    				= $userData->user_id;
   		  	$userData = $auth->getResultRowObject('role');
        $this->_namespace->userLevel = $userData->role;
        $session2->userLevel 				 = $userData->role;
  		  	$userData = $auth->getResultRowObject('user_name');
				$this->_namespace->userName = htmlspecialchars($userData->user_name);
				$session2->userName 				= htmlspecialchars($userData->user_name);
				
				
				// ログインユーザ情報の登録
				$this->_acl->registLoginUser($user_id);
				
        // 呼び出し元のコントローラへ転送する
        $targetUrl = 'top/index/sid/'. $sid;
        return $this->_redirect($targetUrl);
				
    }




    /**-------------------------------------------------------------------------------------------
     * logoutアクション
     */
    public function logoutAction()
    {
				
			
        $targetUrl = '';
				$sid = '';
				
				{
						
						$sid = $this->_sessionId;
		        // ユーザーレベルを取得する
						if( isset($sid) ){
								
								if( Zend_Session::namespaceIsset($sid) ){			// $session != null 
        						$session2 = new Zend_Session_Namespace($sid);
        						$userId		= $session2->userId;
										
										// ログインユーザ情報の削除
										$this->_acl->deleteLoginUser($userId);
										
										
        						Zend_Session::namespaceUnset($sid);
										
		if( $this->_config->global->debugOn )
            				$this->_setParam('errorMsg', 'ログアウトに成功。'.$sid);
								}
								else{
		if( $this->_config->global->debugOn )
            				$this->_setParam('errorMsg', 'ログアウトに失敗１。'.$sid);
								}
						}
						else{
		if( $this->_config->global->debugOn )
            				$this->_setParam('errorMsg', 'ログアウトに失敗２。'.$sid);
						}
				}
				
				
				$this->view->user_id		= '';
        // ビュースクリプトが表示されます
        $this->_namespace->userId    = '';
        $this->_namespace->userLevel = 'guest';
				$this->_namespace->userName  = '';
				
				
        return $this->_forward('index');
   }



    /**-------------------------------------------------------------------------------------------
     * loginアクション
     */
    public function loginAction()
    {
				
				
        // ビュースクリプトが表示されます
    }



    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
				
				
        // ビュースクリプトが表示されます
    }




}
