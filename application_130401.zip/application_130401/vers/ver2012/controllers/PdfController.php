<?php
/**
 * Pdfコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する
Zend_Loader::loadClass('Zend_Pdf'); // 追加する

// モデルをロードする
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/subjectModel.php';
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/learnModel.php';
require_once '../application/vers/default/models/employModel.php';
require_once '../application/vers/default/models/supportModel.php';
require_once '../application/vers/default/models/requireModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class PdfController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_learn;					// ラーニングモデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
    private $_member;					// メンバーモデルのインスタンス
    private $_subject;				// サブジェクトモデルのインスタンス
    private $_employ;					// エンプロイモデルのインスタンス
    private $_support;				// サポートモデルのインスタンス
    private $_require;				// リクイァモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{
				
        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');
				
        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');
				
        // ユーザモデルのインスタンスを生成する
        $this->_learn  	= new learnModel('../application/lib/member.db');
        $this->_subject	= new subjectModel('../application/lib/member.db');
        $this->_user 		= new userModel('../application/lib/user.db');
        $this->_member 	= new memberModel('../application/lib/member.db');
        $this->_employ	= new employModel('../application/lib/user.db');
        $this->_support	= new supportModel('../application/lib/user.db');
        $this->_require	= new requireModel('../application/lib/user.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				
		}



    /**-------------------------------------------------------------------------------------------
     * viewアクション
     *--------------------------------------------------------------------------------------------
     */
    public function viewAction()
    {
				
				$file 		= $this->getRequest()->getParam('file');
				$this->view->pdf		= $file;
		}





    /**-------------------------------------------------------------------------------------------
     * viewirアクション
     *--------------------------------------------------------------------------------------------
     */
    public function viewirAction()
    {
				
				if( $this->getRequest()->isGet() )
					{
						
						$commId	= $this->getRequest()->getParam('comm_id');
						$userId	= $this->getRequest()->getParam('user_id');
				}
				
				$file 		= $this->getRequest()->getParam('file');
				$this->view->pdf		= $file;
		}






    /**-------------------------------------------------------------------------------------------
     * enrollpageアクション（表pdf作成）２・３年生
     *--------------------------------------------------------------------------------------------
     */
    public function enrollpageAction( )
    {
				
				if( $this->getRequest()->isGet() ){
					
					$memberId		= $this->getRequest()->getParam('member_id','0');
					
					$maxNumber	= $this->_learn->countMemberLearn( $memberId );
					
				}
				$fileName = $memberId .'.pdf';
				$fileName = 'ananfd_'. $memberId .'.pdf';
				
					// 文字コードをUTF-8に設定する
					iconv_set_encoding('internal_encoding', 'UTF-8');
					
					
					
					// インスタンスを生成する
					$pdf = new Zend_Pdf();
					
					$maxBrock	= $this->_member->getMemberGrade($memberId);
					//$maxBrock = 3;
					for( $brock = 1; $brock <= $maxBrock; $brock++ ){
							if( $brock == 1 ){
									/** １ブロック（ 1～ 4回目) */
									$brock 	= 1;
									$gradeArray = array();
									$number = 1;
									$max		= $this->_learn->countMemberLearnGrade( $memberId, array( $brock ) );
									if( $max > 4 )	$max = 4;
				   				$this->enrollframeAction( $pdf, $brock, true );
									for( $idx = 1; $idx <=$max; $idx++, $number++ ){
				   					$this->enrolltextAction( $pdf, $brock, $memberId, $idx, $number, true );
									}
							} else {
									
									/** ２ブロック（ 5～ 8回目) */
									/** ３ブロック（ 9～12回目) */
									/** ４ブロック（13～16回目) */
									/** ５ブロック（17～20回目) */
									array_push( $gradeArray, ($brock-1) );
									$number	= $this->_learn->countMemberLearnGrade( $memberId, $gradeArray ) +1;
									$max		= $this->_learn->countMemberLearnGrade( $memberId, array( $brock ) );
									if( $max > 4 )	$max = 4;
				   				$this->enrollframeAction( $pdf, $brock );
									for( $idx = 1; $idx <=$max; $idx++, $number++ ){
				   					$this->enrolltextAction( $pdf, $brock, $memberId, $idx, $number );
									}
							}
					}
					
					
					
					// 保存 
					$pdf->save('../ananfd/docs/' .$fileName ); 
					
					// ドキュメントを出力する
					$this->view->pdf		= $fileName;
					
		}




    /**-------------------------------------------------------------------------------------------
     * enrolltextアクション（文字作成）
     *--------------------------------------------------------------------------------------------
     */
    public function enrolltextAction( $pdf, $brock, $memberId, $index = 1, $number = 1, $bFresh =false )
    {
				
				$result = $this->_learn->getLearnMemberNumber( $memberId, $number );
				if( $result['learn_id'] <= 0 ){
					
				} elseif ( $result != null && $result['learn_id'] != 0 ){
					
					$learn			= $result['learn_id'];
					
					$date2		= $result['date'];
					if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date2, $m)) {
							$date2 = ' '.$m[1] .'/'. $m[2] .'/'. $m[3] ;
					}
					
					$userName	= ' '.$this->_user->getUserName($result['user_1']);
					if( $result['user_2'] != 0 ){
							$userName	.= '、'.$this->_user->getUserName($result['user_2']) ;
					}
					
					
					
						$menu_mode ='';					//select
					$menu_findArray = array(
																	 's_kind'		=>  '1',
																	 's_group'	=>  '0',
																	 's_grade'	=>  '0',
																	 's_year'		=>  '0'
																	);
					$hoursArray		= $this->_menu->getHoursList( null, null );
					$studyArray		= $this->_menu->getStudyList( null, null );
					$statusArray	= $this->_menu->getStatusList( null, null );
					$status2Array	= $this->_menu->getStatus2List( $menu_mode, null );
					$coachArray		= $this->_menu->getCoachList( null, null );
					$groupList		= $this->_menu->getGroupList( null, $menu_findArray );
						$groupList[1] = "-";
					
						$menu_findArray['s_kind']='1';
					$club1Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
						$menu_findArray['s_kind']='2';
					$club2Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
						$menu_findArray['s_kind']='3';
					$club3Array		= $this->_menu->getClubList( $menu_mode, $menu_findArray );
					
					// 1レコードの取得
					$employArray = array();
					$employ = $this->_learn->chargedEmployId( $learn );
					foreach( $employ as $row ){
						$name = $this->_employ->getEmployName($row['employ_id']);
						array_push( $employArray, array("employ_id"=>$row['id'],"name"=>$name ) );
					}
					
					// 1レコードの取得
					$supportArray = array();
					$support = $this->_learn->chargedSupportId( $learn );
					foreach( $support as $row ){
						$name = $this->_subject->getSubjectName($row['subject_id']);
						$status = $status2Array[$row['status']];
						array_push( $supportArray, array("support_id"=>$row['id'],"name"=>$name,"status"=>$status ) );
					}
					
					// 1レコードの取得
					$requireArray = array();
					$require = $this->_learn->chargedRequireId( $learn );
					foreach( $require as $row ){
						$name 	= $this->_subject->getSubjectName($row['subject_id']);
						array_push( $requireArray, 
											array("require_id"=>$row['id'],"name"=>$name,"memo"=>$row['require']) );
					}
					
				}
				
				$page		= ($brock -1) * 2 ;
				
			/** 1ページ目 */
			// 1ページを作成
					
					$font = Zend_Pdf_Font::fontWithPath('../application/lib/IPAfont00203/ipamp.ttf');				// 明朝体p
					
					$color1 = new Zend_Pdf_Color_Html('black');
					$color2 = new Zend_Pdf_Color_Html('darkseagreen');
					$color3 = new Zend_Pdf_Color_Html('white');
					
					$pdf->pages[$page]->setLineColor($color1);
					$textColor = new Zend_Pdf_Color_Html('black');
					
					
					// フォントサイズ
					$fontSize = 11;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
					$name		= $this->_member->getMemberName($memberId);
					$grade	= $this->_member->getMemberGrade($memberId);
					
					if( $index == 1 )
						{
								
								$text = '　　年　　組　　番　　氏名　' .$name ;
								$textArea = array('start' => array(3, 80),	'end'   => array(4,170)  );
							$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 0 );
							$this->drawLinePdf( $page, $pdf, array('start' => array( 4, 80), 'end'  => array( 4,170)  ), 170 );
							
							if( $bFresh == false  )
								{
								// この項目は成績情報なので、学年毎まとめて設定する
								//	$text = '９．　不合格科目の回復状況（科目名、学生の取り組み）';
									$text	= array( ' 基礎数学',' 4',' 回復' );
									$pos	= array( 0,48 );
									$this->drawTextAreaPdf9( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
									$pos	= array( 85,48 );
									$this->drawTextAreaPdf9( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
								}
						}
						
					
					/** 1ページ目 */
						$page		= ($brock -1) * 2 ;
						//$number	= ($brock -1) * 4 + 1;
					//	$text = '１．　ミーティング実施日';
							$text1 = $number ;			//$text = '１';
							$textArea = array('start' => array(6 +($index-1), 3),	'end'   => array( 6 +($index), 10)  );
						$this->drawTextAreaPdf( $page, $pdf,  $textArea,  $text1,  $fontSize, $font, $textColor, 170 );
							$text	= array( ' 2012/01/01',' 1:00',' 後藤田浩二、後藤田浩二',' ○○教官室', ''.$name );
							$text	= array( $date2, $hoursArray[$result['hours']], $userName,' ○○教員室', $name );
							$pos	= array( 6 +($index-1) );
						$this->drawTextAreaPdf1( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
					//	$text = '２．　学生生活全般について（部活、アルバイトの有無等）';
							$textArea = array('start' => array(11, ($index-1)),	'end'   => array(12, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$text	= array();	//$text	= array( ' ＜体育局＞',' ＜文化局＞',' ＜同好会＞' );
							$text[0]	= ' '.$club1Array[$result['club_1']];
							$text[1]	= ' '.$club2Array[$result['club_2']];
							$text[2]	= ' '.$club3Array[$result['club_3']];
							$pos	= array( 0+($index-1), 12 );
						$this->drawTextAreaPdf2( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 4, 0  );
					//	$text = '３．　自宅・寮での学習状況（何時間位、集中できているか等）';
							$textArea = array('start' => array(16, ($index-1)),	'end'   => array(17, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$text	= array();	//$text	= array( ' 1:00' );
							$text[0]	= $studyArray[$result['study']];
							$pos	= array( 0+($index-1), 17 );
						$this->drawTextAreaPdf3( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 4, 0  );
					//	$text = '４．　出席状況（サイボウズ出席表により確認、欠課時数を提示して自分の状況を把握させる）';
							$textArea = array('start' => array(20, ($index-1)),	'end'   => array(21, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$text	= array();	//$text	= array( ' なし' );
							$text[0]	= $statusArray[$result['status']];
							$pos	= array( 0+($index-1), 21 );
						$this->drawTextAreaPdf4( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 4, 0  );
					//	$text = '５．　進路に関する希望（ＡＣＥの内容についても希望を聞く）';
							$textArea = array('start' => array(24, ($index-1)),	'end'   => array(25, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$text	= array();	//$text	= array( ' 阿南高専専攻科',' 阿南高専専攻科',' 阿南高専専攻科',' 阿南高専専攻科' );
							$idx = 0;
							foreach( $employArray as $row ){
								$text[$idx]	= ' '.$row['name'];
								if( ($idx++)>=4 )	break;
							}
							$pos	= array( 0+($index-1), 25 );
						$this->drawTextAreaPdf5( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 4, 0  );
					//	$text = '６．　生活指導（服装、頭髪、ピアス、通学方法の確認、自転車等の登録等）';
							$textArea = array('start' => array(30, ($index-1)),	'end'   => array(31, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$text	= array();	//$text	= array( ' なし' );
							$text[0]	= $coachArray[$result['coach']];
							$pos	= array( 0+($index-1), 31 );
						$this->drawTextAreaPdf6( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 4, 0  );
					//	$text = '７．　特別な学習支援の希望・実施状況（希望・実施内容を聞く、科目担当者と協議して対応する）';
							$textArea = array('start' => array(35, ($index-1)),	'end'   => array(36, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$text	= array();	//$text	= array( ' 学習支援(対応済)',' 学習支援(対応済)',' 学習支援(未対応)',' 学習支援(未対応)' );
							$idx = 0;
							foreach( $supportArray as $row ){
								$text[$idx]	= ' '.$row['name'].'('.$row['status'].')';
								if( ($idx++)>=4 )	break;
							}
							$pos	= array( 0+($index-1), 36 );
						$this->drawTextAreaPdf7( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 4, 0  );
					//	$text = '８．　授業等に関する要望等';
							$textArea = array('start' => array(41, ($index-1)),	'end'   => array(42, ($index))	);
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 4, 20 );
							$pos	= array( 0+($index-1), 42 );
							$text	= array();	//$text	= array( ' 要望',' 要望',' 要望',' 要望' );
							$idx = 0;
							foreach( $requireArray as $row ){
								$text[$idx]	= ' '.$row['name'].'('.$row['memo'].')';
								if( ($idx++)>=4 )	break;
							}
						$this->drawTextAreaPdf8( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
					if( $bFresh )
						{
						//	$text = '９．希望学科（推薦・学力）　推薦入試希望学科：　　　　　　　　　　入学学科：';
							if( $index == 1 ){
									$text = '９．希望学科（推薦・学力）　推薦入試希望学科：'.$groupList[$result['recommend']].'　　　　入学学科：';
									$textArea = array('start' => array(47, 0), 'end'   => array(48, 4)	);
								$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
							}
								$textArea = array('start' => array(48, 27+($index-1)*36),	'end'   => array(49, 27+($index)*36)	);
							$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 170, 20 );
								$text	= array( '第１希望','第２希望','第３希望','第４希望' );
								$text	= array();
								$text[0]	= $groupList[$result['wish_1']];
								$text[1]	= $groupList[$result['wish_2']];
								$text[2]	= $groupList[$result['wish_3']];
								$text[3]	= $groupList[$result['wish_4']];
								$pos	= array(  27+($index-1)*36,50 );
							$this->drawTextAreaPdf9f( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
						}	else {
/*
						// この項目は成績情報なので、学年毎まとめて設定する
						//	$text = '９．　不合格科目の回復状況（科目名、学生の取り組み）';
							$text	= array( ' 基礎数学',' 4',' 回復' );
							$pos	= array( 0,48 );
							$this->drawTextAreaPdf9( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
							$pos	= array( 85,48 );
							$this->drawTextAreaPdf9( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
*/
						}
					
					/** 2ページ目 */
						$page		= ($brock -1) * 2 + 1;
					//	$text = '１０．　その他';
							$textArea = array('start' => array( 8+($index-1)*13, 2),	'end'   => array( 9+($index-1)*13, 7)  );
						$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text1,  $fontSize, $font, $textColor, 170 );
							$text = $result['comments'];
							$pos	= array( 8,3+($index-1)*13 );
						$this->drawTextAreaPdf10( $page, $pdf, $pos,  $text,  $fontSize, $font, $textColor, 170, 0  );
					
					
				
				return $pdf;
				
		}







    /**-------------------------------------------------------------------------------------------
     * enrollframeアクション（フレーム作成）
     *--------------------------------------------------------------------------------------------
     */
    public function enrollframeAction( $pdf, $brock, $bFresh =false )
    {
				$page		= ($brock -1) * 2 ;
				$number	= ($brock -1) * 4 + 1;
				
					// メタデータ 
					$pdf->properties['Title'] 	= 'タイトル'; 
					$pdf->properties['Subject'] = 'サブジェクト';
					$pdf->properties['Keywords'] = 'キーワード';
					$pdf->properties['Author']	= 'gotodak'; 
					$pdf->properties['CreationDate'] = "D:200903101345+09'00'";

			/** 1ページ目 */
			// 1ページを作成
					// ページを新規作成する
					$pdf->pages[] = $pdf->newPage(Zend_Pdf_Page::SIZE_A4);
					
					$font = Zend_Pdf_Font::fontWithPath('../application/lib/IPAfont00203/ipamp.ttf');			// 明朝体p
					
					// フォントを適用する
					// フォントサイズ
					$fontSize = 11;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
					// ページのサイズを取得する
					$pageHeight = $pdf->pages[$page]->getHeight();
					$pageWidth  = $pdf->pages[$page]->getWidth();
					
					// 矩形を描画する
					$color1 = new Zend_Pdf_Color_Html('black');
					$color2 = new Zend_Pdf_Color_Html('darkseagreen');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color3);
					$pdf->pages[$page]->setFillColor($color3);
					
					
					// 描画矩形の座標
					$wakuArea = array('start' => array(80,  10),
					                  'end'   => array(585, 832)
											);
					$pdf->pages[$page]->drawRectangle($wakuArea['start'][0], $wakuArea['start'][1],
					                           			   $wakuArea['end'][0], 	 $wakuArea['end'][1]
																						);
					
					$pdf->pages[$page]->setLineColor($color1);
					$pdf->pages[$page]->setFillColor($color3);
					$textColor = new Zend_Pdf_Color_Html('black');
					
					// フォントサイズ
					$fontSize = 16;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
						//$text = '学習支援ミーティング記録簿 （２・３年）';
						$text = '学習支援ミーティング記録簿 （'	.$brock. '年）';
						$textArea = array('start' => array(0, 0),	'end'   => array(2,147)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5 );
					
					// フォントサイズ
					$fontSize = 11;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);

						$text = '　　年　　組　　番　　氏名';
						$textArea = array('start' => array(3, 80),	'end'   => array(4,147)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 0 );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 4, 80), 'end'  => array( 4,170)  ), 170 );

						$text = '１．　ミーティング実施日';
						$textArea = array('start' => array(4, 0),	'end'   => array(5, 4)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					$this->drawBoxPdf(  $page, $pdf, array('start' => array( 5, 0), 'end'  => array(10, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 6, 0), 'end'  => array( 6, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 7, 0), 'end'  => array( 7, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 8, 0), 'end'  => array( 8, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 9, 0), 'end'  => array( 9, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 5, 10), 'end'  => array(10, 10)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 5, 35), 'end'  => array(10, 35)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 5, 75), 'end'  => array(10, 75)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 5,125), 'end'  => array(10,125)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array( 5,147), 'end'  => array(10,147)  ), 170 );
						$text = '回';
						$textArea = array('start' => array(5, 0),	'end'   => array(6, 10)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5  );
						$text = '実施日';
						$textArea = array('start' => array(5, 10),	'end'   => array(6, 35)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5  );
						$text = '実施時間';
						$textArea = array('start' => array(5, 35),	'end'   => array(6, 75)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5  );
						$text = '面談教員';
						$textArea = array('start' => array(5, 75),	'end'   => array(6,125)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5  );
						$text = '場所';
						$textArea = array('start' => array(5,125),	'end'   => array(6,147)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5  );
						$text = '学生';
						$textArea = array('start' => array(5,147),	'end'   => array(6,170)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 5  );
						$text = '２．　学生生活全般について（部活、アルバイトの有無等）';
						$textArea = array('start' => array(10, 0),	'end'   => array(11, 4)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf( $page, $pdf, array('start' => array(11, 0), 'end'  => array(15, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(12, 0), 'end'  => array(12, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(11, 1), 'end'  => array(15, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(11, 2), 'end'  => array(15, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(11, 3), 'end'  => array(15, 3)  ) );
						$text = '３．　自宅・寮での学習状況（何時間位、集中できているか等）';
						$textArea = array('start' => array(15, 0),	'end'   => array(16, 4)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf( $page, $pdf, array('start' => array(16, 0), 'end'  => array(19, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(17, 0), 'end'  => array(17, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(16, 1), 'end'  => array(19, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(16, 2), 'end'  => array(19, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(16, 3), 'end'  => array(19, 3)  ) );
						$text = '４．　出席状況（サイボウズ出席表により確認、欠課時数を提示して自分の状況を把握させる）';
						$textArea = array('start' => array(19, 0),	'end'   => array(20, 4)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf( $page, $pdf, array('start' => array(20, 0), 'end'  => array(23, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(21, 0), 'end'  => array(21, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(20, 1), 'end'  => array(23, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(20, 2), 'end'  => array(23, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(20, 3), 'end'  => array(23, 3)  ) );
						$text = '５．　進路に関する希望（ＡＣＥの内容についても希望を聞く）';
						$textArea = array('start' => array(23, 0),	'end'   => array(24, 4)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf( $page, $pdf, array('start' => array(24, 0), 'end'  => array(29, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(25, 0), 'end'  => array(25, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(24, 1), 'end'  => array(29, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(24, 2), 'end'  => array(29, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(24, 3), 'end'  => array(29, 3)  ) );
						$text = '６．　生活指導（服装、頭髪、ピアス、通学方法の確認、自転車等の登録等）';
						$textArea = array('start' => array(29, 0),	'end'   => array(30, 4)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf( $page, $pdf, array('start' => array(30, 0), 'end'  => array(34, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(31, 0), 'end'  => array(31, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(30, 1), 'end'  => array(34, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(30, 2), 'end'  => array(34, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(30, 3), 'end'  => array(34, 3)  ) );
						$text = '７．　特別な学習支援の希望・実施状況（希望・実施内容を聞く、科目担当者と協議して対応する）';
						$textArea = array('start' => array(34, 0),	'end'   => array(35, 4)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf( $page, $pdf, array('start' => array(35, 0), 'end'  => array(40, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(36, 0), 'end'  => array(36, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(35, 1), 'end'  => array(40, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(35, 2), 'end'  => array(40, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(35, 3), 'end'  => array(40, 3)  ) );
						$text = '８．　授業等に関する要望等';
						$textArea = array('start' => array(40, 0),	'end'   => array(41, 4)		);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf(  $page, $pdf, array('start' => array(41, 0), 'end'  => array(46, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(42, 0), 'end'  => array(42, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(41, 1), 'end'  => array(46, 1)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(41, 2), 'end'  => array(46, 2)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(41, 3), 'end'  => array(46, 3)  ) );
				if( $bFresh )
					{
						$text = '９．希望学科（推薦・学力）　推薦入試希望学科：　　　　　　　　　　入学学科：';
						$textArea = array('start' => array(47, 0), 'end'   => array(48, 4)	);
					//$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf(  $page, $pdf, array('start' => array(48, 0), 'end'  => array(54, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(49, 0), 'end'  => array(49, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(50, 0), 'end'  => array(50, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(51, 0), 'end'  => array(51, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(52, 0), 'end'  => array(52, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(53, 0), 'end'  => array(53, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(48, 26), 'end'  => array(54, 26)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(48, 62), 'end'  => array(54, 62)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(49, 80), 'end'  => array(54, 80)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(48, 98), 'end'  => array(54, 98)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(49,116), 'end'  => array(54,116)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(48,134), 'end'  => array(54,134)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(49,152), 'end'  => array(54,152)  ), 170 );
					
						$text = '（学力入試時）';
						$textArea = array('start' => array(49, 25),	'end'   => array(50, 62)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 3 );
						$text = '希望';
						$textArea = array('start' => array(49, 62),	'end'   => array(50, 80)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = ' 模擬結果';
						$textArea = array('start' => array(49, 80),	'end'   => array(50, 98)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 0 );
						$text = '希望';
						$textArea = array('start' => array(49, 98),	'end'   => array(50,116)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = ' 模擬結果';
						$textArea = array('start' => array(49,116),	'end'   => array(50,134)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 0 );
						$text = '希望';
						$textArea = array('start' => array(49,134),	'end'   => array(50,152)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = ' 模擬結果';
						$textArea = array('start' => array(49,152),	'end'   => array(50,170)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 0 );
						$text = '第１希望';
						$textArea = array('start' => array(50, 0),	'end'   => array(51, 26)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = '第２希望';
						$textArea = array('start' => array(51, 0),	'end'   => array(52, 26)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = '第３希望';
						$textArea = array('start' => array(52, 0),	'end'   => array(53, 26)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = '第４希望';
						$textArea = array('start' => array(53, 0),	'end'   => array(54, 26)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
					}
			else
					{
						$text = '９．　不合格科目の回復状況（科目名、学生の取り組み）';
						$textArea = array('start' => array(46, 0),	'end'   => array(47, 4)		);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					
					$this->drawBoxPdf(  $page, $pdf, array('start' => array(47, 0), 'end'  => array(52, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(48, 0), 'end'  => array(48, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(49, 0), 'end'  => array(49, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(50, 0), 'end'  => array(50, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(51, 0), 'end'  => array(51, 4)  ) );
					$this->drawLinePdf( $page, $pdf, array('start' => array(47, 30), 'end'  => array(52, 30)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(47, 50), 'end'  => array(52, 50)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(47, 84), 'end'  => array(52, 84)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(47, 85), 'end'  => array(52, 85)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(47,115), 'end'  => array(52,115)  ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(47,135), 'end'  => array(52,135)  ), 170 );
						$text = '不合格科目';
						$textArea = array('start' => array(47, 0),	'end'   => array(48, 30)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 3 );
						$text = '単位数';
						$textArea = array('start' => array(47, 30),	'end'   => array(48, 50)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 3 );
						$text = '回復状況';
						$textArea = array('start' => array(47, 50),	'end'   => array(48, 84)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
						$text = '不合格科目';
						$textArea = array('start' => array(47, 85),	'end'   => array(48,115)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 3 );
						$text = '単位数';
						$textArea = array('start' => array(47,115),	'end'   => array(48,135)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 3 );
						$text = '回復状況';
						$textArea = array('start' => array(47,135),	'end'   => array(48,170)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170, 4 );
					}
					
			
			/** 2ページ目 */
			// 2ページを作成
				$page		= ($brock -1) * 2 + 1;
				$number	= ($brock -1) * 4 + 1;
					// ページを新規作成する
					$pdf->pages[] = $pdf->newPage(Zend_Pdf_Page::SIZE_A4);
					
					$textArea = array('start' => array(50,  800),
					                  'end'   => array(290, 650)
					            );
					$textArea2 = array('start' => array(50, 650),
					                  'end'   => array(290, 500)
					            );
					
					// フォントを作成する
					$font = Zend_Pdf_Font::fontWithPath('../application/lib/IPAfont00203/ipamp.ttf');				// 明朝体pro
					
					// フォントを適用する
					// フォントサイズ
					$fontSize = 11;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
					// ページのサイズを取得する
					$pageHeight = $pdf->pages[$page]->getHeight();
					$pageWidth  = $pdf->pages[$page]->getWidth();
					
					// 矩形を描画する
					$color1 = new Zend_Pdf_Color_Html('black');
					$color2 = new Zend_Pdf_Color_Html('darkseagreen');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color3);
					$pdf->pages[$page]->setFillColor($color3);
					
					// 描画矩形の座標
					$wakuArea = array('start' => array(80,  10),
					                  'end'   => array(585, 832)
											);
					$pdf->pages[$page]->drawRectangle($wakuArea['start'][0], $wakuArea['start'][1],
					                              		$wakuArea['end'][0], 	 $wakuArea['end'][1]
																						);
					
					$pdf->pages[$page]->setLineColor($color1);
					$pdf->pages[$page]->setFillColor($color3);
					$textColor = new Zend_Pdf_Color_Html('black');
					
					// フォントサイズ
					$fontSize = 11;	//max:15
					$pdf->pages[$page]->setFont($font, $fontSize);
					
						$text = '１０．　その他';
						$textArea = array('start' => array(2, 0),	'end'   => array(3, 4)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor );
					$this->drawBoxPdf( $page, $pdf, array('start' => array( 3,  0), 'end'  => array(15,170)  ), 170 );
					$this->drawBoxPdf( $page, $pdf, array('start' => array(16,  0), 'end'  => array(28,170)  ), 170 );
					$this->drawBoxPdf( $page, $pdf, array('start' => array(29,  0), 'end'  => array(41,170)  ), 170 );
					$this->drawBoxPdf( $page, $pdf, array('start' => array(42,  0), 'end'  => array(54,170)  ), 170 );
					
					$this->drawLinePdf( $page, $pdf, array('start' => array( 3,  7), 'end'  => array(15,  7)   ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(16,  7), 'end'  => array(28,  7)   ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(29,  7), 'end'  => array(41,  7)   ), 170 );
					$this->drawLinePdf( $page, $pdf, array('start' => array(42,  7), 'end'  => array(54,  7)   ), 170 );
				
				return $pdf;
				
		}











    /**-------------------------------------------------------------------------------------------
     * １．　ミーティング実施日
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf1( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 170, $divNum = 0  ) 
    {
				
					$sy = $pos[0];
					$ey = $pos[0]+1;
						//$text = ' 2012/01/01';
						$textArea = array('start' => array($sy, 10),	'end'   => array($ey, 35)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 170, 0  );
						//$text = ' 1:00';
						$textArea = array('start' => array($sy, 35),	'end'   => array($ey, 75)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 170, 5  );
						//$text = ' 後藤田浩二、後藤田浩二';
						$textArea = array('start' => array($sy, 75),	'end'   => array($ey,125)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 170, 0  );
						//$text = ' ○○教官室';	
						$textArea = array('start' => array($sy,125),	'end'   => array($ey,147)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[3],  $fontSize, $font, $textColor, 170, 0  );
						//$text = ' 後藤田浩二';
						$textArea = array('start' => array($sy,147),	'end'   => array($ey,170)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[4],  $fontSize, $font, $textColor, 170, 0  );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ２．　学生生活全般について
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf2( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' ＜体育局＞';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' ＜文化局＞';
						$textArea = array('start' => array($sy+1, $sx),	'end'   => array($sy+2, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' ＜同好会＞';
						$textArea = array('start' => array($sy+2, $sx),	'end'   => array($sy+3, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 4, 0 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ３．　自宅・寮での学習状況
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf3( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' ＜体育局＞';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 10 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ４．　出席状況
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf4( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' なし';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 10 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ５．　進路に関する希望
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf5( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' 阿南高専専攻';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 阿南高専専攻';
						$textArea = array('start' => array($sy+1, $sx),	'end'   => array($sy+2, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 阿南高専専攻';
						$textArea = array('start' => array($sy+2, $sx),	'end'   => array($sy+3, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 阿南高専専攻';
						$textArea = array('start' => array($sy+3, $sx),	'end'   => array($sy+4, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[3],  $fontSize, $font, $textColor, 4, 0 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ６．　生活指導
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf6( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' なし';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 10 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ７．　特別な学習支援の希望・実施状況
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf7( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' 学習支援(対応済)';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 学習支援(対応済)';
						$textArea = array('start' => array($sy+1, $sx),	'end'   => array($sy+2, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 学習支援(対応済)';
						$textArea = array('start' => array($sy+2, $sx),	'end'   => array($sy+3, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 学習支援(対応済)';
						$textArea = array('start' => array($sy+3, $sx),	'end'   => array($sy+4, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[3],  $fontSize, $font, $textColor, 4, 0 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ８．　授業等に関する要望等
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf8( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 4, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = ' 要望';
						$textArea = array('start' => array($sy, $sx),	'end'   => array($sy+1, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 要望';
						$textArea = array('start' => array($sy+1, $sx),	'end'   => array($sy+2, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 要望';
						$textArea = array('start' => array($sy+2, $sx),	'end'   => array($sy+3, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 4, 0 );
						//$text = ' 要望';
						$textArea = array('start' => array($sy+3, $sx),	'end'   => array($sy+4, $sx+1)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[3],  $fontSize, $font, $textColor, 4, 0 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ９．　不合格科目の回復状況
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf9( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 170, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = '不合格科目';
						$textArea = array('start' => array($sy, $sx+0),	'end'   => array($sy+1, $sx+30)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 170, 3 );
						//$text = '単位数';
						$textArea = array('start' => array($sy, $sx+30),	'end'   => array($sy+1, $sx+50)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 170, 8 );
						//$text = '回復状況';
						$textArea = array('start' => array($sy, $sx+50),	'end'   => array($sy+1, $sx+84)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 170, 4 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * ９．希望学科（推薦・学力）　推薦入試希望学科
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf9f( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 170, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text = '第１希望';
						$textArea = array('start' => array($sy, $sx+0),	'end'   => array($sy+1, $sx+30)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[0],  $fontSize, $font, $textColor, 170, 0 );
						//$text = '第２希望';
						$textArea = array('start' => array($sy+1, $sx+0),	'end'   => array($sy+2, $sx+30)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[1],  $fontSize, $font, $textColor, 170, 0 );
						//$text = '第３希望';
						$textArea = array('start' => array($sy+2, $sx+0),	'end'   => array($sy+3, $sx+30)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[2],  $fontSize, $font, $textColor, 170, 0 );
						//$text = '第４希望';
						$textArea = array('start' => array($sy+3, $sx+0),	'end'   => array($sy+4, $sx+30)	);
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text[3],  $fontSize, $font, $textColor, 170, 0 );
				
		}




    /**-------------------------------------------------------------------------------------------
     * １０．　その他
     *--------------------------------------------------------------------------------------------
     */
		function drawTextAreaPdf10( $page, $pdf, $pos, $text, $fontSize, $font, $textColor, $maxColumn = 170, $divNum = 0  ) 
    {
				
					$sx = $pos[0];
					$sy = $pos[1];
						//$text1 = $number ;		//$text = '１';
						$textArea = array('start' => array( $sy, $sx),	'end'   => array( $sy+11, 169)  );
					$this->drawTextAreaPdf( $page, $pdf, $textArea,  $text,  $fontSize, $font, $textColor, 170 );
				
		}







    /**-------------------------------------------------------------------------------------------
		 * drawLinePdf
		 * ：矩形を描画する
		 *
		 * @param  object $page     ページオブジェクト
		 * @param  array  $position 描画矩形の座標
		 * @param  object $color    色オブジェクト
		 * @return void
		 */


		function drawLinePdf( $page, $pdf, $position, $maxColumn = 4 ) 
		{
			$HEIGHT		= 822 ;
			$WIDTH  	= 505 ;
			$MAXHEIGHT= 832 ;
			$MINWIDTH =  80 ;		//80+505+10
			$MAXLINE 	=  54 ;
			//$MAXCOLUMN=   4 ;
			if( ($page % 2 ) == 1 )		$MINWIDTH =  10 ;
			
			$pos['start'][0] = $MINWIDTH  + $WIDTH * $position['start'][1] / $maxColumn	;		//array(4, 0)
			$pos['start'][1] = $MAXHEIGHT - $HEIGHT* $position['start'][0] / $MAXLINE		;   //array(5, 4)
			$pos['end'][0]	 = $MINWIDTH  + $WIDTH * $position['end'][1]   / $maxColumn	;
			$pos['end'][1]	 = $MAXHEIGHT - $HEIGHT* $position['end'][0]   / $MAXLINE		;
			
					$color1 = new Zend_Pdf_Color_Html('black');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color1);
//					$pdf->pages[$page]->setFillColor($color3);
					$pdf->pages[$page]->drawLine( $pos['start'][0],$pos['start'][1],
						               $pos['end'][0],	$pos['end'][1]
						             	 );
			
			return ;
		}




    /**-------------------------------------------------------------------------------------------
		 * drawBoxPdf
		 * ：矩形を描画する
		 *
		 * @param  object $page     ページオブジェクト
		 * @param  array  $position 描画矩形の座標
		 * @param  object $color    色オブジェクト
		 * @return void
		 */
		function drawBoxPdf( $page, $pdf, $position, $maxColumn=4  ) 
		{
			$HEIGHT		= 822 ;
			$WIDTH  	= 505 ;
			$MAXHEIGHT= 832 ;
			$MINWIDTH =  80 ;		//80+505+10
			$MAXLINE 	=  54 ;
			if( ($page % 2 ) == 1 )		$MINWIDTH =  10 ;
			
			$pos['start'][0] = $MINWIDTH  + $WIDTH * $position['start'][1] / $maxColumn	;		//array(4, 0)
			$pos['start'][1] = $MAXHEIGHT - $HEIGHT* $position['start'][0] / $MAXLINE		;   //array(5, 4)
			$pos['end'][0]	 = $MINWIDTH  + $WIDTH * $position['end'][1]   / $maxColumn	;
			$pos['end'][1]	 = $MAXHEIGHT - $HEIGHT* $position['end'][0]   / $MAXLINE		;
					
					
					
					
					$color1 = new Zend_Pdf_Color_Html('black');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color1);

					$pdf->pages[$page]->drawLine( $pos['start'][0],$pos['start'][1],
						               							$pos['end'][0]	,$pos['start'][1]		);
					$pdf->pages[$page]->drawLine( $pos['end'][0]	,$pos['start'][1],
						               							$pos['end'][0]	,$pos['end'][1]		);
					$pdf->pages[$page]->drawLine( $pos['end'][0]	,$pos['end'][1],
						               							$pos['start'][0],$pos['end'][1]		);
					$pdf->pages[$page]->drawLine( $pos['start'][0],$pos['end'][1],
						               							$pos['start'][0],$pos['start'][1]		);

			
			return ;
		}






    /**-------------------------------------------------------------------------------------------
		 * drawTextAreaPdf
		 * ：文字列を矩形内に描画する
		 *
		 * @param  object $page     ページオブジェクト
		 * @param  array  $position 描画矩形の座標
		 * @param  string $text     文字列
		 * @param  int    $size     フォントサイズ
		 * @param  object $font     フォントオブジェクト
		 * @param  object $color    色オブジェクト
		 * @param  bool   $drawRect 枠描画の有無
		 * @return void
		 */
		function drawTextAreaPdf( $page, $pdf, $position, $text, $size, $font, $color, $maxColumn = 4, $divNum = 0  ) 
		{
			
			$HEIGHT		= 822 ;
			$WIDTH  	= 505 ;
			$MAXHEIGHT= 832 ;
			$MINWIDTH =  80 ;		//80+505+10
			$MAXLINE 	=  54 ;
			$drawRect = false;
			if( ($page % 2 ) == 1 )		$MINWIDTH =  10 ;
			
		  // 描画矩形の情報を整理する
			$startPosX = $MINWIDTH  + $WIDTH * $position['start'][1] / $maxColumn	;		//array(4, 0)
			$startPosY = $MAXHEIGHT - $HEIGHT* $position['start'][0] / $MAXLINE		;   //array(5, 4)
			$endPosX	 = $MINWIDTH  + $WIDTH * $position['end'][1]   / $maxColumn	;
			$endPosY	 = $MAXHEIGHT - $HEIGHT* $position['end'][0]   / $MAXLINE		;
			
		    $text = str_replace("\r\n", "\n", $text);
				
				// 矩形を描画する
				if( $drawRect )
				{
					$color1 = new Zend_Pdf_Color_Html('black');
					$color3 = new Zend_Pdf_Color_Html('white');
					$pdf->pages[$page]->setLineColor($color1);
					$pdf->pages[$page]->drawRectangle(	$position['start'][0],$position['start'][1],
						             							      	$position['end'][0],	$position['end'][1]
						             							   		);
				}
				
		    // 幅と高さを算出する
		    $areaWidth  = abs($endPosX - $startPosX) ;
		    $areaHeight = abs($endPosY - $startPosY) ;
				
		    $i = 0;
		    $textCnt = mb_strlen($text);
		    $lines   = array();
				
		    $tmpHeight = 0;
		    // 1文字ずつ処理していく
		    while ($i < $textCnt) {
						
		        $tmpWidth = 0;
		        $lineText = '';
						
						$tmpHeight += $size;
			      // 矩形の幅を超えていれば次の行へ
			      if ($tmpHeight > $areaHeight) {
			          break;
			      }
						
			      // 1行分の文字列を算出する
			      while ($tmpWidth < $areaWidth) {
								
			          // 1文字取り出す
			          $tmpChar = mb_substr($text, $i, 1);
								
			          // 改行コードの場合は次の行へ
			          if ($tmpChar == "\n") {
			              $i++;
			              break;
			          }
								
			          // 文字のグリフ番号を取得する
			          $glyph = intval(bin2hex(mb_convert_encoding($tmpChar, 'UTF-16', 'UTF-8')), 16);
								
			          // 文字の幅を取得する
			          $charWidth = $font->widthForGlyph($glyph) / $font->getUnitsPerEm() * $size;
			          $tmpWidth += (float)$charWidth;
								
			          // 矩形の幅を超えていれば次の行へ
			          if ($tmpWidth > $areaWidth) {
			              break;
			          }
			          $lineText .= $tmpChar;
			          $i++;
			      }
						
		        $lines[] = $lineText;
		    }
				if( count($lines) == 1 )
				{
						
						if( $divNum != 0 )
		    			$startPosX = $startPosX + ( $areaWidth / 2 ) - ( $tmpWidth / $divNum ) ;
						else
			    		$startPosX = $startPosX ;		//+ ( $areaWidth / 2 );
						
				}
				
		    // 色設定を適用する
		    $pdf->pages[$page]->setFillColor($color);
				
		    $posY = $startPosY;
				
		    // 1行ずつ描画する
		    foreach ($lines as $line) {
						
		        // 文字列を描画する
		        $pdf->pages[$page]->drawText($line, $startPosX, $posY - $size, 'UTF-8');
		        $posY -= $size;
		    }
			
			return $i;
			
		}






}
