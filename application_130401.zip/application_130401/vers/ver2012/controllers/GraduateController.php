<?php
/**
 * Graduateコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Controller/Action.php';

// モデルをロードする
require_once '../application/vers/default/models/commModel.php';
require_once '../application/vers/default/models/employModel.php';
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/graduateModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';





class GraduateController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_comm;						// コミッティーモデルのインスタンス
    private $_employ;					// エンプロイモデルのインスタンス
    private $_member;					// メンバーモデルのインスタンス
    private $_graduate;				// 卒業生モデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		


    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

				
        // ユーザモデルのインスタンスを生成する
        $this->_comm		= new commModel('../application/lib/user.db');
        $this->_employ	= new employModel('../application/lib/user.db');
        $this->_member 	= new memberModel('../application/lib/member.db');
        $this->_graduate= new graduateModel('../application/lib/graduate.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}


				// 指定された権限の委員会に属するユーザが登録されているかチェックする
				$permissionArray	= array( COMM_CAREER );
        // ページアクセス関連の設定をレジストリから取得する
				{
					if( isset($this->_config->allowComm->grauate) ) {
		        Zend_Registry::set('permission', $this->_config->allowComm->grauate->toArray());
		        if (Zend_Registry::isRegistered('permission')) {
								$permissionArray = $this->_config->allowComm->grauate->toArray();
							}
        	}
        }
				$userId	= $this->_userspace->userId;
				if( $this->_comm->isAllowCommUsers( $userId, $permissionArray ) == false )	
				{	
						
			      $targetUrl = '/career/index'. $this->view->sid .'/comm_id/'.$commId .'/'.DISP_MESSAGE.'/'.ERR_CAREER_ACCESS;	//'キャリア支援室のメンバーではありません。
			      return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);




		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['student']['sGroup']	= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['student']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['student']['sEdyear']	= $this->getRequest()->getParam('s_edyear');
						$this->_userspace->search['student']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['student']['sKeyword']= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['student']['sField']	= $this->getRequest()->getParam('s_field');
						$this->_userspace->search['student']['sState']	= $this->getRequest()->getParam('s_state');
				} else {
						if( !isset($this->_userspace->search['student']['sGroup']) )
							$this->_userspace->search['student']['sGroup']	= '0';
						if( !isset($this->_userspace->search['student']['sStyear']) )
							$this->_userspace->search['student']['sStyear']	= '0';
						if( !isset($this->_userspace->search['student']['sEdyear']) )
							$this->_userspace->search['student']['sEdyear']		= getNowYear(true);		// '0';
							//$this->_userspace->search['student']['sEdyear']	= '0';
						if( !isset($this->_userspace->search['student']['sKana']) )
							$this->_userspace->search['student']['sKana']		= '0';
						if( !isset($this->_userspace->search['student']['sKeyword']) )
							$this->_userspace->search['student']['sKeyword']= '';
						if( !isset($this->_userspace->search['student']['sField']) )
							$this->_userspace->search['student']['sField']	= '0';
						if( !isset($this->_userspace->search['student']['sState']) )
							$this->_userspace->search['student']['sState']	= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['student']['sGroup'];	
				$sStyear	= $this->_userspace->search['student']['sStyear'];
				$sEdyear	= $this->_userspace->search['student']['sEdyear'];
				$sKana		= $this->_userspace->search['student']['sKana'];	
				$sKeyword	=	$this->_userspace->search['student']['sKeyword'];
				$sField		=	$this->_userspace->search['student']['sField'];	
				$sState		= $this->_userspace->search['student']['sState'];	
				if( $sGroup 		=== null 
					|| 	$sStyear	=== null 
					|| 	$sEdyear	=== null 
					||	$sKana		=== null 
					||	$sState		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sStyear == "0" 
					&& $sEdyear == "0" 
					&& $sKana		== "0" 
					&& $sState  == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  '0',
																	's_styear'  =>  $sStyear,
																	's_edyear'  =>  $sEdyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  '0',
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_state'		=>  $sState
																);
						
						$select = $this->_graduate->getGraduatePage( null, $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_graduate->getGraduatePage( null, null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます

				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->edyearArray	= 
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );
				$this->view->stateArray		= $this->_menu->getConditionList( $menu_mode, null );
				
				$this->view->stateList		= $this->_menu->getConditionList( '', null );
				$this->view->edyearList		= 
				$this->view->styearList		= $this->_menu->getYearList( '', null );

				
				$this->view->selGroup		= $sGroup;
				$this->view->selStyear	= $sStyear;
				$this->view->selEdyear	= $sEdyear;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selState		= $sState;




				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$career2index		= $this->view->modulePath.'career/index'	.$this->view->sid;
				$graduate2index	= $this->view->modulePath.'graduate/index'.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'卒業生支援'	,'url'=>$career2index ),
									array('name'=>'卒業生管理'	,'url'=>$graduate2index ),
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }





    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$graduate_id = $this->getRequest()->getParam('graduate_id');
						if( $graduate_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_graduate->getGraduateId( $graduate_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['graduate_id'] != 0 ){
											
											$this->view->graduate_id	= $result["graduate_id"];	
											$this->view->member_id		= $result["member_id"];	
											$this->view->member_name	= $this->_member->getMemberName($result["member_id"]);
											$this->view->comments			= $result["comments"];	
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											$this->view->employName		= $this->_employ->getEmployName($result['employ_id']);
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
											$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
											$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null );
											$this->view->sexArray			= $this->_menu->getSexList( null, null );
											$this->view->stateArray		= $this->_menu->getConditionList( '', null );
										
										$this->view->selSex = $result['sex'];
										$this->view->attribs = array( 	'disabled'	=>  'disabled');
										$this->view->options = null;
									}
						}
				}
				else{
				}
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$career2index		= $this->view->modulePath.'career/index'	.$this->view->sid;
				$graduate2index	= $this->view->modulePath.'graduate/index'.$this->view->sid;
				$graduate2item	= $this->view->modulePath.'graduate/item/graduate_id/'.$this->view->graduate_id. '/member_id/' .$this->view->member_id. $this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'卒業生支援'	,'url'=>$career2index ),
									array('name'=>'卒業生管理'	,'url'=>$graduate2index ),
									array('name'=>$this->view->member_name	,'url'=>$graduate2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$graduate2index		= $this->view->modulePath.'graduate/index'.$this->view->sid;
				$graduate2edit		= $this->view->modulePath.'graduate/edit/graduate_id/'.$this->view->graduate_id. '/member_id/' .$this->view->member_id. $this->view->sid;
				$graduate2delete	= $this->view->modulePath.'graduate/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$graduate2index		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$graduate2edit		,'onclick'=>'' )
									);
					break;
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				case 'admin':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$graduate2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }





    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->sexArray			= $this->_menu->getSexList( null, null );
				$this->view->stateArray		= $this->_menu->getConditionList( $menu_mode, null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->attribs = array( 	'disabled'	=>  'disabled');
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$graduate_id = $this->getRequest()->getParam('graduate_id');
						if( $graduate_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_graduate->getGraduateId( $graduate_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['graduate_id'] != 0 ){
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											$this->view->graduate_id	= $result['graduate_id'];
											$this->view->member_id		= $result['member_id'];
											$this->view->member_name	= $this->_member->getMemberName($result['member_id']);
											$this->view->member_kana	= $result['member_kana'];
											
											$this->view->employName		= $this->_employ->getEmployName($result['employ_id']);
											
											$school_name	= 
											$this->view->school_name	= $result['school_name'];
											
											$employ_name	= 
											$this->view->employ_name	= $result['employName'];
											$contact_1	= 
											$this->view->contact_1		= $result['contact_1'];
											$contact_2	= 
											$this->view->contact_2		= $result['contact_2'];
											$family_name	= 
											$this->view->family_name	= $result['familyName'];
											$this->view->comments			= $result['comments'];
											$this->view->selGroup			= $result['group_id'];
											$this->view->selSex 			= $result['sex'];
											$this->view->selState			= $result['state'];	

									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						$member_id 	= $this->getRequest()->getParam('member_id');
						
						$member_name= $this->getRequest()->getParam('member_name');
						$member_kana= $this->getRequest()->getParam('member_kana');
						$group_id 	= $this->getRequest()->getParam('group_id');
						$styear 		= $this->getRequest()->getParam('styear');
						$edyear 		= $this->getRequest()->getParam('edyear');
						$school_name= $this->getRequest()->getParam('school_name');
						$sex				= $this->getRequest()->getParam('sex');


						$graduate_id 	= $this->getRequest()->getParam('graduate_id');
						$state				= $this->getRequest()->getParam('state');
						$contact_1		= $this->getRequest()->getParam('contact_1');
						$contact_2		= $this->getRequest()->getParam('contact_2');
						$employ_name	= $this->getRequest()->getParam('employ_name');
						$family_name	= $this->getRequest()->getParam('family_name');
						$comments			= $this->getRequest()->getParam('comments');
						
						$employ_name= trim($employ_name);								//半角スペースのみ
						$family_name= trim($family_name);								//半角スペースのみ
						$contact_1		= trim($contact_1);								//半角スペースのみ
						$contact_2		= trim($contact_2);								//半角スペースのみ
						$comments		= trim($comments);									//半角スペースのみ
						
						
	      		
						$msgs = validateSelect( '状態', $state);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateStringFull( 3, 30, '現進路先', $employ_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringKana( 3, 30, '住所（本人）', $contact_1);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringKana( 3, 30, '新姓（本人）', $family_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringKana( 3, 30, '連絡先', $contact_2);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						
						if (count($errors) == 0){
								
								$data = array(
													'state'				=>	$state,
													'employ_name'	=>	$employ_name,
													'contact_1'		=>	$contact_1,
													'contact_2'	 	=>	$contact_2,
													'family_name'	=>	$family_name,
													'comments'		=>	$comments,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								if( $graduate_id != NULL ){
										
			    					$this->_graduate->updateGraduate( $data, $graduate_id, '0' );
										
						        // ビュースクリプトが表示されます
								    $targetUrl = '/graduate/index/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->graduate_id	= $graduate_id;
								$this->view->member_id		= $member_id;
								$this->view->member_name	= $member_name;
								$this->view->member_kana	= $member_kana;
								$this->view->school_name	= $school_name;
								$this->view->selStyear		= $styear;
								$this->view->selEdyear		= $edyear;
								$this->view->selGroup			= $group_id;
								$this->view->selSex				= $sex;
								
								$this->view->employ_name	= $employ_name;
								$this->view->contact_1		= $contact_1;
								$this->view->contact_2		= $contact_2;	
								$this->view->family_name	= $family_name;
								$this->view->comments			= $comments;
								$this->view->selState			= $state;	
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$career2index		= $this->view->modulePath.'career/index'	.$this->view->sid;
				$graduate2index	= $this->view->modulePath.'graduate/index'.$this->view->sid;
				$graduate2item	= $this->view->modulePath.'graduate/item/graduate_id/'.$this->view->graduate_id. '/member_id/' .$this->view->member_id. $this->view->sid;
				$graduate2edit	= $this->view->modulePath.'graduate/edit/graduate_id/'.$this->view->graduate_id. '/member_id/' .$this->view->member_id. $this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'卒業生支援'	,'url'=>$career2index ),
									array('name'=>'卒業生管理'	,'url'=>$graduate2index ),
									array('name'=>$this->view->member_name	,'url'=>$graduate2item ),
									array('name'=>'編集'				,'url'=>$graduate2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$graduate2index	= $this->view->modulePath.'graduate/index'.$this->view->sid;
				$graduate2item	= $this->view->modulePath.'graduate/item/graduate_id/'.$this->view->graduate_id. '/member_id/' .$this->view->member_id. $this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$graduate2index	,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$graduate2item	,'onclick'=>'' )
									);
							break;
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				case 'admin':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$graduate2index	,'onclick'=>'' )
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }





    /**-------------------------------------------------------------------------------------------
     * employアクション
     */
    public function employAction()
    {
				
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['job']['sGroup']	= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['job']['sArea']		= $this->getRequest()->getParam('s_area');
						$this->_userspace->search['job']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['job']['sKeyword']= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['job']['sField']	= $this->getRequest()->getParam('s_field');
						
						$member		= $this->getRequest()->getParam('member_id');		
						$graduate	= $this->getRequest()->getParam('graduate_id');	
						
						$name			= $this->_member->getMemberName($member);
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['job']['sGroup']) )
							$this->_userspace->search['job']['sGroup']		= '0';
						if( !isset($this->_userspace->search['job']['sArea']) )
							$this->_userspace->search['job']['sArea']			= '0';
						if( !isset($this->_userspace->search['job']['sKana']) )
							$this->_userspace->search['job']['sKana']			= '0';
						if( !isset($this->_userspace->search['job']['sKeyword']) )
							$this->_userspace->search['job']['sKeyword']	= '';
						if( !isset($this->_userspace->search['job']['sField']) )
							$this->_userspace->search['job']['sField']		= '0';
						
						$member		= $this->getRequest()->getParam('member_id');		
						$graduate	= $this->getRequest()->getParam('graduate_id');	
						
				}
				

				$bFind = true;	


				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['job']['sGroup'];		
				$sArea		= $this->_userspace->search['job']['sArea'];		
				$sKana		= $this->_userspace->search['job']['sKana'];		
				$sKeyword	= $this->_userspace->search['job']['sKeyword'];	
				$sField		= $this->_userspace->search['job']['sField'];		
				if( $sGroup 	=== null 
					||	$sArea	=== null 
					|| 	$sKana	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sArea   == "0" 
					&& $sKana   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_area'		=>  $sArea,	
																	's_kana'	  =>  $sKana,	
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_employ->getEmployPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						
						$select = $this->_employ->getEmployPage( null );
						
				}
				
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );
				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->areaArray		= $this->_menu->getAreaList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getFieldList( null, null );
				$menu_mode ='-';
				$this->view->headArray		= $this->_menu->getAreaList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selArea		= $sArea;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
				$this->view->graduate			= $graduate;
				$this->view->member				= $member;
				$this->view->name					= $this->_member->getMemberName($member);
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
				
				
				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$career2index		= $this->view->modulePath.'career/index'	.$this->view->sid;
				$graduate2index	= $this->view->modulePath.'graduate/index'.$this->view->sid;
				$graduate2item	= $this->view->modulePath.'graduate/item/member_id/'	.$this->view->member.$this->view->sid;
				$graduate2edit	= $this->view->modulePath.'graduate/edit/member_id/'	.$this->view->member.$this->view->sid;
				$graduate2employ= $this->view->modulePath.'graduate/employ/member_id/'.$this->view->member.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'							,'url'=>$top2index ),
									array('name'=>'卒業生支援'			,'url'=>$career2index ),
									array('name'=>'卒業生管理'			,'url'=>$graduate2index ),
									array('name'=>$this->view->name	,'url'=>$graduate2item ),
									array('name'=>'編集'						,'url'=>$graduate2edit ),
									array('name'=>'卒業後就職先'		,'url'=>$graduate2employ )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);
		
		
				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
		
		
    }




    /**-------------------------------------------------------------------------------------------
     * addemployアクション
     */
    public function addemployAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$graduate	 		= $this->getRequest()->getParam('graduate_id');
						$employArray	= $this->getRequest()->getParam('employ_id');
				}
				
				if( count($employArray) == 0 ){
		        $targetUrl = '/graduate/employ/graduate_id/'. $graduate. '/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($employArray) >= 2 ){
		        $targetUrl = '/graduate/employ/graduate_id/'. $graduate. '/error/2/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($employArray) == 1 ){
						
						if( $graduate != null ){
							
			    		$this->_graduate->updateGraduateAddemploy( $graduate, $employArray );
							
			        // ビュースクリプトが表示されます
			        $targetUrl = '/graduate/edit/graduate_id/'. $graduate. '/sid/'.$this->_sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
				}
				
				
   }








    /**-------------------------------------------------------------------------------------------
     * user0アクション
     */
    public function user0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * user0Editアクション
     */
    public function user0EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
