



CREATE DATABASE IF NOT EXISTS `ananfd2011`  CHARACTER SET utf8 ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_coachen` (
`coachen_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`date` datetime NOT NULL ,
`hours` CHAR( 1 ) NOT NULL default '0' ,
`place` INT NOT NULL default '0' ,
`placeS` VARCHAR( 32 ) NOT NULL ,
`comments` text ,
`type` CHAR( 1 ) NOT NULL default '0' ,
`user_1` INT NOT NULL default '0' ,
`user_2` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_coachenmember` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`coachen` INT NOT NULL ,
`member` INT NOT NULL default '0' ,
`group_id` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_coachengroup` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`coachen` INT NOT NULL ,
`class_id` INT NOT NULL default '0' ,
`year` DATE NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;



CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_coachst` (
`coachst_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`date` datetime NOT NULL ,
`hours` CHAR( 1 ) NOT NULL default '0' ,
`place` INT NOT NULL default '0' ,
`placeS` VARCHAR( 32 ) NOT NULL ,
`comments` text ,
`type` CHAR( 1 ) NOT NULL default '0' ,
`user_1` INT NOT NULL default '0' ,
`user_2` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_coachstmember` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`coachst` INT NOT NULL ,
`member` INT NOT NULL default '0' ,
`group_id` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_coachstgroup` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`coachst` INT NOT NULL ,
`class_id` INT NOT NULL default '0' ,
`year` DATE NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;



CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_ir` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`kind` CHAR( 1 ) NOT NULL default '0' ,
`name` VARCHAR( 32 ) NOT NULL ,
`group_id` INT NOT NULL ,
`grade` INT NOT NULL ,
`start_year` DATE NOT NULL ,
`public` CHAR( 1 ) NOT NULL default '1' ,
`file` VARCHAR( 32 ) NOT NULL ,
`movie` VARCHAR( 32 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_cyllabus` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`code` INT NOT NULL ,
`name` VARCHAR( 32 ) NOT NULL ,
`start_year` DATE NOT NULL ,
`public` CHAR( 1 ) NOT NULL default '1' ,
`file` VARCHAR( 32 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_tp` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user` INT NOT NULL ,
`name` VARCHAR( 32 ) NOT NULL ,
`start_year` DATE NOT NULL ,
`public` CHAR( 1 ) NOT NULL default '0' ,
`file` VARCHAR( 32 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_tpfile` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user` INT NOT NULL ,
`year` INT NOT NULL ,
`file` VARCHAR( 32 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_learning` (
`learn_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`member_id` INT NOT NULL ,
`number` INT NOT NULL ,
`grade` INT NOT NULL ,
`date` datetime NOT NULL ,
`hours` CHAR( 1 ) NOT NULL default '0' ,
`place` INT NOT NULL default '0' ,
`club_1` INT NOT NULL default '0' ,
`club_2` INT NOT NULL default '0' ,
`club_3` INT NOT NULL default '0' ,
`study` CHAR( 1 ) NOT NULL default '0' ,
`status` CHAR( 1 ) NOT NULL default '0' ,
`coach` CHAR( 1 ) NOT NULL default '0' ,
`recommend` INT NOT NULL default '1' ,
`wish_1` INT NOT NULL default '1' ,
`wish_2` INT NOT NULL default '1' ,
`wish_3` INT NOT NULL default '1' ,
`wish_4` INT NOT NULL default '1' ,
`user_1` INT NOT NULL default '0' ,
`user_2` INT NOT NULL default '0' ,
`comments` text ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_learnemploy` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`learn_id` INT NOT NULL ,
`member_id` INT NOT NULL ,
`date` date NOT NULL ,
`employ_id` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_learnsupport` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`learn_id` INT NOT NULL ,
`member_id` INT NOT NULL ,
`date` date NOT NULL ,
`subject_id` INT NOT NULL default '0' ,
`group_id` INT NOT NULL default '0' ,
`grade_at` CHAR( 1 ) NOT NULL default '0' ,
`status` CHAR( 1 ) NOT NULL default '0' ,
`memo` VARCHAR( 128 ) ,
`user_id` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;



CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_learnrequire` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`learn_id` INT NOT NULL ,
`member_id` INT NOT NULL ,
`date` date NOT NULL ,
`subject_id` INT NOT NULL default '0' ,
`group_id` INT NOT NULL default '0' ,
`grade_at` CHAR( 1 ) NOT NULL default '0' ,
`require` VARCHAR( 128 ) ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;





CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_employment` (
`employ` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`name` VARCHAR( 32 ) NOT NULL ,
`kana` VARCHAR( 32 ) ,
`url` VARCHAR( 256 ) ,
`area` INT NOT NULL DEFAULT '0'  ,
`comments` text ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_employgroup` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`employ` INT NOT NULL ,
`group_id` INT NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;




CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_subject` (
`code` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`name` VARCHAR( 32 ) NOT NULL ,
`units` INT NOT NULL ,
`grade` INT NOT NULL ,
`term` CHAR( 1 ) NOT NULL ,
`require` CHAR( 1 ) NOT NULL ,
`start_year` DATE NOT NULL ,
`end_year` DATE NOT NULL default '9999-03-31' ,
`file` VARCHAR( 32 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_subgroup` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`code` INT NOT NULL ,
`group_id` INT NOT NULL ,
`start_year` DATE NOT NULL ,
`end_year` DATE NOT NULL default '9999-03-31' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_subuser` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`code` INT NOT NULL ,
`user_id` INT NOT NULL ,
`start_year` DATE NOT NULL ,
`end_year` DATE NOT NULL default '9999-03-31' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_subfile` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`code` INT NOT NULL ,
`year` INT NOT NULL ,
`file` VARCHAR( 32 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;



CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_graduate` (
`graduate_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`member_id` INT NOT NULL ,
`employ_id` INT NOT NULL ,
`state` CHAR( 1 ) NOT NULL default '0' ,
`employName` VARCHAR( 64 ) NOT NULL ,
`employKana` VARCHAR( 64 ) ,
`employUrl` VARCHAR( 256 ) ,
`employArea` INT NOT NULL DEFAULT '0'  ,
`contact_1` VARCHAR( 64 ) ,
`contact_2` VARCHAR( 64 ) ,
`address` VARCHAR( 64 ) ,
`familyName` VARCHAR( 32 ) ,
`comments` text ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;





CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_user` (
`user_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user_name` VARCHAR( 32 ) NOT NULL ,
`user_kana` VARCHAR( 32 ) NOT NULL ,
`group_id` INT NOT NULL ,
`job_id` INT NOT NULL default 0 ,
`email` VARCHAR( 32 ) NOT NULL ,
`tel` VARCHAR( 16 ) NOT NULL default '' ,
`url` VARCHAR( 48 ) NOT NULL default '' ,
`kind` CHAR( 1 ) NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP ,
`create_date` timestamp NOT NULL default '0000-00-00 00:00:00'
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_user` (
`login_id` VARCHAR( 32 ) NOT NULL ,
`password` VARCHAR( 32 ) NOT NULL ,
`role` VARCHAR( 10 ) NOT NULL ,
`user_name` VARCHAR( 32 ) NOT NULL ,
`user_id` INT NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP ,
PRIMARY KEY ( `login_id` )
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`m_user` (`user_id`, `user_name`, `user_kana`, `group_id`, `job_id`, `email`, `tel`, `delete_flg`)
VALUES
    ('1'	,'admin'		,'あどみに',       '9'	,'1'	,'admin@anan-nct.ac.jp'		,'内線111'	,'f' ),
    ('2'	,'master'		,'ますたー',       '9'	,'1'	,'master@anan-nct.ac.jp'	,'内線222'	,'f' ),
    ('3'	,'manager'	,'まねーじゃー',   '9'	,'1'	,'manager@anan-nct.ac.jp'	,'内線222'	,'f' ),
    ('4'	,'teacher'	,'てぃちゃー',     '9'	,'1'	,'teacher@anan-nct.ac.jp'	,'内線222'	,'f' ),
    ('5'	,'staff'		,'すたっふ',       '9'	,'1'	,'staff@anan-nct.ac.jp'		,'内線222'	,'f' ),
    ('6'	,'user'			,'ゆーざ',      	 '9'	,'1'	,'user@anan-nct.ac.jp'		,'内線222'	,'f' ),
    ('7'	,'guest'		,'げすと',      	 '9'	,'1'	,'guest@anan-nct.ac.jp'		,'内線222'	,'f' ),
    ('8'	,'user1'		,'ゆーざ１',       '9'	,'1'	,'user1@anan-nct.ac.jp'		,'内線222'	,'f' ),
    ('9'	,'ananfd'		,'あなんえふでぃ', '9'	,'1'	,'ananfd@anan-nct.ac.jp'	,'内線333'	,'f' );
INSERT INTO `ananfd2011`.`t_user` (`login_id`, `password`, `role`, `user_name`, `user_id`)
VALUES
    ('admin'		,'5f4dcc3b5aa765d61d8327deb882cf99'	,'admin'		,'admin'		,'1'	),
    ('master'		,'5f4dcc3b5aa765d61d8327deb882cf99'	,'master'		,'master'		,'2'	),
    ('manager'	,'5f4dcc3b5aa765d61d8327deb882cf99'	,'manager'	,'manager'	,'3'	),
    ('teacher'	,'5f4dcc3b5aa765d61d8327deb882cf99'	,'teacher'	,'teacher'	,'4'	),
    ('staff'		,'5f4dcc3b5aa765d61d8327deb882cf99'	,'staff'		,'staff'		,'5'	),
    ('user'			,'5f4dcc3b5aa765d61d8327deb882cf99'	,'user'			,'user'			,'6'	),
    ('guest'		,'5f4dcc3b5aa765d61d8327deb882cf99'	,'guest'		,'guest'		,'7'	),
    ('user1'		,'5f4dcc3b5aa765d61d8327deb882cf99'	,'user'			,'user1'		,'8'	),
    ('ananfd'		,'5f4dcc3b5aa765d61d8327deb882cf99'	,'admin'		,'ananfd'		,'9'	);


/*
    ('10'	,'3'	,'0'	,'校長（副）'					),
    ('11'	,'3'	,'0'	,'教務主任（副）'			),
    ('12'	,'3'	,'0'	,'学生主任（副）'			),
    ('13'	,'3'	,'0'	,'寮務主任（副）'			),
*/


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_committee` (
`comm_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`comm_name` VARCHAR( 16 ) NOT NULL ,
`comm_kind` CHAR( 1 ) NOT NULL ,
`comm_level` CHAR( 1 ) NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`m_committee` (`comm_id`, `comm_kind`, `comm_level`, `delete_flg`, `comm_name`)
VALUES
    ('1'	,'1'	,'5'	,'0'	,'管理部門' 												),
    ('2'	,'1'	,'5'	,'0'	,'校長補佐会議'	 										),
    ('3'	,'1'	,'5'	,'0'	,'教務委員会' 											),
    ('4'	,'1'	,'0'	,'0'	,'学生委員会' 											),
    ('5'	,'1'	,'0'	,'0'	,'寮務委員会' 											),
    ('6'	,'1'	,'4'	,'0'	,'ＦＤ専門委員会' 									),
    ('7'	,'1'	,'4'	,'0'	,'キャリア支援室' 									),
    ('8'	,'1'	,'7'	,'0'	,'総合情報処理室' 									),
    ('9'	,'1'	,'4'	,'0'	,'ＦＤ高度化推進室'									),
    ('10'	,'2'	,'4'	,'0'	,'学科主任　【一般教科】'						),
    ('11'	,'2'	,'4'	,'0'	,'学科主任　【機械工学科】'					),
    ('12'	,'2'	,'4'	,'0'	,'学科主任　【電気電子工学科】'			),
    ('13'	,'2'	,'4'	,'0'	,'学科主任　【制御情報工学科】'			),
    ('14'	,'2'	,'4'	,'0'	,'学科主任　【建設システム工学科】'	),
    ('15'	,'2'	,'4'	,'1'	,'学科主任　【●●●●●●工学科】'	),
    ('16'	,'2'	,'4'	,'0'	,'学年主任　【一年】'			),
    ('17'	,'2'	,'4'	,'0'	,'学年主任　【二年】'			),
    ('18'	,'2'	,'4'	,'0'	,'学年主任　【三年】'			),
    ('19'	,'2'	,'4'	,'0'	,'学年主任　【四年】'			),
    ('20'	,'2'	,'4'	,'0'	,'学年主任　【五年】'			),
    ('21'	,'2'	,'4'	,'0'	,'学級担任　【一年１組】'	),
    ('22'	,'2'	,'4'	,'0'	,'学級担任　【一年２組】'	),
    ('23'	,'2'	,'4'	,'0'	,'学級担任　【一年３組】'	),
    ('24'	,'2'	,'4'	,'0'	,'学級担任　【一年４組】'	),
    ('25'	,'2'	,'4'	,'1'	,'学級担任　【一年●組】'	),
    ('26'	,'2'	,'4'	,'0'	,'学級担任　【二年Ｍ組】'	),
    ('27'	,'2'	,'4'	,'0'	,'学級担任　【二年Ｅ組】'	),
    ('28'	,'2'	,'4'	,'0'	,'学級担任　【二年Ｓ組】'	),
    ('29'	,'2'	,'4'	,'0'	,'学級担任　【二年Ｃ組】'	),
    ('30'	,'2'	,'4'	,'1'	,'学級担任　【二年●組】'	),
    ('31'	,'2'	,'4'	,'0'	,'学級担任　【三年Ｍ組】'	),
    ('32'	,'2'	,'4'	,'0'	,'学級担任　【三年Ｅ組】'	),
    ('33'	,'2'	,'4'	,'0'	,'学級担任　【三年Ｓ組】'	),
    ('34'	,'2'	,'4'	,'0'	,'学級担任　【三年Ｃ組】'	),
    ('35'	,'2'	,'4'	,'1'	,'学級担任　【三年●組】'	),
    ('36'	,'2'	,'4'	,'0'	,'学級担任　【四年Ｍ組】'	),
    ('37'	,'2'	,'4'	,'0'	,'学級担任　【四年Ｅ組】'	),
    ('38'	,'2'	,'4'	,'0'	,'学級担任　【四年Ｓ組】'	),
    ('39'	,'2'	,'4'	,'0'	,'学級担任　【四年Ｃ組】'	),
    ('40'	,'2'	,'4'	,'1'	,'学級担任　【四年●組】'	),
    ('41'	,'2'	,'4'	,'0'	,'学級担任　【五年Ｍ組】'	),
    ('42'	,'2'	,'4'	,'0'	,'学級担任　【五年Ｅ組】'	),
    ('43'	,'2'	,'4'	,'0'	,'学級担任　【五年Ｓ組】'	),
    ('44'	,'2'	,'4'	,'0'	,'学級担任　【五年Ｃ組】'	),
    ('45'	,'2'	,'4'	,'1'	,'学級担任　【五年●組】'	);


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_commuser` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`comm_id` INT NOT NULL ,
`user_id` INT NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`t_commuser` (`id`, `comm_id`, `user_id`, `delete_flg` )
VALUES
    ('1'	,'1'		,'10'	,'0'	),
    ('2'	,'2'		,'10'	,'0'	),
    ('3'	,'3'		,'10'	,'0'	),
    ('4'	,'4'		,'10'	,'0'	),
    ('5'	,'5'		,'10'	,'0'	),
    ('6'	,'6'		,'10'	,'0'	),
    ('7'	,'7'		,'10'	,'0'	),
    ('8'	,'8'		,'10'	,'0'	),
    ('9'	,'9'		,'10'	,'0'	),
    ('10'	,'10'		,'10'	,'0'	),
    ('11'	,'11'		,'10'	,'0'	),
    ('12'	,'12'		,'10'	,'0'	),
    ('13'	,'13'		,'10'	,'0'	),
    ('14'	,'14'		,'10'	,'0'	),
    ('15'	,'15'		,'10'	,'1'	),
    ('16'	,'16'		,'10'	,'0'	),
    ('17'	,'17'		,'10'	,'0'	),
    ('18'	,'18'		,'10'	,'0'	),
    ('19'	,'19'		,'10'	,'0'	),
    ('20'	,'20'		,'10'	,'0'	),
    ('21'	,'21'		,'10'	,'0'	),
    ('22'	,'22'		,'10'	,'0'	),
    ('23'	,'23'		,'10'	,'0'	),
    ('24'	,'24'		,'10'	,'0'	),
    ('25'	,'25'		,'10'	,'1'	),
    ('26'	,'26'		,'10'	,'0'	),
    ('27'	,'27'		,'10'	,'0'	),
    ('28'	,'28'		,'10'	,'0'	),
    ('29'	,'29'		,'10'	,'0'	),
    ('30'	,'30'		,'10'	,'1'	),
    ('31'	,'31'		,'10'	,'0'	),
    ('32'	,'32'		,'10'	,'0'	),
    ('33'	,'33'		,'10'	,'0'	),
    ('34'	,'34'		,'10'	,'0'	),
    ('35'	,'35'		,'10'	,'1'	),
    ('36'	,'36'		,'10'	,'0'	),
    ('37'	,'37'		,'10'	,'0'	),
    ('38'	,'38'		,'10'	,'0'	),
    ('39'	,'39'		,'10'	,'0'	),
    ('40'	,'40'		,'10'	,'1'	),
    ('41'	,'41'		,'10'	,'0'	),
    ('42'	,'42'		,'10'	,'0'	),
    ('43'	,'43'		,'10'	,'0'	),
    ('44'	,'44'		,'10'	,'0'	),
    ('45'	,'45'		,'10'	,'1'	);


CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_commgroup` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`comm_id` INT NOT NULL ,
`chief_type` CHAR( 1 ) NOT NULL default '0' ,
`chief_id` INT NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`t_commgroup` (`id`, `comm_id`, `chief_type`, `chief_id`, `delete_flg` )
VALUES
    ('1'	,'1'		,'4'	,'0'	,'0'	),
    ('2'	,'2'		,'4'	,'0'	,'0'	),
    ('3'	,'3'		,'4'	,'0'	,'0'	),
    ('4'	,'4'		,'4'	,'0'	,'0'	),
    ('5'	,'5'		,'4'	,'0'	,'0'	),
    ('6'	,'6'		,'4'	,'0'	,'0'	),
    ('7'	,'7'		,'4'	,'0'	,'0'	),
    ('8'	,'8'		,'4'	,'0'	,'0'	),
    ('9'	,'9'		,'4'	,'0'	,'0'	),
    ('10'	,'10'		,'1'	,'1'	,'0'	),
    ('11'	,'11'		,'1'	,'2'	,'0'	),
    ('12'	,'12'		,'1'	,'3'	,'0'	),
    ('13'	,'13'		,'1'	,'4'	,'0'	),
    ('14'	,'14'		,'1'	,'5'	,'0'	),
    ('15'	,'15'		,'1'	,'6'	,'0'	),
    ('16'	,'16'		,'2'	,'1'	,'0'	),
    ('17'	,'17'		,'2'	,'2'	,'0'	),
    ('18'	,'18'		,'2'	,'3'	,'0'	),
    ('19'	,'19'		,'2'	,'4'	,'0'	),
    ('20'	,'20'		,'2'	,'5'	,'0'	),
    ('21'	,'21'		,'3'	,'1'	,'0'	),
    ('22'	,'22'		,'3'	,'2'	,'0'	),
    ('23'	,'23'		,'3'	,'3'	,'0'	),
    ('24'	,'24'		,'3'	,'4'	,'0'	),
    ('25'	,'25'		,'3'	,'5'	,'0'	),
    ('26'	,'26'		,'3'	,'6'	,'0'	),
    ('27'	,'27'		,'3'	,'7'	,'0'	),
    ('28'	,'28'		,'3'	,'8'	,'0'	),
    ('29'	,'29'		,'3'	,'9'	,'0'	),
    ('30'	,'30'		,'3'	,'10'	,'0'	),
    ('31'	,'31'		,'3'	,'11'	,'0'	),
    ('32'	,'32'		,'3'	,'12' ,'0'	),
    ('33'	,'33'		,'3'	,'13' ,'0'	),
    ('34'	,'34'		,'3'	,'14' ,'0'	),
    ('35'	,'35'		,'3'	,'15' ,'0'	),
    ('36'	,'36'		,'3'	,'16' ,'0'	),
    ('37'	,'37'		,'3'	,'17' ,'0'	),
    ('38'	,'38'		,'3'	,'18' ,'0'	),
    ('39'	,'39'		,'3'	,'19' ,'0'	),
    ('40'	,'40'		,'3'	,'20' ,'0'	),
    ('41'	,'41'		,'3'	,'21' ,'0'	),
    ('42'	,'42'		,'3'	,'22' ,'0'	),
    ('43'	,'43'		,'3'	,'23' ,'0'	),
    ('44'	,'44'		,'3'	,'24' ,'0'	),
    ('45'	,'45'		,'3'	,'25' ,'0'	);


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_class` (
`class_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`class_name` VARCHAR( 10 ) NOT NULL ,
`group_id` INT NOT NULL ,
`grade` INT NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`m_class` 
(`class_id`, `class_name`, `group_id`, `grade`, `delete_flg`)
VALUES
    ('1',  '１組', '1', '1', '0'),
    ('2',  '２組', '1', '1', '0'),
    ('3',  '３組', '1', '1', '0'),
    ('4',  '４組', '1', '1', '0'),
    ('5',  '●組', '1', '1', '1'),
    ('6',  '２Ｍ', '2', '2', '0'),
    ('7',  '２Ｅ', '3', '2', '0'),
    ('8',  '２Ｓ', '4', '2', '0'),
    ('9',  '２Ｃ', '5', '2', '0'),
    ('10', '２●', '6', '2', '1'),
    ('11', '３Ｍ', '2', '3', '0'),
    ('12', '３Ｅ', '3', '3', '0'),
    ('13', '３Ｓ', '4', '3', '0'),
    ('14', '３Ｃ', '5', '3', '0'),
    ('15', '３●', '6', '3', '1'),
    ('16', '４Ｍ', '2', '4', '0'),
    ('17', '４Ｅ', '3', '4', '0'),
    ('18', '４Ｓ', '4', '4', '0'),
    ('19', '４Ｃ', '5', '4', '0'),
    ('20', '４●', '6', '4', '1'),
    ('21', '５Ｍ', '2', '5', '0'),
    ('22', '５Ｅ', '3', '5', '0'),
    ('23', '５Ｓ', '4', '5', '0'),
    ('24', '５Ｃ', '5', '5', '0'),
    ('25', '５●', '6', '5', '1');


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_group` (
`group_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`group_name` VARCHAR( 16 ) NOT NULL ,
`group_kind` CHAR( 1 ) NOT NULL ,
`start_year` DATE NOT NULL ,
`end_year` DATE NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`m_group` (`group_id`, `group_name`, `group_kind`, `start_year`, `end_year`, `delete_flg`)
VALUES
    ( '1', '一般教科'								,'1'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '2', '機械工学科'							,'1'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '3', '電気電子工学科'					,'1'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '4', '制御情報工学科'					,'1'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '5', '建設システム工学科'			,'1'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '6', '●●●●●●工学科'			,'1'	,'2009-04-01'	,'9999-04-01'	,'1'),
    ( '7', '非常勤講師'							,'2'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '8', 'teacher（教員）'				,'2'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ( '9', '寄附講座'								,'2'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ('10', 'staff（職員）'					,'2'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ('11', '総務課'									,'2'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ('12', '学生課'									,'2'	,'2009-04-01'	,'9999-04-01'	,'0'),
    ('13', '技術部'									,'2'	,'2009-04-01'	,'9999-04-01'	,'0');


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_job` (
`job_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`job_name` VARCHAR( 16 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`m_job` (`job_id`, `job_name`, `delete_flg`)
VALUES
    ( '1'	,'−'							,'0'),
    ( '2'	,'教授'						,'0'),
    ( '3'	,'准教授'					,'0'),
    ( '4'	,'講師'						,'0'),
    ( '5'	,'助教'						,'0'),
    ( '6'	,'非常勤講師'			,'0'),
    ( '7'	,'特任教授'				,'0'),
    ( '8'	,'嘱託教授'				,'0'),
    ( '9'	,'客員教授'				,'0'),
    ('10'	,'特別研究教授'		,'0'),
    ('11'	,'特別研究准教授'	,'0');


CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_club` (
`club_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`club_name` VARCHAR( 32 ) NOT NULL ,
`club_kana` VARCHAR( 32 ),
`kind` CHAR( 1 ) NOT NULL ,
`adviser_id` INT ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

INSERT INTO `ananfd2011`.`m_club` 
( `club_name`, `club_kana`, `kind`)
VALUES
    ('ソフトテニス部',		 '', '1'),
    ('テニス部', 					 '', '1'),
    ('剣道部', 						 '', '1'),
    ('サッカー部', 				 '', '1'),
    ('バスケットボール部', '', '1'),
    ('硬式野球部',				 '', '1'),
    ('卓球部',						 '', '1'),
    ('陸上競技部',				 '', '1'),
    ('バレーボール部',		 '', '1'),
    ('ラグビー部',				 '', '1'),
    ('柔道部',						 '', '1'),
    ('弓道部',						 '', '1'),
    ('バドミントン部',		 '', '1'),
    ('ハンドボール部',		 '', '1'),
    ('ソフトボール部',		 '', '1'),
    ('写真部',						 '', '2'),
    ('落語研究部',				 '', '2'),
    ('軽音楽部',					 '', '2'),
    ('吹奏楽部',					 '', '2'),
    ('茶道部',						 '', '2'),
    ('ロボット研究部',		 '', '2'),
    ('書道部',						 '', '2'),
    ('碁道部',						 '', '2'),
    ('ボランティア部',		 '', '2'),
    ('演劇部',						 '', '2'),
    ('沖縄文化交流会',		 '', '3'),
    ('コンクリート研究会', '', '3'),
    ('プログラミング',		 '', '3'),
    ('工作・オーディオ',	 '', '3'),
    ('化学',							 '', '3'),
    ('Street Dance',			 '', '3'),
    ('構造デザイン',			 '', '3'),
    ('ラジオ無線',				 '', '3'),
    ('自動車',						 '', '3'),
    ('Lego',							 '', '3'),
    ('水泳',							 '', '3'),
    ('ワンダーフォーゲル', '', '3'),
    ('物理学',						 '', '3'),
    ('英会話',						 '', '3'),
    ('美術',							 '', '3'),
    ('空手道',						 '', '3');



CREATE TABLE IF NOT EXISTS `ananfd2011`.`t_login` (
`user_id` INT NOT NULL PRIMARY KEY ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP 
) ENGINE = InnoDB  ;

CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_member` (
`member_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`member_name` VARCHAR( 32 ) NOT NULL ,
`member_kana` VARCHAR( 32 ) NOT NULL ,
`group_id` INT NOT NULL ,
`class_id` INT NOT NULL default 0 ,
`grade` INT NOT NULL ,
`start_year` DATE NOT NULL ,
`end_year` DATE NOT NULL default '9999-03-31' ,
`school_name` VARCHAR( 32 ) NOT NULL ,
`sex` CHAR( 1 ) NOT NULL default '0' ,
`kind` CHAR( 1 ) NOT NULL default '0' ,
`dormitory_state` CHAR( 1 ) NOT NULL default '0' ,
`director_state` CHAR( 1 ) NOT NULL default '0' ,
`conditions` CHAR( 1 ) NOT NULL default '0' ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP ,
`create_date` timestamp NOT NULL default '0000-00-00 00:00:00'
) ENGINE = InnoDB  ;







CREATE TABLE IF NOT EXISTS `ananfd2011`.`m_acl` (
`acl_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`module` VARCHAR( 30 ) NOT NULL ,
`controller` VARCHAR( 30 ) NOT NULL ,
`action` VARCHAR( 30 ) NOT NULL ,
`resource` VARCHAR( 30 ) NOT NULL ,
`delete_flg` CHAR( 1 ) NOT NULL default '0' ,
`modified_date` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
) ENGINE = InnoDB  ;



INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'index'				,'index'			,'anonPage'				,'0'),
    ('default'	,'index'				,'user'				,'userPage'				,'0'),
    ('default'	,'index'				,'admin'			,'adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'error'				,'error'			,'anonPage'				,'0'),
		
    ('default'	,'login'				,'index'			,'anonPage'				,'0'),
    ('default'	,'login'				,'auth'				,'anonPage'				,'0'),
    ('default'	,'login'				,'logout'			,'anonPage'				,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'top'					,'index'			,'anonPage'				,'0'),
    ('default'	,'top'					,'password'		,'anonPage'				,'0'),
    ('default'	,'top'					,'userinfo'		,'anonPage'				,'0'),
    ('default'	,'top'					,'dump'				,'anonPage'				,'0'),
    ('default'	,'top'					,'image'			,'anonPage'				,'0'),
    ('default'	,'top'					,'auth'				,'anonPage'				,'0'),
    ('default'	,'top'					,'initpass'		,'userPage'				,'0'),
    ('default'	,'top'					,'user'				,'userPage'				,'0'),
    ('default'	,'top'					,'adduser'		,'userPage'				,'0'),
    ('default'	,'top'					,'deluser'		,'userPage'				,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'learning'			,'index'			,'userPage'				,'0'),
    ('default'	,'learning'			,'user'				,'userPage'				,'0'),
    ('default'	,'learning'			,'item'				,'userPage'				,'0'),
    ('default'	,'learning'			,'edit'				,'userPage'				,'0'),
    ('default'	,'learning'			,'new'				,'userPage'				,'0'),
    ('default'	,'learning'			,'delete'			,'userPage'				,'0'),
    ('default'	,'learning'			,'employ'			,'userPage'				,'0'),
    ('default'	,'learning'			,'support'		,'userPage'				,'0'),
    ('default'	,'learning'			,'require'		,'userPage'				,'0'),
    ('default'	,'learning'			,'addemploy'	,'userPage'				,'0'),
    ('default'	,'learning'			,'addsupport'	,'userPage'				,'0'),
    ('default'	,'learning'			,'addrequire'	,'userPage'				,'0'),
    ('default'	,'learning'			,'delemploy'	,'userPage'				,'0'),
    ('default'	,'learning'			,'delsupport'	,'userPage'				,'0'),
    ('default'	,'learning'			,'delrequire'	,'userPage'				,'0'),
    ('default'	,'learning'			,'member'			,'userPage'				,'0'),
    ('default'	,'learning'			,'adduser'		,'userPage'				,'0'),
    ('default'	,'learning'			,'delete'			,'userPage'				,'0'),
    ('default'	,'learning'			,'job'				,'userPage'				,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'support'			,'index'			,'teacherPage'			,'0'),
    ('default'	,'support'			,'student'		,'teacherPage'			,'0'),
    ('default'	,'support'			,'teacher'		,'teacherPage'			,'0'),
    ('default'	,'support'			,'addstudent'	,'teacherPage'			,'0'),
    ('default'	,'support'			,'addteacher'	,'teacherPage'			,'0'),
    ('default'	,'support'			,'delstudent'	,'teacherPage'			,'0'),
    ('default'	,'support'			,'delteacher'	,'teacherPage'			,'0'),
    ('default'	,'support'			,'subject'		,'teacherPage'			,'0'),
    ('default'	,'support'			,'sumup'			,'teacherPage'			,'0'),
    ('default'	,'support'			,'item'				,'teacherPage'			,'0'),
    ('default'	,'support'			,'edit'				,'teacherPage'			,'0'),
		
    ('default'	,'require'			,'index'			,'teacherPage'			,'0'),
    ('default'	,'require'			,'student'		,'teacherPage'			,'0'),
    ('default'	,'require'			,'teacher'		,'teacherPage'			,'0'),
    ('default'	,'require'			,'addstudent'	,'teacherPage'			,'0'),
    ('default'	,'require'			,'addteacher'	,'teacherPage'			,'0'),
    ('default'	,'require'			,'delstudent'	,'teacherPage'			,'0'),
    ('default'	,'require'			,'delteacher'	,'teacherPage'			,'0'),
    ('default'	,'require'			,'subject'		,'teacherPage'			,'0'),
    ('default'	,'require'			,'sumup'			,'teacherPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'coachstudent'	,'index'			,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'item'				,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'delete'			,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'new'				,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'edit'				,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'group'			,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'member'			,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'user'				,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'student'		,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'student2'		,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'teacher'		,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'addmember'	,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'delmember'	,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'addteacher'	,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'delteacher'	,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'addstudent'	,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'delstudent'	,'teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'addstudent2','teacherPage'		,'0'),
    ('default'	,'coachstudent'	,'delstudent2','teacherPage'		,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'coachentrust'	,'index'			,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'item'				,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'delete'			,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'new'				,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'edit'				,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'group'			,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'member'			,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'user'				,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'student'		,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'student2'		,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'delstudent'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'teacher'		,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'addmember'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'delmember'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'addteacher'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'delteacher'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'addstudent'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'delstudent'	,'chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'addstudent2','chiefPage'			,'0'),
    ('default'	,'coachentrust'	,'delstudent2','chiefPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'career'				,'index'			,'staffPage'			,'0'),
    ('default'	,'graduate'			,'index'			,'staffPage'			,'0'),
    ('default'	,'graduate'			,'item'				,'staffPage'			,'0'),
    ('default'	,'graduate'			,'edit'				,'staffPage'			,'0'),
    ('default'	,'graduate'			,'employ'			,'staffPage'			,'0'),
    ('default'	,'graduate'			,'delete'			,'staffPage'			,'0'),
    ('default'	,'graduate'			,'addemploy'	,'staffPage'			,'0'),
		
    ('default'	,'employ'				,'index'			,'staffPage'			,'0'),
    ('default'	,'employ'				,'item'				,	'staffPage'			,'0'),
    ('default'	,'employ'				,'new'				,'staffPage'			,'0'),
    ('default'	,'employ'				,'edit'				,'staffPage'			,'0'),
    ('default'	,'employ'				,'delete'			,'staffPage'			,'0'),
    ('default'	,'employ'				,'import'			,'staffPage'			,'0'),
    ('default'	,'employ'				,'upload'			,'staffPage'			,'0'),
		
    ('default'	,'master'				,'index'			,'staffPage'			,'0'),
		
    ('default'	,'sys'					,'index'			,'adminPage'			,'0'),
    ('default'	,'sys'					,'edit'				,'adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'access'   		,'index'			,'staffPage'			,'0'),
		
    ('default'	,'position'  		,'index'			,'staffPage'			,'0'),
    ('default'	,'position'  		,'comm'				,'staffPage'			,'0'),
    ('default'	,'position'  		,'expert'			,'staffPage'			,'0'),
		
    ('default'	,'role'					,'index'			,'staffPage'			,'0'),
    ('default'	,'role'					,'item'				,'staffPage'			,'0'),
    ('default'	,'role'					,'edit'				,'staffPage'			,'0'),
    ('default'	,'role'					,'user'				,'staffPage'			,'0'),
    ('default'	,'role'					,'adduser'		,'staffPage'			,'0'),
    ('default'	,'role'					,'deluser'		,'staffPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'user'					,'index'			,'staffPage'			,'0'),
    ('default'	,'user'					,'item'				,'staffPage'			,'0'),
    ('default'	,'user'					,'new'				,'adminPage'			,'0'),
    ('default'	,'user'					,'add'				,'adminPage'			,'0'),
    ('default'	,'user'					,'edit'				,'adminPage'			,'0'),
    ('default'	,'user'					,'update'			,'adminPage'			,'0'),
    ('default'	,'user'					,'delete'			,'adminPage'			,'0'),
    ('default'	,'user'					,'import'			,'adminPage'			,'0'),
    ('default'	,'user'					,'upload'			,'adminPage'			,'0'),
    ('default'	,'user'					,'comm'				,'adminPage'			,'0'),
    ('default'	,'user'					,'addcomm'		,'adminPage'			,'0'),
    ('default'	,'user'					,'delcomm'		,'adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'student'			,'index'			,'staffPage'			,'0'),
    ('default'	,'student'			,'new'				,'staffPage'			,'0'),
    ('default'	,'student'			,'item'				,'staffPage'			,'0'),
    ('default'	,'student'			,'edit'				,'staffPage'			,'0'),
    ('default'	,'student'			,'update'			,'staffPage'			,'0'),
    ('default'	,'student'			,'delete'			,'staffPage'			,'0'),
    ('default'	,'student'			,'import'			,'staffPage'			,'0'),
    ('default'	,'student'			,'upload'			,'staffPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'promotion'		,'index'			,'adminPage'			,'0'),
    ('default'	,'promotion'		,'item'			  ,'adminPage'			,'0'),
    ('default'	,'promotion'		,'class'			,'adminPage'			,'0'),
    ('default'	,'promotion'		,'student'		,'adminPage'			,'0'),
    ('default'	,'promotion'		,'upgrade'		,'adminPage'			,'0'),
    ('default'	,'promotion'		,'downgrade'	,'adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'information'	,'index'			,'staffPage'			,'0'),
		
    ('default'	,'club'					,'index'			,'staffPage'			,'0'),
    ('default'	,'club'					,'item'				,'staffPage'			,'0'),
    ('default'	,'club'					,'new'				,'adminPage'			,'0'),
    ('default'	,'club'					,'edit'				,'adminPage'			,'0'),
    ('default'	,'club'					,'delete'			,'adminPage'			,'0'),
		
    ('default'	,'job'					,'index'			,'staffPage'			,'0'),
    ('default'	,'job'					,'item'				,'staffPage'			,'0'),
    ('default'	,'job'					,'new'				,'adminPage'			,'0'),
    ('default'	,'job'					,'edit'				,'adminPage'			,'0'),
    ('default'	,'job'					,'delete'			,'adminPage'			,'0'),
    ('default'	,'job'					,'import'			,'adminPage'			,'0'),
    ('default'	,'job'					,'upload'			,'adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'section'			,'index'			,'staffPage'			,'0'),
		
    ('default'	,'class'				,'index'			,'staffPage'			,'0'),
    ('default'	,'class'				,'new'				,'staffPage'			,'0'),
    ('default'	,'class'				,'item'				,'staffPage'			,'0'),
    ('default'	,'class'				,'edit'				,'staffPage'			,'0'),
    ('default'	,'class'				,'update'			,'staffPage'			,'0'),
    ('default'	,'class'				,'delete'			,'staffPage'			,'0'),
    ('default'	,'class'				,'import'			,'staffPage'			,'0'),
    ('default'	,'class'				,'upload'			,'staffPage'			,'0'),
		
    ('default'	,'group'				,'index'			,'staffPage'			,'0'),
    ('default'	,'group'				,'new'				,'staffPage'			,'0'),
    ('default'	,'group'				,'item'				,'staffPage'			,'0'),
    ('default'	,'group'				,'edit'				,'staffPage'			,'0'),
    ('default'	,'group'				,'update'			,'staffPage'			,'0'),
    ('default'	,'group'				,'delete'			,'staffPage'			,'0'),
    ('default'	,'group'				,'import'			,'staffPage'			,'0'),
    ('default'	,'group'				,'upload'			,'staffPage'			,'0'),
		
    ('default'	,'comm'					,'index'			,'staffPage'			,'0'),
    ('default'	,'comm'					,'item'				,'staffPage'			,'0'),
    ('default'	,'comm'					,'new'				,'staffPage'			,'0'),
    ('default'	,'comm'					,'edit'				,'staffPage'			,'0'),
    ('default'	,'comm'					,'update'			,'staffPage'			,'0'),
    ('default'	,'comm'					,'delete'			,'adminPage'			,'0'),
    ('default'	,'comm'					,'import'			,'adminPage'			,'0'),
    ('default'	,'comm'					,'upload'			,'adminPage'			,'0'),
    ('default'	,'comm'					,'group'			,'adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'education'		,'index'			,'staffPage'			,'0'),
		
    ('default'	,'subject'			,'index'			,'staffPage'			,'0'),
    ('default'	,'subject'			,'item'				,'staffPage'			,'0'),
    ('default'	,'subject'			,'new'				,'adminPage'			,'0'),
    ('default'	,'subject'			,'edit'				,'adminPage'			,'0'),
    ('default'	,'subject'			,'update'			,'adminPage'			,'0'),
    ('default'	,'subject'			,'delete'			,'adminPage'			,'0'),
    ('default'	,'subject'			,'user'				,'adminPage'			,'0'),
    ('default'	,'subject'			,'adduser'		,'adminPage'			,'0'),
    ('default'	,'subject'			,'deluser'		,'adminPage'			,'0'),
    ('default'	,'subject'			,'import'			,'adminPage'			,'0'),
    ('default'	,'subject'			,'upload'			,'adminPage'			,'0'),
    ('default'	,'subject'			,'upload2'		,'adminPage'			,'0'),
    ('default'	,'subject'			,'upload3'		,'adminPage'			,'0'),
    ('default'	,'subject'			,'upload4'		,'adminPage'			,'0'),
    ('default'	,'subject'			,'syllabus'		,'adminPage'			,'0'),
    ('default'	,'subject'			,'delsyllabus','adminPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'tp'						,'index'			,'staffPage'			,'0'),
    ('default'	,'tp'						,'user'				,'staffPage'			,'0'),
    ('default'	,'tp'						,'item'				,'staffPage'			,'0'),
		
    ('default'	,'ir'						,'index'			,'staffPage'			,'0'),
    ('default'	,'ir'						,'view'				,'staffPage'			,'0');

INSERT INTO `ananfd2011`.`m_acl` (`module`, `controller`, `action`, `resource`, `delete_flg`)
VALUES
    ('default'	,'pdf'					,'index'			,'userPage'				,'0'),
    ('default'	,'pdf'					,'enroll'			,'userPage'				,'0'),
    ('default'	,'pdf'					,'fresh'			,'userPage'				,'0'),
    ('default'	,'pdf'					,'enrollpage'	,'userPage'				,'0'),
    ('default'	,'pdf'					,'enrollframe','userPage'				,'0'),
    ('default'	,'pdf'					,'enrolltext'	,'userPage'				,'0'),
    ('default'	,'pdf'					,'freshpage'	,'userPage'				,'0'),
    ('default'	,'pdf'					,'freshframe'	,'userPage'				,'0'),
    ('default'	,'pdf'					,'freshtext'	,'userPage'				,'0'),
    ('default'	,'pdf'					,'view'				,'userPage'				,'0'),
    ('default'	,'pdf'					,'pdf'				,'userPage'				,'0'),
    ('default'	,'pdf'					,'pdf1'				,'userPage'				,'0'),
    ('default'	,'pdf'					,'pdf2'				,'userPage'				,'0'),
    ('default'	,'pdf'					,'pdf3'				,'userPage'				,'0'),
    ('default'	,'pdf'					,'file'				,'userPage'				,'0'),
    ('default'	,'pdf'					,'viewir'			,'userPage'				,'0');


