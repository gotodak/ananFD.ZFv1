<?php
/**
 * ananFD定義ファイル
 * 
 * 共通定義
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */


//const EDIT_RT	= 'NO_EDIT';
	define( 'DISP_MESSAGE' 		,'eid' );
	
	define( 'ERR_ZERO' 							,0 );
	define( 'ERR_EDIT_NORIGHT' 			,0x001 );
	define( 'ERR_EDIT_DISABLE' 			,0x002 );
	
	define( 'ERR_DELETE_NORIGHT'		,0x003 );
	define( 'ERR_DELETE_DISABLE'		,0x004 );
	define( 'ERR_REGIST_NORIGHT'		,0x005 );
	define( 'ERR_REGIST_DISABLE'		,0x006 );
	
	define( 'ERR_VIEW_NORIGHT' 			,0x007 );
	define( 'ERR_VIEW_DISABLE' 			,0x008 );
	
	define( 'ERR_PASSWORD_CHG' 			,0x009 );
	define( 'ERR_PASSWORD_INIT' 		,0x00A );
	define( 'ERR_PASSWORD_ERR' 			,0x00B );
	
	define( 'ERR_CAREER_ACCESS' 		,0x100 );
	define( 'ERR_SELF_DELETE' 			,0x101 );
	define( 'ERR_DUPCOMM_USER' 			,0x102 );
	define( 'ERR_DELETE_LEARN' 			,0x103 );

//FATAL_ERR
	define( 'FATAL_EDIT_NORIGHT' 		,0x001 );
	define( 'FATAL_TEACHER_ACCESS' 	,0x101 );
	define( 'FATAL_ENTRUST_ACCESS' 	,0x102 );
	define( 'FATAL_COMM_ACCESS' 		,0x103 );


//committee_id
	define( 'COMM_EXECUTIVE' 	, '1' );
	define( 'COMM_ASSISTANCE' , '2' );
	define( 'COMM_EDUCATION'	, '3' );
	define( 'COMM_STUDENT'		, '4' );
	define( 'COMM_DOMITORY'		, '5' );
	define( 'COMM_FD'					, '6' );
	define( 'COMM_CAREER' 		, '7' );
	define( 'COMM_INFOMATION' , '8' );
	define( 'COMM_UPGRADE' 		, '9' );

//committee_type
	define( 'COMM_KIND_EXPERT' 		, '1' );
	define( 'COMM_KIND_POSITION'	, '2' );
	define( 'COMM_KIND_USER'			, '3' );

//committee_level
	define( 'USER_KIND_TEACHER'		, '1' );
	define( 'COMM_LEVLE_GUEST' 		, '0' );
	define( 'COMM_LEVLE_STAFF' 		, '1' );
	define( 'COMM_LEVLE_USER' 		, '2' );
	define( 'COMM_LEVLE_TEACHER'	, '3' );
	define( 'COMM_LEVLE_CHIEF'		, '4' );
	define( 'COMM_LEVLE_MANAGER'	, '5' );
	define( 'COMM_LEVLE_MASTER'		, '6' );
	define( 'COMM_LEVLE_ADMIN' 		, '7' );

//chief_type
	define( 'CHIEF_KIND_GROUP' 	, '1' );
	define( 'CHIEF_KIND_GRADE'	, '2' );
	define( 'CHIEF_KIND_CLASS'	, '3' );
	define( 'CHIEF_KIND_CHECK'	, '4' );		// COMM_CHECK

//chief_id
	define( 'CHIEF_GROUP_1' 	, '1' );
	define( 'CHIEF_GRADE_1'		, '1' );
	define( 'CHIEF_CLASS_1'		, '1' );
	define( 'CHIEF_CHECK_1'		, '1' );

	define( 'TEACHER_ID'			,  '8' );
	define( 'KIFU_ID'					,  '9' );
	define( 'STAFF_ID'				, '10' );
	define( 'USER_ID'					, '10' );

//role_name
	define( 'ROLE_NAME_ADMIN' 		, 'admin' );
	define( 'ROLE_NAME_MASTER'		, 'master' );
	define( 'ROLE_NAME_MANAGER'		, 'manager' );
	define( 'ROLE_NAME_CHIEF'			, 'chief' );
	define( 'ROLE_NAME_TEACHER'		, 'teacher' );
	define( 'ROLE_NAME_USER'			, 'user' );
	define( 'ROLE_NAME_STAFF'			, 'staff' );
	define( 'ROLE_NAME_GUEST'			, 'guest' );
