<?php
/**
 * ananFDブログシステム
 * 
 * 共通関数
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Validate_EmailAddress'); 	// 追加する
Zend_Loader::loadClass('Zend_Validate_NotEmpty'); 			// 追加する
Zend_Loader::loadClass('Zend_Validate_StringLength'); 	// 追加する
Zend_Loader::loadClass('Zend_Validate_GreaterThan'); 		// 追加する
Zend_Loader::loadClass('Zend_Validate_LessThan'); 			// 追加する
Zend_Loader::loadClass('Zend_Validate_Between'); 				// 追加する
Zend_Loader::loadClass('Zend_Validate_Digits'); 				// 追加する
Zend_Loader::loadClass('Zend_Validate_Regex'); 					// 追加する
Zend_Loader::loadClass('Zend_Validate_Date');		 				// 追加する
Zend_Loader::loadClass('Zend_Validate'); 								// 追加する



// モジュールをロードする
require_once '../application/lib/anandef.php';


    /**-------------------------------------------------------------------------------------------
     * getDispMessage()
     */
		function getDispMessage( $noMsg,$view )
		{
/*
				$view->message;
*/

				$msg = null;
				switch( $noMsg ){
						
						case ERR_ZERO:		break;
						case ERR_EDIT_NORIGHT:		$msg	= '編集権がありません。('	. $view->userName .')';		break;
						case ERR_EDIT_DISABLE	:		$msg	= '編集はできません。('		. $view->userName .')';		break;
						case ERR_DELETE_NORIGHT :	$msg	= '削除権がありません。('	. $view->userName .')';		break;
						case ERR_DELETE_DISABLE :	$msg	= '削除はできません。('		. $view->userName .')';		break;
						case ERR_REGIST_NORIGHT :	$msg	= '登録権がありません。('	. $view->userName .')';		break;
						case ERR_REGIST_DISABLE :	$msg	= '登録はできません。('		. $view->userName .')';		break;
						case ERR_VIEW_NORIGHT	:		$msg	= '参照権がありません。('	. $view->userName .')';		break;
						case ERR_VIEW_DISABLE	:		$msg	= '参照はできません。('		. $view->userName .')';		break;
						case ERR_PASSWORD_CHG	:		$msg	= 'パスワードを変更しました。('		. $view->userName .')';								break;
						case ERR_PASSWORD_INIT:		$msg	= 'パスワードを初期化しました。('		. $view->userName .')';							break;
						case ERR_PASSWORD_ERR:		$msg	= 'パスワード処理でエラーが発生しました。('		. $view->userName .')';		break;
						
						case ERR_CAREER_ACCESS:		$msg	= 'キャリア支援室のメンバーではありません。('		. $view->userName .')';	break;
						case ERR_SELF_DELETE:			$msg	= '自分自身は削除できません。('		. $view->userName .')';								break;
						case ERR_DUPCOMM_USER:		$msg	= '同種の役職に既に登録されています。';			break;
						case ERR_DELETE_LEARN:		$msg	= '最新の面接記録でないので削除はできません。('		. $view->userName .')';		break;
						default:
							break;
				}
				return $msg;
		}



    /**-------------------------------------------------------------------------------------------
     * getFatalError()
     */
		function getFatalError( $noMsg,$view )
		{
/*
				$view->message;
*/

				$msg = null;
				switch( $noMsg ){
						
						case FATAL_TEACHER_ACCESS:	$msg	= '教員ではありません。('		. $view->userName .')';		break;
						case FATAL_ENTRUST_ACCESS:	$msg	= '担任ではありません。('		. $view->userName .')';		break;
						case FATAL_COMM_ACCESS:			$msg	= '許可された委員会メンバーではありません。('		. $view->userName .')';		break;
						default:
							break;
				}
				if( !is_null($msg) ){
				//	$this->_forward( 'error', 'Error', null, 
				//										array('accessError' => $msg ) 
				//									);	
						$msg = array('accessError' => $msg ) ;
				}
				
				return $msg;
		}



    /**-------------------------------------------------------------------------------------------
     * getNowYear()
     */
		function getNowYear( $fiscalYear )
		{
			
			$dt = getdate();
			$y	= $dt['year'];
			$m	= $dt['mon'];
			
			if( $fiscalYear ){
				if( $m <= 3 )		$y--;
				
			}
			
			$year = $y;									//'2011'
			return $year;
			
		}



    /**-------------------------------------------------------------------------------------------
     * setNaviToPlacefolder()
     */
		function setNaviToPlacefolder( $name ,$view ,$data )
		{
			
			if( is_object($view) )
			{
				
				$view->placeholder($name)->captureStart();
				
				echo "<div class='navi'>";
				foreach($data as $row){
					if( $row['name']=='TOP' ) {
						echo "<a href='" .$row['url']. "'>" .$row['name']. "</a>" ;
					} else {
						echo " &gt; <a href='" .$row['url']. "'>" .$row['name']. "</a>" ;
					}
				}
				echo "</div>";
				
				$view->placeholder($name)->captureEnd();
				
			}
			
		}



    /**-------------------------------------------------------------------------------------------
     * setActionmenuToPlacefolder()
     */
		function setActionmenuToPlacefolder( $name ,$view ,$data )
		{

			if( is_object($view) )
			{
				
				
				$view->placeholder($name)->captureStart();
				
				echo "<div class='actionMenu'>";
				

				foreach($data as $row){
					if( $row['name']=='separator' ) {
						echo "<span class='separator'></span>" ;
					} elseif ( $row['onclick']!='' ) {
						echo "<a href='" .$row['url']. "' onclick='" .$row['onclick']. "'>" .$row['name']. "</a>" ;
					} else {
						echo "<a href='" .$row['url']. "'>" .$row['name']. "</a>" ;
					}
				}

				
	/*
				foreach($data as $row){
					echo "<a href='" .$row['url']. "' onclick='" .$row['onclick']. "'>" .$row['name']. "</a>" ;
				}
	*/
				
				echo "</div>";
				
				$view->placeholder($name)->captureEnd();
				
			}
			
		}





    /**-------------------------------------------------------------------------------------------
     * setMainmenuToPlacefolder()
     */
		function setMainmenuToPlacefolder( $name ,$view ,$controller )
		{
				$mainData = array();
				
				$urlNon						= '#';
				$urlLearning			= $view->modulePath.'learning/index'		.$view->sid;
				$urlCoachstudent	= $view->modulePath.'coachstudent/index'.$view->sid;
				$urlCoachentrust	= $view->modulePath.'coachentrust/index'.$view->sid;
				$urlCareer				= $view->modulePath.'career/index'			.$view->sid;
				$urlGraduate			= $view->modulePath.'graduate/index'		.$view->sid;
				$urlTp						= $view->modulePath.'tp/index'					.$view->sid;
				$urlIr						= $view->modulePath.'ir/index'					.$view->sid;
				$urlMaster				= $view->modulePath.'master/index'			.$view->sid;
				switch( $view->userLevel ){
					case 'admin':
					case 'master':
					case 'manager':
								$mainData = array(
													array('name'=>'学習支援'  ,'class'=>'learning','url'=>$urlLearning ),
													array('name'=>'学生指導'  ,'class'=>'student' ,'url'=>$urlCoachstudent ),
													array('name'=>'担任指導'  ,'class'=>'entrust' ,'url'=>$urlCoachentrust ),
													array('name'=>'卒業生支援','class'=>'career'	,'url'=>$urlCareer ),
													array('name'=>'ＴＰ支援'  ,'class'=>'tp'      ,'url'=>$urlTp ),
													array('name'=>'ＩＲ支援'  ,'class'=>'ir'      ,'url'=>$urlIr ),
													array('name'=>'マスタ設定','class'=>'master'  ,'url'=>$urlMaster ) 
													);
							break;
					case 'chief':
					case 'teacher':
								$mainData = array(
													array('name'=>'学習支援'  ,'class'=>'learning','url'=>$urlLearning ),
													array('name'=>'学生指導'  ,'class'=>'student' ,'url'=>$urlCoachstudent ),
													array('name'=>'担任指導'  ,'class'=>'entrust' ,'url'=>$urlCoachentrust ),
													array('name'=>'卒業生支援','class'=>'career'	,'url'=>$urlCareer ),
													array('name'=>'ＴＰ支援'  ,'class'=>'tp'      ,'url'=>$urlTp ),
													array('name'=>'ＩＲ支援'  ,'class'=>'ir'      ,'url'=>$urlIr ),
													array('name'=>'マスタ設定','class'=>'master'  ,'url'=>$urlMaster ) 
													);
								break;
					case 'staff':
								$mainData = array(
													array('name'=>'－'        ,'class'=>'learning','url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'entrust' ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'entrust' ,'url'=>$urlNon ),
													array('name'=>'卒業生支援','class'=>'career'	,'url'=>$urlCareer ),
													array('name'=>'ＴＰ支援'  ,'class'=>'tp'      ,'url'=>$urlTp ),
													array('name'=>'ＩＲ支援'  ,'class'=>'ir'      ,'url'=>$urlIr ),
													array('name'=>'マスタ設定','class'=>'master'  ,'url'=>$urlMaster ) 
													);
								break;
					case 'user':
								$mainData = array(
													array('name'=>'－'        ,'class'=>'learning','url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'entrust' ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'entrust' ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'career'	,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'tp'      ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'ir'      ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'master'  ,'url'=>$urlNon )
													);
								break;
					case 'guest':
					default:
								$mainData = array(
													array('name'=>'－'        ,'class'=>'learning','url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'student' ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'entrust' ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'career'	,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'tp'      ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'ir'      ,'url'=>$urlNon ),
													array('name'=>'－'        ,'class'=>'master'  ,'url'=>$urlNon ) 
													);
								break;
					}


							switch( $controller ){
								case 'master':
								case 'student':
									case 'promotion':
									case 'dormitory':
									case 'director':
									case 'contact':
								case 'information':
									case 'club':
									case 'job':
								case 'education':
									case 'subject':
								case 'user':
								case 'access':
									case 'position':
									case 'role':
								case 'section':
									case 'class':
									case 'group':
									case 'comm':
								case 'sys':
										$mainData[6]['class'] .= ' current';	break;
								case 'learning':
								case 'support':
								case 'require':
								case 'learnlist':
										$mainData[0]['class'] .= ' current';	break;
								case 'coachstudent':
										$mainData[1]['class'] .= ' current';	break;
								case 'coachentrust':
										$mainData[2]['class'] .= ' current';	break;
								case 'career':
								case 'graduate':
								case 'employ':
										$mainData[3]['class'] .= ' current';	break;
								case 'tp':
										$mainData[4]['class'] .= ' current';	break;
								case 'ir':
										$mainData[5]['class'] .= ' current';	break;
								case 'top':
								default:	break;
							}


			if( is_object($view) )
			{
				
				$view->placeholder($name)->captureStart();
				echo "<div class='mainMenu'>";
				foreach($mainData as $row){
					echo "<a href='" .$row['url']. "' class='" .$row['class']. "'>" .$row['name']. "</a>" ;
				}
				echo "</div>";
				$view->placeholder($name)->captureEnd();
				
			}
			
		}




    /**-------------------------------------------------------------------------------------------
     * setContentmenuToPlacefolder()
     */
		function setContentmenuToPlacefolder($name,$view,$controller,$action)
		{
			
				switch( $controller ){
					case 'top':
						$top2password	= $view->modulePath.'top/password'.$view->sid;
						$top2dump			= $view->modulePath.'top/dump'.$view->sid;
						$top2image		= $view->modulePath.'top/image'.$view->sid;
						$top2figlet		= $view->modulePath.'top/figlet'.$view->sid;
						$top2userinfo	= $view->modulePath.'top/userinfo'.$view->sid;
						$top2initpass	= $view->modulePath.'top/initpass'.$view->sid;
						switch( $view->userLevel ){
								case 'admin':
									$contenData = array(
													array('name'=>'パスワード変更'  ,'class'=>''  ,'url'=>$top2image  	),
													array('name'=>'ユーザ情報'    	,'class'=>''  ,'url'=>$top2userinfo	), 
													array('name'=>'パスワード初期化','class'=>''  ,'url'=>$top2initpass	)
													//array('name'=>'パスワード変更'  ,'class'=>''  ,'url'=>$top2dump  	),
													//array('name'=>'パスワード変更'  ,'class'=>''  ,'url'=>$top2password  	)
													);
									break;
								default:
									$contenData = array(
													array('name'=>'パスワード変更'  ,'class'=>''  ,'url'=>$top2image  	),
													array('name'=>'ユーザ情報'    	,'class'=>''  ,'url'=>$top2userinfo 	) 
													//array('name'=>'パスワード初期化','class'=>''  ,'url'=>$top2initpass	),
													//array('name'=>'パスワード変更'  ,'class'=>''  ,'url'=>$top2dump  	),
													//array('name'=>'パスワード変更'  ,'class'=>''  ,'url'=>$top2password  	)
													);
									break;
						}
						switch( $action ){
							case 'image':
								$contenData[0]['class'] = 'current';	break;
							case 'userinfo':
								$contenData[1]['class'] = 'current';	break;
							case 'initpass':
								$contenData[2]['class'] = 'current';	break;
							case 'dump':
								$contenData[3]['class'] = 'current';	break;
							case 'password':
								$contenData[4]['class'] = 'current';	break;
							default:	break;
						}
						break;
					case 'master':
						$student2index	= $view->modulePath.'student/index'			.$view->sid;
						$inform2index		= $view->modulePath.'information/index'	.$view->sid;
						$education2index= $view->modulePath.'education/index'		.$view->sid;
						$user2index			= $view->modulePath.'user/index'				.$view->sid;
						$access2index		= $view->modulePath.'access/index'			.$view->sid;
						$section2index	= $view->modulePath.'section/index'			.$view->sid;
						$sys2index			= $view->modulePath.'sys/index'					.$view->sid;
/*
						$contenData = array(
											array('name'=>'学生管理'    ,'class'=>''  ,'url'=>$student2index ),
											array('name'=>'学生情報'    ,'class'=>''  ,'url'=>$inform2index  ),
											array('name'=>'教務管理'    ,'class'=>''  ,'url'=>$education2index ),
											array('name'=>'ユーザ管理'  ,'class'=>''  ,'url'=>$user2index  ),
											array('name'=>'アクセス管理','class'=>''  ,'url'=>$access2index ),
											array('name'=>'組織管理'    ,'class'=>''  ,'url'=>$section2index  ),
											array('name'=>'システム管理','class'=>''  ,'url'=>$sys2index  ) 
											);
*/
						switch( $view->userLevel ){
								case 'admin':
									$contenData = array(
											array('name'=>'学生管理'    ,'class'=>''  ,'url'=>$student2index ),
											array('name'=>'学生情報'    ,'class'=>''  ,'url'=>$inform2index  ),
											array('name'=>'教務管理'    ,'class'=>''  ,'url'=>$education2index ),
											array('name'=>'ユーザ管理'  ,'class'=>''  ,'url'=>$user2index  ),
											array('name'=>'アクセス管理','class'=>''  ,'url'=>$access2index ),
											array('name'=>'組織管理'    ,'class'=>''  ,'url'=>$section2index  ),
											array('name'=>'システム管理','class'=>''  ,'url'=>$sys2index  ) 
											);
									break;
								default:
									$contenData = array(
											array('name'=>'学生管理'    ,'class'=>''  ,'url'=>$student2index ),
											array('name'=>'学生情報'    ,'class'=>''  ,'url'=>$inform2index  ),
											array('name'=>'教務管理'    ,'class'=>''  ,'url'=>$education2index ),
											array('name'=>'ユーザ管理'  ,'class'=>''  ,'url'=>$user2index  ),
											array('name'=>'アクセス管理','class'=>''  ,'url'=>$access2index ),
											array('name'=>'組織管理'    ,'class'=>''  ,'url'=>$section2index  )
											);
									break;
						}
						break;
					case 'student':
						case 'promotion':
						case 'dormitory':
						case 'director':
						case 'contact':
					case 'information':
						case 'club':
						case 'job':
					case 'education':
						case 'subject':
					case 'user':
					case 'access':
								case 'position':
								case 'role':
					case 'section':
						case 'class':
						case 'group':
						case 'comm':
						$student2index	= $view->modulePath.'student/index'			.$view->sid;
						$inform2index		= $view->modulePath.'information/index'	.$view->sid;
						$education2index= $view->modulePath.'education/index'		.$view->sid;
						$user2index			= $view->modulePath.'user/index'				.$view->sid;
						$access2index		= $view->modulePath.'access/index'			.$view->sid;
						$section2index	= $view->modulePath.'section/index'			.$view->sid;
						$contenData = array(
											array('name'=>'学生管理'    ,'class'=>''  ,'url'=>$student2index ),
											array('name'=>'学生情報'    ,'class'=>''  ,'url'=>$inform2index ),
											array('name'=>'教務管理'    ,'class'=>''  ,'url'=>$education2index ),
											array('name'=>'ユーザ管理'  ,'class'=>''  ,'url'=>$user2index ),
											array('name'=>'アクセス管理','class'=>''  ,'url'=>$access2index ),
											array('name'=>'組織管理'    ,'class'=>''  ,'url'=>$section2index ) 
											);
						switch( $controller ){
							case 'student':
							case 'promotion':
							case 'dormitory':
							case 'director':
							case 'contact':
								$contenData[0]['class'] = 'current';	break;
							case 'information':
							case 'club':
							case 'job':
								$contenData[1]['class'] = 'current';	break;
							case 'education':
							case 'subject':
								$contenData[2]['class'] = 'current';	break;
							case 'user':
								$contenData[3]['class'] = 'current';	break;
							case 'access':
							case 'position':
							case 'role':
								$contenData[4]['class'] = 'current';	break;
							case 'section':
							case 'class':
							case 'group':
							case 'comm':
								$contenData[5]['class'] = 'current';	break;
							default:
								$contenData[0]['class'] = 'current';	break;
						}
						break;
					case 'sys':
						$student2index	= $view->modulePath.'student/index'			.$view->sid;
						$inform2index		= $view->modulePath.'information/index'	.$view->sid;
						$education2index= $view->modulePath.'education/index'		.$view->sid;
						$user2index			= $view->modulePath.'user/index'				.$view->sid;
						$access2index		= $view->modulePath.'access/index'			.$view->sid;
						$section2index	= $view->modulePath.'section/index'			.$view->sid;
						$sys2index			= $view->modulePath.'sys/index'					.$view->sid;
						$contenData = array(
											array('name'=>'学生管理'    ,'class'=>''  ,'url'=>$student2index ),
											array('name'=>'学生情報'    ,'class'=>''  ,'url'=>$inform2index ),
											array('name'=>'教務管理'    ,'class'=>''  ,'url'=>$education2index ),
											array('name'=>'ユーザ管理'  ,'class'=>''  ,'url'=>$user2index ),
											array('name'=>'アクセス管理','class'=>''  ,'url'=>$access2index ),
											array('name'=>'組織管理'    ,'class'=>''  ,'url'=>$section2index  ),
											array('name'=>'システム管理','class'=>''  ,'url'=>$sys2index  ) 
											);
						switch( $controller ){
							case 'sys':
								$contenData[6]['class'] = 'current';	break;
							default:
								$contenData[0]['class'] = 'current';	break;
						}
						break;
					case 'learning':
					case 'support':
					case 'require':
					case 'learnlist':
						$learning2index	= $view->modulePath.'learning/index'	.$view->sid;
						$support2index	= $view->modulePath.'support/index'		.$view->sid;
						$require2index	= $view->modulePath.'require/index'		.$view->sid;
						$learnlist2index= $view->modulePath.'learnlist/index'	.$view->sid;
						$contenData = array(
											array('name'=>'学習支援'    ,'class'=>''  ,'url'=>$learning2index ),
											array('name'=>'サポート'    ,'class'=>''  ,'url'=>$support2index  ),
											array('name'=>'要望'        ,'class'=>''  ,'url'=>$require2index  ),
											array('name'=>'面談一覧'    ,'class'=>''  ,'url'=>$learnlist2index  ) 
											);
						switch( $controller ){
							case 'learning':
								$contenData[0]['class'] = 'current';	break;
							case 'support':
								$contenData[1]['class'] = 'current';	break;
							case 'require':
								$contenData[2]['class'] = 'current';	break;
							case 'learnlist':
								$contenData[3]['class'] = 'current';	break;
							default:
								$contenData[0]['class'] = 'current';	break;
						}
						break;
					case 'coachstudent':
						$url2coachstudent		= $view->modulePath.'coachstudent/index'	.$view->sid;
						$url2coachstudent2	= $view->modulePath.'coachstudent2/index'	.$view->sid;
						$url2coachstudent3	= $view->modulePath.'coachstudent3/index'	.$view->sid;
						$contenData = array(
											array('name'=>'学生指導'        ,'class'=>'current'  ,'url'=>$url2coachstudent ),
											array('name'=>'指導一覧'        ,'class'=>''				 ,'url'=>$url2coachstudent ),
											array('name'=>'担当一覧'        ,'class'=>''				 ,'url'=>$url2coachstudent ) 
											);
						break;
					case 'coachentrust':
						$url2coachentrust	= $view->modulePath.'coachentrust/index'.$view->sid;
						$contenData = array(
											array('name'=>'担任指導'        ,'class'=>'current'  ,'url'=>$url2coachentrust ),
											array('name'=>'指導一覧'        ,'class'=>''  			 ,'url'=>$url2coachentrust ),
											array('name'=>'担当一覧'        ,'class'=>''  			 ,'url'=>$url2coachentrust ) 
											);
						break;
					case 'career':
						//$url2graduate	= $view->modulePath.'graduate/index'.$view->sid;
						$url2career		= $view->modulePath.'career/index'	.$view->sid;
						$url2graduate	= $view->modulePath.'graduate/index'.$view->sid;
						$url2employ		= $view->modulePath.'employ/index'	.$view->sid;
						$contenData = array(
											//array('name'=>'卒業生支援'        ,'class'=>''  ,'url'=>$url2career )
											array('name'=>'卒業生管理'     ,'class'=>''  ,'url'=>$url2graduate ),
											array('name'=>'就職先管理'     ,'class'=>''  ,'url'=>$url2employ )
											);
						break;
					case 'graduate':
						//$url2graduate	= $view->modulePath.'graduate/index'.$view->sid;
						$url2career		= $view->modulePath.'career/index'	.$view->sid;
						$url2graduate	= $view->modulePath.'graduate/index'.$view->sid;
						$url2employ		= $view->modulePath.'employ/index'	.$view->sid;
						$contenData = array(
											//array('name'=>'卒業生支援'        ,'class'=>''  ,'url'=>$url2career )
											array('name'=>'卒業生管理'     ,'class'=>'current'  ,'url'=>$url2graduate ),
											array('name'=>'就職先管理'     ,'class'=>''  				,'url'=>$url2employ )
											);
						break;
					case 'employ':
						//$url2graduate	= $view->modulePath.'graduate/index'.$view->sid;
						$url2career		= $view->modulePath.'career/index'	.$view->sid;
						$url2graduate	= $view->modulePath.'graduate/index'.$view->sid;
						$url2employ		= $view->modulePath.'employ/index'	.$view->sid;
						$contenData = array(
											//array('name'=>'卒業生支援'        ,'class'=>''  ,'url'=>$url2career )
											array('name'=>'卒業生管理'     ,'class'=>''  				,'url'=>$url2graduate ),
											array('name'=>'就職先管理'     ,'class'=>'current'  ,'url'=>$url2employ )
											);
						break;
					case 'tp':
						$tp2index			= $view->modulePath.'tp/index'				.$view->sid;
						$tp2list			= $view->modulePath.'tp/list-tp'			.$view->sid;
						$tp2syllabus	= $view->modulePath.'tp/list-syllabus'.$view->sid;
						$contenData = array(
											array('name'=>'ＴＰ支援'    ,'class'=>''  ,'url'=>$tp2index ),
											array('name'=>'ＴＰ一覧'    ,'class'=>''  ,'url'=>$tp2list ),
											array('name'=>'シラバス一覧','class'=>''  ,'url'=>$tp2syllabus ),
											array('name'=>'授業評価一覧','class'=>''  ,'url'=>$tp2syllabus ),
											array('name'=>'授業参観一覧','class'=>''  ,'url'=>$tp2syllabus ) 
											);
						switch( $action ){
							case 'index':
								$contenData[0]['class'] = 'current';	break;
							case 'list-tp':
								$contenData[1]['class'] = 'current';	break;
							case 'list-syllabus':
								$contenData[2]['class'] = 'current';	break;
							default:
								$contenData[0]['class'] = 'current';	break;
						}
						break;
					case 'ir':
						$ir2index		= $view->modulePath.'ir/index'.$view->sid;
						$contenData = array(
											array('name'=>'ＩＲ支援'        ,'class'=>'current'  ,'url'=>$ir2index ),
											array('name'=>'調査一覧'        ,'class'=>''			   ,'url'=>$ir2index ),
											array('name'=>'分析一覧'        ,'class'=>'' 				 ,'url'=>$ir2index ) 
											);
						break;
					case 'xxx':
						break;
					default:
						$contenData = array(
										);
						break;
				}

			if( is_object($view) )
			{
				
				$view->placeholder($name)->captureStart();
				echo "<div class='contentMenu'>";
				foreach( $contenData as $row){
					echo "<a href='" .$row['url']. "' class='" .$row['class']. "'>" .$row['name']. "</a>" ;
				}
				echo "</div>";
				$view->placeholder($name)->captureEnd();
				
			}
			
		}



    /**-------------------------------------------------------------------------------------------
		 * 日付文字列のバリデート処理を行う（未完）
		 *
		 * @param  int    $min     最小文字数
		 * @param  int    $max     最大文字数
		 * @param  array  $message エラーメッセージ
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
		function validateDate( $message, $input)
		{
		    // 内部文字コードをUTF-8に設定する
		    iconv_set_encoding('internal_encoding', 'UTF-8');
				
		    // メッセージ情報を初期化する
				
		    $errMessage = array();
				
		    // バリデータを生成する
		    $validator = new Zend_Validate_Date();
				
/*
		    // エラーメッセージを設定する
		    $messages = array(
													//Zend_Validate_Date::NOT_YYYY_MM_DD => $message .'は、「YYYY-MM-DD」の書式になっていません。',
		                      //Zend_Validate_Date::INVALID				 => $message .'は、日付として不正です。'
		                      Zend_Validate_Date::FALSEFORMAT				 => $message .'は、日付として不正です。'
		                );
		    $validator->setMessages($messages);
				
		    // チェック処理を実行する
		    if (!$validator->isValid($input)) {
		        $error = $validator->getMessages();
		        foreach ($error as $value) {
		            $errMessage[] = $value;
		        }
		    }
		    $validator = null;
		    return $errMessage;
*/
				if ( !$validator->isValid($sStdate) )
				{
				
            //$errMessage[] = $message .'は、日付として不正です（"yyyy-mm-dd HH:nn"）。';
            $errMessage[] = $message .'は、不正な日付フォーマットです（"yyyy-mm-dd HH:nn"）。';
				}
				
		    $validator = null;
		    return $errMessage;


				
		}




    /**-------------------------------------------------------------------------------------------
		 * 文字列のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数
		 * @param  int    $max     最大文字数
		 * @param  array  $message エラーメッセージ
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
		function validateString($min, $max, $message, $input)
		{
		    // 内部文字コードをUTF-8に設定する
		    iconv_set_encoding('internal_encoding', 'UTF-8');
				
		    // メッセージ情報を初期化する
		    $tooShort = (isset($message['tooShort'])) ? $message['tooShort'] : '';
		    $tooLong  = (isset($message['tooLong']))  ? $message['tooLong']  : '';
				
		    $errMessage = array();
				
		    // バリデータを生成する
		    $validator = new Zend_Validate_StringLength($min, $max);
				
		    // エラーメッセージを設定する
		    $messages = array(Zend_Validate_StringLength::TOO_SHORT => $tooShort,
		                      Zend_Validate_StringLength::TOO_LONG  => $tooLong
		                );
		    $validator->setMessages($messages);
				
		    // チェック処理を実行する
		    if (!$validator->isValid($input)) {
		        $error = $validator->getMessages();
		        foreach ($error as $value) {
		            $errMessage[] = $value;
		        }
		    }
		    $validator = null;
				
		    return $errMessage;
		}




    /**-------------------------------------------------------------------------------------------
     * 入力データのチェックを行なう（未使用）
     *
     * @return array $errMsg エラーメッセージ
     */
    function checkData()
    {
        // コンポーネントをロードする
        require_once 'Zend/Validate.php';
        require_once 'Zend/Validate/NotEmpty.php';
        require_once 'Zend/Validate/StringLength.php';
        require_once '../application/lib/validateUri.php';
				
        // バリデータを定義する
        $notEmpty = new Zend_Validate_NotEmpty();
        $uri      = new My_Validate_Uri();
        $stringLength = array('feedName' => new Zend_Validate_StringLength(1, 100),
                              'feedUrl'  => new Zend_Validate_StringLength(1, 200)
                        );
				
        // サイト名用のバリデータチェーンを作成する
        $validatorFeedName = new Zend_Validate();
        $validatorFeedName->addValidator($notEmpty, true)
                          ->addValidator($stringLength['feedName']);
				
        // フィードURL用のバリデータチェーンを作成する
        $validatorFeedUrl = new Zend_Validate();
        $validatorFeedUrl->addValidator($notEmpty, true)
                         ->addValidator($uri, true)
                         ->addValidator($stringLength['feedUrl']);
				
        // 入力データを取得する
        $feedName = $this->_getParam('feedName');
        $feedUrl  = $this->_getParam('feedUrl');
				
        $errMsg = array();
				
        // サイト名をバリデートする
        if (!$validatorFeedName->isValid($feedName)) {
            $errMsg[] = 'サイト名の入力値に誤りがあります。' . '<br />'
                      . '　・サイト名は必須項目です' . '<br />'
                      . '　・全角50文字以内で入力してください';
        }
				
        // フィードURLをバリデートする
        if (!$validatorFeedUrl->isValid($feedUrl)) {
            $errMsg[] = 'フィードURLの入力値に誤りがあります。' . '<br />'
                      . '　・フィードURLは必須項目です' . '<br />'
                      . '　・URLの書式を確認してください' . '<br />'
                      . '　・半角200文字以内で入力してください';
				
        // フィードタイプを取得する
        } else {
            $this->_feedType = $this->_feed->getFeedType($feedUrl);
            if (empty($this->_feedType)) {
                $errMsg[] = 'フィードURLの入力値に誤りがあります。' . '<br />'
                          . '　・フィード情報が取得できませんでした。';
            }
        }
			
        return $errMsg;
    }



    /**-------------------------------------------------------------------------------------------
		 * BRタグを除いてHTMLエンティティ処理を行う
		 *
		 * @param  string $str 入力文字列
		 * @return array  エンティティ化済み文字列
		 */
		function extEscape($str)
		{
		    // 一度すべてのタグをエンティティ化する
		    $outStr = htmlspecialchars($str);
		
		    // BRタグを逆エンティティ化する
		    $outStr = preg_replace('/&lt;br&gt;|&lt;br \/&gt;/i', '<br />', $outStr);
		
		    return $outStr;
		}



    /**-------------------------------------------------------------------------------------------
     * 検索文字列の正規表現を取得する
     *
     * @param  string $strKana     検索文字
     * @return stirng $strReg      正規表現
     */
    function getRegStr( $strKana )
    {
				$strReg = '';
				
						switch( $strKana ){
							case 'あ':
								$strReg = '^あ|^い|^う|^え|^お|^ぁ|^ぃ|^ぅ|^ぇ|^ぉ|^ゔ' ;
								break;
							case 'か':
								$strReg = '^か|^き|^く|^け|^こ|^が|^ぎ|^ぐ|^げ|^ご|^ゕ|^ゖ' ;
								break;
							case 'さ':
								$strReg = '^さ|^し|^す|^せ|^そ|^ざ|^じ|^ず|^ぜ|^ぞ' ;
								break;
							case 'た':
								$strReg = '^た|^ち|^つ|^て|^と|^だ|^ぢ|^づ|^で|^ど|^っ' ;
								break;
							case 'な':
								$strReg = '^な|^に|^ぬ|^ね|^の' ;		//
								break;
							case 'は':
								$strReg = '^は|^ひ|^ふ|^へ|^ほ|^ば|^び|^ぶ|^べ|^ぼ|^ぱ|^ぴ|^ぷ|^ぺ|^ぽ' ;
								break;
							case 'ま':
								$strReg = '^ま|^み|^む|^め|^も' ;		//
								break;
							case 'や':
								$strReg = '^や|^ゆ|^よ|^ゃ|^ゅ|^ょ' ;
								break;
							case 'ら':
								$strReg = '^ら|^り|^る|^れ|^ろ' ;		//
								break;
							case 'わ':
								$strReg = '^わ|^ゐ|^ゑ|^を|^ん' ;		//
								break;
							case 'abc':
								$strReg = '^[0-9a-zA-Z]' ;		
								break;
							}
			
        return $strReg;
    }







    /**-------------------------------------------------------------------------------------------
		 * 全角文字列のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				3
		 * @param  int    $max     最大文字数				30
		 * @param  array  $message エラーメッセージ	'よみがな'
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringKana( $min, $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						//A-Za-z0-9 ァ-ヶ
						$full_sign = 'A-Za-z 一-龠ぁ-ゖァ-ヶ　、。，．・：；？！゛゜´｀¨＾￣＿ヽヾ〃仝々〆〇ー―‐／～∥｜…‥‘’“”（）〔〕［］｛｝〈〉《》「」『』【】＋－±×÷＝≠＜＞≦≧∞∴♂♀°′″℃￥＄￠￡％＃＆＊＠§☆★○●◎◇字◆□■△▲▽▼※〒→←↑↓〓∈∋⊆⊇⊂⊃∪∩∧∨￢⇒⇔∀∃∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬Å‰♯♭♪†‡¶◯';
						$kana_sign = 'ぁ-ゖ　ー';
						$tel_sign = '0-9-+()内線';
						//$patternZen ='/^[一-龠ぁ-ゖァ-ヶーヽヾ々]+$/u';			//全角文字(仕様的に狭い範囲) 全角スペース無理
						//$patternKana ='/^[ぁ-ゖ]+$/u';											//全角ひらがな UTF-8 の文字コードの正規表現では u オプションを付加
						$patternZen 	="/^[" . $full_sign. "]+$/u";
						$patternKana 	="/^[" . $kana_sign. "]+$/u";
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				
				// インスタンスを生成する
						$user_kanaEmpty = new Zend_Validate_NotEmpty();
						$user_kanaRegex = new Zend_Validate_Regex($patternKana);
						$user_kanaLength = new Zend_Validate_StringLength( $min,$max );
						//$user_kanaLength = new Zend_Validate_StringLength();
						//$user_kanaLength->setMin(3);
						//$user_kanaLength->setMax(30);
				
				// エラーメッセージをセットする
							$user_kanaEmpty->setMessage( $message .'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							$user_kanaRegex->setMessage( $message .'は、全角ひらがなのみで構成されていません。');
							$user_kanaLength->setMessages(array(
							    Zend_Validate_StringLength::TOO_SHORT =>  $message .'は、%min%文字以上にしてください。',
							    Zend_Validate_StringLength::TOO_LONG  =>  $message .'は、%max%文字以下にしてください。')
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($user_kanaEmpty, true)
				               ->addValidator($user_kanaRegex, true)
				               ->addValidator($user_kanaLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }






    /**-------------------------------------------------------------------------------------------
		 * 全角文字列のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				 2, 3,2,2
		 * @param  int    $max     最大文字数				30,30,8,3
		 * @param  array  $message エラーメッセージ	'氏名','会社名称','グループ名称','本社','会社名称','出身学校','授業科目名',
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringFull( $min, $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						//$value = mb_convert_encoding($value, 'EUC-JP', 'UTF-8');
						//preg_match("/^(\xa1[\xa1-\xfe]|\xa2[\xa1-\xfe])+$/", $value);			//EUC-JP版正規表現
						// iconvの内部文字コードをUTF-8に設定する
						//iconv_set_encoding('internal_encoding', 'UTF-8');
							//$tmp = trim($member_name);								//半角スペースのみ
							//$tmp2 = str_replace(" ","ヾ",$tmp );
							//$tmp3 = str_replace("　","ヾ",$tmp2 );
							//var_dump($tmp3);
						
						//A-Za-z0-9 ァ-ヶ
						$full_sign = 'A-Za-z 一-龠ぁ-ゖァ-ヶ１２３４５ＭＥＳＣ　、。，．・：；？！゛゜´｀¨＾￣＿ヽヾ〃仝々〆〇ー―‐／～∥｜…‥‘’“”（）〔〕［］｛｝〈〉《》「」『』【】＋－±×÷＝≠＜＞≦≧∞∴♂♀°′″℃￥＄￠￡％＃＆＊＠§☆★○●◎◇字◆□■△▲▽▼※〒→←↑↓〓∈∋⊆⊇⊂⊃∪∩∧∨￢⇒⇔∀∃∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬Å‰♯♭♪†‡¶◯';
						$kana_sign = 'ぁ-ゖ　ー';
						$tel_sign = '0-9-+()内線';
						//$patternZen ='/^[一-龠ぁ-ゖァ-ヶーヽヾ々]+$/u';			//全角文字(仕様的に狭い範囲) 全角スペース無理
						//$patternKana ='/^[ぁ-ゖ]+$/u';											//全角ひらがな UTF-8 の文字コードの正規表現では u オプションを付加
						$patternZen 	="/^[" . $full_sign. "]+$/u";
						$patternKana 	="/^[" . $kana_sign. "]+$/u";
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				
				// インスタンスを生成する
						$member_nameEmpty = new Zend_Validate_NotEmpty();
						$member_zenRegex 	= new Zend_Validate_Regex($patternZen);
						$member_nameLength= new Zend_Validate_StringLength( $min,$max );
						//$member_nameLength = new Zend_Validate_StringLength();
						//$member_nameLength->setMin(2);
						//$member_nameLength->setMax(30);
				
				// エラーメッセージをセットする
							$member_nameEmpty->setMessage( $message .'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							$member_zenRegex->setMessage( $message .'は、全角のみで構成されていません。');
							$member_nameLength->setMessages(array(
							    Zend_Validate_StringLength::TOO_SHORT => $message .'は、%min%文字以上にしてください。',
							    Zend_Validate_StringLength::TOO_LONG  => $message .'は、%max%文字以下にしてください。')
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($member_nameEmpty, true)
				               ->addValidator($member_zenRegex, true)
				               ->addValidator($member_nameLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }




    /**-------------------------------------------------------------------------------------------
		 * 全角文字列のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				 2, 3,2,2
		 * @param  int    $max     最大文字数				30,30,8,3
		 * @param  array  $message エラーメッセージ	'氏名','会社名称','グループ名称','本社','会社名称','出身学校','授業科目名',
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringFull2( $min, $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						//$value = mb_convert_encoding($value, 'EUC-JP', 'UTF-8');
						//preg_match("/^(\xa1[\xa1-\xfe]|\xa2[\xa1-\xfe])+$/", $value);			//EUC-JP版正規表現
						// iconvの内部文字コードをUTF-8に設定する
						//iconv_set_encoding('internal_encoding', 'UTF-8');
							//$tmp = trim($member_name);								//半角スペースのみ
							//$tmp2 = str_replace(" ","ヾ",$tmp );
							//$tmp3 = str_replace("　","ヾ",$tmp2 );
							//var_dump($tmp3);
						
						//A-Za-z0-9 ァ-ヶ
						$full_sign = 'A-Za-z 一-龠ぁ-ゖァ-ヶ１２３４５６７８９０ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ　、。，．・：；？！゛゜´｀¨＾￣＿ヽヾ〃仝々〆〇ー―‐／～∥｜…‥‘’“”（）〔〕［］｛｝〈〉《》「」『』【】＋－±×÷＝≠＜＞≦≧∞∴♂♀°′″℃￥＄￠￡％＃＆＊＠§☆★○●◎◇字◆□■△▲▽▼※〒→←↑↓〓∈∋⊆⊇⊂⊃∪∩∧∨￢⇒⇔∀∃∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬Å‰♯♭♪†‡¶◯';
						$kana_sign = 'ぁ-ゖ　ー';
						$tel_sign = '0-9-+()内線';
						//$patternZen ='/^[一-龠ぁ-ゖァ-ヶーヽヾ々]+$/u';			//全角文字(仕様的に狭い範囲) 全角スペース無理
						//$patternKana ='/^[ぁ-ゖ]+$/u';											//全角ひらがな UTF-8 の文字コードの正規表現では u オプションを付加
						$patternZen 	="/^[" . $full_sign. "]+$/u";
						$patternKana 	="/^[" . $kana_sign. "]+$/u";
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				
				// インスタンスを生成する
						$member_nameEmpty = new Zend_Validate_NotEmpty();
						$member_zenRegex 	= new Zend_Validate_Regex($patternZen);
						$member_nameLength= new Zend_Validate_StringLength( $min,$max );
						//$member_nameLength = new Zend_Validate_StringLength();
						//$member_nameLength->setMin(2);
						//$member_nameLength->setMax(30);
				
				// エラーメッセージをセットする
							$member_nameEmpty->setMessage( $message .'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							$member_zenRegex->setMessage( $message .'は、全角のみで構成されていません。');
							$member_nameLength->setMessages(array(
							    Zend_Validate_StringLength::TOO_SHORT => $message .'は、%min%文字以上にしてください。',
							    Zend_Validate_StringLength::TOO_LONG  => $message .'は、%max%文字以下にしてください。')
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($member_nameEmpty, true)
				               ->addValidator($member_zenRegex, true)
				               ->addValidator($member_nameLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }




    /**-------------------------------------------------------------------------------------------
		 * 半角文字列のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				3
		 * @param  int    $max     最大文字数				16
		 * @param  array  $message エラーメッセージ	ユーザＩＤ
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringHalf($min, $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						//A-Za-z0-9 ァ-ヶ
						$half_sign = 'A-Za-z0-9';
						$kana_sign = 'ぁ-ゖ　ー';
						$tel_sign = '0-9-+()内線';
						//$patternZen ='/^[一-龠ぁ-ゖァ-ヶーヽヾ々]+$/u';			//全角文字(仕様的に狭い範囲) 全角スペース無理
						//$patternKana ='/^[ぁ-ゖ]+$/u';											//全角ひらがな UTF-8 の文字コードの正規表現では u オプションを付加
						$patternHan 	="/^[" . $half_sign. "]+$/u";
						$patternKana 	="/^[" . $kana_sign. "]+$/u";
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				// インスタンスを生成する
						$user_nameEmpty = new Zend_Validate_NotEmpty();
						$user_zenRegex 	= new Zend_Validate_Regex($patternHan);
						$user_nameLength= new Zend_Validate_StringLength( $min, $max );
						//$user_nameLength = new Zend_Validate_StringLength();
						//$user_nameLength->setMin($min);
						//$user_nameLength->setMax($max);
				
				// エラーメッセージをセットする
							$user_nameEmpty->setMessage( $message .'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							$user_zenRegex->setMessage(  $message .'は、半角英数字のみで構成されていません。');
							$user_nameLength->setMessages(array(
							    Zend_Validate_StringLength::TOO_SHORT => $message .'は、%min%文字以上にしてください。',
							    Zend_Validate_StringLength::TOO_LONG  => $message .'は、%max%文字以下にしてください。')
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($user_nameEmpty, true)
				               ->addValidator($user_zenRegex, true)
				               ->addValidator($user_nameLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }




    /**-------------------------------------------------------------------------------------------
		 * 半角文字列のバリデート処理を行う（未使用）
		 *
		 * @param  int    $min     最小文字数				3
		 * @param  int    $max     最大文字数				16
		 * @param  array  $message エラーメッセージ	ユーザＩＤ
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringDate($min, $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						//A-Za-z0-9 ァ-ヶ
						//$half_sign = 'A-Za-z0-9';
						$half_sign = 'A-Za-z0-9-:　';
						$half_sign = '0-9-:　';
						$kana_sign = 'ぁ-ゖ　ー';
						$tel_sign = '0-9-:　';
						//$patternZen ='/^[一-龠ぁ-ゖァ-ヶーヽヾ々]+$/u';			//全角文字(仕様的に狭い範囲) 全角スペース無理
						//$patternKana ='/^[ぁ-ゖ]+$/u';											//全角ひらがな UTF-8 の文字コードの正規表現では u オプションを付加
						$patternHan 	="/^[" . $half_sign. "]+$/u";
						$patternKana 	="/^[" . $kana_sign. "]+$/u";
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				// インスタンスを生成する
						$user_nameEmpty = new Zend_Validate_NotEmpty();
						$user_zenRegex 	= new Zend_Validate_Regex($patternHan);
						$user_nameLength= new Zend_Validate_StringLength( $min, $max );
						//$user_nameLength = new Zend_Validate_StringLength();
						//$user_nameLength->setMin($min);
						//$user_nameLength->setMax($max);
				
				// エラーメッセージをセットする
							$user_nameEmpty->setMessage( $message .'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							$user_zenRegex->setMessage(  $message .'は、半角英数字のみで構成されていません。');
							$user_nameLength->setMessages(array(
							    Zend_Validate_StringLength::TOO_SHORT => $message .'は、%min%文字以上にしてください。',
							    Zend_Validate_StringLength::TOO_LONG  => $message .'は、%max%文字以下にしてください。')
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($user_nameEmpty, true)
				               ->addValidator($user_zenRegex, true)
				               ->addValidator($user_nameLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }




    /**-------------------------------------------------------------------------------------------
		 * 半角数字入力のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				7,5,
		 * @param  int    $max     最大文字数				7,5,
		 * @param  array  $message エラーメッセージ	'学籍番号','科目コード',
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringNumber( $min, $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						$minMemberId = 1041258;
						$maxMemberId = 1115405;
						$minMemberId = 1000000;
						$maxMemberId = 1040000;
						$minMemberId = 10000;
						$maxMemberId = 99999;
				
				// インスタンスを生成する
						$member_idEmpty = new Zend_Validate_NotEmpty();
						$member_idDigits = new Zend_Validate_Digits();
						$member_idBetween = new Zend_Validate_Between($minMemberId,$maxMemberId);
						$member_idLength 	= new Zend_Validate_StringLength( $min,$max );
						//$member_idLength = new Zend_Validate_StringLength();
						//$member_idLength->setMin(7);
						//$member_idLength->setMax(7);
				
				// エラーメッセージをセットする
							$member_idEmpty->setMessage(  $message . 'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							$member_idDigits->setMessage( $message . '「' . $input . '」は、半角数字のみで構成されていません。');
							$member_idBetween->setMessages(array(
							    Zend_Validate_Between::NOT_BETWEEN        =>  $message . '「%value%」は、「%min%」と「%max%」の範囲内ではありません。',
							    Zend_Validate_Between::NOT_BETWEEN_STRICT =>  $message . '「%value%」は、「%min%」を超えて「%max%」未満の範囲内ではありません。')
							);
							$member_idLength->setMessages(array(
							    Zend_Validate_StringLength::TOO_SHORT =>  $message . 'は、%min%桁にしてください。',
							    Zend_Validate_StringLength::TOO_LONG  =>  $message . 'は、%max%桁にしてください。')
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($member_idEmpty, true)
				               ->addValidator($member_idDigits, true)
				               ->addValidator($member_idLength, true)
				               ->addValidator($member_idLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }




    /**-------------------------------------------------------------------------------------------
		 * 半角Email入力のバリデート処理を行う
		 *
		 * @param  int    $max     最大文字数				30,
		 * @param  array  $message エラーメッセージ	'E-mail',
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringEmail( $max, $message, $input)
    {
				$msg = array();
				
				// パラメータ
						//A-Za-z0-9 ァ-ヶ
						$full_sign = 'A-Za-z 一-龠ぁ-ゖァ-ヶ　、。，．・：；？！゛゜´｀¨＾￣＿ヽヾ〃仝々〆〇ー―‐／～∥｜…‥‘’“”（）〔〕［］｛｝〈〉《》「」『』【】＋－±×÷＝≠＜＞≦≧∞∴♂♀°′″℃￥＄￠￡％＃＆＊＠§☆★○●◎◇字◆□■△▲▽▼※〒→←↑↓〓∈∋⊆⊇⊂⊃∪∩∧∨￢⇒⇔∀∃∠⊥⌒∂∇≡≒≪≫√∽∝∵∫∬Å‰♯♭♪†‡¶◯';
						$kana_sign = 'ぁ-ゖ　ー';
						$tel_sign = '0-9-+()内線';
						//$patternZen ='/^[一-龠ぁ-ゖァ-ヶーヽヾ々]+$/u';			//全角文字(仕様的に狭い範囲) 全角スペース無理
						//$patternKana ='/^[ぁ-ゖ]+$/u';											//全角ひらがな UTF-8 の文字コードの正規表現では u オプションを付加
						$patternZen 	="/^[" . $full_sign. "]+$/u";
						$patternKana 	="/^[" . $kana_sign. "]+$/u";
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				
				// インスタンスを生成する
						$emailEmpty = new Zend_Validate_NotEmpty();
						$emailCheck	= new Zend_Validate_EmailAddress();
						//$emailLength= new Zend_Validate_StringLength( 6,30 );
						$emailLength = new Zend_Validate_StringLength();
						$emailLength->setMax($max);
				
				// エラーメッセージをセットする
							$emailEmpty->setMessage( $message . 'は、必須項目です。',Zend_Validate_NotEmpty::IS_EMPTY);
							//$emailCheck->setMessage('メールアドレスではありません。',Zend_Validate_EmailAddress::INVALID);
							$emailCheck->setMessages(array(
									Zend_Validate_EmailAddress::INVALID_FORMAT => '\'%value%\' は、メールアドレスではありません。',
									Zend_Validate_EmailAddress::LENGTH_EXCEEDED  => '\'%value%\' は、メールアドレスではありません。'
								)
							);
							//$emailLength->setMessages(array(
							//    Zend_Validate_StringLength::TOO_SHORT => 'E-mailは、6文字以上で入力してください。',
							//    Zend_Validate_StringLength::TOO_LONG  => 'E-mailは、30文字以下で入力してください。')
							//);
							$emailLength->setMessages(
								array(
									Zend_Validate_StringLength::TOO_LONG  => $message . 'は、最大%max%文字以内にしてください。'
								)
							);
							iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($emailEmpty, true)
				               ->addValidator($emailCheck, true)
				               ->addValidator($emailLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }





    /**-------------------------------------------------------------------------------------------
		 * 半角TEL入力のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				3,
		 * @param  int    $max     最大文字数				30,
		 * @param  array  $message エラーメッセージ	'ＴＥＬ',
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 */
    function validateStringTel( $min, $max, $message, $input)
    {
				$msg = array();
				
				if( $input == '' )	return $msg;
				
				// パラメータ
						$tel_sign = '0-9-+()内線';
						$patternTel		="/^[" . $tel_sign. "]+$/u";
				
				
				// インスタンスを生成する
						$telRegex = new Zend_Validate_Regex($patternTel);
						//$telLength = new Zend_Validate_StringLength( $min,$max );
						$telLength = new Zend_Validate_StringLength();
						$telLength->setMin(3);
						$telLength->setMax(30);
				
				// エラーメッセージをセットする
						$telRegex->setMessage(  $message . 'は、数字のみで構成されていません。');
						$telLength->setMessages(array(
						    Zend_Validate_StringLength::TOO_SHORT =>  $message . 'は、%min%文字以上にしてください。',
						    Zend_Validate_StringLength::TOO_LONG  =>  $message . 'は、%max%文字以下にしてください。')
						);
						iconv_set_encoding('internal_encoding', 'UTF-8');		// iconvの内部文字コードをUTF-8に設定する
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($telRegex, true)
				               ->addValidator($telLength);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }




    /**-------------------------------------------------------------------------------------------
		 * 選択のバリデート処理を行う
		 *
		 * @param  int    $min     最小文字数				3
		 * @param  int    $max     最大文字数				16
		 * @param  array  $message エラーメッセージ	
		 *						'学年','グループ','分類','種別','適応開始入学年度','適応終了入学年度','入学年度','性別',
		 *						'適応教育課程（グループ）','適応学年','単位数','開講時期','必修選択','適応入学年度','適応終了年度',
		 * @param  string $input   入力データ
		 * @return array  エラーリスト
		 * 
		 * count($array)も可
		 */
    function validateSelect( $message, $input, $min =0 )
    {
				$msg = array();
				
				// パラメータ
						$minSelect =$min;
				
				// インスタンスを生成する
						$gradeGreater = new Zend_Validate_GreaterThan($minSelect);
				
				// エラーメッセージをセットする
						$gradeGreater->setMessage( $message .'が、選択されていません。');
				
				// バリデータチェーンを作成する
				$validatorChain = new Zend_Validate();
				$validatorChain->addValidator($gradeGreater);
				
				// バリデート処理
				if (!$validatorChain->isValid($input)) {
				    $msg = $validatorChain->getMessages();
						return $msg;
				} else {
				    //echo 'チェック処理を通過しました！';
				}
				
				return $msg;
				
    }


    function isDispMode( $view )
    {
			if( $view->userLevel=='admin' )
					return true;
			else
					return false;
		}


