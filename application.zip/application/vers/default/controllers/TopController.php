<?php
/**
 * Topコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Auth_Adapter_DbTable'); 
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する


require_once 'Zend/Session.php';
require_once 'Zend/Captcha/Dumb.php';
require_once 'Zend/Captcha/Figlet.php';
require_once 'Zend/Captcha/Image.php';


// モデルをロードする
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class TopController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_user;						// ユーザモデルのインスタンス
    private $_namespace;
    private $_userspace;
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        $this->_user = new userModel('../application/lib/user.db');
        $this->_menu = new menuModel('../application/lib/user.db');

        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				$this->view->sid 			 = '';	
				$this->view->loginUrl  = 'login/index';	
				$this->view->loginName = 'ログイン';	
				
				$this->view->userLevel = '-';		//FD高度化推進室　システム管理者
				$this->view->userName  = '';			//admin
				$this->view->userId		 = '';			//admin
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
					        //$this->view->userId		 = $this->_userspace->userId;			//$_SESSION[$this->_sid]['userId'];			//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
									$this->view->sid 			 = '';	
									$this->view->loginUrl  = 'login/index';	
									$this->view->loginName = 'ログイン';	
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}




        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
        // 前アクションでエラーならメッセージを表示する
				if( $this->getRequest()->isGet() ) {
						
					  // 前アクションでエラーならメッセージを表示する
					  $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
						$msg		= getDispMessage( $noMsg,$this->view ) ;
						if( !is_null($msg) ){
								array_push( $errors,array($msg) );
						}
						
						if( $noMsg == ERR_PASSWORD_INIT ){		//'パスワードを初期化しました。
								
								$teacherPasss	= $this->_userspace->search['top']['teacherPasss'];	
								if( $teacherPasss != null ){
									$no =0;
									foreach( $teacherPasss as $row )
									{
										$no++;
										
										$msg  = '　' . $no . '：　' . $row['name'] .'　（'. $row['pass'] .'）';
										array_push( $errors,array($msg) );
									}
								}
								
						}
						
					  $name	= $this->getRequest()->getParam('name',null );
						if( !is_null($name) ){
								array_push( $errors,array($name) );
						}
						
						$this->view->assign('errors',$errors);			// 追加後に再設定必要
						
				}
				
				{
						
						$this->_sid = $this->_sessionId;
		        // ユーザーレベルを取得する
						if( !isset($this->_sid) ){
								
						    $contents = 'このユーザは自動ログアウトしています';
		           	$this->_setParam('errorMsg', $contents );
								
				        $targetUrl = 'login/index';
						    $targetUrl = 'top/index';
						}else{
								if( !Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
										
						        $targetUrl = 'login/index';
						        $targetUrl = 'top/index';
								}
						}
				}
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }






    /**-------------------------------------------------------------------------------------------
     * imageアクション
     */
    public function imageAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
		        $this->view->user_name 		 = $this->_userspace->userName;
		        $this->view->user_id  		 = $this->_userspace->userId;
		        //$this->view->password_old  = '';
		        $this->view->password_new  = '';
		        $this->view->password_new2 = '';

		        // Imageオブジェクトを生成する
		        $captcha = new Zend_Captcha_Image();
		        $captcha->setName('captcha');
		        $captcha->setFont('../application/lib/IPAfont00203/ipagui.ttf');
		        $captcha->setImgDir('../ananfd/docs/captcha/');
						$expiration = 60;
						$captcha->setExpiration($expiration);
						$height = 60;
						$captcha->setHeight($height);
		        $captcha->setImgUrl( '/ananfd/docs/' . 'captcha/');
		        $captcha->generate();
		        $this->view->captcha = $captcha->render($this->view);
		        $this->view->captchaId = $captcha->getId();
						

				}
				else if( $this->getRequest()->isPost() ){
						
						$userId 	= $this->getRequest()->getParam('user_id');
						$passNew 	= $this->getRequest()->getParam('password_new');
						$passNew2	= $this->getRequest()->getParam('password_new2');
		        // リクエストオブジェクトを取得する
		        $request 		 = $this->getRequest();
		        $captchaId   = $request->getPost('captcha_id');
		        $captchaWord = $request->getPost('captcha_word');
            $captcha = new Zend_Captcha_Image();
						
						$userId 	= trim($userId);								//半角スペースのみ
						$passNew 	= trim($passNew);								//半角スペースのみ
						$passNew2	= trim($passNew2);							//半角スペースのみ
						


		        // Captchaの内部名を設定する
		        $captcha->setName('captcha');
		        // 認証用にパラメータを作成する
		        $param = array('captcha' => array('id'    => $captchaId, 
		                                          'input' => $captchaWord
		                                    )
		                 );
		        // 認証処理を行う
		        $ret = $captcha->isValid('', $param);
		        // 認証成功時
		        if ($ret) {
		            //$this->view->message = '認証が成功しました！';
		        // 認証失敗時
		        } else {
		            // エラーコードを取得する
		            $errorCode = $captcha->getErrors();
		            // エラーの種類ごとにメッセージを設定する
		            switch ($errorCode[0]) {
		                case Zend_Captcha_Word::MISSING_VALUE:
												array_push($errors, array('認証コードの文字列が入力されていません。') );
		                    break;
		                case Zend_Captcha_Word::MISSING_ID:
												array_push($errors, array('認証にて、認証IDが不正です。') );
		                    break;
		                case Zend_Captcha_Word::BAD_CAPTCHA:
												array_push($errors, array('認証コードの入力された文字列が正しくありません。') );
		                    break;
		                default:
												array_push($errors, array('認証にて、予期せぬエラーが発生しました。') );
		                    break;
		            }
		        }
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード',$passNew);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード（確認入力）',$passNew2);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								//新しいパスワード名チェック
								if( $passNew !== $passNew2 ){
									array_push($errors, array('確認入力のパスワードが、一致しませんでした。') );
									
				 				}
								
						}
						
						if (count($errors) == 0){
								
								$this->_user->updateUserPassword( $userId, $passNew, $this->_userspace );
								
					      // ビュースクリプトが表示されます
							  $targetUrl = '/top/index/sid/'.$this->_sid.'/'.DISP_MESSAGE.'/'.ERR_PASSWORD_CHG;		//'パスワードを変更しました。
						    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else{
								
		     				$this->view->user_name 		= $this->_userspace->userName;
								$this->view->user_id			= $userId;
								$this->view->password			= '';
								$this->view->password2		= '';
								
				        // Imageオブジェクトを生成する
				        $captcha = new Zend_Captcha_Image();
				        $captcha->setName('captcha');
				        $captcha->setFont('../application/lib/IPAfont00203/ipagui.ttf');
				        $captcha->setImgDir('../ananfd/docs/captcha/');
				        $captcha->setImgUrl( '/ananfd/docs/' . 'captcha/');
				        $captcha->generate();
				        $this->view->captcha = $captcha->render($this->view);
				        $this->view->captchaId = $captcha->getId();
								
						}
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。
				
    }





    /**-------------------------------------------------------------------------------------------
     * dumpアクション
     */
    public function dumpAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
		        $this->view->user_name 		 = $this->_userspace->userName;
		        $this->view->user_id  		 = $this->_userspace->userId;
		        $this->view->password_new  = '';
		        $this->view->password_new2 = '';

		        // Dumbオブジェクトを生成する
		        $captcha = new Zend_Captcha_Dumb();
		        $captcha->setName('captcha');
		        $captcha->generate();
		        $this->view->captcha = $captcha->render($this->view);
		        $this->view->captchaId = $captcha->getId();
						

				}
				else if( $this->getRequest()->isPost() ){
						
						$userId 	= $this->getRequest()->getParam('user_id');
						$password	= $this->getRequest()->getParam('password_old');
						$passNew 	= $this->getRequest()->getParam('password_new');
						$passNew2	= $this->getRequest()->getParam('password_new2');
		        // リクエストオブジェクトを取得する
		        $request 		 = $this->getRequest();
		        $captchaId   = $request->getPost('captcha_id');
		        $captchaWord = $request->getPost('captcha_word');
            $captcha = new Zend_Captcha_Dumb();
						$userId 	= trim($userId);								//半角スペースのみ
						$password	= trim($password);							//半角スペースのみ
						$passNew 	= trim($passNew);								//半角スペースのみ
						$passNew2	= trim($passNew2);							//半角スペースのみ
						

		        // Captchaの内部名を設定する
		        $captcha->setName('captcha');
		        // 認証用にパラメータを作成する
		        $param = array('captcha' => array('id'    => $captchaId, 
		                                          'input' => $captchaWord
		                                    )
		                 );
		        // 認証処理を行う
		        $ret = $captcha->isValid('', $param);
		        // 認証成功時
		        if ($ret) {
		            //$this->view->message = '認証が成功しました！';
		        // 認証失敗時
		        } else {
		            // エラーコードを取得する
		            $errorCode = $captcha->getErrors();
		            // エラーの種類ごとにメッセージを設定する
		            switch ($errorCode[0]) {
		                case Zend_Captcha_Word::MISSING_VALUE:
												array_push($errors, array('認証コードの文字列が入力されていません。') );
		                    break;
		                case Zend_Captcha_Word::MISSING_ID:
												array_push($errors, array('認証にて、認証IDが不正です。') );
		                    break;
		                case Zend_Captcha_Word::BAD_CAPTCHA:
												array_push($errors, array('認証コードの入力された文字列が正しくありません。'.$captchaWord) );
		                    break;
		                default:
												array_push($errors, array('認証にて、予期せぬエラーが発生しました。') );
		                    break;
		            }
		        }
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード',$passNew);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード（確認入力）',$passNew2);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								//新しいパスワード名チェック
								if( $passNew !== $passNew2 ){
									array_push($errors, array('確認入力のパスワードが、一致しませんでした。') );
									
				 				}
								
						}
						

						if (count($errors) == 0){

/**
	ファイル削除処理必要
**/
								
								$this->_user->updateUserPassword( $userId, $passNew, $this->_userspace );
								
					      // ビュースクリプトが表示されます
							  $targetUrl = '/top/index/sid/'.$this->_sid.'/'.DISP_MESSAGE.'/'.ERR_PASSWORD_CHG;		//'パスワードを変更しました。
						    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else{
								
		     				$this->view->user_name 		= $this->_userspace->userName;
								$this->view->user_id			= $userId;
								$this->view->password_old	= $password;
								$this->view->password			= $passNew;
								$this->view->password2		= $passNew2;
								
				        // Dumbオブジェクトを生成する
				        $captcha = new Zend_Captcha_Dumb();
				        $captcha->setName('captcha');
				        $captcha->generate();
				        $this->view->captcha = $captcha->render($this->view);
				        $this->view->captchaId = $captcha->getId();
								
						}
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。
				
    }




    /**-------------------------------------------------------------------------------------------
     * figletアクション
     */
    public function figletAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
		        $this->view->user_name 		 = $this->_userspace->userName;
		        $this->view->user_id  		 = $this->_userspace->userId;
		        $this->view->password_old  = '';
		        $this->view->password_new  = '';
		        $this->view->password_new2 = '';
						
		        // Figletオブジェクトを生成する
		        $captcha = new Zend_Captcha_Figlet();
		        $captcha->setName('captcha');
		        $captcha->setWordlen(5);
		        $captcha->generate();
		        $this->view->captcha = $captcha->render($this->view);
		        $this->view->captchaId = $captcha->getId();
						
				}
				else if( $this->getRequest()->isPost() ){
						
						$userId 	= $this->getRequest()->getParam('user_id');
						$password	= $this->getRequest()->getParam('password_old');
						$passNew 	= $this->getRequest()->getParam('password_new');
						$passNew2	= $this->getRequest()->getParam('password_new2');
						
						$userId 	= trim($userId);								//半角スペースのみ
						$password	= trim($password);							//半角スペースのみ
						$passNew 	= trim($passNew);								//半角スペースのみ
						$passNew2	= trim($passNew2);							//半角スペースのみ
						
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード',$passNew);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード（確認入力）',$passNew2);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								//新しいパスワード名チェック
								if( $passNew !== $passNew2 ){
									array_push($errors, array('確認入力のパスワードが、一致しませんでした。') );
									
				 				}
								
						}
						
									array_push($errors, array('確認入力のパスワードが、一致しませんでした。') );
						if (count($errors) == 0){
								
								$this->_user->updateUserPassword( $userId, $passNew, $this->_userspace );
								
							  $targetUrl = '/top/index/sid/'.$this->_sid.'/'.DISP_MESSAGE.'/'.ERR_PASSWORD_CHG;		//'パスワードを変更しました。
						    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else{
								
		     				$this->view->user_name 		= $this->_userspace->userName;
								$this->view->user_id			= $userId;
								$this->view->password_old	= $password;
								$this->view->password			= $passNew;
								$this->view->password2		= $passNew2;
								

				        // Figletオブジェクトを生成する
				        $captcha = new Zend_Captcha_Figlet();
				        $captcha->setName('captcha');
				        $captcha->setWordlen(5);
				        $captcha->generate();
				        $this->view->captcha = $captcha->render($this->view);
				        $this->view->captchaId = $captcha->getId();
								

						}
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。
				
    }



    /**-------------------------------------------------------------------------------------------
     * authアクション
     * ：認証処理を行う
     */
    public function authAction()
    {
        // リクエストオブジェクトを取得する
        $request = $this->getRequest();
				
        // 渡されたパラメータを取得する
        $captchaType = $request->getPost('mode');
        $captchaId   = $request->getPost('captcha_id');
        $captchaWord = $request->getPost('captcha_word');
				
        // モードごとにCaptchaオブジェクトを生成する
        switch ($captchaType) {
            case 'dumb':
                $captcha = new Zend_Captcha_Dumb();
                break;
            case 'figlet':
                $captcha = new Zend_Captcha_Figlet();
                break;
            case 'image':
                $captcha = new Zend_Captcha_Image();
                break;
        }
				
        // Captchaの内部名を設定する
        $captcha->setName('captcha');
        // 認証用にパラメータを作成する
        $param = array('captcha' => array('id'    => $captchaId, 
                                          'input' => $captchaWord
                                    )
                 );
        // 認証処理を行う
        $ret = $captcha->isValid('', $param);
        // 認証成功時
        if ($ret) {
            $this->view->message = '認証が成功しました！';
        // 認証失敗時
        } else {
            // エラーコードを取得する
            $errorCode = $captcha->getErrors();
            // エラーの種類ごとにメッセージを設定する
            switch ($errorCode[0]) {
                case Zend_Captcha_Word::MISSING_VALUE:
                    $this->view->message = '文字列が入力されていません。';
                    break;
                case Zend_Captcha_Word::MISSING_ID:
                    $this->view->message = '認証IDが不正です。';
                    break;
                case Zend_Captcha_Word::BAD_CAPTCHA:
                    $this->view->message = '入力された文字列が正しくありません。';
                    break;
                default:
                    $this->view->message = '予期せぬエラーが発生しました。';
                    break;
            }
        }
    }


    /**-------------------------------------------------------------------------------------------
     * passwordアクション
     */
    public function passwordAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
		        $this->view->user_id  		 = '';
		        $this->view->password_old  = '';
		        $this->view->password_new  = '';
		        $this->view->password_new2 = '';
				}
				else if( $this->getRequest()->isPost() ){
						
						$userId 	= $this->getRequest()->getParam('user_id');
						$password	= $this->getRequest()->getParam('password_old');
						$passNew 	= $this->getRequest()->getParam('password_new');
						$passNew2	= $this->getRequest()->getParam('password_new2');
						
						$userId 	= trim($userId);								//半角スペースのみ
						$password	= trim($password);							//半角スペースのみ
						$passNew 	= trim($passNew);								//半角スペースのみ
						$passNew2	= trim($passNew2);							//半角スペースのみ
						
						$msgs = validateStringHalf( 3, 16, 'ユーザＩＤ', $userId);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringHalf( 3, 16, '古いパスワード',$password);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else if( $userId !==null || $userId==='' ){
								//ユーザＩＤ・古いパスワード名チェック
								
				        // データベースの接続パラメータを定義する
				        $params = array('host'     => $this->_config->datasource->database->host,
				                        'username' => $this->_config->datasource->database->username,
				                        'password' => $this->_config->datasource->database->password,
				                        'dbname'   => $this->_config->datasource->database->name
				                  );
				        // データベースアダプタを作成する
				        $db = Zend_Db::factory($this->_config->datasource->database->type, $params);
								$db->query("set names 'utf8'");
				        // データベース認証アダプタを作成する
				        $auth = new Zend_Auth_Adapter_DbTable($db, 't_user', 'login_id', 'password','MD5(?)');
				        // 認証処理を実行する
				        $auth->setIdentity( $userId );
				        $auth->setCredential( $password );
				        $result = $auth->authenticate();
				        // 認証失敗であれば入力画面にもどる
				        if (!$result->isValid()) {
								    $errCode = $result->getCode();
								    switch ($errCode) {
								        case Zend_Auth_Result::FAILURE_IDENTITY_NOT_FOUND:
								            $contents = 'このユーザＩＤは存在しません。';
								            break;
								        case Zend_Auth_Result::FAILURE_CREDENTIAL_INVALID:
								            $contents = '古いパスワードが間違っている可能性があります。';
								            break;
								        default:
								            $contents = 'ユーザ認証に失敗しました。';
								            break;
								    }
										array_push($errors, array($contents) );
				 				}
								
						}
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード',$passNew);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateStringHalf( 3, 16, '新しいパスワード（確認入力）',$passNew2);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								//新しいパスワード名チェック
								if( $passNew !== $passNew2 ){
									array_push($errors, array('確認入力のパスワードが、一致しませんでした。') );
									
				 				}
								
						}
						
						if (count($errors) == 0){
								
								$this->_user->updateLoginPassword( $userId, $passNew );
								
					      // ビュースクリプトが表示されます
							  $targetUrl = '/top/index/sid/'.$this->_sid.'/noMsg/1';
						    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else{
								
								$this->view->user_id			= $userId;
								$this->view->password_old	= $password;
								$this->view->password			= '';
								$this->view->password2		= '';
								
						}
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。
				
    }




    /**-------------------------------------------------------------------------------------------
     * userinfoアクション
     */
    public function userinfoAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$userId		 = $this->_userspace->userId;	
				$select = $this->_user->getUserId( $userId );
				
        // ビュースクリプトが表示されます
       	$this->view->assign( 'result', $select );	//複数の変数（連想配列）を一度に設定する。
				
				$menu_mode ='';					//select
				$this->view->groupArray	= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray		= $this->_menu->getJobList( $menu_mode, null );
				$this->view->roleArray	= $this->_menu->getRoleList( $menu_mode, null );
				
    }




    /**-------------------------------------------------------------------------------------------
     * initpassアクション
     */
    public function initpassAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
						
		        $this->view->user_name 		 = $this->_userspace->userName;
		        $this->view->user_id  		 = '';
		        $this->view->user_id  		 = $this->_userspace->userId;

						
						$this->view->user ='';
						$teacherLists	= $this->_userspace->search['top']['teacherLists'];	
						if( $teacherLists != null ){
							foreach( $teacherLists as $idx )
							{
								$student = $this->_user->getUserName($idx);
								if (end($teacherLists) == $idx ) 
									$this->view->user	.= $student ;
								else
									$this->view->user	.= $student .'、';
							}
						}

				}
				else if( $this->getRequest()->isPost() ){
						
						
						if (count($errors) == 0){
								
								
								$teacherLists	= $this->_userspace->search['top']['teacherLists'];
								$passArray = array();	
								if( $teacherLists != null ){
									foreach( $teacherLists as $idx )
									{
										
										$userId		 = $idx;	
										if( ($pass = $this->_user->initPassword( $userId, $this->_userspace ))==false ){
									      // ビュースクリプトが表示されます
											  $targetUrl = '/top/index/sid/'.$this->_sid.'/'.DISP_MESSAGE.'/'.ERR_PASSWORD_ERR;			//'パスワード処理でエラーが発生しました。
										    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										} else {
												$name	= $this->_user->getUserName($userId);
												array_push( $passArray, 
																	array("user_id"=>$userId,"name"=>$name,"pass"=>$pass) );
										}
									}
									
									$this->_userspace->search['top']['teacherPasss'] = $passArray;
									$targetUrl = '/top/index/sid/'.$this->_sid.'/'.DISP_MESSAGE.'/'.ERR_PASSWORD_INIT;		//'パスワードを初期化しました。
									return $this->_redirect($targetUrl);		//DebugMessage 表示不可
								}
						}
						else{
								
		     			  $this->view->user_name 		 = $this->_userspace->userName;
								$this->view->user_id			= $userId;
		        		$this->view->user_id  		 = $this->_userspace->userId;
								
						}
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。
				
    }




    /**-------------------------------------------------------------------------------------------
     * userアクション（ユーザ選択検索）
     */
    public function userAction()
    {
				$errors = array();
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['top']['sGroup']		= $this->getRequest()->getParam('s_group');		
						$this->_userspace->search['top']['sJob']			= $this->getRequest()->getParam('s_job');			
						$this->_userspace->search['top']['sKana']			= $this->getRequest()->getParam('s_kana');		
						$this->_userspace->search['top']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
						$this->_userspace->search['top']['sField']		= $this->getRequest()->getParam('s_field');		
						$this->_userspace->search['top']['sKind']			= $this->getRequest()->getParam('s_kind');		
						
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['top']['sGroup']) )
							$this->_userspace->search['top']['sGroup']		= '0';
						if( !isset($this->_userspace->search['top']['sJob']) )
							$this->_userspace->search['top']['sJob']			= '0';
						if( !isset($this->_userspace->search['top']['sKana']) )
							$this->_userspace->search['top']['sKana']			= '0';
						if( !isset($this->_userspace->search['top']['sKeyword']) )
							$this->_userspace->search['top']['sKeyword']	= '';
						if( !isset($this->_userspace->search['top']['sField']) )
							$this->_userspace->search['top']['sField']		= '0';
						if( !isset($this->_userspace->search['top']['sKind']) )
							$this->_userspace->search['top']['sKind']			= '0';
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加ユーザが、指定されていません。') );
						}
						else if( $error ==2 ){
							
							array_push($errors, array('追加ユーザは、１名のみ選択してください。') );
						}
				}
				
				
				$bFind = true;	
				
				$sGroup		= $this->_userspace->search['top']['sGroup'];		
				$sJob			= $this->_userspace->search['top']['sJob'];			
				$sKana		= $this->_userspace->search['top']['sKana'];			
				$sKeyword	= $this->_userspace->search['top']['sKeyword'];	
				$sField		= $this->_userspace->search['top']['sField'];		
				$sKind		=	$this->_userspace->search['top']['sKind'];			
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sKind	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  $sKind,
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
					
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				$this->view->roleArray		= $this->_menu->getRoleList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selKind		= $sKind;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要





				$top2index		= $this->view->modulePath.'top/index'	.$this->view->sid;
				$top2initpass	= $this->view->modulePath.'top/initpass2'	.$this->view->sid;
				$top2user			= $this->view->modulePath.'top/user'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'パスワード初期化'	,'url'=>$top2initpass ),
									array('name'=>'ユーザ選択'				,'url'=>$top2user )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * adduserアクション
     */
    public function adduserAction()
    {

				if( $this->getRequest()->isPost() ) {
						
						$userArray	= $this->getRequest()->getParam('user_id');
						
						if( count($userArray) == 0 ){
				        $targetUrl = '/top/user/error/1/sid/'.$this->_sid;		//'追加ユーザが、指定されていません。'
				        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else if( count($userArray) > 1 ){
				        $targetUrl = '/top/user/error/2/sid/'.$this->_sid;		//'追加ユーザは、１名のみ選択してください。'
				        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else{
								$teacherArray = $this->_userspace->search['top']['teacherLists'];
								if( $teacherArray == null )
										$teacherArray = array();	
								foreach( $userArray as $idx )
								{
									if( array_search( $idx, $teacherArray )===false )
										array_push( $teacherArray, $idx );
								}
								$this->_userspace->search['top']['teacherLists'] = $teacherArray;
								
						}
				}
				
			  // ビュースクリプトが表示されます
			  $targetUrl = '/top/initpass/sid/'.$this->_sid;
			  return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }


    /**-------------------------------------------------------------------------------------------
     * deluesrアクション
     */
    public function deluserAction()
    {
				
				
				$this->_userspace->search['top']['teacherLists'] = array();
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/top/initpass/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
		}











    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
