<?php
/**
 * Subjectコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); 							// 追加する

// モデルをロードする
require_once '../application/vers/default/models/subjectModel.php';
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/menuModel.php';

// モジュールをロードする
require_once '../application/lib/functions.php';



class SubjectController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_subject;				// サブジェクトモデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
				$this->_sid = 
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        $this->_subject = new subjectModel('../application/lib/subject.db');
        $this->_user 		= new userModel('../application/lib/user.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}



				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->reqArray			= $this->_menu->getReqList( $menu_mode, null );
				$this->view->termArray		= $this->_menu->getTermList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField2List( null, null );
				
				


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);




				}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				
				if( $this->getRequest()->isPost() ) 
				{
						$this->_userspace->search['subject']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['subject']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['subject']['sStyear']		= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['subject']['sReq']			= $this->getRequest()->getParam('s_req');
						$this->_userspace->search['subject']['sTerm']			= $this->getRequest()->getParam('s_term');
						$this->_userspace->search['subject']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['subject']['sField']		= $this->getRequest()->getParam('s_field');
				} else {
						if( !isset($this->_userspace->search['subject']['sGroup']) )
							$this->_userspace->search['subject']['sGroup']		= '0';
						if( !isset($this->_userspace->search['subject']['sGrade']) )
							$this->_userspace->search['subject']['sGrade']		= '0';
						if( !isset($this->_userspace->search['subject']['sStyear']) )
							$this->_userspace->search['subject']['sStyear']		= '0';
						if( !isset($this->_userspace->search['subject']['sReq']) )
							$this->_userspace->search['subject']['sReq']			= '0';
						if( !isset($this->_userspace->search['subject']['sTerm']) )
							$this->_userspace->search['subject']['sTerm']			= '0';
						if( !isset($this->_userspace->search['subject']['sKeyword']) )
							$this->_userspace->search['subject']['sKeyword']	= '';
						if( !isset($this->_userspace->search['subject']['sField']) )
							$this->_userspace->search['subject']['sField']		= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['subject']['sGroup'];		
				$sGrade		= $this->_userspace->search['subject']['sGrade'];		
				$sStyear	= $this->_userspace->search['subject']['sStyear'];	
				$sReq			= $this->_userspace->search['subject']['sReq'];			
				$sTerm		= $this->_userspace->search['subject']['sTerm'];		
				$sKeyword	= $this->_userspace->search['subject']['sKeyword'];	
				$sField		= $this->_userspace->search['subject']['sField'];		
				if( $sGroup 	=== null 
					||	$sGrade	=== null 
					|| 	$sStyear=== null 
					||	$sReq		=== null 
					||	$sTerm	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sReq		== "0"  
					&& $sTerm		== "0"  
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_req'			=>  $sReq,
																	's_term'		=>  $sTerm,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						
						$select = $this->_subject->getSubjectPage( $findArray );
						
				} else 
				{
						
						$select = $this->_subject->getSubjectPage( null );
						
				}
				
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				


				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selReq			= $sReq;
				$this->view->selTerm		= $sTerm;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;




				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$education2index= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index	= $this->view->modulePath.'subject/index'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$subject2new		= $this->view->modulePath.'subject/new'			.$this->view->sid;
				$subject2import	= $this->view->modulePath.'subject/import'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成' 	,'url'=>$subject2new		,'onclick'=>'' ),
									array('name'=>'separator' ,'url'=>$urlNon      		,'onclick'=>'' ),
									array('name'=>'一括読込'	,'url'=>$subject2import	,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

	    }



    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$subject_id = $this->getRequest()->getParam('subject_id');
						if( $subject_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_subject->getSubjectId( $subject_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['code'] != 0 ){
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											$this->view->selReq			= $result["require"];	
											$this->view->selTerm		= $result["term"];	
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
											$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
											$this->view->reqArray			= $this->_menu->getReqList( null, null );
											$this->view->termArray		= $this->_menu->getTermList( null, null );
											
											
											// 1レコードの取得
											$group = $this->_subject->chargedGroupId( $subject_id );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );					//DB 1:一般教科 20110906
											}
											$this->view->selGroup		= $groupArray;

											// 1レコードの取得
											$syllabus = $this->_subject->chargedSyllabus( $subject_id );
											$syllabus2Array = array();
											foreach( $syllabus as $row ){
												array_push( $syllabus2Array, array("file"=>$row['file'],"year"=>$row['year'] ) );
											}
											$this->view->syllabus		= $syllabus2Array;

											// 1レコードの取得
											$user = $this->_subject->chargedUserId( $subject_id );
											$user2Array = array();
											foreach( $user as $row ){
												$name = $this->_subject->getUserName($row['user_id']);
												array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
											}
											$this->view->user		= $user2Array;
											
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}
				else{
				}


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$education2index= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index	= $this->view->modulePath.'subject/index'	.$this->view->sid;
				$subject2item		= $this->view->modulePath.'subject/item/subject_id/'.$result['code'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index ),
									array('name'=>$result['name']	,'url'=>$subject2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$subject2index	= $this->view->modulePath.'subject/index'.$this->view->sid;
				$subject2edit		= $this->view->modulePath.'subject/edit/subject_id/'.$result['code'].$this->view->sid;
				$subject2delete	= $this->view->modulePath.'subject/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$subject2index	,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$subject2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$subject2delete ,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'student/delete/subject_id/'.$result["code"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$subject2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$code 		= $this->getRequest()->getParam('subject_id');
				}
				
				if( $code != null ){
						$info 	= array();
						$deleteType = '1';
						
   					$this->_subject->deleteSubject( $code );
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/subject/index'. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }





    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->unitsArray		= $this->_menu->getUnitsList( null, $menu_findArray );
				$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
				$this->view->reqArray			= $this->_menu->getReqList( null, null );
				$this->view->termArray		= $this->_menu->getTermList( null, null );
				
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$subject_id = $this->getRequest()->getParam('subject_id');
						if( $subject_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_subject->getSubjectId( $subject_id );
									
									if( $result['code'] != 0 ){
											
											$this->view->code				= $result['code'];
											$this->view->name				= $result['name'];
											$this->view->file				= $result['file'];
											
											$this->view->selUnits		= $result['units'];
											$this->view->selGrade		= $result['grade'];	
											$this->view->selReq			= $result["require"];	
											$this->view->selTerm		= $result["term"];	
											
											$this->view->selStyear	= substr($result['start_year'],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											
											// 1レコードの取得
											$group = $this->_subject->chargedGroupId( $subject_id );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );
											}
											$this->view->selGroup		= $groupArray;
											// 1レコードの取得
											$syllabus = $this->_subject->chargedSyllabus( $subject_id );
											$syllabus2Array = array();
											foreach( $syllabus as $row ){
												array_push( $syllabus2Array, array("file"=>$row['file'],"year"=>$row['year'],"id"=>$row['id'] ) );
											}
											$this->view->syllabus		= $syllabus2Array;

											// 1レコードの取得
											$user = $this->_subject->chargedUserId( $subject_id );
											$user2Array = array();
											foreach( $user as $row ){
												$name = $this->_subject->getUserName($row['user_id']);
												array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
											}
											$this->view->user		= $user2Array;

											$this->view->assign('errors',$errors);			// 追加後に再設定必要
									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$code 		= $this->getRequest()->getParam('code');
						$name			= $this->getRequest()->getParam('name');
						$req			= $this->getRequest()->getParam('req');
						$term			= $this->getRequest()->getParam('term');
						$units	 	= $this->getRequest()->getParam('units');
						$grade 		= $this->getRequest()->getParam('grade');
						$styear 	= $this->getRequest()->getParam('styear');
						$edyear 	= $this->getRequest()->getParam('edyear');
						$file 		= $this->getRequest()->getParam('file');
						
						$group		= $this->getRequest()->getParam('group');
						$user			= $this->getRequest()->getParam('user');
						if( $user ==null )
							$user = array();
						
						
						$name		= trim($name);								//半角スペースのみ
						$code		= trim($code);								//半角スペースのみ
						$file		= trim($file);								//半角スペースのみ
						
						
						
						$msgs = validateStringFull( 3, 30, '授業科目名', $name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '適応入学年度', $styear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '適応終了年度', $edyear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								if( $edyear != 0 ){
									if( $edyear <= $styear ){
											
											array_push($errors, array('適応終了年度が、適応入学年度より過去に設定されています。') );
											
									}
								}
						}
						
						$msgs = validateSelect( '必修選択', $req);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '開講時期', $term);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '単位数', $units);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '適応学年', $grade);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '適応教育課程（グループ）', $group );
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						if (count($errors) == 0){
								
								$data = array(
													'name'				=>	$name,
													'code'				=>	$code,
													'start_year'	=>	$styear.'-04-01',
													'end_year'		=>	$edyear.'-04-01',
													'require'			=>	$req,
													'term'				=>	$term,
													'units'				=>	$units,
													'grade'				=>	$grade,
													'file'				=>	$file,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								if( $data['start_year'] == '0-04-01' ){
										$data['start_year'] = '0000-00-00';
								}
								if( $data['end_year'] 	== '0-04-01' ){
										$data['end_year'] 	= '9999-04-01';
								}
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $code != NULL ){
										
			    					$this->_subject->updateSubject( $data, $code, $group, $grade, $deleteType );
										
						        // ビュースクリプトが表示されます
						        $targetUrl = '/subject/index'. $this->view->sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->name				= $name;
								$this->view->code				= $code;
								$this->view->file				= $file;
								$this->view->selStyear 	= $styear;
								$this->view->selEdyear 	= $edyear;
								$this->view->selReq			= $req;
								$this->view->selTerm		= $term;
								$this->view->selUnits 	= $units;
								$this->view->selGrade 	= $grade;
								
								$this->view->selGroup 	= $group;
								$this->view->user			 	= $user;
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'		.$this->view->sid;
				$education2index= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
				$subject2item		= $this->view->modulePath.'subject/item/subject_id/'.$this->view->code.$this->view->sid;
				$subject2edit		= $this->view->modulePath.'subject/edit/subject_id/'.$this->view->code.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index ),
									array('name'=>$this->view->name	,'url'=>$subject2item ),
									array('name'=>'編集'					,'url'=>$subject2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
				$subject2item		= $this->view->modulePath.'subject/item/subject_id/'.$this->view->code.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'	,'url'=>$subject2index	,'onclick'=>'' ),
									array('name'=>'詳細'	,'url'=>$subject2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
    }






    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->unitsArray		= $this->_menu->getUnitsList( $menu_mode, $menu_findArray );
				$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
				$this->view->reqArray			= $this->_menu->getReqList( null, null );
				$this->view->termArray		= $this->_menu->getTermList( null, null );
				
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				
				
				if ($this->getRequest()->isPost()){
						
						$name 		= $this->getRequest()->getParam('name');
						$code			= $this->getRequest()->getParam('code');
						$file			= $this->getRequest()->getParam('file');
						$styear 	= $this->getRequest()->getParam('styear');
						$edyear 	= $this->getRequest()->getParam('edyear');
						$req		 	= $this->getRequest()->getParam('req');
						$term		 	= $this->getRequest()->getParam('term');
						$units 		= $this->getRequest()->getParam('units');
						$grade 		= $this->getRequest()->getParam('grade');
						$group 		= $this->getRequest()->getParam('group');
						
						$name 	= trim($name);								//半角スペースのみ
						$code 	= trim($code);								//半角スペースのみ
						$file	 	= trim($file);								//半角スペースのみ
						
						
						
						$msgs = validateStringNumber( 5, 5, '科目コード', $code);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複コードチェック
			  	  else if ( $this->_subject->isRegisteredSubject($code) == true )	{
								array_push($errors, array('この科目コードは、既に登録されています。') );
			      	}

						
						
						
						$msgs = validateStringFull( 3, 30, '授業科目名', $name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '適応入学年度', $styear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '適応終了年度', $edyear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								if( $edyear != 0 ){
									if( $edyear <= $styear ){
											
											array_push($errors, array('適応終了年度が、適応入学年度より過去に設定されています。') );
											
									}
								}
						}
						
						$msgs = validateSelect( '必修選択', $req);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '開講時期', $term);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '単位数', $units);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '適応学年', $grade);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						$msgs = validateSelect( '適応教育課程（グループ）', $group );
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
					
					
					if (count($errors) == 0){
							$data = array(
												'name'				=>	$name,
												'code'				=>	$code,
												'start_year'	=>	$styear.'-04-01',
												'end_year'		=>	$edyear.'-04-01',
												'require'			=>	$req,
												'term'				=>	$term,
												'units'				=>	$units,
												'grade'				=>	$grade,
												'file'				=>	$file,
												'delete_flg'	=> '0',
												'create_date'	=> NULL
											);
							if( $data['start_year'] == '0-04-01' ){
									$data['start_year'] = '0000-00-00';
							}
							if( $data['end_year'] 	== '0-04-01' ){
									$data['end_year'] 	= '9999-04-01';
							}
							
							
							// グループＩＤを取得する
							$deleteType = '0';
							$term = 1;
							$user = 1;
							
	    				$subject = $this->_subject->registSubjectNew( $data, $group, $user, $term, $deleteType );
	    				if( $subject != 0 ){
							  	$targetUrl = '/subject/edit/subject_id/'. $subject .$this->view->sid;
							  	return $this->_redirect($targetUrl);		//DebugMessage 表示不可
							}
	    				else if( $subject == 0 ){
									echo '中止 ';
							  	$targetUrl = '/subject/index'. $this->view->sid;
							  	return $this->_redirect($targetUrl);		//DebugMessage 表示不可
							}
					}
					else{
						
						$this->view->name				= $name;
						$this->view->code				= $code;
						$this->view->file				= $file;
						$this->view->selStyear 	= $styear;
						$this->view->selEdyear 	= $edyear;
						$this->view->selReq			= $req;
						$this->view->selTerm		= $term;
						$this->view->selUnits 	= $units;
						$this->view->selGrade 	= $grade;
						$this->view->selGroup 	= $group;
						
						}
				}
				else{
						
						$this->view->name	= ''; 		
						$this->view->code	= ''; 		
						$this->view->file	= ''; 		
						
						$this->view->selStyear 	= 0;
						$this->view->selEdyear 	= 0;
						$this->view->selUnits		= 0;
						$this->view->selGrade		= 0;
						$this->view->selReq			= 0;
						$this->view->selTerm		= 0;
						$this->view->selGroup		= array(  );
				}
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'		.$this->view->sid;
				$education2index= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
				$subject2new		= $this->view->modulePath.'subject/new'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index ),
									array('name'=>'新規作成'			,'url'=>$subject2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'	,'url'=>$subject2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }





    /**-------------------------------------------------------------------------------------------
     * userアクション
     */
    public function userAction()
    {
				$errors = array();
				
				$name			= $this->getRequest()->getParam('name');
				$code			= $this->getRequest()->getParam('code');
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['subject2']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['subject2']['sJob']			= $this->getRequest()->getParam('s_job');
						$this->_userspace->search['subject2']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['subject2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['subject2']['sField']		= $this->getRequest()->getParam('s_field');
				}
				else {
						if( !isset($this->_userspace->search['subject2']['sGroup']) )
							$this->_userspace->search['subject2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['subject2']['sJob']) )
							$this->_userspace->search['subject2']['sJob']			= '0';
						if( !isset($this->_userspace->search['subject2']['sKana']) )
							$this->_userspace->search['subject2']['sKana']		= '0';
						if( !isset($this->_userspace->search['subject2']['sKeyword']) )
							$this->_userspace->search['subject2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['subject2']['sField']) )
							$this->_userspace->search['subject2']['sField']		= '0';
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
						}
						else if( $error ==2 ){
							
						}
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['subject2']['sGroup'];
				$sJob			=	$this->_userspace->search['subject2']['sJob'];
				$sKana		=	$this->_userspace->search['subject2']['sKana'];
				$sKeyword	=	$this->_userspace->search['subject2']['sKeyword'];
				$sField		=	$this->_userspace->search['subject2']['sField'];
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  '0',
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
				$this->view->name				= $name;
				$this->view->code				= $code;
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				


				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'		.$this->view->sid;
				$education2index	= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index		= $this->view->modulePath.'subject/index'		.$this->view->sid;
				$subject2item			= $this->view->modulePath.'subject/item/subject_id/'.$code.$this->view->sid;
				$subject2edit			= $this->view->modulePath.'subject/edit/subject_id/'.$code.$this->view->sid;
				$subject2user			= $this->view->modulePath.'subject/user/code/'.$code.'/name/'.$name.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index ),
									array('name'=>$name						,'url'=>$subject2item ),
									array('name'=>'編集'					,'url'=>$subject2edit ),
									array('name'=>'担当教員追加'	,'url'=>$subject2user )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }




    /**-------------------------------------------------------------------------------------------
     * adduserアクション
     */
    public function adduserAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						//$name			= $this->getRequest()->getParam('name');
						$code 			= $this->getRequest()->getParam('code');
						$userArray	= $this->getRequest()->getParam('user_id');
				}
				
				if( $code != null ){
						$info 	= array();
						$styear = '2009-04-01';
						$deleteType = '0';
						
		    		$this->_subject->updateSubjectAdduser( $info, $code, $userArray, $styear, $deleteType);
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/subject/edit/subject_id/'. $code. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * deluserアクション
     */
    public function deluserAction()
    {
				if( $this->getRequest()->isGet() ) 
				{
						
						$code 		= $this->getRequest()->getParam('code');
						$userId		= $this->getRequest()->getParam('user_id');
				}
				
				if( $code != null ){
						$info 	= array();
						$styear = '2009-04-01';
						$deleteType = '1';
						
   					$this->_subject->updateSubjectDeluser( $info, $code, $userId, $styear, $deleteType);
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/subject/edit/subject_id/'. $code. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * syllabusアクション
     */
    public function syllabusAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				if( $this->getRequest()->isGet() ) {
						
						$code 		= $this->getRequest()->getParam('code');
						$name 		= $this->getRequest()->getParam('name');
						$file			= $this->getRequest()->getParam('upfile');
						$year			= $this->getRequest()->getParam('year');
						
				}
				else if( $this->getRequest()->isPost() ){
						
						$code 		= $this->getRequest()->getParam('code');
						$name			= $this->getRequest()->getParam('name');
						$year			= $this->getRequest()->getParam('year');
						$file			= $_FILES["upfile"]["name"];
						
						if( $file==null || $file=='' ){
								array_push($errors, array('HTMLFファイルが、選択されていません。') );
						}else{
								$res = explode("." , $file);
								if( $res[1]!='html' && $res[1]!='htm' )
									array_push($errors, array('HTMLファイルが、選択されていません。') );
						}
						
						$msgs = validateSelect( '設定年度', $year);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						if (count($errors) == 0){
							
							$path 	= "../ananfd/docs/syllabus/".$year ."/";
							if( is_dir( $path ) ){
									//echo "/folder ディレクトリは存在します。";
							}else{
									if ( mkdir( $path ) ) {
											//　echo "ディレクトリ作成成功！！
								    chmod( $path, 0777);
									}else{
											//　echo "ディレクトリ作成失敗！！
								    echo "ディレクトリ作成できません。";
									}
							}
							
							define('UPLOAD_ERROR_OK', '0');
							
							$bLoad = true;
			        $message  = "upload";
							if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK)
							{
								if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) 
								{
								  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
								  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   $path . $_FILES["upfile"]["name"])) 
									{
								    chmod( $path . $_FILES["upfile"]["name"], 0644);
								    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
				        		//$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
								  } else {
								    echo "ファイルをアップロードできません。";
				        		//$message  = "ファイルをアップロードできません。";
										$bLoad = false;
								  }
								} else {
								  echo "ファイルが選択されていません。";
				        	//$message  = "ファイルが選択されていません。";
									$bLoad = false;
								}
							}
if( $this->_config->global->debugOn )
		Zend_Debug::dump($message);
							
							//fgetcsvの場合
							//fgetcsv(handle,length,delimiter,enclosure,escape)
							$fileName = $path . $_FILES["upfile"]["name"];
							if( $bLoad ){
								
								$data = array(
													'file'				=>	$file,			//$_FILES["upfile"]["name"],
													'code'				=>	$code,
													'year'				=>	$year,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								$deleteType = '0';
								
				    		$this->_subject->updateSubjectAddsyllabus( $data, $deleteType);
								
							}
							
							
			        $targetUrl = '/subject/edit/subject_id/'. $code. $this->view->sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
							
						}
						
				} else {
								
						
						
						
				}

				$menu_mode ='年度';		//search
				$menu_mode ='';					//select
				$this->view->yearArray	= $this->_menu->getYearList( $menu_mode, null );
				
				$this->view->code				= $code;
				$this->view->name				= $name;
				$this->view->selYear		= $year;
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				


				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'		.$this->view->sid;
				$education2index	= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index		= $this->view->modulePath.'subject/index'		.$this->view->sid;
				$subject2item			= $this->view->modulePath.'subject/item/subject_id/'.$code.$this->view->sid;
				$subject2edit			= $this->view->modulePath.'subject/edit/subject_id/'.$code.$this->view->sid;
				$subject2syllabus	= $this->view->modulePath.'subject/syllabus/subject_id/'.$code.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index ),
									array('name'=>$name						,'url'=>$subject2item ),
									array('name'=>'編集'					,'url'=>$subject2edit ),
									array('name'=>'シラバス追加'	,'url'=>$subject2syllabus )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }


    /**-------------------------------------------------------------------------------------------
     * delsyllabusアクション
     */
    public function delsyllabusAction()
    {
						
				$code 	= $this->getRequest()->getParam('code');
				$id			= $this->getRequest()->getParam('id');
				
				if( $id != null )
				{
						$info = array(
											'id'					=>	$id,
											'code'				=>	$code,
											'delete_flg'	=> '1'
										);
						$deleteType = '1';
						
  					$this->_subject->updateSubjectDelsyllabus( $info, $deleteType );
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/subject/edit/subject_id/'. $code. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }





    /**-------------------------------------------------------------------------------------------
     * uploadsyllabusアクション
     */
    public function uploadsyllabusAction()
    {
				
        // ビュースクリプトが表示されます
				
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				
        // ビュースクリプトが表示されます	
        $targetUrl = '/subject/edit/subject_id/'. $code. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }






    /**-------------------------------------------------------------------------------------------
     * importアクション
     */
    public function importAction()
    {
        // ビュースクリプトが表示されます


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'		.$this->view->sid;
				$education2index= $this->view->modulePath.'education/index'	.$this->view->sid;
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
				$subject2import	= $this->view->modulePath.'subject/import'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'教務管理'			,'url'=>$education2index ),
									array('name'=>'授業科目管理'	,'url'=>$subject2index ),
									array('name'=>'一括読込'			,'url'=>$subject2import )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$subject2index	= $this->view->modulePath.'subject/index'		.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'	,'url'=>$subject2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }





    /**-------------------------------------------------------------------------------------------
     * uploadアクション
     */
    public function uploadAction()
    {
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];


				$file = fopen($fileName,"r");
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="課程" ) continue;
						if( $str[3]=="" ) 		continue;
						
						$data = array(
											'adapted_group'		=> $str[0],
											'adapted_grade'		=> $str[1],
											'subject_require'	=> $str[2],
											'subject_code'		=> $str[3],
											'subject_name'		=> $str[4],
											'subject_units'		=> $str[6],
											'subject_kind'		=> $str[7],
											'start_year'			=> $str[10] . '-04-01',
											'end_year'				=> $str[11] . '-04-01',
											'file'						=> $str[12],
											'delete_flg'			=> '0',
											'create_date'			=> NULL
											);
						
						
						// グループＩＤを取得する
						$groupId = $this->_subject->getGroupId( $data['adapted_group'] );
						$deleteType = '0';
						$req = 0;
						switch($str[2]){
							case '1':		$req = 1;	break;		//'必修'
							case '0':		$req = 2;	break;		//'選択'
							default:		$req = 0;	break;
						}
						$term = 0;
						switch($str[7]){
							case '通年':		$term = 1;	break;
							case '前期':		$term = 2;	break;
							case '後期':		$term = 3;	break;
							default:				$term = 0;	break;
						}
						
    				$rval = $this->_subject->registSubject( $data, $groupId, $req, $term, $deleteType ) ;
						if( $rval == 0 )
						{
								echo '中止 ';
						}
				} 
				fclose($file);

		if( $rval != 0 )
			{
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="課程" ) continue;
						if( $str[3]=="" ) 		continue;
						
						$data = array(
											'adapted_group'		=> $str[0],
											'adapted_grade'		=> $str[1],
											'subject_require'	=> $str[2],
											'subject_code'		=> $str[3],
											'subject_name'		=> $str[4],
											'subject_units'		=> $str[6],
											'subject_kind'		=> $str[7],
											'start_year'			=> $str[10] . '-04-01',
											'end_year'				=> $str[11] . '-04-01',
											'file'						=> $str[12],
											'delete_flg'			=> '0',
											'create_date'			=> NULL
											);
						
						
						// グループＩＤを取得する
						$groupId = $this->_subject->getGroupId( $data['adapted_group'] );
						$deleteType = '0';
						$req = 0;
						switch($str[2]){
							case '1':		$req = 1;	break;		//'必修'
							case '0':		$req = 2;	break;		//'選択'
							default:		$req = 0;	break;
						}
						$term = 0;
						switch($str[7]){
							case '通年':		$term = 1;	break;
							case '前期':		$term = 2;	break;
							case '後期':		$term = 3;	break;
							default:				$term = 0;	break;
						}
						
    				if( $this->_subject->registSubjectGroup( $data, $groupId, $deleteType ) == 0 ){
								echo '中止 ';
						}
				} 
				fclose($file);
			}


				
				$targetUrl = '/subject/index'. $this->view->sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * upload2アクション
     */
    public function upload2Action()
    {
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="課程" ) continue;
						if( $str[3]=="" ) 		continue;

						$data = array(
											'adapted_group'		=> $str[0],
											'adapted_grade'		=> $str[1],
											'subject_require'	=> $str[2],
											'subject_code'		=> $str[3],
											'subject_name'		=> $str[4],
											'subject_units'		=> $str[6],
											'subject_kind'		=> $str[7],
											'start_year'			=> $str[10] . '-04-01',
											'end_year'				=> $str[11] . '-04-01',
											'delete_flg'			=> '0',
											'create_date'			=> NULL
											);
						
						
						// グループＩＤを取得する
						$groupId = $this->_subject->getGroupId( $data['adapted_group'] );
						$deleteType = '0';
						
    				if( $this->_subject->registSubjectGroup( $data, $groupId, $deleteType ) == 0 ){
								echo '中止 ';
						}
				} 
				fclose($file);

				$targetUrl = '/subject/index'. $this->view->sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * upload3アクション
     * 
     * 担当教員のアップロード
     */
    public function upload3Action()
    {
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="課程" ) continue;
						if( $str[3]=="" ) 		continue;

						$data = array(
											'adapted_group'		=> $str[0],
											'adapted_grade'		=> $str[1],
											'subject_require'	=> $str[2],
											'subject_code'		=> $str[3],
											'subject_name'		=> $str[4],
											'user_name'				=> $str[5],
											'delete_flg'			=> '0',
											'create_date'			=> NULL
											);
						
						
						// グループＩＤを取得する
						$groupId = $this->_subject->getGroupId( $data['adapted_group'] );
						// ユーザＩＤを取得する
						$userId = $this->_user->getUserNameId( $data['user_name'] );
						$deleteType = '0';
						
						if( $data['subject_code'] != null ){
								$userArray = array( $userId );
								
								$styear = '2009-04-01';
								$deleteType = '0';
								$code = $data['subject_code'];
								
				    		if( $this->_subject->updateSubjectAdduser( $data, $code, $userArray, $styear, $deleteType)==0){
									echo '中止 ';
								}
						}
				} 
				
				
				$targetUrl = '/subject/index'. $this->view->sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }





    /**-------------------------------------------------------------------------------------------
     * upload4アクション
     */
    public function upload4Action()
    {
				
				
        // ビュースクリプトが表示されます
				
				define('UPLOAD_ERROR_OK', '0');
				
        $message  = "upload";
				if($_FILES['upfile']['error'] == UPLOAD_ERROR_OK){
					if (is_uploaded_file($_FILES["upfile"]["tmp_name"])) {
					  //if (move_uploaded_file($_FILES["upfile"]["tmp_name"], "../application/files/" . $_FILES["upfile"]["name"])) 
					  if (move_uploaded_file($_FILES["upfile"]["tmp_name"],   "../ananfd/docs/" . $_FILES["upfile"]["name"])) 
						{
					    chmod("../ananfd/docs/" . $_FILES["upfile"]["name"], 0644);
					    echo $_FILES["upfile"]["name"] . "をアップロードしました。";
	        		$message  = $_FILES["upfile"]["name"] . "をアップロードしました。";
					  } else {
					    echo "ファイルをアップロードできません。";
	        		$message  = "ファイルをアップロードできません。";
					  }
					} else {
					  echo "ファイルが選択されていません。";
	        	$message  = "ファイルが選択されていません。";
					}
				}
				
				//fgetcsvの場合
				//fgetcsv(handle,length,delimiter,enclosure,escape)
				$fileName = "../ananfd/docs/" . $_FILES["upfile"]["name"];
				$file = fopen($fileName,"r");
				while(!feof($file)){
						
				    $str = fgetcsv($file);
						if( $str[0]=="課程" ) continue;
						if( $str[3]=="" ) 		continue;
						
						$code = $str[3];
						$data = array(
													'file'				=>	'sy'.$code.'.html',			//$_FILES["upfile"]["name"],
													'code'				=>	$code,
													'year'				=>	'2011',
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
						
						$deleteType = '0';
						
						if( $data['code'] != null ){
								
								$data['year'] = '2006';
				    		if( $this->_subject->updateSubjectAddsyllabus( $data, $deleteType)==0 ){
									echo '中止 ';
								}
								$data['year'] = '2007';
				    		if( $this->_subject->updateSubjectAddsyllabus( $data, $deleteType)==0 ){
									echo '中止 ';
								}
								$data['year'] = '2008';
				    		if( $this->_subject->updateSubjectAddsyllabus( $data, $deleteType)==0 ){
									echo '中止 ';
								}
								$data['year'] = '2009';
				    		if( $this->_subject->updateSubjectAddsyllabus( $data, $deleteType)==0 ){
									echo '中止 ';
								}
								$data['year'] = '2010';
				    		if( $this->_subject->updateSubjectAddsyllabus( $data, $deleteType)==0 ){
									echo '中止 ';
								}
//最終がカレントファイル
								$data['year'] = '2011';
				    		if( $this->_subject->updateSubjectAddsyllabus( $data, $deleteType)==0 ){
									echo '中止 ';
								}
						}
				} 
				fclose($file);
				
				
				$targetUrl = '/subject/index'. $this->view->sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }















    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
