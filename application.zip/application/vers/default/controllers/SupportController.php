<?php
/**
 * Supportコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する

// モデルをロードする
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/subjectModel.php';
require_once '../application/vers/default/models/learnModel.php';
require_once '../application/vers/default/models/employModel.php';
require_once '../application/vers/default/models/supportModel.php';
require_once '../application/vers/default/models/requireModel.php';
require_once '../application/vers/default/models/menuModel.php';
require_once '../application/vers/default/models/commModel.php';
require_once '../application/vers/default/models/userModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class SupportController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_learn;					// ラーニングモデルのインスタンス
    private $_member;					// メンバーモデルのインスタンス
    private $_subject;				// サブジェクトモデルのインスタンス
    private $_employ;					// エンプロイモデルのインスタンス
    private $_support;				// サポートモデルのインスタンス
    private $_require;				// リクイァモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
    private $_comm;						// コミッティーモデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{
				
        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');
				
        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');
				
        // ユーザモデルのインスタンスを生成する
        $this->_learn  	= new learnModel('../application/lib/member.db');
        $this->_subject	= new subjectModel('../application/lib/member.db');
        $this->_member 	= new memberModel('../application/lib/member.db');
        $this->_employ	= new employModel('../application/lib/user.db');
        $this->_support	= new supportModel('../application/lib/user.db');
        $this->_require	= new requireModel('../application/lib/user.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');
        $this->_comm	= new commModel('../application/lib/user.db');
        $this->_user 		= new userModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				


				//指定されたユーザが教員、または指定された権限の委員会に属するメンバーを許可する
				$permissionArray	= array( COMM_EXECUTIVE,COMM_ASSISTANCE );
				{
					if( isset($this->_config->allowComm->support) ) {
		        Zend_Registry::set('permission', $this->_config->allowComm->support->toArray());
		        if (Zend_Registry::isRegistered('permission')) {
								//$permissionArray = Zend_Registry::get('permissionArray');
								$permissionArray = $this->_config->allowComm->support->toArray();
							}
	        }
				}
				$userId	= $this->_userspace->userId;
				if( $this->_user->isTeacherCommUsers( $userId, $permissionArray ) == false ){	
						
						if( true )
						{
								$this->_forward( 'error', 'Error', null, 
																	getFatalError( FATAL_TEACHER_ACCESS,$this->view )				//'教員ではありません。
																);	
						}
						
				}
				
        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selTerm		= 0;
				$this->view->selKana		= 0;
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['support']['sStyear']		= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['support']['sEdyear']		= $this->getRequest()->getParam('s_edyear');
						
						$this->_userspace->search['support']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['support']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['support']['sTerm']			= $this->getRequest()->getParam('s_term');
						$this->_userspace->search['support']['sReq']			= $this->getRequest()->getParam('s_req');
						$this->_userspace->search['support']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['support']['sField']		= $this->getRequest()->getParam('s_field');
				}else{
						
						if( !isset($this->_userspace->search['support']['sStyear']) )
							$this->_userspace->search['support']['sStyear']		= getNowYear(true);		// '0';
						if( !isset($this->_userspace->search['support']['sEdyear']) )
							$this->_userspace->search['support']['sEdyear']		= '0';
							
						if( !isset($this->_userspace->search['support']['sGroup']) )
							$this->_userspace->search['support']['sGroup']		= '0';
						if( !isset($this->_userspace->search['support']['sGrade']) )
							$this->_userspace->search['support']['sGrade']		= '0';
						if( !isset($this->_userspace->search['support']['sTerm']) )
							$this->_userspace->search['support']['sTerm']			= '0';
						if( !isset($this->_userspace->search['support']['sReq']) )
							$this->_userspace->search['support']['sReq']			= '0';
						if( !isset($this->_userspace->search['support']['sKeyword']) )
							$this->_userspace->search['support']['sKeyword']	= '';
						if( !isset($this->_userspace->search['support']['sField']) )
							$this->_userspace->search['support']['sField']		= '0';

						if( !isset($this->_userspace->search['support']['studentLists']) )
							$this->_userspace->search['support']['studentLists']	= array();
						if( !isset($this->_userspace->search['support']['teacherLists']) )
							$this->_userspace->search['support']['teacherLists']	= array();
				}
				$studentLists	= $this->_userspace->search['support']['studentLists'];	
				$teacherLists	= $this->_userspace->search['support']['teacherLists'];	
				
				
				$bFind = true;	


				$this->view->student ='';
				$studentLists = null;
				if( isset($this->_userspace->search['support']['studentLists']) )
				{
					$studentLists	= $this->_userspace->search['support']['studentLists'];	
				}
				if( isset($studentLists) )
				{
					foreach( $studentLists as $idx )
					{
						$student = $this->_member->getMemberName($idx);
						if (end($studentLists) == $idx ) 
							$this->view->student	.= $student ;
						else
							$this->view->student	.= $student .'、';
					}
				}
				
				$this->view->teacher ='';
				$teacherLists = null;
				if( isset($this->_userspace->search['support']['teacherLists']) )
				{
					$teacherLists	= $this->_userspace->search['support']['teacherLists'];	
				}
				if( isset($teacherLists) )
				{
					foreach( $teacherLists as $idx )
					{
						$student = $this->_user->getUserName($idx);
						if (end($teacherLists) == $idx ) 
							$this->view->teacher	.= $student ;
						else
							$this->view->teacher	.= $student .'、';
					}
				}

				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sStyear	= $this->_userspace->search['support']['sStyear'];	
				$sEdyear	= $this->_userspace->search['support']['sEdyear'];	
				$sGroup		= $this->_userspace->search['support']['sGroup'];		
				$sGrade		= $this->_userspace->search['support']['sGrade'];		
				$sTerm		= $this->_userspace->search['support']['sTerm'];		
				$sReq			= $this->_userspace->search['support']['sReq'];			
				$sKeyword	= $this->_userspace->search['support']['sKeyword'];	
				$sField		= $this->_userspace->search['support']['sField'];		
				if( $sGroup 	=== null 
					||	$sGrade	=== null 
					|| 	$sTerm	=== null 
					||	$sReq		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sTerm   == "0" 
					&& $sReq		== "0" 
					&& $sKeyword== ""  
					&& $sStyear == "0" 
					&& $sEdyear == "0" 
					&& $studentLists== ""
					&& $teacherLists== ""
					)	{
							$bFind = false;
				}
				

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				// 指定された権限の委員会に属するメンバーを許可する
				$this->view->dispTeacher	= false;
				$userId	= $this->_userspace->userId;
				$commArray	= array( COMM_LEVLE_MANAGER,COMM_LEVLE_MASTER );
				if( $this->_comm->isAllowCommLevelUsers( $userId, $commArray ) == true ){	
					
					$userId	= 0;
					$this->view->dispTeacher	= true;
				}


				$bTerm = false;	
				if( $sStyear != "0" &&	$sEdyear	!= "0" )
				{
					if( $sEdyear < $sStyear ){
						array_push($errors, array('終了年度が、開始年度より過去に設定されています。') );
						$this->view->assign('errors',$errors);			// 追加後に再設定必要
					}
					else{
						$bTerm = true;	
					}
				}
				{
					if ( $bFind ){
							
							$findArray = array( 	's_group'		=>  $sGroup,
																		's_grade'		=>  $sGrade,
																		's_term'  	=>  $sTerm,
																		's_req'			=>  $sReq,
																		's_styear'	=>	$sStyear,
																		's_edyear'	=>	$sEdyear,
																		's_keyword'	=>  $sKeyword,
																		's_field'		=>  $sField,
																	's_student'	=>  $studentLists,
																	's_teacher'	=>  $teacherLists
																	);
							
							$select = $this->_support->getSupport2Page( $findArray, $userId );
							
					} else 
					{
							$select = $this->_support->getSupport2Page( null, $userId );
							
					}
					

					$paginator	= Zend_Paginator::factory( $select );
					$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
					$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
					$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
					
					$this->view->assign( 'paginator', $paginator );

					
	        // ビュースクリプトが表示されます
					
	        $page  = $this->getRequest()->getParam('page');		
	        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
					$this->view->max	= $this->_config->view->countPerPage;

					$menu_mode ='';					//select
					$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
					$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
					$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
					$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
					$this->view->reqArray			= $this->_menu->getReqList( $menu_mode, null );
					$this->view->termArray		= $this->_menu->getTermList( $menu_mode, null );
					$this->view->fieldArray		= $this->_menu->getField2List( null, null );
					
					$menu_ext 	='-';					//select
					$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
					$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );

					$this->view->selGroup		= $sGroup;
					$this->view->selGrade		= $sGrade;
					$this->view->selTerm		= $sTerm;
					$this->view->selReq			= $sReq;
					$this->view->selKeyword	= $sKeyword;
					$this->view->selField		= $sField;
					$this->view->selStyear	= $sStyear;
					$this->view->selEdyear	= $sEdyear;
					
				}
				
				
				
				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>'サポート'					,'url'=>$support2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);
			
			
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }



    /**-------------------------------------------------------------------------------------------
     * sumupアクション
     */
    public function sumupAction()
    {
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				$subjectId 	= $this->getRequest()->getParam('subject');
				
				$name = $this->_subject->getSubjectName($subjectId);
				

				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['support2']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['support2']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['support2']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['support2']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['support2']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['support2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['support2']['sField']		= $this->getRequest()->getParam('s_field');
						$this->_userspace->search['support2']['group']		= $this->getRequest()->getParam('group');
				} else {
						if( !isset($this->_userspace->search['support2']['sGroup']) )
							$this->_userspace->search['support2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['support2']['sGrade']) )
							$this->_userspace->search['support2']['sGrade']		= '0';
						if( !isset($this->_userspace->search['support2']['sStyear']) )
							$this->_userspace->search['support2']['sStyear']	= '0';
						if( !isset($this->_userspace->search['support2']['sKana']) )
							$this->_userspace->search['support2']['sKana']		= '0';
						if( !isset($this->_userspace->search['support2']['sClass']) )
							$this->_userspace->search['support2']['sClass']		= '0';
						if( !isset($this->_userspace->search['support2']['sKeyword']) )
							$this->_userspace->search['support2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['support2']['sField']) )
							$this->_userspace->search['support2']['sField']		= '0';
						if( !isset($this->_userspace->search['support2']['group']) )
							$this->_userspace->search['support2']['group']		= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['support2']['sGroup'];	
				$sGrade		= $this->_userspace->search['support2']['sGrade'];	
				$sStyear	= $this->_userspace->search['support2']['sStyear'];	
				$sKana		= $this->_userspace->search['support2']['sKana'];		
				$sClass		=	$this->_userspace->search['support2']['sClass'];	
				$sKeyword	=	$this->_userspace->search['support2']['sKeyword'];
				$sField		=	$this->_userspace->search['support2']['sField'];	
				
				$styear		= $this->_userspace->search['support']['sStyear'];	
				$edyear		= $this->_userspace->search['support']['sEdyear'];	
				$group		= $this->_userspace->search['support2']['group'];		
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0"  
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				if( $styear != "0" || $edyear != "0" ) {
					
						if( $bFind == false ){
							
							$sGroup  = "0"; 
							$sGrade  = "0"; 
							$sStyear = "0"; 
							$sKana	 = "0"; 
							$sClass	 = "0"; 
							$sKeyword= "" ; 
						}
					
					$bFind = true;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	'styear'  =>  $styear,
																	'edyear'  =>  $edyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_support->getSupportPage( $subjectId, $group, $findArray );
						
				} else 
				{
				
						$select = $this->_support->getSupportPage( $subjectId, $group, null );
				
				}
				
				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				$this->view->assign( 'paginator', $paginator );
				
				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->statusArray	= $this->_menu->getStatus2List( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;

				$this->view->subject		= $subjectId;
				$this->view->group			= $group;
				$this->view->styear			= $styear;
				$this->view->edyear			= $edyear;
				
			


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
				$support2list		= $this->view->modulePath.'support/sumup/subject/'.$subjectId.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'学習支援'		,'url'=>$learning2index ),
									array('name'=>'サポート'		,'url'=>$support2index ),
									array('name'=>$name					,'url'=>$support2list )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$support2index	= $this->view->modulePath.'support/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$support2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
				

    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$support_id 	= $this->getRequest()->getParam('support');
						if( $support_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_support->getSupportId( $support_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['id'] != 0 ){
											
											$this->view->support		= $result['id'];
											$this->view->user				= $result['name'];
											$this->view->selStatus	= $result['status'];
											$this->view->memo				= $result['memo'];
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
											$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
											$this->view->statusArray		= $this->_menu->getStatus2List( $menu_mode, null );
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
											
											$this->view->subject			= $result['subject_id'];
											$this->view->name					= $result['name'];
											$this->view->memberName		= $result['member_name'];
										}
						}
				}
				else{
				}
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
				$support2list		= $this->view->modulePath.'support/sumup/subject/'.$result['subject_id'].$this->view->sid;
				$support2item		= $this->view->modulePath.'support/item/support/'.$result['id'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>'サポート'					,'url'=>$support2index ),
									array('name'=>$result['name']			,'url'=>$support2list ),
									array('name'=>$result['member_name']		,'url'=>$support2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$support2list		= $this->view->modulePath.'support/sumup/subject/'.$result['subject_id'].$this->view->sid;
				$support2edit		= $this->view->modulePath.'support/edit/support_id/'.$result['id'].$this->view->sid;
				$support2delete	= $this->view->modulePath.'support/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$support2list		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$support2edit		,'onclick'=>'' )
									);
					break;
				case 'admin':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$support2list		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション（未使用）削除すると面接履歴が削除される
     */
    public function deleteAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$support 		= $this->getRequest()->getParam('support');
				}
				
				if( $support != null ){
						$info 	= array();
						$deleteType = '1';
						
   					$this->_support->deleteSupport( $support );
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/subject/index'. '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }




    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->statusArray		= $this->_menu->getStatus2List( $menu_mode, null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$support_id = $this->getRequest()->getParam('support_id');
						if( $support_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_support->getSupportId( $support_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['id'] != 0 ){
											
											
											$this->view->support		= $result['id'];
											$this->view->user				= $result['name'];
											$this->view->selStatus	= $result['status'];
											$this->view->memo				= $result['memo'];
											
											$this->view->subject			= $result['subject_id'];
											$this->view->name					= $result['name'];
											$this->view->memberName		= $result['member_name'];
											
										}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$support	= $this->getRequest()->getParam('support');
						$status		= $this->getRequest()->getParam('status');
						$memo			= $this->getRequest()->getParam('memo');
						
						$subject		= $this->getRequest()->getParam('subject');
						$name				= $this->_subject->getSubjectName($subject);
						$memberName	= $this->getRequest()->getParam('memberName');
						
						$memo			= trim($memo);					//半角スペースのみ
						
						
						if (count($errors) == 0){
								
								$user		= $this->_userspace->userId;
								$data = array(
													'support'			=>	$support,
													'user'				=>	$user,
													'status'			=>	$status,
													'memo'				=>	$memo,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $support != NULL ){
										
			    					$this->_support->updateSupport( $data, $support, $deleteType );
										
						        // ビュースクリプトが表示されます
						        $targetUrl = '/support/item/support/'.$support. '/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else 
						{
								
								$this->view->support		= $support;
								
								$this->view->selStatus	= $status;
								$this->view->memo			 	= $memo;

								$this->view->subject		= $subject;
								$this->view->name				= $name;
								$this->view->memberName	= $$memberName;
								
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
				$support2list		= $this->view->modulePath.'support/sumup/subject/'		.$this->view->subject.$this->view->sid;
				$support2item		= $this->view->modulePath.'support/item/support/'		.$this->view->support.$this->view->sid;
				$support2edit		= $this->view->modulePath.'support/edit/support_id/'.$this->view->support.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>'サポート'					,'url'=>$support2index ),
									array('name'=>$this->view->name		,'url'=>$support2list ),
									array('name'=>$this->view->memberName		,'url'=>$support2item ),
									array('name'=>'編集'							,'url'=>$support2edit ),
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$support2list		= $this->view->modulePath.'support/sumup/subject/'.$this->view->subject.$this->view->sid;
				$support2item		= $this->view->modulePath.'support/item/support/'.$this->view->support.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$support2list		,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$support2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

    }



    /**-------------------------------------------------------------------------------------------
     * subjectアクション
     */
    public function subjectAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$subject_id = $this->getRequest()->getParam('subject_id');
						if( $subject_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_subject->getSubjectId( $subject_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['code'] != 0 ){
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											$this->view->selReq			= $result["require"];	
											$this->view->selTerm		= $result["term"];	
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
											$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
											$this->view->reqArray			= $this->_menu->getReqList( null, null );
											$this->view->termArray		= $this->_menu->getTermList( null, null );
											
											
											// 1レコードの取得
											$group = $this->_subject->chargedGroupId( $subject_id );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );					//DB 1:一般教科 20110906
											}
											$this->view->selGroup		= $groupArray;

											// 1レコードの取得
											$syllabus = $this->_subject->chargedSyllabus( $subject_id );
											$syllabus2Array = array();
											foreach( $syllabus as $row ){
												array_push( $syllabus2Array, array("file"=>$row['file'],"year"=>$row['year'] ) );
											}
											$this->view->syllabus		= $syllabus2Array;

											// 1レコードの取得
											$user = $this->_subject->chargedUserId( $subject_id );
											$user2Array = array();
											foreach( $user as $row ){
												$name = $this->_subject->getUserName($row['user_id']);
												array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
											}
											$this->view->user		= $user2Array;
											
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}
				else{
				}


				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
				$support2subject= $this->view->modulePath.'support/subject/subject_id/'	.$subject_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'								,'url'=>$top2index ),
									array('name'=>'学習支援'					,'url'=>$learning2index ),
									array('name'=>'サポート'					,'url'=>$support2index ),
									array('name'=>$result['name']			,'url'=>$support2subject )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$support2index	= $this->view->modulePath.'support/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'戻る'  	,'url'=>$support2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
				
    }





    /**-------------------------------------------------------------------------------------------
     * studentアクション（学生選択検索）
     */
    public function studentAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ){
						
						$this->_userspace->search['support3']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['support3']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['support3']['sStyear']		= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['support3']['sKana']			= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['support3']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['support3']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['support3']['sField']		= $this->getRequest()->getParam('s_field');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['support3']['sGroup']) )
							$this->_userspace->search['support3']['sGroup']		= '0';
						if( !isset($this->_userspace->search['support3']['sGrade']) )
							$this->_userspace->search['support3']['sGrade']		= '0';
						if( !isset($this->_userspace->search['support3']['sStyear']) )
							$this->_userspace->search['support3']['sStyear']	= '0';
						if( !isset($this->_userspace->search['support3']['sKana']) )
							$this->_userspace->search['support3']['sKana']		= '0';
						if( !isset($this->_userspace->search['support3']['sClass']) )
							$this->_userspace->search['support3']['sClass']		= '0';
						if( !isset($this->_userspace->search['support3']['sKeyword']) )
							$this->_userspace->search['support3']['sKeyword']	= '';
						if( !isset($this->_userspace->search['support3']['sField']) )
							$this->_userspace->search['support3']['sField']		= '0';
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加学生が、選択されていません。') );
						}
				}
				
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['support3']['sGroup'];	
				$sGrade		= $this->_userspace->search['support3']['sGrade'];	
				$sStyear	= $this->_userspace->search['support3']['sStyear'];
				$sKana		= $this->_userspace->search['support3']['sKana'];	
				$sClass		=	$this->_userspace->search['support3']['sClass'];	
				$sKeyword	=	$this->_userspace->search['support3']['sKeyword'];
				$sField		=	$this->_userspace->search['support3']['sField'];	
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0" 
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_member->getMemberPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_member->getMemberPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );

				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;


				
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';
				
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要








				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
				$support2student= $this->view->modulePath.'support/student'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'学習支援'		,'url'=>$learning2index ),
									array('name'=>'サポート'		,'url'=>$support2index ),
									array('name'=>'学生選択'		,'url'=>$support2student )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * addstudentアクション
     */
    public function addstudentAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$memberArray	= $this->getRequest()->getParam('member_id');
				}
				
				if( count($memberArray) == 0 ){
		        $targetUrl = '/support/student/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($memberArray) >= 1 ){
						
						$studentArray = $this->_userspace->search['support']['studentLists'];
						if( $studentArray == null )
								$studentArray = array();	
						foreach( $memberArray as $idx )
						{
							if( array_search( $idx, $studentArray )===false )
								array_push( $studentArray, $idx );
						}
						$this->_userspace->search['support']['studentLists'] = $studentArray;
						
				}
				
				
				
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/support/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }








    /**-------------------------------------------------------------------------------------------
     * teacherアクション（教員選択検索）
     */
    public function teacherAction()
    {
				$errors = array();
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['support4']['sGroup']		= $this->getRequest()->getParam('s_group');		
						$this->_userspace->search['support4']['sJob']			= $this->getRequest()->getParam('s_job');			
						$this->_userspace->search['support4']['sKana']		= $this->getRequest()->getParam('s_kana');		
						$this->_userspace->search['support4']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
						$this->_userspace->search['support4']['sField']		= $this->getRequest()->getParam('s_field');		
						$this->_userspace->search['support4']['sKind']		= $this->getRequest()->getParam('s_kind');		
						
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['support4']['sGroup']) )
							$this->_userspace->search['support4']['sGroup']		= '0';
						if( !isset($this->_userspace->search['support4']['sJob']) )
							$this->_userspace->search['support4']['sJob']			= '0';
						if( !isset($this->_userspace->search['support4']['sKana']) )
							$this->_userspace->search['support4']['sKana']		= '0';
						if( !isset($this->_userspace->search['support4']['sKeyword']) )
							$this->_userspace->search['support4']['sKeyword']	= '';
						if( !isset($this->_userspace->search['support4']['sField']) )
							$this->_userspace->search['support4']['sField']		= '0';
						if( !isset($this->_userspace->search['support4']['sKind']) )
							$this->_userspace->search['support4']['sKind']		= '0';
						
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加教員が、指定されていません。') );
						}
						else if( $error ==2 ){
							
							array_push($errors, array('追加教員は、１名のみ選択してください。') );
						}
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['support4']['sGroup'];		
				$sJob			= $this->_userspace->search['support4']['sJob'];			
				$sKana		= $this->_userspace->search['support4']['sKana'];			
				$sKeyword	= $this->_userspace->search['support4']['sKeyword'];	
				$sField		= $this->_userspace->search['support4']['sField'];		
				$sKind		=	$this->_userspace->search['support4']['sKind'];			
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sKind	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  $sKind,
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				$this->view->roleArray		= $this->_menu->getRoleList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selKind		= $sKind;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要









				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$learning2index	= $this->view->modulePath.'learning/index'	.$this->view->sid;
				$support2index	= $this->view->modulePath.'support/index'		.$this->view->sid;
				$support2teacher= $this->view->modulePath.'support/teacher'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'学習支援'		,'url'=>$learning2index ),
									array('name'=>'サポート'		,'url'=>$support2index ),
									array('name'=>'教員選択'		,'url'=>$support2teacher )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * addteacherアクション
     */
    public function addteacherAction()
    {

				if( $this->getRequest()->isPost() ) {
						
						$userArray	= $this->getRequest()->getParam('user_id');
				}
				
				if( count($userArray) == 0 ){
		        $targetUrl = '/support/teacher/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($userArray) >= 1 ){
						
						$teacherArray = $this->_userspace->search['support']['teacherLists'];
						if( $teacherArray == null )
								$teacherArray = array();	
						foreach( $userArray as $idx )
						{
							if( array_search( $idx, $teacherArray )===false )
								array_push( $teacherArray, $idx );
						}
						$this->_userspace->search['support']['teacherLists'] = $teacherArray;
						
				}
				
				
			  // ビュースクリプトが表示されます
			  $targetUrl = '/support/index/sid/'.$this->_sid;
			  return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }


    /**-------------------------------------------------------------------------------------------
     * delstudentアクション
     */
    public function delstudentAction()
    {
				
				$this->_userspace->search['support']['studentLists'] = array();
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/support/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
		}



    /**-------------------------------------------------------------------------------------------
     * delteacherアクション
     */
    public function delteacherAction()
    {
				
				
				$this->_userspace->search['support']['teacherLists'] = array();
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/support/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
		}













    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }



}
