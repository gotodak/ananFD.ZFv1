<?php
/**
 * Sysコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Debug'); 


// モデルをロードする
require_once '../application/vers/default/models/sysModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class SysController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_user;						// ユーザモデルのインスタンス
    private $_namespace;
    private $_userspace;
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        $this->_sys  = new sysModel('../application/lib/user.db');

        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				$this->view->sid 			 = '';	
				$this->view->loginUrl  = 'login/index';	
				$this->view->loginName = 'ログイン';	
				
				$this->view->userLevel = '-';		//FD高度化推進室　システム管理者
				$this->view->userName  = '';			//admin
				$this->view->userId		 = '';			//admin
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
									$this->view->sid 			 = '';	
									$this->view->loginUrl  = 'login/index';	
									$this->view->loginName = 'ログイン';	
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}



				
        // 初期化処理
        $isError  = false;
        $errorMsg = '';
        $errMsg = array();
        // 前アクションでエラーならメッセージを表示する
        if ($this->_getParam('errorMsg') != '') {
            $isError  = true;
            $errorMsg = $this->_getParam('errorMsg');
						$errMsg[] = $errorMsg;
        }
        $this->view->isError   = $isError;
        $this->view->errorMsg  = $errMsg;
				
				$errors = array();
				array_push($errors, $errMsg );
				$this->view->assign('errors',$errors);			// 追加後に再設定必要	//複数の変数（連想配列）を一度に設定する。


				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				
				$this->view->moduleArray = array( 	
																				'/ananfd/'					=>  'default',
																				'/ananfd/ver2012/'	=>  'ver2012'
																);
				$this->view->sessionArray = array( 	
																				'60'	=>    '60',
																				'300'	=>   '300',
																				'900'	=>   '900',
																			 '1200'	=>  '1200',
																			 '1440'	=>  '1440'
																);
				$this->view->countArray = array( 	
																				'5'		=>   '5',
																				'10'	=>  '10',
																				'15' 	=>  '15',
																				'20'	=>  '20',
																				'30'	=>  '30',
																				'40' 	=>  '40'
																);
				$this->view->rangeArray = array( 	
																				'5'		=>   '5',
																				'10'	=>  '10',
																				'15' 	=>  '15',
																				'20'	=>  '20',
																				'30'	=>  '30',
																				'40' 	=>  '40'
																);
				$this->view->debugArray = array( 	
																				'false'	=>  'Off',
																				'true'  =>  'On'
																);
				$this->view->databaseArray = array( 	
																				'ananfd2011'	=>  'ananfd2011',
																				'ananfd2012'  =>  'ananfd2012',
																				'ananfd2013'  =>  'ananfd2013'
																);


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {

				$list = $this->_sys->getConfigData( );
				
				
				$this->view->base_path 	= $list['basePath']		;
				$this->view->selModule 	= $list['modulePath']	;
				$this->view->selSession	= $list['session']		;
				$this->view->selCount 	= $list['count']			;
				$this->view->selRange 	= $list['range']			;
				$this->view->selDebug 	= $list['debug']			;
				$this->view->selDatabase= $list['database']		;
				
				$this->view->attribs = array( 	'disabled'	=>  'disabled');
				$this->view->options = null;

        // ビュースクリプトが表示されます


				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$sys2index		= $this->view->modulePath.'sys/index'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'システム情報'	,'url'=>$sys2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$sys2edit		= $this->view->modulePath.'sys/edit'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'編集'		,'url'=>$sys2edit		,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
			
			
    }


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function editAction()
    {
				$errors = array();
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						
						$list = $this->_sys->getConfigData( );
						
						
											$this->view->base_path 	= $list['basePath']		;
											$this->view->selModule 	= $list['modulePath']	;
											$this->view->selSession	= $list['session']		;
											$this->view->selCount 	= $list['count']			;
											$this->view->selRange 	= $list['range']			;
											$this->view->selDebug 	= $list['debug']			;
											$this->view->selDatabase 	= $list['database']		;
											
						
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$base_path	= $this->getRequest()->getParam('base_path');
						$module_path= '/ananfd/';
						$session	 	= $this->getRequest()->getParam('session');
						$count			= $this->getRequest()->getParam('count');
						$range	 		= $this->getRequest()->getParam('range');
						$debug	 		= 'false';
						$database		= $this->getRequest()->getParam('database');
						
						$base_path	= trim($base_path);								//半角スペースのみ
						
						
						if (count($errors) == 0){
								
								$data = array(
													'modulePath'=>	$module_path,
													'session'		=>	$session,
													'count'			=>	$count,
													'range'			=>	$range,
													'database'	=>	$database,
													'debug'			=>	$debug
												);
								
								
	    					$this->_sys->setConfigData( $data );
								
			        $targetUrl = '/sys/index/sid/'.$this->_sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						} else {
								
								$this->view->basePath		= $base_path;		
								
								$this->view->selModule	= $module_path;	
								$this->view->selSession	= $session;			
								$this->view->selCount		= $count;				
								$this->view->selRange		= $range;				
								$this->view->selDebug		= $debug;				
								$this->view->selDatabase= $database;		
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				
				$top2index		= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index	= $this->view->modulePath.'master/index'	.$this->view->sid;
				$sys2index		= $this->view->modulePath.'sys/index'			.$this->view->sid;
				$sys2edit			= $this->view->modulePath.'sys/edit'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'システム情報'	,'url'=>$sys2index ),
									array('name'=>'編集'					,'url'=>$sys2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$sys2index		= $this->view->modulePath.'sys/index'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'詳細'		,'url'=>$sys2index		,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

				
    }





    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}




