<?php
/**
 * Committeeコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する


// モデルをロードする
require_once '../application/vers/default/models/commModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';



class CommController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_comm;						// コミッティーモデルのインスタンス
    private $_namespace;
    private $_userspace;
		
		
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

				
        // ユーザモデルのインスタンスを生成する
        $this->_comm	= new commModel('../application/lib/user.db');
        $this->_menu	= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;		//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['comm']['sKind']		= $this->getRequest()->getParam('s_kind');		
						$this->_userspace->search['comm']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
				} else {
						if( !isset($this->_userspace->search['comm']['sKind']) )
							$this->_userspace->search['comm']['sKind']		= '0';
						if( !isset($this->_userspace->search['comm']['sKeyword']) )
							$this->_userspace->search['comm']['sKeyword']	= '';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sKind		= $this->_userspace->search['comm']['sKind'];		
				$sKeyword	= $this->_userspace->search['comm']['sKeyword'];
				if( $sKind 	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sKind  == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				$bFind = true;
				$sKind = '3';
				if ( $bFind ){
						
						$findArray = array( 	's_kind'  	=>  $sKind,
																	's_keyword'	=>  $sKeyword
																);
						
						$select = $this->_comm->getCommPage( $findArray, true );
						
				} else 
				{
						
						$select = $this->_comm->getCommPage( null, true );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, '3' );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '-', null );
				
				
				$this->view->selKind		= $sKind;
				$this->view->selKeyword	= $sKeyword;




				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$comm2index			= $this->view->modulePath.'comm/index'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'組織管理'		,'url'=>$section2index ),
									array('name'=>'委員会管理'	,'url'=>$comm2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$comm2new			= $this->view->modulePath.'comm/new'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成'		,'url'=>$comm2new		,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
				
    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$commId = $this->getRequest()->getParam('comm_id');
						if( $commId != NULL ){
									
									// 1レコードの取得
									$result = $this->_comm->getCommId( $commId );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['comm_id'] != 0 ){
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled');
											$this->view->options = null;
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, null );
											$this->view->deleteArray	= $this->_menu->getDeleteList( '-', null );
											
											$this->view->typeArray		= $this->_menu->getChiefTypeList( '', null );
											if ( $result['comm_kind'] == 2 ){
													// 1レコードの取得
													$group = $this->_comm->getCommGroupId( $commId );
													if( $group ){
															$this->view->selType	= $group['chief_type'];
															$this->view->selChief	= $group['chief_id'];
															switch( $group['chief_type'] ){
																case '1':
																	$menu_findArray = array(
																											 's_kind'		=>  '1',
																											 's_group'	=>  '0',
																											 's_grade'	=>  '0',
																											 's_year'		=>  '0'
																											);
																	$this->view->chiefArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
																	break;
																case '2':
																	$this->view->chiefArray		= $this->_menu->getGradeList( $menu_mode, null );
																	break;
																case '3':
																	$this->view->chiefArray		= $this->_menu->getClassList( $menu_mode, null );
																	break;
																default:
															}
													}
											}
									}
						}
				}
				else{
				}
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$comm2index			= $this->view->modulePath.'comm/index'		.$this->view->sid;
				$comm2item			= $this->view->modulePath.'comm/item/comm_id/'.$result['comm_id'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'組織管理'		,'url'=>$section2index ),
									array('name'=>'委員会管理'	,'url'=>$comm2index ),
									array('name'=>$result['comm_name']		,'url'=>$comm2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$comm2index		= $this->view->modulePath.'comm/index'.$this->view->sid;
				$comm2edit		= $this->view->modulePath.'comm/edit/comm_id/'.$result['comm_id'].$this->view->sid;
				$comm2delete	= $this->view->modulePath.'comm/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$comm2index	,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$comm2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$comm2delete ,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'comm/delete/comm_id/'.$result["comm_id"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$comm2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, null );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
				$this->view->typeArray		= $this->_menu->getChiefTypeList( '', null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$comm_id = $this->getRequest()->getParam('comm_id');
						if( $comm_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_comm->getCommId( $comm_id );
									
									if( $result['comm_id'] != 0 ){
											
											$this->view->comm_id		= $result['comm_id'];
												$this->_userspace->search['comm']['name']		= 
											$this->view->comm_name	= $result['comm_name'];
											$this->view->selKind 		= $result['comm_kind'];
											$this->view->selDelete	= $result['delete_flg'];	
											
											$this->view->typeArray		= $this->_menu->getChiefTypeList( '', null );
											if ( $result['comm_kind'] == 2 ){
													// 1レコードの取得
													$group = $this->_comm->getCommGroupId( $comm_id );
													if( $group ){
															$this->view->selType	= $group['chief_type'];
															$this->view->selChief	= $group['chief_id'];
															switch( $group['chief_type'] ){
																case '1':
																	$menu_findArray = array(
																											 's_kind'		=>  '1',
																											 's_group'	=>  '0',
																											 's_grade'	=>  '0',
																											 's_year'		=>  '0'
																											);
																	$this->view->chiefArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
																	break;
																case '2':
																	$this->view->chiefArray		= $this->_menu->getGradeList( $menu_mode, null );
																	break;
																case '3':
																	$this->view->chiefArray		= $this->_menu->getClassList( $menu_mode, null );
																	break;
																default:
															}
													}
											}
									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$comm_id 		= $this->getRequest()->getParam('comm_id');
						$comm_name	= $this->getRequest()->getParam('comm_name');
						$kind				= $this->getRequest()->getParam('kind');
						$delete			= $this->getRequest()->getParam('delete');
						
						$comm_name	= trim($comm_name);								//半角スペースのみ
						
						
						$msgs = validateStringFull2( 3, 30, '委員会名称', $comm_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	//● 重複チェック
						if( $this->_userspace->search['comm']['name'] != $comm_name ){
			  				if ( $this->_comm->isRegisteredComm($comm_name) == true )	{
									array_push($errors, array('この委員会名称は、既に登録されています。') );
			      		}
						}
						
						
						$msgs = validateSelect( '種別', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	      		
						
						
						if (count($errors) == 0){
								
								$data = array(
													'comm_id'			=>	$comm_id,
													'comm_name'		=>	$comm_name,
													'comm_kind'		=>	$kind,
													'delete_flg' 	=>	$delete,
													'create_date'	=> NULL
												);
								
								$commId			= $data['comm_id'];	
								$commKind		= $data['kind'] ;	
								$deleteType	= $data['delete_flg'] ;	
								if( $comm_id != NULL ){
										
			    					$this->_comm->updateComm( $data, $commId, $deleteType );
										
						        // ビュースクリプトが表示されます
								    $targetUrl = '/comm/index/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->comm_id		= $comm_id;
								$this->view->comm_name	= $comm_name;
								$this->view->selKind		= $kind;	
								$this->view->selDelete	= $delete;	
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$comm2index			= $this->view->modulePath.'comm/index'		.$this->view->sid;
				$comm2item			= $this->view->modulePath.'comm/item/comm_id/'.$this->view->comm_id.$this->view->sid;
				$comm2edit			= $this->view->modulePath.'comm/edit/comm_id/'.$this->view->comm_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'										,'url'=>$top2index ),
									array('name'=>'マスタ設定'						,'url'=>$master2index ),
									array('name'=>'組織管理'							,'url'=>$section2index ),
									array('name'=>'委員会管理'						,'url'=>$comm2index ),
									array('name'=>$this->view->comm_name	,'url'=>$comm2item ),
									array('name'=>'編集'									,'url'=>$comm2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$comm2index		= $this->view->modulePath.'comm/index'.$this->view->sid;
				$comm2item		= $this->view->modulePath.'comm/item/comm_id/'.$this->view->comm_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$comm2index		,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$comm2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
    }





    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				
				if ($this->getRequest()->isPost())
				{
						
						$comm_id 		= $this->getRequest()->getParam('comm_id');
						$comm_name	= $this->getRequest()->getParam('comm_name');
						$kind 			= '3';	//$this->getRequest()->getParam('kind');
						$delete			= $this->getRequest()->getParam('delete');
						
						$comm_name	= trim($comm_name);								//半角スペースのみ
						
						
						
	 		     	// 重複チェック
						if ( $this->_comm->isRegisteredComm($comm_name) == true )	{
								array_push($errors, array('この委員会名称は、既に登録されています。') );
			      }
						
						
						$msgs = validateSelect( '種別', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						
						if (count($errors) == 0){
								$data = array(
													'comm_name'		=>	$comm_name,
													'comm_kind'		=>	$kind,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$commId 		= 0;
								$commKind		= $kind;
								$deleteType = '0';
								
		    				if( $this->_comm->registComm( $data, $commId, $this->_userspace ) == 0 ){
										echo '中止 ';
										}

							$targetUrl = '/comm/index/sid/'.$this->_sid;
							return $this->_redirect($targetUrl);
						}else{
							
							$this->view->comm_id		= $comm_id;		
							$this->view->comm_name	= $comm_name;	
							
							$this->view->selKind		= $kind;
						}
				}
				else{
						
						
						$this->view->comm_id			= '';	
						$this->view->comm_name		= '';	
						$this->view->selKind			= '3';
						$this->view->selDelete		= 0;	
				}
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, null );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$comm2index			= $this->view->modulePath.'comm/index'		.$this->view->sid;
				$comm2new				= $this->view->modulePath.'comm/new'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'組織管理'		,'url'=>$section2index ),
									array('name'=>'委員会管理'	,'url'=>$comm2index ),
									array('name'=>'新規作成'		,'url'=>$comm2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$comm2index			= $this->view->modulePath.'comm/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'		,'url'=>$comm2index		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				
				if( $this->getRequest()->isPost() )
						{
						
						$comm_id = $this->getRequest()->getParam('comm_id');
						if( $comm_id != NULL ){
									
									// 1レコードの削除
									$result = $this->_comm->deleteComm( $comm_id );
						}
				}
				else{
				}
        // ビュースクリプトが表示されます
				$targetUrl = '/comm/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);
    }









    /**-------------------------------------------------------------------------------------------
     * chiefアクション（未使用）
     */
    public function chiefAction()
    {
				
				if( $this->getRequest()->isPost() ){
						
						$commId			= $this->getRequest()->getParam('comm_id');
						$chiefType	= $this->getRequest()->getParam('chief_type');
						
				    // ビュースクリプトが表示されます
					  $targetUrl = '/comm/group/comm_id/'. $commId. '/chief_type/' .$chiefType. '/sid/'.$this->_sid;
					  return $this->_redirect($targetUrl);		//DebugMessage 表示不可
					
				}
				
    }




    /**-------------------------------------------------------------------------------------------
     * groupアクション（未使用）
     */
    public function groupAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
						$commId 		= $this->getRequest()->getParam('comm_id');
						$chiefType	= $this->getRequest()->getParam('chief_type');
						
				}
				else if( $this->getRequest()->isPost() ){
						
						$commId			= $this->getRequest()->getParam('comm_id');
						$chiefType	= $this->getRequest()->getParam('chief_type');
						$chiefId		= $this->getRequest()->getParam('chief_id');
						
						if ( $chiefId != 0 )
						{
									
									$info = array( 
															'chief_type'			=> $chiefType,
															'chief_id'				=> $chiefId		
																);
									$this->_comm->updateCommGroup( $info, $commId );
									
					        // ビュースクリプトが表示されます
					        $targetUrl = '/comm/edit/comm_id/'. $commId. '/sid/'.$this->_sid;
					        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
								
						}else{
								
								
								
						}
					
				}
				
				$menu_mode ='';					//select
				if( $chiefType==2 )
					$this->view->chiefArray		= $this->_menu->getGradeList( $menu_mode, null );
				else if( $chiefType==3 )
					$this->view->chiefArray		= $this->_menu->getClassList( $menu_mode, null );
				else{
					$menu_findArray = array(
																	 's_kind'		=>  '1',
																	 's_group'	=>  '0',
																	 's_grade'	=>  '0',
																	 's_year'		=>  '0'
																	);
					$this->view->chiefArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				}
				
				$this->view->typeArray	= $this->_menu->getChiefTypeList( '', null );
				$this->view->selType 		= $chiefType;
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';
				
				
				$this->view->comm_id		= $commId;
				$comm_name	= $this->_comm->getCommName($commId);
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$comm2index			= $this->view->modulePath.'comm/index'		.$this->view->sid;
				$comm2item			= $this->view->modulePath.'comm/item/comm_id/'.$this->view->comm_id.$this->view->sid;
				$comm2edit			= $this->view->modulePath.'comm/edit/comm_id/'.$this->view->comm_id.$this->view->sid;
				$comm2group			= $this->view->modulePath.'comm/group/comm_id/'.$this->view->comm_id.'/chief_type/'.$chiefType.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'										,'url'=>$top2index ),
									array('name'=>'マスタ設定'						,'url'=>$master2index ),
									array('name'=>'組織管理'							,'url'=>$section2index ),
									array('name'=>'委員会管理'						,'url'=>$comm2index ),
									array('name'=>$comm_name							,'url'=>$comm2item ),
									array('name'=>'編集'									,'url'=>$comm2edit ),
									array('name'=>'クラス編集'						,'url'=>$comm2group )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$comm2index		= $this->view->modulePath.'comm/index'.$this->view->sid;
				$comm2item		= $this->view->modulePath.'comm/item/comm_id/'.$this->view->comm_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
    }















    /**-------------------------------------------------------------------------------------------
     * item0アクション
     */
    public function item0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * item0Editアクション
     */
    public function item0EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
