<?php
/**
 * Tpコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); 							// 追加する
Zend_Loader::loadClass('Zend_Pdf'); 										// 追加する


// モデルをロードする
require_once '../application/vers/default/models/subjectModel.php';
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/menuModel.php';

// モジュールをロードする
require_once '../application/lib/functions.php';




class TpController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_subject;				// サブジェクトモデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        $this->_subject = new subjectModel('../application/lib/subject.db');
        $this->_user 		= new userModel('../application/lib/user.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
 				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$this->view->selGroup		= 0;
				$this->view->selJob			= 0;
				$this->view->selKana		= 0;
				$this->view->selComm		= 0;
				$this->view->selKeyword	= '';
				$this->view->selField		= 0;
				$this->view->selStyear	= 0;
				$this->view->selEdyear	= 0;
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['tp']['sStyear']	= $this->getRequest()->getParam('s_styear','0');
						$this->_userspace->search['tp']['sEdyear']	= $this->getRequest()->getParam('s_edyear','0');
						$this->_userspace->search['tp']['sGroup']		= $this->getRequest()->getParam('s_group','0');
						$this->_userspace->search['tp']['sJob']			= $this->getRequest()->getParam('s_job','0');
						$this->_userspace->search['tp']['sKana']		= $this->getRequest()->getParam('s_kana','0');
						$this->_userspace->search['tp']['sComm']		= $this->getRequest()->getParam('s_comm','0');
						$this->_userspace->search['tp']['sKeyword']	= $this->getRequest()->getParam('s_keyword','');
						$this->_userspace->search['tp']['sField']		= $this->getRequest()->getParam('s_field','0');
				} else {
						if( !isset($this->_userspace->search['tp']['sStyear']) )
							$this->_userspace->search['tp']['sStyear']	= '0';
						if( !isset($this->_userspace->search['tp']['sEdyear']) )
							$this->_userspace->search['tp']['sEdyear']	= '0';
						if( !isset($this->_userspace->search['tp']['sGroup']) )
							$this->_userspace->search['tp']['sGroup']		= '0';
						if( !isset($this->_userspace->search['tp']['sJob']) )
							$this->_userspace->search['tp']['sJob']			= '0';
						if( !isset($this->_userspace->search['tp']['sKana']) )
							$this->_userspace->search['tp']['sKana']		= '0';
						if( !isset($this->_userspace->search['tp']['sComm']) )
							$this->_userspace->search['tp']['sComm']		= '0';
						if( !isset($this->_userspace->search['tp']['sKeyword']) )
							$this->_userspace->search['tp']['sKeyword']	= '';
						if( !isset($this->_userspace->search['tp']['sField']) )
							$this->_userspace->search['tp']['sField']		= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sStyear	=	$this->_userspace->search['tp']['sStyear'];
				$sEdyear	=	$this->_userspace->search['tp']['sEdyear'];
				$sGroup		= $this->_userspace->search['tp']['sGroup'];	
				$sJob			=	$this->_userspace->search['tp']['sJob'];		
				$sKana		=	$this->_userspace->search['tp']['sKana'];	
				$sComm		=	$this->_userspace->search['tp']['sComm'];	
				$sKeyword	=	$this->_userspace->search['tp']['sKeyword'];
				$sField		=	$this->_userspace->search['tp']['sField'];	
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sComm	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sJob	  == "0" 
					&& $sKana   == "0" 
					&& $sComm   == "0" 
					&& $sKeyword== ""  
					&& $sStyear == "0" 
					&& $sEdyear == "0" 
					)	{
							$bFind = false;
				}
				

				$bTerm = false;	
				if( $sStyear != "0" &&	$sEdyear	!= "0" )
				{
					if( $sEdyear < $sStyear ){
						array_push($errors, array('終了年度が、開始年度より過去に設定されています。') );
						$this->view->assign('errors',$errors);			// 追加後に再設定必要
					}
					else{
						$bTerm = true;	
					}
				}

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_comm'	  =>  $sComm,
																	'styear'	=>	$sStyear,
																	'edyear'	=>	$sEdyear,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						
						$select = $this->_subject->getUser2Page( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_subject->getUser2Page( null );
						
				}
				
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selComm		= $sComm;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selStyear	= $sStyear;
				$this->view->selEdyear	= $sEdyear;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupSelect= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->groupList	= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray		= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray	= $this->_menu->getKanaList( $menu_mode, null );
				$menu_commArray	= array( COMM_KIND_EXPERT,COMM_KIND_USER );
	   		$this->view->commArray	= $this->_menu->getCommitteeList( $menu_mode, $menu_commArray );
				$this->view->fieldArray	= $this->_menu->getField3List( null, null );
				
				$menu_ext 	='-';					//select
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );




				$top2index	= $this->view->modulePath.'top/index'		.$this->view->sid;
				$tp2index		= $this->view->modulePath.'tp/index'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'														,'url'=>$top2index ),
									array('name'=>'ＴＰ支援'											,'url'=>$tp2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$tp2new		= $this->view->modulePath.'tp/user0-new'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);




if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }



    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function userAction()
    {
				
				
				$this->view->selGroup		= 0;
				$this->view->selJob			= 0;
				$this->view->selKana		= 0;
				$this->view->selKeyword	= "";
				
				$comm = 0;
				$user 	= $this->getRequest()->getParam('user_id');
				if( $user == NULL )	return ;
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['tp2']['sGroup']		= $this->getRequest()->getParam('s_group','0');
						$this->_userspace->search['tp2']['sGrade']		= $this->getRequest()->getParam('s_grade','0');
						$this->_userspace->search['tp2']['sReq']			= $this->getRequest()->getParam('s_req','0');
						$this->_userspace->search['tp2']['sTerm']			= $this->getRequest()->getParam('s_term','0');
						$this->_userspace->search['tp2']['sStyear']		= $this->getRequest()->getParam('s_styear','0');
						$this->_userspace->search['tp2']['sKeyword']	= $this->getRequest()->getParam('s_keyword','');
						$this->_userspace->search['tp2']['sField']		= $this->getRequest()->getParam('s_field','0');
						$this->_userspace->search['tp2']['styear']		= $this->getRequest()->getParam('styear','0');
						$this->_userspace->search['tp2']['edyear']		= $this->getRequest()->getParam('edyear','0');
				} else {
						if( !isset($this->_userspace->search['tp2']['sGroup']) )
							$this->_userspace->search['tp2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['tp2']['sGrade']) )
							$this->_userspace->search['tp2']['sGrade']		= '0';
						if( !isset($this->_userspace->search['tp2']['sReq']) )
							$this->_userspace->search['tp2']['sReq']			= '0';
						if( !isset($this->_userspace->search['tp2']['sTerm']) )
							$this->_userspace->search['tp2']['sTerm']			= '0';
						if( !isset($this->_userspace->search['tp2']['sStyear']) )
							$this->_userspace->search['tp2']['sStyear']		= '0';
						if( !isset($this->_userspace->search['tp2']['sKeyword']) )
							$this->_userspace->search['tp2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['tp2']['sField']) )
							$this->_userspace->search['tp2']['sField']		= '0';
						if( !isset($this->_userspace->search['tp2']['styear']) )
							$this->_userspace->search['tp2']['styear']		= '0';
						if( !isset($this->_userspace->search['tp2']['edyear']) )
							$this->_userspace->search['tp2']['edyear']		= '0';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		=	$this->_userspace->search['tp2']['sGroup'];
				$sGrade		=	$this->_userspace->search['tp2']['sGrade'];
				$sReq			=	$this->_userspace->search['tp2']['sReq'];
				$sTerm		=	$this->_userspace->search['tp2']['sTerm'];
				$sStyear	=	$this->_userspace->search['tp2']['sStyear'];
				$sKeyword	=	$this->_userspace->search['tp2']['sKeyword'];
				$sField		=	$this->_userspace->search['tp2']['sField'];
				$styear		=	$this->_userspace->search['tp2']['styear'];
				$edyear		=	$this->_userspace->search['tp2']['edyear'];
				if( $sGroup 	=== null 
					||	$sGrade	=== null 
					|| 	$sReq		=== null 
					|| 	$sTerm	=== null 
					|| 	$sStyear=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sReq    == "0" 
					&& $sTerm   == "0" 
					&& $sStyear == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				if( $styear != "0" || $edyear != "0" ) {
					
						if( $bFind == false ){
							
							$sGroup  = "0";
							$sGrade  = "0";
							$sReq    = "0";
							$sTerm   = "0";
							$sKeyword= "" ;
						}
					
					$bFind = true;
				}

				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_req'		  =>  $sReq,
																	's_term'	  =>  $sTerm,
																	's_styear'	=>  $sStyear,
																	'committee' =>  $comm,
																	'styear'  	=>  $styear,
																	'edyear'  	=>  $edyear,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						
						$select = $this->_subject->getSubjectUserPage( $user, $findArray, $styear, $edyear );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_subject->getSubjectUserPage( $user, null, $styear, $edyear  );
						
				}
				
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selReq			= $sReq;
				$this->view->selTerm		= $sTerm;
				$this->view->selStyear	= $sStyear;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				
        // ビュースクリプトが表示されます
				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->reqArray			= $this->_menu->getReqList( $menu_mode, null );
				$this->view->termArray		= $this->_menu->getTermList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField2List( null, null );
				
				$this->view->user			 	= $user;
				$this->view->name				= $this->_user->getUserName($user);
				$this->view->styear		 	= $styear;
				$this->view->edyear		 	= $edyear;




				$top2index	= $this->view->modulePath.'top/index'		.$this->view->sid;
				$tp2index		= $this->view->modulePath.'tp/index'		.$this->view->sid;
				$tp2user		= $this->view->modulePath.'tp/user/user_id/'	.$user.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'														,'url'=>$top2index ),
									array('name'=>'ＴＰ支援'											,'url'=>$tp2index ),
									array('name'=>$this->view->name								,'url'=>$tp2user )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$tp2new		= $this->view->modulePath.'tp/user0-new'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'ＴＰ新規作成'  	,'url'=>$tp2new		,'onclick'=>'' )
									);
					break;
				case 'admin':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
		}


    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
						{
						$styear	=	$this->_userspace->styear;	
						$edyear	=	$this->_userspace->edyear;	
						
						$subject_id = $this->getRequest()->getParam('subject_id');
						$user_id 		= $this->getRequest()->getParam('user_id');
						if( $subject_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_subject->getSubjectId( $subject_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['code'] != 0 ){
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											$this->view->selReq			= $result["require"];	
											$this->view->selTerm		= $result["term"];	
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array(
																							 's_kind'		=>  '1',
																							 's_group'	=>  '0',
																							 's_grade'	=>  '0',
																							 's_year'		=>  '0'
																							);
											$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
											$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
											$this->view->reqArray			= $this->_menu->getReqList( null, null );
											$this->view->termArray		= $this->_menu->getTermList( null, null );
											
											
											// 1レコードの取得
											$group = $this->_subject->chargedGroupId( $subject_id );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['group_id'] );					//DB 1:一般教科 20110906
											}
											$this->view->selGroup		= $groupArray;

											// 1レコードの取得
											$syllabus = $this->_subject->chargedSyllabus( $subject_id );
											$syllabus2Array = array();
											foreach( $syllabus as $row ){
												array_push( $syllabus2Array, array("file"=>$row['file'],"year"=>$row['year'] ) );
											}
											$this->view->syllabus		= $syllabus2Array;


											// 1レコードの取得
											$user = $this->_subject->chargedUserId( $subject_id );
											$user2Array = array();
											foreach( $user as $row ){
												$name = $this->_subject->getUserName($row['user_id']);
												array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
											}
											$this->view->user		= $user2Array;
											$this->view->subject_id	= $subject_id;
											$this->view->user_id		= $user_id;
											$this->view->name				= $this->_user->getUserName($user_id);
											
											$this->view->styear		 	= $styear;
											$this->view->edyear		 	= $edyear;
											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}


				$top2index	= $this->view->modulePath.'top/index'		.$this->view->sid;
				$tp2index		= $this->view->modulePath.'tp/index'		.$this->view->sid;
				$tp2user		= $this->view->modulePath.'tp/user/user_id/'			.$user_id.$this->view->sid;
				$tp2item		= $this->view->modulePath.'tp/item/subject_id/'	.$subject_id.'/user_id/'.$user_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'														,'url'=>$top2index ),
									array('name'=>'ＴＰ支援'											,'url'=>$tp2index ),
									array('name'=>$this->view->name								,'url'=>$tp2user ),
									array('name'=>$result["name"]	.'　（シラバス）'	,'url'=>$tp2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$tp2user		= $this->view->modulePath.'tp/user/user_id/'.$user_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$tp2user	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }








    /**-------------------------------------------------------------------------------------------
     * user0アクション
     */
    public function user0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * user0Newアクション
     */
    public function user0NewAction()
    {
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * user0Tpアクション
     */
    public function user0TpAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * user0TpEditアクション
     */
    public function user0TpEditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * user0Syllabus0アクション
     */
    public function user0Syllabus0Action()
    {
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listTpアクション
     */
    public function listTpAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listTpItem0アクション
     */
    public function listTpItem0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listTpItem1アクション
     */
    public function listTpItem1Action()
    {
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listSyllabusアクション
     */
    public function listSyllabusAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listSyllabusItem0アクション
     */
    public function listSyllabusItem0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
