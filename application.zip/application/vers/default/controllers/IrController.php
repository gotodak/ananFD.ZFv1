<?php
/**
 * Irコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する
Zend_Loader::loadClass('Zend_Pdf'); // 追加する

// モデルをロードする
require_once '../application/vers/default/models/commModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';





class IrController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_comm;						// コミッティーモデルのインスタンス
    private $_namespace;
    private $_userspace;
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        $this->_comm	= new commModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}


				{
	        $controller = strtolower($this->getRequest()->getControllerName());
					setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
					
					
	        $controller = strtolower($this->getRequest()->getControllerName());
	        $action     = strtolower($this->getRequest()->getActionName());
					setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);
				}



		}





    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
				

				if( $this->getRequest()->isGet() )
				{
					  // 前アクションでエラーならメッセージを表示する
					  $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
						$msg		= getDispMessage( $noMsg,$this->view ) ;
						if( !is_null($msg) ){
								array_push( $errors,array($msg) );
						}
						// メンバ設定によるコマンド禁止
				}



				$this->view->user_id		= $this->_userspace->userId;
				$this->view->comm_id		= '6';
				$this->view->public			= false;
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要




if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }



    /**-------------------------------------------------------------------------------------------
     * viewアクション
     *--------------------------------------------------------------------------------------------
     */
    public function viewAction()
    {
				
				if( $this->getRequest()->isGet() )
						{
						
						$irId		= $this->getRequest()->getParam('ir_id'	 ,null);
						$userId	= $this->getRequest()->getParam('user_id',null);
						$commId	= COMM_FD;
						if( $this->_comm->isAllowCommuser( $userId,$commId ) == false ){	
									
									
					        $targetUrl = '/ir/index'. $this->view->sid.'/'.DISP_MESSAGE.'/'.ERR_VIEW_NORIGHT;		//'参照権がありません。
					        $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}else{
							
							$file 		= $this->getRequest()->getParam('file');
							$this->view->pdf		= $file;
						}
				}
				
		}





    /**-------------------------------------------------------------------------------------------
     * viewirアクション
     *--------------------------------------------------------------------------------------------
     */
    public function viewirAction()
    {
				
				if( $this->getRequest()->isGet() )
				{
						
						$irId		= $this->getRequest()->getParam('ir_id');
						$userId	= $this->getRequest()->getParam('user_id');
						$commId	= COMM_FD;
						if( $this->_comm->isAllowCommuser( $userId,$commId ) == false ){	
									
					 				$this->_forward( 'error', 'Error', null, 
																		array('accessError' => '参照権がありません。('. $this->view->userName .')' ) 
																		);	
						}else{
							
							$file 		= $this->getRequest()->getParam('file');
							$this->view->pdf		= $file;
						}
				}
				
		}








    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * invest0addアクション
     */
    public function invest0AddAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * invest0アクション
     */
    public function invest0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * invest0Editアクション
     */
    public function invest0EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * invest0Ir0アクション
     */
    public function invest0Ir0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * invest0Ir0Editアクション
     */
    public function invest0Ir0EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }



    /**-------------------------------------------------------------------------------------------
     * invest1アクション
     */
    public function invest1Action()
    {
				
				
        // ビュースクリプトが表示されます
    }
    /**-------------------------------------------------------------------------------------------
     * invest1Editアクション
     */
    public function invest1EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }
    /**-------------------------------------------------------------------------------------------
     * invest1Ir1アクション
     */
    public function invest1Ir1Action()
    {
				
				
        // ビュースクリプトが表示されます
    }
    /**-------------------------------------------------------------------------------------------
     * invest1Ir1Editアクション
     */
    public function invest1Ir1EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }





    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
