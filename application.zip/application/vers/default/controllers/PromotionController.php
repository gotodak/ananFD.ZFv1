<?php
/**
 * Promotionコントローラ（一括進級）
 *
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db');
Zend_Loader::loadClass('Zend_Debug');
Zend_Loader::loadClass('Zend_Paginator'); // 追加する

// モデルをロードする
//require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/graduateModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class PromotionController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    //private $_user;					// ユーザモデルのインスタンス
    private $_member;					// メンバーモデルのインスタンス
    private $_graduate;				// 卒業生モデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス

    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

        // ユーザモデルのインスタンスを生成する
        //$this->_user 		= new userModel('../application/lib/user.db');
        $this->_member 		= new memberModel('../application/lib/member.db');
        $this->_graduate	= new graduateModel('../application/lib/graduate.db');
        $this->_menu 	 		= new menuModel('../application/lib/user.db');

        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin

				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';




				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長

					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;
									$this->view->ssid 		 = $this->_sid;
									$this->view->loginUrl  = 'login/logout';
									$this->view->loginName = 'ログアウト';
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}



        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);


        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);


		}




    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {

				$this->_userspace->search['student2']['fClass']		= '0';

        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }




    /**-------------------------------------------------------------------------------------------
     * classアクション
     */
    public function classAction()
    {

				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要



				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;

				if( $this->getRequest()->isPost() ){

						//$coachst= $this->getRequest()->getParam('coachst' );
						$this->_userspace->search['student2']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['student2']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['student2']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['student2']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['student2']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['student2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['student2']['sField']		= $this->getRequest()->getParam('s_field');

						$this->_userspace->search['student2']['fClass']		= $this->getRequest()->getParam('fix');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['student2']['sGroup']) )
							$this->_userspace->search['student2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['student2']['sGrade']) )
							$this->_userspace->search['student2']['sGrade']		= '0';
						if( !isset($this->_userspace->search['student2']['sStyear']) )
							$this->_userspace->search['student2']['sStyear']	= '0';
						if( !isset($this->_userspace->search['student2']['sKana']) )
							$this->_userspace->search['student2']['sKana']		= '0';
						if( !isset($this->_userspace->search['student2']['sKeyword']) )
							$this->_userspace->search['student2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['student2']['sField']) )
							$this->_userspace->search['student2']['sField']		= '0';

						if( !isset($this->_userspace->search['student2']['fClass'])
								|| $this->_userspace->search['student2']['fClass']=='0' )
							$this->_userspace->search['student2']['fClass']		=
																$this->getRequest()->getParam('fix');


						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){

							array_push($errors, array('追加学生が、選択されていません。') );
						}
				}


/**	fixedSearch	(indexAction)	**/


				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );


				if( true )
				{

						{

								$m_group = 0;
								$m_grade = 0;
								$m_class = $this->_userspace->search['student2']['fClass'];
								$className	= $this->_graduate->getClassName($m_class);

								if( $m_class != 0 ){
									$menu_findArray['s_class']= $m_class;	//'2';
									$this->view->classArray	= $this->_menu->getClassList( ($m_class <= 0 ? $menu_mode : null), $menu_findArray );
									if( $m_class > 0 )
									$this->_userspace->search['student2']['fClass']	= $m_class;
								}
						}


				}


/****/


				$bFind = true;

				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= '0';		//$this->_userspace->search['student2']['sGroup'];
				$sGrade		= '0';		//$this->_userspace->search['student2']['sGrade'];
				$sStyear	= '0';		//$this->_userspace->search['student2']['sStyear'];
				$sKana		= '0';		//$this->_userspace->search['student2']['sKana'];
				$sClass		=	'0';		//$this->_userspace->search['student2']['sClass'];
				$sKeyword	=	'';		//$this->_userspace->search['student2']['sKeyword'];
				$sField		=	'0';		//$this->_userspace->search['student2']['sField'];

				$sClass		=	$this->_userspace->search['student2']['fClass'];
				if( $sGroup 		=== null
					||	$sGrade		=== null
					|| 	$sStyear	=== null
					||	$sKana		=== null
					||	$sClass		=== null
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0"
					&& $sGrade  == "0"
					&& $sStyear == "0"
					&& $sKana		== "0"
					&& $sClass	== "0"
					&& $sKeyword== ""
					)	{
							$bFind = false;
				}


if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){

						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);

						$select = $this->_member->getMemberPage( $findArray );

				} else
				{

						// データ取得形式を設定する
						$select = $this->_member->getMemberPage( null );

				}


				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）

				$this->view->assign( 'paginator', $paginator );


        // ビュースクリプトが表示されます

        $page  = $this->getRequest()->getParam('page');
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;


				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';






        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要





				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index			= $this->view->modulePath.'master/index'		.$this->view->sid;
				$student2index		= $this->view->modulePath.'student/index'		.$this->view->sid;
				$promotion2index	= $this->view->modulePath.'promotion/index'	.$this->view->sid;
				$promotion2class	= $this->view->modulePath.'promotion/class/fix/' .$m_class.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'マスタ設定','url'=>$master2index ),
									array('name'=>'学生管理'	,'url'=>$student2index ),
									array('name'=>'一括進級'	,'url'=>$promotion2index ),
									array('name'=>$className	,'url'=>$promotion2class )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$promotion2student	= $this->view->modulePath.'promotion/student/fix/'.$m_class	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'進級追加'		,'url'=>$promotion2student			,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * studentアクション（進級学生選択）
     */
    public function studentAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要



				$this->view->selGroup2	= 0;
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;

				if( $this->getRequest()->isPost() ){

						//$coachst= $this->getRequest()->getParam('coachst',null );
						$this->_userspace->search['student2']['sGroup2']	= $this->getRequest()->getParam('s_group2');
						$this->_userspace->search['student2']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['student2']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['student2']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['student2']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['student2']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['student2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['student2']['sField']		= $this->getRequest()->getParam('s_field');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['student2']['sGroup2']) )
							$this->_userspace->search['student2']['sGroup2']	= '0';
						if( !isset($this->_userspace->search['student2']['sGroup']) )
							$this->_userspace->search['student2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['student2']['sGrade']) )
							$this->_userspace->search['student2']['sGrade']		= '0';
						if( !isset($this->_userspace->search['student2']['sStyear']) )
							$this->_userspace->search['student2']['sStyear']	= '0';
						if( !isset($this->_userspace->search['student2']['sKana']) )
							$this->_userspace->search['student2']['sKana']		= '0';
						if( !isset($this->_userspace->search['student2']['sClass']) )
							$this->_userspace->search['student2']['sClass']		= '0';
						if( !isset($this->_userspace->search['student2']['sKeyword']) )
							$this->_userspace->search['student2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['student2']['sField']) )
							$this->_userspace->search['student2']['sField']		= '0';

						if( !isset($this->_userspace->search['student2']['fClass'])
								|| $this->_userspace->search['student2']['fClass']=='0' )
							$this->_userspace->search['student2']['fClass']		=
																$this->getRequest()->getParam('fix');

						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							array_push($errors, array('進級学生が、選択されていません。') );
						}
						elseif( $error ==2 ){
							array_push($errors, array('進級グループが、選択されていません。') );
						}
				}


/**	fixedSearch	(indexAction)	**/


				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->group2Array	= $this->_menu->getGroupList( '', $menu_findArray );
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );


				if( true )
				{

						{

								$m_group = 0;
								$m_grade = 0;
								$m_class = $this->_userspace->search['student2']['fClass'];
								$className	= $this->_graduate->getClassName($m_class);

								if( $m_class != 0 ){
									$menu_findArray['s_class']= $m_class;	//'2';
									$this->view->classArray	= $this->_menu->getClassList( ($m_class <= 0 ? $menu_mode : null), $menu_findArray );
									if( $m_class > 0 )
									$this->_userspace->search['student2']['fClass']	= $m_class;
								}
						}


				}


/****/


				$bFind = true;

				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup2	= $this->_userspace->search['student2']['sGroup2'];
				$sGroup		= $this->_userspace->search['student2']['sGroup'];
				$sGrade		= $this->_userspace->search['student2']['sGrade'];
				$sStyear	= $this->_userspace->search['student2']['sStyear'];
				$sKana		= $this->_userspace->search['student2']['sKana'];
				$sClass		=	$this->_userspace->search['student2']['sClass'];
				$sKeyword	=	$this->_userspace->search['student2']['sKeyword'];
				$sField		=	$this->_userspace->search['student2']['sField'];

				$sClass		=	$this->_userspace->search['student2']['fClass'];
				if( $sGroup 		=== null
					||	$sGrade		=== null
					|| 	$sStyear	=== null
					||	$sKana		=== null
					||	$sClass		=== null
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0"
					&& $sGrade  == "0"
					&& $sStyear == "0"
					&& $sKana		== "0"
					&& $sClass	== "0"
					&& $sKeyword== ""
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){

						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);

						$select = $this->_member->getMemberPage( $findArray );

				} else
				{

						// データ取得形式を設定する
						$select = $this->_member->getMemberPage( null );

				}


				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）

				$this->view->assign( 'paginator', $paginator );


        // ビュースクリプトが表示されます

        $page  = $this->getRequest()->getParam('page');
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$this->view->selGroup2	= $sGroup2;
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->class			= $m_class;


				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';



        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要








				$top2index					= $this->view->modulePath.'top/index'				.$this->view->sid;
				$master2index				= $this->view->modulePath.'master/index'	.$this->view->sid;
				$student2index			= $this->view->modulePath.'student/index'		.$this->view->sid;
				$promotion2index		= $this->view->modulePath.'promotion/index'	.$this->view->sid;
				$promotion2class		= $this->view->modulePath.'promotion/class/fix/'		.$m_class.$this->view->sid;
				$promotion2student	= $this->view->modulePath.'promotion/student/fix/'	.$m_class.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'学生管理'	,'url'=>$student2index ),
									array('name'=>'一括進級'	,'url'=>$promotion2index ),
									array('name'=>$className	,'url'=>$promotion2class ),
									array('name'=>'学生選択'	,'url'=>$promotion2student )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * upgradeアクション
     */
    public function upgradeAction()
    {
				if( $this->getRequest()->isPost() ) {

						$memberArray	= $this->getRequest()->getParam('member_id');
						$class			= $this->getRequest()->getParam('class');
				}

				if( count($memberArray) == 0 ){
						$class			= $this->getRequest()->getParam('class');
		        $targetUrl = '/promotion/student/fix/'.$class.'/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($memberArray) >= 1 ){

						if( 21 <= $class )			$grade = 6;
						elseif( 16 <= $class )	$grade = 5;
						elseif( 11 <= $class )	$grade = 4;
						elseif( 6 <= $class )		$grade = 3;
						elseif( 1 <= $class )		$grade = 2;
							else									$grade = 0;

						if(  $grade <= 2 ){
								$group			= $this->getRequest()->getParam('s_group2');
								if( $group < 2 ){
										$class			= $this->getRequest()->getParam('class');
										$targetUrl = '/promotion/student/fix/'.$class.'/error/2/sid/'.$this->_sid;
										return $this->_redirect($targetUrl);		//DebugMessage 表示不可
								} else {

										$class = $this->_graduate->getClassId( $grade, $group );
										if( $class < 6 && 11 < $class )	{
											$class			= $this->getRequest()->getParam('class');
											$targetUrl = '/promotion/student/fix/'.$class.'/error/2/sid/'.$this->_sid;
											return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}
								}
								$data = array(
											'end_year'		=> getNowYear(false).'-03-31',			//'2012-03-31'
											'grade'				=> $grade,
											'group'				=> $group,
											'class'				=> $class,
											'kind'				=> '0',
											'state'				=> '0',
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);
						} else if( $grade <= 5 ){
								$class	= $this->getRequest()->getParam('class') +5;
								$data = array(
											'end_year'		=> getNowYear(false).'-03-31',			//'2012-03-31'
											'grade'				=> $grade,
											//'group'				=> $group,			//2012 delete
											'class'				=> $class,
											'kind'				=> '0',
											'state'				=> '0',
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);
						} else {
								$data = array(
											'end_year'		=> getNowYear(false).'-03-31',			//'2012-03-31'
											'grade'				=> $grade,
											'kind'				=> '1',
											'state'				=> '0',
											'delete_flg'	=> '0',
											'create_date'	=> NULL
										);
						}
						$deleteType = '0';

						if( $grade != 0 ) {
								if( $grade == 6 ){

						    		$this->_graduate->registGraduate( $data, $memberArray, $deleteType );
								} else {

						    		$this->_member->upgradeMember( $data, $memberArray, $deleteType );
								}
						}
				}


				// ビュースクリプトが表示されます
			  $targetUrl = '/promotion/class/fix/'.$class.'/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可

    }










    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }



}
