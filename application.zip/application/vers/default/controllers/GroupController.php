<?php
/**
 * Groupコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する


// モデルをロードする
require_once '../application/vers/default/models/groupModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';



class GroupController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_group;					// グループモデルのインスタンス
    private $_namespace;
    private $_userspace;
		
		
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

				
        // ユーザモデルのインスタンスを生成する
        $this->_group = new groupModel('../application/lib/user.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;		//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);




		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['group']['sStyear']		= $this->getRequest()->getParam('s_styear');	
						$this->_userspace->search['group']['sEdyear']		= $this->getRequest()->getParam('s_edyear');	
						$this->_userspace->search['group']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
				} else {
						if( !isset($this->_userspace->search['group']['sStyear']) )
							$this->_userspace->search['group']['sStyear']		= '0';
						if( !isset($this->_userspace->search['group']['sEdyear']) )
							$this->_userspace->search['group']['sEdyear']		= '0';
						if( !isset($this->_userspace->search['group']['sKeyword']) )
							$this->_userspace->search['group']['sKeyword']	= '';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sStyear	= $this->_userspace->search['group']['sStyear'];		
				$sEdyear	= $this->_userspace->search['group']['sEdyear'];		
				$sKeyword	= $this->_userspace->search['group']['sKeyword'];		
				if( $sStyear 	=== null 
					||	$sEdyear=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sStyear  == "0" 
					&& $sEdyear == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				$bTerm = false;	
				if( $sStyear != "0" &&	$sEdyear	!= "0" )
				{
					if( $sEdyear < $sStyear ){
						array_push($errors, array('終了年度が、開始年度より過去に設定されています。') );
						$this->view->assign('errors',$errors);			// 追加後に再設定必要
					}
					else{
						$bTerm = true;	
					}
				}
				if ( $bFind ){
						
						$findArray = array( 	's_styear'  =>  $sStyear,
																	's_edyear'  =>  $sEdyear,
																	's_keyword'	=>  $sKeyword
																);
						
						$select = $this->_group->getGroupPage( $findArray, isDispMode($this->view) );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_group->getGroupPage( null, isDispMode($this->view) );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->kindArray		= $this->_menu->getGroupKindList( null, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '-', null );
				
				
				$this->view->selStyear	= $sStyear;
				$this->view->selEdyear	= $sEdyear;
				$this->view->selKeyword	= $sKeyword;



				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$group2index		= $this->view->modulePath.'group/index'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'組織管理'			,'url'=>$section2index ),
									array('name'=>'グループ管理'	,'url'=>$group2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$group2new		= $this->view->modulePath.'group/new'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'新規作成'		,'url'=>$group2new		,'onclick'=>'' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



				
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				if( $this->getRequest()->isGet() )
						{
						
						$group_id = $this->getRequest()->getParam('group_id');
						if( $group_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_group->getGroupId( $group_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['group_id'] != 0 ){
											
											$this->view->selStyear			= substr($result["start_year"],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array( 	's_kind'		=>  '1'
																							);
											$menu_find['s_kind']='1';
											$this->view->kindArray		= $this->_menu->getGroupKindList( null, null );
											$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
											$this->view->deleteArray	= $this->_menu->getDeleteList( '-', null );
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled');
											$this->view->options = null;
									}
						}
				}
				else{
				}



				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$group2index		= $this->view->modulePath.'group/index'		.$this->view->sid;
				$group2item			= $this->view->modulePath.'group/item/group_id/'.$result['group_id'].$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'組織管理'			,'url'=>$section2index ),
									array('name'=>'グループ管理'	,'url'=>$group2index ),
									array('name'=>$result['group_name']		,'url'=>$group2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$group2index	= $this->view->modulePath.'group/index'.$this->view->sid;
				$group2edit		= $this->view->modulePath.'group/edit/group_id/'.$result['group_id'].$this->view->sid;
				$group2delete	= $this->view->modulePath.'group/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$group2index	,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$group2edit		,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$group2delete ,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'group/delete/group_id/'.$result["group_id"].$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$group2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
    }



    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->kindArray		= $this->_menu->getGroupKindList( null, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$group_id = $this->getRequest()->getParam('group_id');
						if( $group_id != NULL ){
									
									// 1レコードの取得
									$result = $this->_group->getGroupId( $group_id );
									
									if( $result['group_id'] != 0 ){
											
											$this->view->group_id		= $result['group_id'];
												$this->_userspace->search['group']['name'] = 
											$this->view->group_name	= $result['group_name'];
											$this->view->selKind 		= $result['group_kind'];
											$this->view->selDelete	= $result['delete_flg'];	
											$this->view->selStyear	= substr($result['start_year'],0,4);	
												if( $this->view->selStyear == '0000' )	$this->view->selStyear = '0';
											$this->view->selEdyear			= substr($result["end_year"],0,4);	
												if( $this->view->selEdyear == '0000' )	$this->view->selEdyear = '0';
									}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$group_id 	= $this->getRequest()->getParam('group_id');
						$group_name	= $this->getRequest()->getParam('group_name');
						$kind				= $this->getRequest()->getParam('kind');
						$delete			= $this->getRequest()->getParam('delete');
						$styear 		= $this->getRequest()->getParam('styear');
						$edyear 		= $this->getRequest()->getParam('edyear');
						
						$group_name	= trim($group_name);								//半角スペースのみ
						
						
						$msgs = validateStringFull( 3, 30, 'グループ名称', $group_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     		// ●名前変更ならば重複チェック
						elseif ( $this->_userspace->search['group']['name'] != $group_name ){
							if ( $this->_group->isRegisteredGroup($group_name) == true )	{
										array_push($errors, array('このグループ名称は、既に登録されています。') );
							}
						}
						
						$msgs = validateSelect( '適応開始入学年度', $styear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '適応終了入学年度', $edyear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								if( $edyear != 0 ){
									if( $edyear <= $styear ){
											
											array_push($errors, array('適応終了入学年度が、適応開始入学年度より過去に設定されています。') );
											
									}
								}
						}
						
						$msgs = validateSelect( '種別', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	      		
						
						if (count($errors) == 0){
								
								$data = array(
													'group_id'		=>	$group_id,
													'group_name'	=>	$group_name,
													'group_kind'	=>	$kind,
													'start_year'	=>	$styear,
													'end_year'		=>	$edyear,
													'delete_flg' 	=>	$delete,
													'create_date'	=> NULL
												);
								
								if( $data['start_year'] == '0' )		$data['start_year'] = '0000';
								if( $data['end_year']   == '0' )		$data['end_year'] 	= '0000';
								
								$data['start_year'] = $data['start_year'].'-04-01';
								$data['end_year'] 	= $data['end_year'].'-04-01';
								
								$groupId		= $data['group_id'];	
								$groupKind	= $data['kind'] ;	
								$deleteType	= $data['delete_flg'] ;	
								if( $group_id != NULL ){
										
			    					$this->_group->updateGroup( $data, $groupId, $groupId, $groupKind, $deleteType );
										
						        // ビュースクリプトが表示されます
								    $targetUrl = '/group/index/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->group_id		= $group_id;
								$this->view->group_name	= $group_name;
								$this->view->selKind		= $kind;	
								$this->view->selDelete	= $delete;	
								$this->view->selStyear	= $styear;	
								$this->view->selEdyear	= $edyear;	
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$group2index		= $this->view->modulePath.'group/index'		.$this->view->sid;
				$group2item			= $this->view->modulePath.'group/item/group_id/'.$this->view->group_id.$this->view->sid;
				$group2edit			= $this->view->modulePath.'group/edit/group_id/'.$this->view->group_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'組織管理'			,'url'=>$section2index ),
									array('name'=>'グループ管理'	,'url'=>$group2index ),
									array('name'=>$this->view->group_name		,'url'=>$group2item ),
									array('name'=>'編集'					,'url'=>$group2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$group2index	= $this->view->modulePath.'group/index'.$this->view->sid;
				$group2item		= $this->view->modulePath.'group/item/group_id/'.$this->view->group_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$group2index	,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$group2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
    }




    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				
				if ($this->getRequest()->isPost())
				{
						
						$group_id 	= $this->getRequest()->getParam('group_id');
						$group_name	= $this->getRequest()->getParam('group_name');
						$kind 			= $this->getRequest()->getParam('kind');
						$delete			= $this->getRequest()->getParam('delete');
						$styear 		= $this->getRequest()->getParam('styear');
						$edyear 		= $this->getRequest()->getParam('edyear');
						
						$group_name= trim($group_name);								//半角スペースのみ
						
						
						
						$msgs = validateStringFull( 3, 30, 'グループ名称', $group_name);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
	 		     	// 重複チェック
			  		else if ( $this->_group->isRegisteredGroup($group_name) == true )	{
								array_push($errors, array('このグループ名称は、既に登録されています。') );
			      }
						
						$msgs = validateSelect( '適応開始入学年度', $styear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						$msgs = validateSelect( '適応終了入学年度', $edyear);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						else{
								if( $edyear != 0 ){
									if( $edyear <= $styear ){
											
											array_push($errors, array('適応終了入学年度が、適応開始入学年度より過去に設定されています。') );
											
									}
								}
						}
						
						$msgs = validateSelect( '種別', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						
						if (count($errors) == 0){
								$data = array(
													'group_name'	=>	$group_name,
													'group_kind'	=>	$kind,
													'start_year'	=>	$styear.'-04-01',
													'end_year'		=>	$edyear.'-04-01',
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								if( $data['start_year'] == '0-04-01' )		$data['start_year'] = '0000-00-00';
								if( $data['end_year']   == '0-04-01' )		$data['end_year'] 	= '0000-00-00';
								
								
								// グループＩＤを取得する
								$groupId 		= 0;
								$groupKind	= $kind;
								$deleteType = '0';
								
		    				if( $this->_group->registGroup( $data, $groupId, $groupId, $groupKind, $deleteType ) == 0 ){
										echo '中止 ';
										}

							$targetUrl = '/group/index/sid/'.$this->_sid;
							return $this->_redirect($targetUrl);
						}else{
							
							$this->view->group_id		= $group_id;		
							$this->view->group_name	= $group_name;	
							
							$this->view->selKind		= $kind;
							$this->view->selStyear	= $styear;		
							$this->view->selEdyear	= $edyear;		
						}
				}
				else{
						
						
						$this->view->group_id		= '';	
						$this->view->group_name	= '';	
						$this->view->selKind			= 0;	
						$this->view->selDelete		= 0;	
						$this->view->selStyear		= 0;	
						$this->view->selEdyear		= '9999';	//substr($result["end_year"],0,4);	
				}
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->kindArray		= $this->_menu->getGroupKindList( null, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->edyearArray	= $this->_menu->getYearList( $menu_mode, null, $menu_ext );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$section2index	= $this->view->modulePath.'section/index'	.$this->view->sid;
				$group2index		= $this->view->modulePath.'group/index'		.$this->view->sid;
				$group2new			= $this->view->modulePath.'group/new'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'組織管理'			,'url'=>$section2index ),
									array('name'=>'グループ管理'	,'url'=>$group2index ),
									array('name'=>'新規作成'			,'url'=>$group2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$group2index	= $this->view->modulePath.'group/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$group2index	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				
				if( $this->getRequest()->isPost() )
						{
						
						$class_id = $this->getRequest()->getParam('group_id');
						if( $group_id != NULL ){
									
									// 1レコードの削除
									$result = $this->_group->deleteGroup( $group_id );
						}
				}
				else{
				}
        // ビュースクリプトが表示されます
				$targetUrl = '/group/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);
    }


















    /**-------------------------------------------------------------------------------------------
     * item0アクション
     */
    public function item0Action()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * item0Editアクション
     */
    public function item0EditAction()
    {
				
				
        // ビュースクリプトが表示されます
    }


    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
