<?php
/**
 * Careerコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Controller/Action.php';

// モデルをロードする
require_once '../application/vers/default/models/commModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';




class CareerController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_comm;						// コミッティーモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

				
        // ユーザモデルのインスタンスを生成する
        $this->_comm	= new commModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}



				// 指定された権限の委員会に属するユーザが登録されているかチェックする
				$permissionArray	= array( COMM_CAREER );
        // ページアクセス関連の設定をレジストリから取得する
				{
					if( isset($this->_config->allowComm->career) ) {
		        Zend_Registry::set('permission', $this->_config->allowComm->career->toArray());
		        if (Zend_Registry::isRegistered('permission')) {
								//$permissionArray = Zend_Registry::get('permissionArray');
								$permissionArray = $this->_config->allowComm->career->toArray();
							}
        	}
        }
				$userId	= $this->_userspace->userId;
				if( $this->_comm->isAllowCommUsers( $userId, $permissionArray ) == false )	
				{	
						
						if( true )
						{
								$this->_forward( 'error', 'Error', null, 
																	getFatalError( FATAL_COMM_ACCESS,$this->view )				//'許可された委員会メンバーではありません。
																);	
						}
						
				}




        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				if( $this->getRequest()->isGet() )
				{
						

					  // 前アクションでエラーならメッセージを表示する
					  $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
						$msg		= getDispMessage( $noMsg,$this->view ) ;
						if( !is_null($msg) ){
								array_push( $errors,array($msg) );
						}
						$this->view->assign('errors',$errors);			// 追加後に再設定必要

				}
				
				
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
    }


    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
