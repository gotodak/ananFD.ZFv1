<?php
/**
 * Roleコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する

// モデルをロードする
require_once '../application/vers/default/models/commModel.php';
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/menuModel.php';


// モジュールをロードする
require_once '../application/lib/functions.php';



class RoleController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_comm;						// コミッティーモデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
		
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{

        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');

        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');

				
        // ユーザモデルのインスタンスを生成する
        $this->_comm	= new commModel('../application/lib/user.db');
        $this->_user 	= new userModel('../application/lib/user.db');
        $this->_menu	= new menuModel('../application/lib/user.db');

				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				



				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;		//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}


        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);



		}


    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['role']['sKind']		= $this->getRequest()->getParam('s_kind');		
						$this->_userspace->search['role']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
				} else {
						if( !isset($this->_userspace->search['role']['sKind']) )
							$this->_userspace->search['role']['sKind']		= '0';	
						if( !isset($this->_userspace->search['role']['sKeyword']) )
							$this->_userspace->search['role']['sKeyword']	= '';
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sKind		= $this->_userspace->search['role']['sKind'];		
				$sKeyword	= $this->_userspace->search['role']['sKeyword'];
				if( $sKind 	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sKind  == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_kind'  =>  $sKind,
																	's_keyword'	=>  $sKeyword
																);
						
						$select = $this->_comm->getCommPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_comm->getCommPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$menu_ext 	='-';					//select
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( $menu_mode, null );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '-', null );
				
				
				$this->view->selKind		= $sKind;
				$this->view->selKeyword	= $sKeyword;




				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$access2index		= $this->view->modulePath.'access/index'	.$this->view->sid;
				$role2index			= $this->view->modulePath.'role/index'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'アクセス管理','url'=>$access2index ),
									array('name'=>'メンバ設定'	,'url'=>$role2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$role2new				= $this->view->modulePath.'role/new'.$this->view->sid;
				$position2expert= $this->view->modulePath.'position/expert'.$this->view->sid;
				$position2index	= $this->view->modulePath.'position/index'.$this->view->sid;
				$position2comm	= $this->view->modulePath.'position/comm'	.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'専門委員会一覧'	,'url'=>$position2expert	,'onclick'=>'' ),
									array('name'=>'役職一覧'				,'url'=>$position2index		,'onclick'=>'' ),
									array('name'=>'委員会一覧'			,'url'=>$position2comm	,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
				
    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				if( $this->getRequest()->isGet() )
						{
						
						$comm_id = $this->getRequest()->getParam('comm_id');
						if( $comm_id != NULL ){
									

									
									// 委員会メンバーリストの取得
									// 1レコードの取得
									$user = $this->_comm->chargedUserId( $comm_id );
									$user2Array = array();
									foreach( $user as $row ){
										$name = $this->_comm->getUserName($row['user_id']);
										array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
									}
									$this->view->user		= $user2Array;
									

									// 1レコードの取得
									$result = $this->_comm->getCommId( $comm_id );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result['comm_id'] != 0 ){
											
											$menu_mode ='すべて';		//search
											$menu_mode ='';					//select
											$menu_ext 	='-';					//select
											$menu_findArray = array( 	's_kind'		=>  '1'
																							);
											$menu_find['s_kind']='1';
											$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, null );
											$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled');
											$this->view->options = null;




									}
						}

					  // 前アクションでエラーならメッセージを表示する
					  $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
						$msg		= getDispMessage( $noMsg,$this->view ) ;
						if( !is_null($msg) ){
								array_push( $errors,array($msg) );
						}
						$this->view->assign('errors',$errors);			// 追加後に再設定必要

				}
				else{
				}
				

				$commName				= $this->_comm->getCommName($comm_id);

				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$access2index		= $this->view->modulePath.'access/index'	.$this->view->sid;
				$role2index			= $this->view->modulePath.'role/index'		.$this->view->sid;
				$role2item			= $this->view->modulePath.'role/item/comm_id/'.$comm_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'						,'url'=>$top2index ),
									array('name'=>'マスタ設定'		,'url'=>$master2index ),
									array('name'=>'アクセス管理'	,'url'=>$access2index ),
									array('name'=>'メンバ設定'		,'url'=>$role2index ),
									array('name'=>$commName				,'url'=>$role2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$role2index		= $this->view->modulePath.'role/index'.$this->view->sid;
				$role2edit		= $this->view->modulePath.'role/edit/comm_id/'.$comm_id.$this->view->sid;
				$role2delete	= $this->view->modulePath.'role/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$role2index		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$role2edit		,'onclick'=>'' )
									);
					break;
				case 'user':
				case 'staff':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$role2index		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$role2edit		,'onclick'=>'' )
									);
					break;
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$role2index		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$userId	= $this->_userspace->userId;
				$commId	= $this->getRequest()->getParam('comm_id',null);
				if( $this->_comm->isAllowCommuser( $userId,$commId ) == false ){	
						
						
			      $targetUrl = '/role/item'. $this->view->sid .'/comm_id/'.$commId .'/'.DISP_MESSAGE.'/'.ERR_EDIT_NORIGHT;	//'編集権がありません。
			      return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}


				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, null );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
						{
						
						$comm_id = $this->getRequest()->getParam('comm_id');
						if( $comm_id != NULL ){
									
									
									// 委員会メンバーリストの取得
									// 1レコードの取得
									$user = $this->_comm->chargedUserId( $comm_id );
									$user2Array = array();
									foreach( $user as $row ){
										$name = $this->_comm->getUserName($row['user_id']);
										array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
									}
									$this->view->user		= $user2Array;
									
									$result = $this->_comm->getCommId( $comm_id );
									
									if( $result['comm_id'] != 0 ){
											
											$this->view->comm_id		= $result['comm_id'];
												$this->_userspace->search['role']['name'] = 
											$this->view->comm_name	= $result['comm_name'];
											$this->view->selKind 		= $result['comm_kind'];
											$this->view->selDelete	= $result['delete_flg'];	
									}

					        // 前アクションでエラーならメッセージを表示する
					        $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
									$msg		= getDispMessage( $noMsg,$this->view ) ;
									if( !is_null($msg) ){
											array_push( $errors,array($msg) );
									}
									$this->view->assign('errors',$errors);			// 追加後に再設定必要

						}
				}
				else if( $this->getRequest()->isPost() ){
						
						
						$comm_id 		= $this->getRequest()->getParam('comm_id');
						$comm_name	= $this->getRequest()->getParam('comm_name');
						$kind				= $this->getRequest()->getParam('kind');
						$delete			= $this->getRequest()->getParam('delete');
						
						$comm_name	= trim($comm_name);								//半角スペースのみ
						
						
	 		     	// 重複チェック
						if( $this->_userspace->search['role']['name'] != $comm_name ){
			  				if ( $this->_comm->isRegisteredComm($comm_name) == true )	{
									array_push($errors, array('この委員会名称は、既に登録されています。') );
			      		}
						}
						
						if (count($errors) == 0){
								
								$data = array(
													'comm_id'			=>	$comm_id,
													'comm_name'		=>	$comm_name,
													'comm_kind'		=>	$kind,
													'delete_flg' 	=>	$delete,
													'create_date'	=> NULL
												);
								
								$commId			= $data['comm_id'];	
								$commKind		= $data['kind'] ;	
								$deleteType	= $data['delete_flg'] ;	
								if( $comm_id != NULL ){
										
										
						        // ビュースクリプトが表示されます
								    $targetUrl = '/role/index/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						} else {
								
								$this->view->comm_id		= $comm_id;
								$this->view->comm_name	= $comm_name;
								$this->view->selKind		= $kind;	
								$this->view->selDelete	= $delete;	
								
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
								
								// 委員会メンバーリストの取得
								// 1レコードの取得
								$user = $this->_comm->chargedUserId( $comm_id );
								$user2Array = array();
								foreach( $user as $row ){
									$name = $this->_comm->getUserName($row['user_id']);
									array_push( $user2Array, array("user_id"=>$row['user_id'],"name"=>$name ) );
								}
								$this->view->user		= $user2Array;
								
						}
						
						
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$access2index		= $this->view->modulePath.'access/index'	.$this->view->sid;
				$role2index			= $this->view->modulePath.'role/index'		.$this->view->sid;
				$role2item			= $this->view->modulePath.'role/item/comm_id/'.$this->view->comm_id.$this->view->sid;
				$role2edit			= $this->view->modulePath.'role/edit/comm_id/'.$this->view->comm_id.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'										,'url'=>$top2index ),
									array('name'=>'マスタ設定'						,'url'=>$master2index ),
									array('name'=>'アクセス管理'					,'url'=>$access2index ),
									array('name'=>'メンバ設定'						,'url'=>$role2index ),
									array('name'=>$this->view->comm_name	,'url'=>$role2item ),
									array('name'=>'編集'									,'url'=>$role2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$role2index		= $this->view->modulePath.'role/index'.$this->view->sid;
				$role2item		= $this->view->modulePath.'role/item/comm_id/'.$this->view->comm_id.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$role2index		,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$role2item		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


				
    }





    /**-------------------------------------------------------------------------------------------
     * newアクション（未使用）
     */
    public function newAction()
    {
				$errors = array();
				
				if ($this->getRequest()->isPost())
				{
						
						$comm_id 		= $this->getRequest()->getParam('comm_id');
						$comm_name	= $this->getRequest()->getParam('comm_name');
						$kind 			= $this->getRequest()->getParam('kind');
						$delete			= $this->getRequest()->getParam('delete');
						
						$comm_name	= trim($comm_name);								//半角スペースのみ
						
						
						
	 		     	// 重複チェック
						if ( $this->_comm->isRegisteredComm($comm_name) == true )	{
								array_push($errors, array('この委員会名称は、既に登録されています。') );
			      }
						
						
						$msgs = validateSelect( '種別', $kind);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}
						
						
						
						
						if (count($errors) == 0){
								$data = array(
													'comm_name'		=>	$comm_name,
													'comm_kind'		=>	$kind,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$commId 		= 0;
								$commKind		= $kind;
								$deleteType = '0';
								
		    				if( $this->_comm->registComm( $data, $commId, $deleteType ) == 0 ){
										echo '中止 ';
										}

							$targetUrl = '/comm/index/sid/'.$this->_sid;
							return $this->_redirect($targetUrl);
						}else{
							
							$this->view->comm_id		= $comm_id;		
							$this->view->comm_name	= $comm_name;	
							
							$this->view->selKind		= $kind;
						}
				}
				else{
						
						
						$this->view->comm_id			= '';	
						$this->view->comm_name		= '';	
						$this->view->selKind			= 0;	
						$this->view->selDelete		= 0;	
				}
				
				$menu_mode ='すべて';		//search
				$menu_mode ='';					//select
				$menu_ext 	='-';					//select
				$menu_findArray = array( 	's_kind'		=>  '1'
																);
				$menu_find['s_kind']='1';
				$this->view->kindArray		= $this->_menu->getCommitteeKindList( null, null );
				$this->view->deleteArray	= $this->_menu->getDeleteList( '使用', null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				
				


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$access2index		= $this->view->modulePath.'access/index'	.$this->view->sid;
				$role2index			= $this->view->modulePath.'role/index'		.$this->view->sid;
				$role2new				= $this->view->modulePath.'role/new'			.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'マスタ設定'	,'url'=>$master2index ),
									array('name'=>'アクセス管理','url'=>$access2index ),
									array('name'=>'メンバ設定'	,'url'=>$role2index ),
									array('name'=>'新規作成'		,'url'=>$role2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$role2index			= $this->view->modulePath.'role/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'		,'url'=>$role2index		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				
				
				if( $this->getRequest()->isPost() )
						{
						
						$userId2= $this->_userspace->userId;
						$userId	= $this->getRequest()->getParam('user_id',null);
						$commId	= $this->getRequest()->getParam('comm_id',null);
						if( $this->_comm->isAllowCommuser( $userId,$commId ) == false ){	
					 				$this->_forward( 'error', 'Error', null, array('accessError' => '削除権がありません。('. $this->view->userName .')' ) );	
						} else {
									
									// 1レコードの削除
									$result = $this->_comm->deleteComm( $comm_id );
						}
				}
				else{
				}
        // ビュースクリプトが表示されます
				$targetUrl = '/role/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);
    }





    /**-------------------------------------------------------------------------------------------
     * userアクション
     */
    public function userAction()
    {
				$errors = array();
				
				$commId		= $this->getRequest()->getParam('comm_id');
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['role2']['sGroup']	= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['role2']['sJob']		= $this->getRequest()->getParam('s_job');
						$this->_userspace->search['role2']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['role2']['sKeyword']= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['role2']['sField']	= $this->getRequest()->getParam('s_field');
						$this->_userspace->search['role2']['sKind']		= $this->getRequest()->getParam('s_kind');
						
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['role2']['sGroup']) )
							$this->_userspace->search['role2']['sGroup']	= '0';
						if( !isset($this->_userspace->search['role2']['sJob']) )
							$this->_userspace->search['role2']['sJob']		= '0';
						if( !isset($this->_userspace->search['role2']['sKana']) )
							$this->_userspace->search['role2']['sKana']		= '0';
						if( !isset($this->_userspace->search['role2']['sKeyword']) )
							$this->_userspace->search['role2']['sKeyword']= '';
						if( !isset($this->_userspace->search['role2']['sField']) )
							$this->_userspace->search['role2']['sField']	= '0';
						if( !isset($this->_userspace->search['role2']['sKind']) )
							$this->_userspace->search['role2']['sKind']		= '0';
						
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
						}
						else if( $error ==2 ){
							
						}
				}
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['role2']['sGroup'];
				$sJob			=	$this->_userspace->search['role2']['sJob'];
				$sKana		=	$this->_userspace->search['role2']['sKana'];
				$sKeyword	=	$this->_userspace->search['role2']['sKeyword'];
				$sField		=	$this->_userspace->search['role2']['sField'];
				$sKind		=	$this->_userspace->search['role2']['sKind'];
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sKind	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  $sKind,
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
					
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='';					//select
				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				$this->view->roleArray		= $this->_menu->getRoleList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selKind		= $sKind;
				
				$this->view->comm_id		= $commId;

				$this->view->comm_name	= $this->_comm->getCommName($commId);

				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。


				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$master2index		= $this->view->modulePath.'master/index'	.$this->view->sid;
				$access2index		= $this->view->modulePath.'access/index'	.$this->view->sid;
				$role2index			= $this->view->modulePath.'role/index'		.$this->view->sid;
				$role2item			= $this->view->modulePath.'role/item/comm_id/'	.$commId.$this->view->sid;
				$role2edit			= $this->view->modulePath.'role/edit/comm_id/'	.$commId.$this->view->sid;
				$role2user				= $this->view->modulePath.'role/user/comm_id/'.$commId.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'										,'url'=>$top2index ),
									array('name'=>'マスタ設定'						,'url'=>$master2index ),
									array('name'=>'アクセス管理'					,'url'=>$access2index ),
									array('name'=>'メンバ設定'						,'url'=>$role2index ),
									array('name'=>$this->view->comm_name	,'url'=>$role2item ),
									array('name'=>'編集'									,'url'=>$role2edit ),
									array('name'=>'担当教員追加'					,'url'=>$role2user )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$role2index	= $this->view->modulePath.'role/index'		.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
				
				
    }


    /**-------------------------------------------------------------------------------------------
     * adduserアクション
     */
    public function adduserAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						
						$userId2		= $this->_userspace->userId;
						$userArray	= $this->getRequest()->getParam('user_id');
						$commId			= $this->getRequest()->getParam('comm_id');
						
						if( $this->_comm->isAllowCommuser( $userId2,$commId ) == false ){	
					      $targetUrl = '/role/edit/comm_id/'. $commId. $this->view->sid.'/'.DISP_MESSAGE.'/'.ERR_REGIST_NORIGHT;		//'登録権がありません。
					      return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						elseif( $this->_comm->isDuplicateCommuser( $commId, $userArray ) == true ){
					      $targetUrl = '/role/edit/comm_id/'. $commId. $this->view->sid.'/'.DISP_MESSAGE.'/'.ERR_DUPCOMM_USER;		//'既に同種役職に二重登録されています。
					      return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
						else {
								
		    				$role = $this->_comm->updateCommAdduser( $commId, $userArray, $this->_userspace );
								
						}
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/role/edit/comm_id/'. $commId. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }



    /**-------------------------------------------------------------------------------------------
     * deluserアクション
     */
    public function deluserAction()
    {

				if( $this->getRequest()->isGet() ) 
				{
						
						$userId2	= $this->_userspace->userId;
						$userId		= $this->getRequest()->getParam('user_id');
						$commId		= $this->getRequest()->getParam('comm_id');
						
						if ( $this->_comm->isAllowCommuser( $userId2,$commId ) == false ){	
					        $targetUrl = '/role/edit/comm_id/'. $commId. $this->view->sid.'/'.DISP_MESSAGE.'/'.ERR_DELETE_NORIGHT;		//'削除権がありません。
					        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						} else {
							if( $this->_comm->getCountCommuser( $commId,$userId2 ) <= 1 ){
									
					        $targetUrl = '/role/edit/comm_id/'. $commId. $this->view->sid.'/'.DISP_MESSAGE.'/'.ERR_DELETE_DISABLE;		//'削除はできません。
					        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
							}else
							{
	   							$role = $this->_comm->updateCommDeluser( $commId, $userId, $this->_userspace );
									if( $role != null ){
											$this->view->userLevel = $role;
									}
									
							}
						}
				}
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/role/edit/comm_id/'. $commId. $this->view->sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
    }

















    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
