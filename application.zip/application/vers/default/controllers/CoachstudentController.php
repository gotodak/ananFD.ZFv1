<?php
/**
 * Coachstudentコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する
Zend_Loader::loadClass('Zend_Pdf'); // 追加する

// モデルをロードする
require_once '../application/vers/default/models/coachstModel.php';
require_once '../application/vers/default/models/memberModel.php';
require_once '../application/vers/default/models/userModel.php';
require_once '../application/vers/default/models/menuModel.php';

// モジュールをロードする
require_once '../application/lib/functions.php';




class CoachstudentController extends Zend_Controller_Action
{
    private $_config;    			// システム設定情報
    private $_sessionId;    	// セッションID
    private $_sid;						// セッションID
    private $_namespace;
    private $_userspace;
    private $_coachst;				// 学生指導モデルのインスタンス
    private $_user;						// ユーザモデルのインスタンス
    private $_member;					// メンバーモデルのインスタンス
    private $_menu;						// メニューモデルのインスタンス
		
    /**-------------------------------------------------------------------------------------------
     * 初期処理
     */
		public function init()
		{
				
        // メイン設定情報をロードする
        $this->_config = Zend_Registry::get('config');
				
        // セッションIDを取得する
        $this->_sessionId = Zend_Registry::get('sessionId');
				
        // ユーザモデルのインスタンスを生成する
        $this->_coachst	= new coachstModel('../application/lib/member.db');
        $this->_user 		= new userModel('../application/lib/user.db');
        $this->_member 	= new memberModel('../application/lib/member.db');
        $this->_menu 	 	= new menuModel('../application/lib/user.db');
				
        // ユーザーレベルを取得する
        $this->_namespace = new Zend_Session_Namespace('global');
        $this->view->userLevel = $this->_namespace->userLevel;		//FD高度化推進室　システム管理者
        $this->view->userName  = $this->_namespace->userName;			//admin
				
				// ビュースクリプトの変数をセットする
				$this->view->basePath		= $this->_config->global->basePath;
				$this->view->modulePath = $this->_config->global->modulePath;
				$this->view->debugOn 		= $this->_config->global->debugOn;
				$this->view->userId			= '';
				
				$this->_sid = $this->_sessionId;
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
				      		$this->_userspace = new Zend_Session_Namespace( $this->_sid );
									$this->_userspace->setExpirationSeconds( $this->_config->global->sessionSec );						// 再延長
									
					        $this->view->userLevel = $this->_userspace->userLevel;	//$_SESSION[$this->_sid]['userLevel'];	//
					        $this->view->userName  = $this->_userspace->userName;		//$_SESSION[$this->_sid]['userName'];		//admin
									$this->view->sid 			 = '/sid/'.$this->_sid;	
									$this->view->ssid 		 = $this->_sid;	
									$this->view->loginUrl  = 'login/logout';	
									$this->view->loginName = 'ログアウト';	
							}else{
									// sid 破棄
					        $targetUrl = 'login/index';
					        return $this->_redirect($targetUrl);
							}
						}else{
							// sid 未設定
					    $targetUrl = 'login/index';
						}



				//指定されたユーザが教員、または指定された権限の委員会に属するメンバーを許可する
				$permissionArray	= array( COMM_EXECUTIVE,COMM_ASSISTANCE );
        // ページアクセス関連の設定をレジストリから取得する
				{
					if( isset($this->_config->allowComm->coachstudent) ) {
		        Zend_Registry::set('permission', $this->_config->allowComm->coachstudent->toArray());
		        if (Zend_Registry::isRegistered('permission')) {
								//$permissionArray = Zend_Registry::get('permissionArray');
								$permissionArray = $this->_config->allowComm->coachstudent->toArray();
							}
	        }
				}
				$userId	= $this->_userspace->userId;
				if( $this->_user->isTeacherCommUsers( $userId, $permissionArray ) == false ){	
						
						if( true )
						{
								$this->_forward( 'error', 'Error', null, 
																	getFatalError( FATAL_TEACHER_ACCESS,$this->view )				//'教員ではありません。
																);	
						}
						
				}




				
        $controller = strtolower($this->getRequest()->getControllerName());
				setMainmenuToPlacefolder('mainMenu',$this->view,$controller);
				
				
        $controller = strtolower($this->getRequest()->getControllerName());
        $action     = strtolower($this->getRequest()->getActionName());
				setContentmenuToPlacefolder('contentMenu',$this->view,$controller,$action);
				
		}





    /**-------------------------------------------------------------------------------------------
     * indexアクション
     */
    public function indexAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				if( $this->getRequest()->isPost() ) 
				{
						$defYear = getNowYear(true) .'-04-01 00:00';
						
						$this->_userspace->search['coachst']['sStdate']		= $this->getRequest()->getParam('s_stdate',$defYear);
						$this->_userspace->search['coachst']['sEddate']		= $this->getRequest()->getParam('s_eddate','');
						$this->_userspace->search['coachst']['sGroup']		= $this->getRequest()->getParam('s_group','0');
						$this->_userspace->search['coachst']['sGrade']		= $this->getRequest()->getParam('s_grade','0');
						$this->_userspace->search['coachst']['sClass']		= $this->getRequest()->getParam('s_class','0');
						$this->_userspace->search['coachst']['sCoach']		= $this->getRequest()->getParam('s_coach','0');
						$this->_userspace->search['coachst']['sKeyword']	= $this->getRequest()->getParam('s_keyword','' );
						$this->_userspace->search['coachst']['sField']		= $this->getRequest()->getParam('s_field','0');
				}
				else {
						if( !isset($this->_userspace->search['coachst']['sStdate']) )
							$this->_userspace->search['coachst']['sStdate']		= getNowYear(true) .'-04-01 00:00';
						if( !isset($this->_userspace->search['coachst']['sEddate']) )
							$this->_userspace->search['coachst']['sEddate']		= '';
						if( !isset($this->_userspace->search['coachst']['sGroup']) )
							$this->_userspace->search['coachst']['sGroup']		= '0';
						if( !isset($this->_userspace->search['coachst']['sGrade']) )
							$this->_userspace->search['coachst']['sGrade']		= '0';
						if( !isset($this->_userspace->search['coachst']['sClass']) )
							$this->_userspace->search['coachst']['sClass']		= '0';
						if( !isset($this->_userspace->search['coachst']['sCoach']) )
							$this->_userspace->search['coachst']['sCoach']		= '0';
						if( !isset($this->_userspace->search['coachst']['sKeyword']) )
							$this->_userspace->search['coachst']['sKeyword']	= '';
						if( !isset($this->_userspace->search['coachst']['sField']) )
							$this->_userspace->search['coachst']['sField']		= '0';
						
						if( !isset($this->_userspace->search['coachst']['studentLists']) )
							$this->_userspace->search['coachst']['studentLists']	= array();
						if( !isset($this->_userspace->search['coachst']['teacherLists']) )
							$this->_userspace->search['coachst']['teacherLists']	= array();

				}
				$studentLists	= $this->_userspace->search['coachst']['studentLists'];	
				$teacherLists	= $this->_userspace->search['coachst']['teacherLists'];	
				
				
				$bFind = true;	


				$this->view->student ='';
				$studentLists = null;
				if( isset($this->_userspace->search['coachst']['studentLists']) )
				{
					$studentLists	= $this->_userspace->search['coachst']['studentLists'];	
				}
				if( isset($studentLists) )
				{
					foreach( $studentLists as $idx )
					{
						$student = $this->_member->getMemberName($idx);
						if (end($studentLists) == $idx ) 
							$this->view->student	.= $student ;
						else
							$this->view->student	.= $student .'、';
					}
				}
				
				$this->view->teacher ='';
				$teacherLists = null;
				if( isset($this->_userspace->search['coachst']['teacherLists']) )
				{
					$teacherLists	= $this->_userspace->search['coachst']['teacherLists'];	
				}
				if( isset($teacherLists) )
				{
					foreach( $teacherLists as $idx )
					{
						$student = $this->_user->getUserName($idx);
						if (end($teacherLists) == $idx ) 
							$this->view->teacher	.= $student ;
						else
							$this->view->teacher	.= $student .'、';
					}
				}
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sStdate	= $this->_userspace->search['coachst']['sStdate'];	
				$sEddate	= $this->_userspace->search['coachst']['sEddate'];	
				$sGroup		= $this->_userspace->search['coachst']['sGroup'];		
				$sGrade		= $this->_userspace->search['coachst']['sGrade'];		
				$sClass		= $this->_userspace->search['coachst']['sClass'];		
				$sType		= $this->_userspace->search['coachst']['sCoach'];		
				$sKeyword	= $this->_userspace->search['coachst']['sKeyword'];	
				$sField		= $this->_userspace->search['coachst']['sField'];		
				if( 
							$sGroup 	=== null 
					||	$sGrade	=== null 
					||	$sClass	=== null 
					||	$sType	=== null 
					||	$sKeyword	=== null 
					||	$sStdate	=== null 
					||	$sEddate	=== null 
					)	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sClass  == "0" 
					&& $sType		== "0"  
					&& $sKeyword== ""  
					&& $sStdate	== ""  
					&& $sEddate	== ""  
					&& $studentLists== ""
					&& $teacherLists== ""
					)	{
							$bFind = false;
				}


/**/
						if ( isset($sStdate) && (trim($sStdate) != '')) 
						{
						  // check the date format
						  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d):(\d\d)$/', $sStdate, $m)) {
									
									$sStdate = $m[1] .'-'. $m[2] .'-'. $m[3] .' '. sprintf("%02d",$m[4]) .':'. $m[5];
						  }
							if (!preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $sStdate, $m)) {
									array_push($errors, array('開始日は、書式フォーマットが不正です（"yyyy-mm-dd HH:nn"）。') );
						  } else {
						    if (!mktime($m[4], $m[5], 0, $m[2], $m[3], $m[1])) {
									array_push($errors, array('開始日は、値が不正です。') );
						    }
						  }
						}
						if ( isset($sEddate) && (trim($sEddate) != '')) 
						{
						  // check the date format
						  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d):(\d\d)$/', $sEddate, $m)) {
									
									$sEddate = $m[1] .'-'. $m[2] .'-'. $m[3] .' '. sprintf("%02d",$m[4]) .':'. $m[5];
						  }
							if (!preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $sEddate, $m)) {
									array_push($errors, array('終了日は、書式フォーマットが不正です（"yyyy-mm-dd HH:nn"）。') );
						  } else {
						    if (!mktime($m[4], $m[5], 0, $m[2], $m[3], $m[1])) {
									array_push($errors, array('終了日は、値が不正です。') );
						    }
						  }
						}
/**/

/**/
				$bTerm = false;	
				$stDate = $edDate ="" ;
				if( $sStdate != "" ){
					if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $sStdate, $m)) {
							$stDate = mktime( 0, 0, 0, $m[2], $m[3], $m[1]);
					}
				}
				if( $sEddate	!= "" ){
					if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $sEddate, $m)) {
							$edDate = mktime( 23, 59, 59, $m[2], $m[3], $m[1]);
					}
				}
				if( $stDate != "" &&	$edDate	!= "" ){
					if( $edDate <= $stDate )
					{
						array_push($errors, array('終了日が、開始日より過去に設定されています。') );
					}
					else{
						$bTerm = true;	
					}
				}
/**/





				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_class'		=>  $sClass,
																	's_type'		=>  $sType,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_stdate'	=>  $sStdate,
																	's_eddate'	=>  $sEddate,
																	's_student'	=>  $studentLists,
																	's_teacher'	=>  $teacherLists
																);
						
						
						$select = $this->_coachst->getCoachstPage( $findArray );
						
				} else 
				{
						
						$select = $this->_coachst->getCoachstPage( null );
						
				}
				
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

        // ビュースクリプトが表示されます
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;
				
				
				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->coachArray		= $this->_menu->getCoachKindList( $menu_mode, null );
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField5List( null, null );
				$this->view->placeArray		= $this->_menu->getPlaceList( '', null );

				
				
				$this->view->selType		= $sType;
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->stdate			= $sStdate;
				$this->view->eddate			= $sEddate;
				
				//}
				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要




        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn ){
	var_dump($this->_sessionId);

}

				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
				$coachst2new	= $this->view->modulePath.'coachstudent/new'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'新規作成'  	,'url'=>$coachst2new		,'onclick'=>'' )
									);
					break;
				case 'admin':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);



    }




    /**-------------------------------------------------------------------------------------------
     * newアクション
     */
    public function newAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				$menu_mode ='';					//select
				$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
				$this->view->coachArray		= $this->_menu->getCoachKindList( $menu_mode, null );
				$this->view->placeArray		= $this->_menu->getPlaceList( $menu_mode, null );
				
				$this->view->attribs = null;
				$this->view->options = null;
				
				// データの初期読込
				if( $this->getRequest()->isGet() ){
						
						$mode = $this->getRequest()->getParam('mode','0');
						if( $mode == 0 ){
								$this->_userspace->search['coachst4']['studentLists']	= array();
								$this->_userspace->search['coachst4']['date']		= '';
								$this->_userspace->search['coachst4']['hours']	= '0';
								$this->_userspace->search['coachst4']['place']	= '0';
								$this->_userspace->search['coachst4']['placeS']	= '';
								$this->_userspace->search['coachst4']['comments']	= '';
								$this->_userspace->search['coachst4']['type']		= '0';
						} 
						{
							if( isset($this->_userspace->search['coachst4']['date']) )
								$this->view->date 		= $this->_userspace->search['coachst4']['date'];
							if( isset($this->_userspace->search['coachst4']['hours']) )
								$this->view->selHours		= $this->_userspace->search['coachst4']['hours'];
							if( isset($this->_userspace->search['coachst4']['place']) )
								$this->view->place			= $this->_userspace->search['coachst4']['place'];
							if( isset($this->_userspace->search['coachst4']['placeS']) )
								$this->view->placeS			= $this->_userspace->search['coachst4']['placeS'];
							if( isset($this->_userspace->search['coachst4']['comments']) )
								$this->view->comments 	= $this->_userspace->search['coachst4']['comments'];
							if( isset($this->_userspace->search['coachst4']['type']) )
								$this->view->selType		= $this->_userspace->search['coachst4']['type'];
						}
						
				}
				else if( $this->getRequest()->isPost() ){
						
							$this->_userspace->search['coachst4']['date']	= 
						$date 		= $this->getRequest()->getParam('date');
							$this->_userspace->search['coachst4']['hours']	= 
						$hours		= $this->getRequest()->getParam('hours');
							$this->_userspace->search['coachst4']['placeS']	= 
						$place		= $this->getRequest()->getParam('place');
							$this->_userspace->search['coachst4']['place']	= 
						$placeS		= $this->getRequest()->getParam('placeS','');
							$this->_userspace->search['coachst4']['comments']	= 
						$comments	= $this->getRequest()->getParam('comments');
							$this->_userspace->search['coachst4']['type']	= 
						$type			= $this->getRequest()->getParam('type');
						
						$user1		= $this->_userspace->userId;
						
						$studentLists	= $this->_userspace->search['coachst4']['studentLists'];	
						if( $studentLists==null || !isset($studentLists) ){
									array_push($errors, array('指導学生が、設定されていません。') );
						}
						
						$comments	= trim($comments);			//半角スペースのみ
						$placeS		= trim($placeS);				//半角スペースのみ
						$date			= trim($date);					//半角スペースのみ
						if (!isset($date) || (trim($date) == '') ){
								array_push($errors, array('面接日時が、設定されていません。') );
						}						
						else if (isset($date) && (trim($date) != '')) {
						  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d):(\d\d)$/', $date, $m)) {
									
									$date = $m[1] .'-'. $m[2] .'-'. $m[3] .' '. sprintf("%02d",$m[4]) .':'. $m[5];
						  }

							if (!preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $date, $m)) {
									array_push($errors, array('面接日時は、書式フォーマットが不正です（"yyyy-mm-dd HH:nn"）。') );
						  } else {
						    // make sure the date provided is a validate date
						    if (!mktime($m[4], $m[5], 0, $m[2], $m[3], $m[1])) {
									array_push($errors, array('面接日時は、値が不正です。') );
						    }
						  }
						}

						$msgs = validateSelect( '面接時間', $hours);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '指導場所', $place);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '指導分類', $type);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						if (count($errors) == 0){
						
								$data = array(
													'date'				=>	$date,
													'hours'				=>	$hours,
													'place'				=>	$place,
													'placeS'			=>	$placeS,
													'comments'		=>	$comments,
													'user1'				=>	$user1,
													'user2'				=> '0',
													'group'				=> '0',
													'type'				=>	$type,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								$deleteType = '0';
										{
										
			    					$coachst = $this->_coachst->registCoachstNew( $data, $studentLists, $deleteType );
										if( $coachst != 0 ){
							        // 登録成功　学生追加
							        $targetUrl = '/coachstudent/edit/coachst/' . $coachst . $this->view->sid;
							        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}else if ( $coachst == 0 ){
							        // 登録失敗
							        $targetUrl = '/coachstudent/new' . $this->view->sid;
							        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										}
								}
						} 
						else 
						{
								
								$this->view->date				= $date;
								$this->view->placeS			= $placeS;
								
								$this->view->selPlace		= $place;
								$this->view->selHours		= $hours;
								$this->view->comments 	= $comments;
								$this->view->selType		= $type;
								
						}
						
					}



/*******/
				$this->view->student ='';
				$studentLists	= $this->_userspace->search['coachst4']['studentLists'];	
				if( isset($studentLists) )
				{
					foreach( $studentLists as $idx )
					{
						$student = $this->_member->getMemberName($idx);
						if (end($studentLists) == $idx ) 
							$this->view->student	.= $student ;
						else
							$this->view->student	.= $student .'、';
					}
				}
/*******/


					
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
			





				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
				$coachst2new		= $this->view->modulePath.'coachstudent/new'		.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>'新規作成'	,'url'=>$coachst2new )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
				$coachst2index	= $this->view->modulePath.'coachstudent/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$coachst2index		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * itemアクション
     */
    public function itemAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
					  // 前アクションでエラーならメッセージを表示する
					  $noMsg	= $this->getRequest()->getParam(DISP_MESSAGE,0 );
						$msg		= getDispMessage( $noMsg,$this->view ) ;
						if( !is_null($msg) ){
								array_push( $errors,array($msg) );
						}
						$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				if( $this->getRequest()->isGet() )
						{
						
						$coachst = $this->getRequest()->getParam('coachst');
						if( $coachst != NULL ){
									
									// 1レコードの取得
									$result = $this->_coachst->getCoachstId( $coachst );
				          $this->view->result  = $result;					//１つの変数を設定する
									
									if( $result != null && $result['coachst_id'] == $coachst ){
											
											$menu_mode ='';					//select
											$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
											$this->view->coachArray		= $this->_menu->getCoachKindList( $menu_mode, null );
											$this->view->placeArray		= $this->_menu->getPlaceList( $menu_mode, null );

											$this->view->classList	= 
											$classList2		= $this->_menu->getClassList( null, null );
										    if (count($classList2) > 5) { 
										        $columns = array_chunk($classList2, 4, true); //four columns 
										    } else { 
										        $columns = array($classList2); 
										    } 
											$this->view->classLists		= $columns;

											if( $coachst != null ){
													$date = $this->_coachst->getCoachstDate($coachst);
												  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
															$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
												  }
											}

											$this->view->coachst		= $coachst;
											$this->view->placeS			= $result['placeS'];
											$this->view->comments		= $result['comments'];
											$this->view->selType		= $result['type'];
											$this->view->selPlace		= $result['place'];
											
											$this->view->userName1	= $this->_user->getUserName($result['user_1']);
											$this->view->userName2	= $this->_user->getUserName($result['user_2']);
											

											// 1レコードの取得
											$group = $this->_coachst->chargedGroupId( $coachst );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['class_id'] );	
												$this->view->year		= substr($row['year'],0,4);
											}
											$this->view->selClass		= $groupArray;
											$this->view->fiscalYear	= '('.$this->view->year.'年度)';
											
											$classArray = array();
											foreach( $groupArray as $idx ){
													array_push($classArray, $classList2[$idx] );
											}
											$this->view->classList	= $classArray;
											

											// 1レコードの取得
											$user = $this->_coachst->chargedMemberId( $coachst );
											$user2Array = array();
											foreach( $user as $row ){
												if( $row['member'] != 0 ){
													$name = $this->_member->getMemberName($row['member']);
													array_push( $user2Array, array("member_id"=>$row['member'],"name"=>$name ) );
												}
											}
											$this->view->member		= $user2Array;

											
											
											$this->view->attribs = array( 	'disabled'	=>  'disabled' );
											$this->view->options = null;
										}
						}
				}
				else{
				}
				
				
        // ビュースクリプトが表示されます
if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);
				



				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
				$coachst2item		= $this->view->modulePath.'coachstudent/item/coachst/'		.$coachst.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>$date				,'url'=>$coachst2item )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$coachst2index	= $this->view->modulePath.'coachstudent/index'.$this->view->sid;
				$coachst2edit		= $this->view->modulePath.'coachstudent/edit/coachst/'.$coachst.$this->view->sid;
				$coachst2delete	= $this->view->modulePath.'coachstudent/index'.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$coachst2index		,'onclick'=>'' ),
									array('name'=>'編集'		,'url'=>$coachst2edit			,'onclick'=>'' ),
									array('name'=>'削除'    ,'url'=>$coachst2delete 	,'onclick'=>'if (confirm("削除してよろしいですか？")){var f = document.createElement("form");f.style.display = "none";this.parentNode.appendChild(f);f.method = "POST";f.action = "'.$this->view->modulePath.'coachstudent/delete/coachst/'.$coachst.$this->view->sid.'";f.submit();};return false;' )
									);
					break;
				case 'admin':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$coachst2index		,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);
				
    }




    /**-------------------------------------------------------------------------------------------
     * editアクション
     */
    public function editAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				$menu_mode ='';					//select
				$this->view->hoursArray		= $this->_menu->getHoursList( null, null );
				$this->view->coachArray		= $this->_menu->getCoachKindList( $menu_mode, null );
				$this->view->placeArray		= $this->_menu->getPlaceList( $menu_mode, null );

				$this->view->classList	= 
				$classList2		= $this->_menu->getClassList( null, null );
				  if (count($classList2) > 5) { 
				      $columns = array_chunk($classList2, 4, true); //four columns 
				  } else { 
				      $columns = array($classList2); 
				  } 
				$this->view->classLists		= $columns;

				$this->view->selClass	= null;
				$this->view->member		= array();
				
				$this->view->attribs = array( 	'disabled'	=>  'disabled' );
				$this->view->options = null;
				$this->view->listsep	=' ';

				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
						$coachst= $this->getRequest()->getParam('coachst' );
						if( $coachst != NULL )
						{
									
									// 1レコードの取得
									$userId	= $this->_userspace->userId;
									$result = $this->_coachst->getCoachstId( $coachst, $userId );
				          $this->view->result  = $result;					//１つの変数を設定する
									if( $result['coachst_id'] < 0 ){
											
									    $targetUrl = '/coachstudent/item'. $this->view->sid .'/coachst/'.$coachst .'/'.DISP_MESSAGE.'/'.ERR_EDIT_NORIGHT;	//'編集権がありません。
									    return $this->_redirect($targetUrl);		//DebugMessage 表示不可
									}
									elseif( $result != null && $result['coachst_id'] != 0 ){
											
											// 1レコードの取得
											$group = $this->_coachst->chargedGroupId( $coachst );
											$groupArray = array();
											foreach( $group as $row ){
												array_push($groupArray, $row['class_id'] );					
												$this->view->year		= substr($row['year'],0,4);
											}
											$this->view->selClass		= $groupArray;
											$this->view->fiscalYear	= '('.$this->view->year.'年度)';
											
											$classArray = array();
											foreach( $groupArray as $idx ){
													array_push($classArray, $classList2[$idx] );
											}
											$this->view->classList	= $classArray;

											// 1レコードの取得
											$user = $this->_coachst->chargedMemberId( $coachst );
											$user2Array = array();
											foreach( $user as $row ){
												$name = $this->_member->getMemberName($row['member']);
												array_push( $user2Array, array("member_id"=>$row['member'],"name"=>$name ) );
											}
											$this->view->member		= $user2Array;

											
												$date = '';
												$str 	= $result['date'];
												if( substr_count( $str, ':')==2 )
												{
													$res	=  explode(":", $str);
													$date	= $res[0] .':' . $res[1];
												}else{
													$date = $str;
												}
											$this->view->date		= $date;

											$date2		= $result['date'];
										  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date2, $m)) {
													$date2 = $m[1] .'-'. $m[2] .'-'. $m[3] ;
													$this->view->date2		= $date2;
										  }

											$this->view->coachst		= $coachst;
											$this->view->selHours		= $result['hours'];	
											$this->view->selPlace		= $result['place'];	
											$this->view->placeS			= $result['placeS'];	
											$this->view->comments		= $result['comments'];
											$this->view->selType		= $result['type'];
											
											$this->view->userName1	= $this->_user->getUserName($result['user_1']);
											$this->view->userName2	= $this->_user->getUserName($result['user_2']);
											
											
										}
						}
				}
				else if( $this->getRequest()->isPost() ){
						
						$coachst	= $this->getRequest()->getParam('coachst' );
						$date			= $this->getRequest()->getParam('date');
						$hours 		= $this->getRequest()->getParam('hours');
						$place 		= $this->getRequest()->getParam('place');
						$placeS		= $this->getRequest()->getParam('placeS','');
						$comments	= $this->getRequest()->getParam('comments');
						$type			= $this->getRequest()->getParam('type');
						$user1		= $this->_userspace->userId;
						$user2		= $this->getRequest()->getParam('user2');

						// 1レコードの取得
						$group = $this->_coachst->chargedGroupId( $coachst );
						$groupArray = array();
						foreach( $group as $row ){
							array_push($groupArray, $row['class_id'] );					//DB 1:一般教科 20110906
						}
						$this->view->selClass		= $groupArray;
						
						$classArray = array();
						foreach( $groupArray as $idx ){
								array_push($classArray, $classList2[$idx] );
						}
						$this->view->classList	= $classArray;

						// 1レコードの取得
						$user = $this->_coachst->chargedMemberId( $coachst );
						$user2Array = array();
						foreach( $user as $row ){
							$name = $this->_member->getMemberName($row['member']);
							array_push( $user2Array, array("member_id"=>$row['member'],"name"=>$name ) );
						}
						$this->view->member		= $user2Array;

						
						$date			= trim($date);								//半角スペースのみ
						$placeS		= trim($placeS);							//半角スペースのみ
						$comments	= trim($comments);						//半角スペースのみ
						
						if (!isset($date) || (trim($date) == '') ){
								array_push($errors, array('面接日時は、設定されていません。') );
						}						
						else if (isset($date) && (trim($date) != '')) {
						  // check the date format
						  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d):(\d\d)$/', $date, $m)) {
									
									$date = $m[1] .'-'. $m[2] .'-'. $m[3] .' '. sprintf("%02d",$m[4]) .':'. $m[5];
						  }

							if (!preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $date, $m)) {
									array_push($errors, array('面接日時は、書式フォーマットが不正です（"yyyy-mm-dd HH:nn"）。') );
						  } else {
						    // make sure the date provided is a validate date
						    if (!mktime($m[4], $m[5], 0, $m[2], $m[3], $m[1])) {
									array_push($errors, array('面接日時は、値が不正です。') );
						    }
						  }
						}

						$msgs = validateSelect( '指導時間', $hours);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '指導場所', $place);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						$msgs = validateSelect( '指導分類', $type);
						if( count($msgs) != 0 ){
								array_push( $errors,$msgs );
						}

						if( count($user2Array)==0 && count($groupArray)==0 ){
									array_push($errors, array('指導学生、または指導クラスが、設定されていません。。') );
						}

						
						if (count($errors) == 0){
						
								$data = array(
													'coachst'			=>	$coachst,
													'date'				=>	$date,
													'hours'				=>	$hours,
													'place'				=>	$place,
													'placeS'			=>	$placeS,
													'comments'		=>	$comments,
													'user1'				=>	$user1,
													//'user2'				=>  $user2,
													'type'				=>	$type,
													'delete_flg'	=> '0',
													'create_date'	=> NULL
												);
								
								
								// グループＩＤを取得する
								$deleteType = '0';
								
								if( $coachst != NULL ){
										
			    					$this->_coachst->updateCoachst( $data, $deleteType );
										
						        // ビュースクリプトが表示されます
						        $targetUrl = '/coachstudent/item/coachst/'.$coachst. '/sid/'.$this->_sid;
						        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
										
								}
						
						} else {
								
								$this->view->coachst	= $coachst;
								
								$this->view->date				= $date;
								$this->view->placeS			= $placeS;
								$this->view->selPlace		= $place;
								$this->view->selHours		= $hours;
								$this->view->comments 	= $comments;
								$this->view->selType 		= $type;
								
								
				        // ビュースクリプトが表示されます
								$this->view->assign('errors',$errors);			// 追加後に再設定必要
								
						}
				}
				else{
				}
				
        // ビュースクリプトが表示されます
				
				
				


				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}



				$top2index			= $this->view->modulePath.'top/index'						.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
				$coachst2item		= $this->view->modulePath.'coachstudent/item/coachst/'		.$coachst.$this->view->sid;
				$coachst2edit		= $this->view->modulePath.'coachstudent/edit/coachst/'		.$coachst.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>$date				,'url'=>$coachst2item ),
									array('name'=>'編集'			,'url'=>$coachst2edit )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$coachst2index	= $this->view->modulePath.'coachstudent/index'.$this->view->sid;
				$coachst2item		= $this->view->modulePath.'coachstudent/item/coachst/'.$coachst.$this->view->sid;
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									array('name'=>'一覧'  	,'url'=>$coachst2index		,'onclick'=>'' ),
									array('name'=>'詳細'		,'url'=>$coachst2item			,'onclick'=>'' )
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);

				
    }



    /**-------------------------------------------------------------------------------------------
     * groupアクション
     */
    public function groupAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				// データの初期読込
				if( $this->getRequest()->isGet() )
				{
						$coachst= $this->getRequest()->getParam('coachst' );
						
						// 1レコードの取得
						$group = $this->_coachst->chargedGroupId( $coachst );
						$groupArray = array();
						foreach( $group as $row ){
							array_push($groupArray, $row['class_id'] );	
						}
						$this->view->selClass		= $groupArray;
						$classArray	= $groupArray;
						
				}
				else if( $this->getRequest()->isPost() ){
						
						$coachst= $this->getRequest()->getParam('coachst' );
						
						$classArray	= $this->getRequest()->getParam('class' );
						if( count($classArray) == 0 )
							$classArray	=  array();
						
						if (count($errors) == 0){
								
								//学生ＩＤ取得
								$findArray = array( 	's_group'		=>  '0',
																			's_grade'		=>  '0',
																			's_class'		=>  '0' 
																		);
								{
									
									$fiscalYear = getNowYear( true );
									
									$info = array( 
															'coachst'			=> $coachst,
															'year'				=> $fiscalYear.'-04-01',				//'2011-04-01'
															'class'				=> '0',
															'delete_flg'	=> '0',
															'create_date'	=> NULL
																);
									$deleteType = '0';
									$this->_coachst->updateCoachstAddclass( $info, $classArray, $deleteType );
									
					        // ビュースクリプトが表示されます
					        $targetUrl = '/coachstudent/edit/coachst/'. $coachst. '/sid/'.$this->_sid;
					        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
								}
								
						}
					
				}
				
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_year'		=>  '0'
																);




				$classList2		= $this->_menu->getClassList( null, null );
			    if (count($classList2) > 5) { 
			        $columns = array_chunk($classList2, 4, true); //four columns 
			    } else { 
			        $columns = array($classList2); 
			    } 
				$this->view->classLists		= $columns;

				$this->view->groupList		= $this->_menu->getGroupList( null, $menu_findArray );
				$this->view->gradeList		= $this->_menu->getGradeList( null, null );

				$fiscalYear	= getNowYear(true);
				$this->view->fiscalYear	= '('.$fiscalYear.'年度)';

				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';

				$this->view->selClass	= $classArray;

				$this->view->coachst	= $coachst;
				
				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要




				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}



				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
				$coachst2item		= $this->view->modulePath.'coachstudent/item/coachst/'		.$coachst.$this->view->sid;
				$coachst2edit		= $this->view->modulePath.'coachstudent/edit/coachst/'		.$coachst.$this->view->sid;
				$coachst2group	= $this->view->modulePath.'coachstudent/group/coachst/'		.$coachst.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>$date				,'url'=>$coachst2item ),
									array('name'=>'編集'			,'url'=>$coachst2edit ),
									array('name'=>'クラス編集','url'=>$coachst2group )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * memberアクション
     */
    public function memberAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ){
						
						$coachst= $this->getRequest()->getParam('coachst' );
						$this->_userspace->search['coachst2']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['coachst2']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['coachst2']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['coachst2']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['coachst2']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['coachst2']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['coachst2']['sField']		= $this->getRequest()->getParam('s_field');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['coachst2']['sGroup']) )
							$this->_userspace->search['coachst2']['sGroup']		= '0';
						if( !isset($this->_userspace->search['coachst2']['sGrade']) )
							$this->_userspace->search['coachst2']['sGrade']		= '0';
						if( !isset($this->_userspace->search['coachst2']['sStyear']) )
							$this->_userspace->search['coachst2']['sStyear']	= '0';
						if( !isset($this->_userspace->search['coachst2']['sKana']) )
							$this->_userspace->search['coachst2']['sKana']		= '0';
						if( !isset($this->_userspace->search['coachst2']['sClass']) )
							$this->_userspace->search['coachst2']['sClass']		= '0';
						if( !isset($this->_userspace->search['coachst2']['sKeyword']) )
							$this->_userspace->search['coachst2']['sKeyword']	= '';
						if( !isset($this->_userspace->search['coachst2']['sField']) )
							$this->_userspace->search['coachst2']['sField']		= '0';
						
						$coachst= $this->getRequest()->getParam('coachst' );
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加学生が、選択されていません。') );
						}
				}
				
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['coachst2']['sGroup'];	
				$sGrade		= $this->_userspace->search['coachst2']['sGrade'];	
				$sStyear	= $this->_userspace->search['coachst2']['sStyear'];	
				$sKana		= $this->_userspace->search['coachst2']['sKana'];		
				$sClass		=	$this->_userspace->search['coachst2']['sClass'];	
				$sKeyword	=	$this->_userspace->search['coachst2']['sKeyword'];
				$sField		=	$this->_userspace->search['coachst2']['sField'];	
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0" 
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);


				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_member->getMemberPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						
						$select = $this->_member->getMemberPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );

				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;


				
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';
				
				
				$this->view->coachst	= $coachst;
				

				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}

				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要





				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}



				$top2index			= $this->view->modulePath.'top/index'			.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
				$coachst2item		= $this->view->modulePath.'coachstudent/item/coachst/'	.$coachst.$this->view->sid;
				$coachst2edit		= $this->view->modulePath.'coachstudent/edit/coachst/'	.$coachst.$this->view->sid;
				$coachst2member	= $this->view->modulePath.'coachstudent/member/coachst/'.$coachst.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'					,'url'=>$top2index ),
									array('name'=>'学生指導'		,'url'=>$coachst2index ),
									array('name'=>$date					,'url'=>$coachst2item ),
									array('name'=>'編集'				,'url'=>$coachst2edit ),
									array('name'=>'学生追加'		,'url'=>$coachst2member ),
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
							break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * addmemberアクション
     */
    public function addmemberAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$coachst	 		= $this->getRequest()->getParam('coachst');
						$memberArray	= $this->getRequest()->getParam('member_id');
				}
				
				if( count($memberArray) == 0 ){
		        $targetUrl = '/coachstudent/member/coachst/'. $coachst .'/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($memberArray) >= 1 ){
						
						if( $coachst != null ){
							
								$fiscalYear = getNowYear( true );
								
								$info = array( 
														'coachst'			=> $coachst,
														'class'				=>'0',
														'year'				=> $fiscalYear.'-04-01',				//'2011-04-01'
														'delete_flg'	=> '0',
														'create_date'	=> NULL
															);
								$deleteType = '0';
				    		$this->_coachst->updateCoachstAddmember( $info, $memberArray, $deleteType );
								
						}
				}
				
				        // ビュースクリプトが表示されます
				        $targetUrl = '/coachstudent/edit/coachst/'. $coachst. '/sid/'.$this->_sid;
				        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }





    /**-------------------------------------------------------------------------------------------
     * delmemberアクション
     */
    public function delmemberAction()
    {
				if( $this->getRequest()->isGet() ) {
						
						$coachst	= $this->getRequest()->getParam('coachst');
						$member		= $this->getRequest()->getParam('member_id');
				}
				
				$fiscalYear = getNowYear( true );
				
				if( $member != null ){
						$info = array( 
												'coachst'			=> $coachst,
												'member'			=> $member,
												'group'				=> '0',
												'year'				=> $fiscalYear.'-04-01',
												'delete_flg'	=> '0',
												'create_date'	=> NULL
													);
						$deleteType = '1';
						
   					$this->_coachst->updateCoachstDelmember( $info, $deleteType);
				}
				
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/coachstudent/edit/coachst/'. $coachst . '/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
				
    }





    /**-------------------------------------------------------------------------------------------
     * deleteアクション
     */
    public function deleteAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$coachst	= $this->getRequest()->getParam('coachst');
						if( $coachst != null ){
								$deleteType = '1';
								
								$userId	= $this->_userspace->userId;
		   					$ret = $this->_coachst->deleteCoachst( $coachst, $userId );
								if( $ret < 0 ){
										
										$targetUrl = '/coachstudent/item'. $this->view->sid .'/coachst/'.$coachst .'/'.DISP_MESSAGE.'/'.ERR_DELETE_NORIGHT;	//'削除権がありません。
										return $this->_redirect($targetUrl);		//DebugMessage 表示不可
								}
						}
				}
				
				
				
        // ビュースクリプトが表示されます
        $targetUrl = '/coachstudent/index/sid/'.$this->_sid;
        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
				
    }





    /**-------------------------------------------------------------------------------------------
     * userアクション
     */
    public function userAction()
    {
				$errors = array();
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['coachst3']['sGroup']		= $this->getRequest()->getParam('s_group');		
						$this->_userspace->search['coachst3']['sJob']			= $this->getRequest()->getParam('s_job');			
						$this->_userspace->search['coachst3']['sKana']		= $this->getRequest()->getParam('s_kana');		
						$this->_userspace->search['coachst3']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
						$this->_userspace->search['coachst3']['sField']		= $this->getRequest()->getParam('s_field');		
						$this->_userspace->search['coachst3']['sKind']		= $this->getRequest()->getParam('s_kind');		
						
						$coachst	= $this->getRequest()->getParam('coachst');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['coachst3']['sGroup']) )
							$this->_userspace->search['coachst3']['sGroup']		= '0';
						if( !isset($this->_userspace->search['coachst3']['sJob']) )
							$this->_userspace->search['coachst3']['sJob']			= '0';
						if( !isset($this->_userspace->search['coachst3']['sKana']) )
							$this->_userspace->search['coachst3']['sKana']		= '0';
						if( !isset($this->_userspace->search['coachst3']['sKeyword']) )
							$this->_userspace->search['coachst3']['sKeyword']	= '';
						if( !isset($this->_userspace->search['coachst3']['sField']) )
							$this->_userspace->search['coachst3']['sField']		= '0';
						if( !isset($this->_userspace->search['coachst3']['sKind']) )
							$this->_userspace->search['coachst3']['sKind']		= '0';
						
						$coachst		= $this->getRequest()->getParam('coachst');
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加教員は、既に登録されています。') );
						}
						else if( $error ==2 ){
							
							array_push($errors, array('追加教員は、１名のみ選択してください。') );
						}
				}
				
				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['coachst3']['sGroup'];		
				$sJob			= $this->_userspace->search['coachst3']['sJob'];			
				$sKana		= $this->_userspace->search['coachst3']['sKana'];			
				$sKeyword	= $this->_userspace->search['coachst3']['sKeyword'];	
				$sField		= $this->_userspace->search['coachst3']['sField'];		
				$sKind		= $this->_userspace->search['coachst3']['sKind'];		
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sKind	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  $sKind,
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
					
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				$this->view->roleArray		= $this->_menu->getRoleList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selKind		= $sKind;
				
				$this->view->coachst		= $coachst;

				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}

				
				$this->view->assign('errors',$errors);			// 追加後に再設定必要 //複数の変数（連想配列）を一度に設定する。
				
				



				$top2index			= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index	= $this->view->modulePath.'coachstudent/index'	.$this->view->sid;
				$coachst2item		= $this->view->modulePath.'coachstudent/item/coachst/'	.$coachst.$this->view->sid;
				$coachst2edit		= $this->view->modulePath.'coachstudent/edit/coachst/'	.$coachst.$this->view->sid;
				$coachst2user		= $this->view->modulePath.'coachstudent/user/coachst/'	.$coachst.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>$date				,'url'=>$coachst2item ),
									array('name'=>'編集'			,'url'=>$coachst2edit ),
									array('name'=>'教員追加'	,'url'=>$coachst2user )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon				= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * adduserアクション
     */
    public function adduserAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$coachst 		= $this->getRequest()->getParam('coachst');
						$userArray	= $this->getRequest()->getParam('user_id');
				}
				
				if( count($userArray) >= 2 ){
		        $targetUrl = '/coachstudent/user/coachst/'. $coachst .'/error/2/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($userArray) == 1 ){
						
						$user1 = $this->_coachst->getCoachstUser1($coachst);
						if( $user1 == $userArray[0] ){
							
			        $targetUrl = '/coachstudent/user/coachst/'. $coachst .'/error/1/sid/'.$this->_sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
							
						} else if( $coachst != null ){
							
			    		$this->_coachst->updateCoachstAdduser( $coachst, $userArray );
							
			        // ビュースクリプトが表示されます
			        $targetUrl = '/coachstudent/edit/coachst/'. $coachst . '/sid/'.$this->_sid;
			        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
						}
				}
				
				
    }










    /**-------------------------------------------------------------------------------------------
     * student2アクション（学生選択検索）
     */
    public function student2Action()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ){
						
						$coachst= $this->getRequest()->getParam('coachst' );
						
						$this->_userspace->search['coachst4']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['coachst4']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['coachst4']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['coachst4']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['coachst4']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['coachst4']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['coachst4']['sField']		= $this->getRequest()->getParam('s_field');
				}
				else if( $this->getRequest()->isGet() ){
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['coachst4']['sGroup']) )
							$this->_userspace->search['coachst4']['sGroup']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sGrade']) )
							$this->_userspace->search['coachst4']['sGrade']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sClass']) )
							$this->_userspace->search['coachst4']['sClass']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sKana']) )
							$this->_userspace->search['coachst4']['sKana']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sStyear']) )
							$this->_userspace->search['coachst4']['sStyear']	= '0';
						if( !isset($this->_userspace->search['coachst4']['sKeyword']) )
							$this->_userspace->search['coachst4']['sKeyword']	= '';
						if( !isset($this->_userspace->search['coachst4']['sField']) )
							$this->_userspace->search['coachst4']['sField']		= '0';
						
						$coachst= $this->getRequest()->getParam('coachst' );
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加学生が、選択されていません。') );
						}
				}
				
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['coachst4']['sGroup'];	
				$sGrade		= $this->_userspace->search['coachst4']['sGrade'];	
				$sStyear	= $this->_userspace->search['coachst4']['sStyear'];
				$sKana		= $this->_userspace->search['coachst4']['sKana'];	
				$sClass		=	$this->_userspace->search['coachst4']['sClass'];	
				$sKeyword	=	$this->_userspace->search['coachst4']['sKeyword'];
				$sField		=	$this->_userspace->search['coachst4']['sField'];	
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0" 
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);


				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_member->getMemberPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						
						$select = $this->_member->getMemberPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );

				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;


				
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';
				
				
				$this->view->coachst	= $coachst;
				

				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}

				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要








				$top2index				= $this->view->modulePath.'top/index'							.$this->view->sid;
				$coachst2index		= $this->view->modulePath.'coachstudent/index'		.$this->view->sid;
				$coachst2new			= $this->view->modulePath.'coachstudent/new'			.$this->view->sid;
				$coachst2student2	= $this->view->modulePath.'coachstudent/student2'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>'新規作成'	,'url'=>$coachst2new ),
									array('name'=>'学生選択'	,'url'=>$coachst2student2 )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * addstudent2アクション
     */
    public function addstudent2Action()
    {
				if( $this->getRequest()->isPost() ) {
						
						$coachst	 		= $this->getRequest()->getParam('coachst');
						$memberArray	= $this->getRequest()->getParam('member_id');
				}
				
				if( count($memberArray) == 0 ){
		        $targetUrl = '/coachstudent/student2/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($memberArray) >= 1 ){
						
						$studentArray = $this->_userspace->search['coachst4']['studentLists'];
						if( $studentArray == null )
								$studentArray = array();	
						foreach( $memberArray as $idx )
						{
							if( array_search( $idx, $studentArray )===false )
								array_push( $studentArray, $idx );
						}
						$this->_userspace->search['coachst4']['studentLists'] = $studentArray;
						
				}
				
				
				
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/coachstudent/new/mode/1/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }








    /**-------------------------------------------------------------------------------------------
     * studentアクション（学生選択検索）
     */
    public function studentAction()
    {
				$errors = array();
				$this->view->assign('errors',$errors);			// 追加後に再設定必要
				
				
				
				$this->view->selGroup		= 0;
				$this->view->selGrade		= 0;
				$this->view->selStyear	= 0;
				$this->view->selKana		= 0;
				$this->view->selClass		= 0;
				
				if( $this->getRequest()->isPost() ){
						
						$coachst= $this->getRequest()->getParam('coachst' );
						$this->_userspace->search['coachst4']['sGroup']		= $this->getRequest()->getParam('s_group');
						$this->_userspace->search['coachst4']['sGrade']		= $this->getRequest()->getParam('s_grade');
						$this->_userspace->search['coachst4']['sStyear']	= $this->getRequest()->getParam('s_styear');
						$this->_userspace->search['coachst4']['sKana']		= $this->getRequest()->getParam('s_kana');
						$this->_userspace->search['coachst4']['sClass']		= $this->getRequest()->getParam('s_class');
						$this->_userspace->search['coachst4']['sKeyword']	= $this->getRequest()->getParam('s_keyword');
						$this->_userspace->search['coachst4']['sField']		= $this->getRequest()->getParam('s_field');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['coachst4']['sGroup']) )
							$this->_userspace->search['coachst4']['sGroup']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sGrade']) )
							$this->_userspace->search['coachst4']['sGrade']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sStyear']) )
							$this->_userspace->search['coachst4']['sStyear']	= '0';
						if( !isset($this->_userspace->search['coachst4']['sKana']) )
							$this->_userspace->search['coachst4']['sKana']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sClass']) )
							$this->_userspace->search['coachst4']['sClass']		= '0';
						if( !isset($this->_userspace->search['coachst4']['sKeyword']) )
							$this->_userspace->search['coachst4']['sKeyword']	= '';
						if( !isset($this->_userspace->search['coachst4']['sField']) )
							$this->_userspace->search['coachst4']['sField']		= '0';
						
						$coachst= $this->getRequest()->getParam('coachst' );
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加学生が、選択されていません。') );
						}
				}
				
				
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['coachst4']['sGroup'];	
				$sGrade		= $this->_userspace->search['coachst4']['sGrade'];	
				$sStyear	= $this->_userspace->search['coachst4']['sStyear'];
				$sKana		= $this->_userspace->search['coachst4']['sKana'];	
				$sClass		=	$this->_userspace->search['coachst4']['sClass'];	
				$sKeyword	=	$this->_userspace->search['coachst4']['sKeyword'];
				$sField		=	$this->_userspace->search['coachst4']['sField'];	
				if( $sGroup 		=== null 
					||	$sGrade		=== null 
					|| 	$sStyear	=== null 
					||	$sKana		=== null 
					||	$sClass		=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}

				if( $sGroup   == "0" 
					&& $sGrade  == "0" 
					&& $sStyear == "0" 
					&& $sKana		== "0" 
					&& $sClass	== "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}

if( $this->_config->global->debugOn )
	var_dump($this->_sessionId);

				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_grade'		=>  $sGrade,
																	's_styear'  =>  $sStyear,
																	's_kana'		=>  $sKana,
																	's_class'		=>  $sClass,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField
																);
						
						$select = $this->_member->getMemberPage( $findArray );
						
				} else 
				{
						
						// データ取得形式を設定する
						$select = $this->_member->getMemberPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます

				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null ) ? $page : 1;				//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$menu_findArray = array(
																 's_kind'		=>  '1',
																 's_group'	=>  '0',
																 's_grade'	=>  '0',
																 's_class'	=>  '0',		//??
																 's_year'		=>  '0'
																);
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, $menu_findArray );
				$this->view->gradeArray		= $this->_menu->getGradeList( $menu_mode, null );
				$this->view->styearArray	= $this->_menu->getYearList( $menu_mode, null );
				$this->view->classArray		= $this->_menu->getClassList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField4List( null, null );

				
				$this->view->selGroup		= $sGroup;
				$this->view->selGrade		= $sGrade;
				$this->view->selStyear	= $sStyear;
				$this->view->selKana		= $sKana;
				$this->view->selClass		= $sClass;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;


				
				
				$this->view->attribs = null;
				$this->view->options = null;
				$this->view->listsep	=' ';
				
				
				$this->view->coachst	= $coachst;
				

				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}

				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要








				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index		= $this->view->modulePath.'coachstudent/index'		.$this->view->sid;
				$coachst2student	= $this->view->modulePath.'coachstudent/student'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>'学生選択'	,'url'=>$coachst2student )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }



    /**-------------------------------------------------------------------------------------------
     * addstudentアクション
     */
    public function addstudentAction()
    {
				if( $this->getRequest()->isPost() ) {
						
						$coachst	 		= $this->getRequest()->getParam('coachst');
						$memberArray	= $this->getRequest()->getParam('member_id');
				}
				
				if( count($memberArray) == 0 ){
		        $targetUrl = '/coachstudent/student/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($memberArray) >= 1 ){
						
						$studentArray = $this->_userspace->search['coachst']['studentLists'];
						if( $studentArray == null )
								$studentArray = array();	
						foreach( $memberArray as $idx )
						{
							if( array_search( $idx, $studentArray )===false )
								array_push( $studentArray, $idx );
						}
						$this->_userspace->search['coachst']['studentLists'] = $studentArray;
						
				}
				
				
				
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/coachstudent/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }








    /**-------------------------------------------------------------------------------------------
     * teacherアクション（教員選択検索）
     */
    public function teacherAction()
    {
				$errors = array();
				
				
				if( $this->getRequest()->isPost() ) {
						
						$this->_userspace->search['coachst5']['sGroup']		= $this->getRequest()->getParam('s_group');		
						$this->_userspace->search['coachst5']['sJob']			= $this->getRequest()->getParam('s_job');			
						$this->_userspace->search['coachst5']['sKana']		= $this->getRequest()->getParam('s_kana');		
						$this->_userspace->search['coachst5']['sKeyword']	= $this->getRequest()->getParam('s_keyword');	
						$this->_userspace->search['coachst5']['sField']		= $this->getRequest()->getParam('s_field');		
						$this->_userspace->search['coachst5']['sKind']		= $this->getRequest()->getParam('s_kind');		
						
						//$member	 	= $this->getRequest()->getParam('member_id');
						$coachst	= $this->getRequest()->getParam('coachst');
				}
				else {
						//ページングはここを通るため検索actionURLに取得パラメータが必要
						if( !isset($this->_userspace->search['coachst5']['sGroup']) )
							$this->_userspace->search['coachst5']['sGroup']		= '0';
						if( !isset($this->_userspace->search['coachst5']['sJob']) )
							$this->_userspace->search['coachst5']['sJob']			= '0';
						if( !isset($this->_userspace->search['coachst5']['sKana']) )
							$this->_userspace->search['coachst5']['sKana']		= '0';
						if( !isset($this->_userspace->search['coachst5']['sKeyword']) )
							$this->_userspace->search['coachst5']['sKeyword']	= '';
						if( !isset($this->_userspace->search['coachst5']['sField']) )
							$this->_userspace->search['coachst5']['sField']		= '0';
						if( !isset($this->_userspace->search['coachst5']['sKind']) )
							$this->_userspace->search['coachst5']['sKind']		= '0';
						
						$coachst		= $this->getRequest()->getParam('coachst');
						
						$error 		= $this->getRequest()->getParam('error',0);
						if( $error ==1 ){
							
							array_push($errors, array('追加教員が、指定されていません。') );
						}
						else if( $error ==2 ){
							
							array_push($errors, array('追加教員は、１名のみ選択してください。') );
						}
				}
				
				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}
				
				$bFind = true;	
				
				// 検索項目が設定された保存して再表示、再検索でも有効にする
				$sGroup		= $this->_userspace->search['coachst5']['sGroup'];		
				$sJob			= $this->_userspace->search['coachst5']['sJob'];			
				$sKana		= $this->_userspace->search['coachst5']['sKana'];			
				$sKeyword	= $this->_userspace->search['coachst5']['sKeyword'];	
				$sField		= $this->_userspace->search['coachst5']['sField'];		
				$sKind		=	$this->_userspace->search['coachst5']['sKind'];			
				if( $sGroup 	=== null 
					||	$sJob		=== null 
					|| 	$sKana	=== null 
					|| 	$sKind	=== null 
					||	$sKeyword	=== null )	{
							$bFind = false;
				}
				
				if( $sGroup   == "0" 
					&& $sJob		== "0" 
					&& $sKana   == "0" 
					&& $sKind   == "0" 
					&& $sKeyword== ""  
					)	{
							$bFind = false;
				}
				
				
				if ( $bFind ){
						
						$findArray = array( 	's_group'		=>  $sGroup,
																	's_job'			=>  $sJob,
																	's_kana'	  =>  $sKana,
																	's_keyword'	=>  $sKeyword,
																	's_field'		=>  $sField,
																	's_kind'		=>  $sKind,
																	's_comm'		=>  '0'					//getUserPage() 仕様変更
																);
					
						
						$select = $this->_user->getUserPage( $findArray );
						
				} else 
				{
						
						$select = $this->_user->getUserPage( null );
						
				}
				

				$paginator	= Zend_Paginator::factory( $select );
				$paginator->setItemCountPerPage( $this->_config->view->countPerPage );		// １ページあたりの項目数
				$paginator->setCurrentPageNumber( $this->getRequest()->getParam('page') );
				$paginator->setPageRange( $this->_config->view->pageRange );							// 表示するページネーション範囲（default:10）
				
				$this->view->assign( 'paginator', $paginator );

				
        // ビュースクリプトが表示されます
				
        $page  = $this->getRequest()->getParam('page');		
        $this->view->page = ($page != null) ? $page : 1;			//１つの変数を設定する
				$this->view->max	= $this->_config->view->countPerPage;

				$menu_mode ='すべて';		//search
				$this->view->groupArray		= $this->_menu->getGroupList( $menu_mode, null );
				$this->view->jobArray			= $this->_menu->getJobList( $menu_mode, null );
				$this->view->kanaArray		= $this->_menu->getKanaList( $menu_mode, null );
				$this->view->fieldArray		= $this->_menu->getField3List( null, null );
				$this->view->roleArray		= $this->_menu->getRoleList( $menu_mode, null );
				
				$this->view->selGroup		= $sGroup;
				$this->view->selJob			= $sJob;
				$this->view->selKana		= $sKana;
				$this->view->selKeyword	= $sKeyword;
				$this->view->selField		= $sField;
				$this->view->selKind		= $sKind;
				
				$this->view->coachst		= $coachst;

				if( $coachst != null ){
						$date = $this->_coachst->getCoachstDate($coachst);
					  if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d):(\d\d)$/', $date, $m)) {
								$date = $m[1] .'-'. $m[2] .'-'. $m[3] ;
					  }
				}


				
        // ビュースクリプトが表示されます
				$this->view->assign('errors',$errors);			// 追加後に再設定必要









				$top2index				= $this->view->modulePath.'top/index'				.$this->view->sid;
				$coachst2index		= $this->view->modulePath.'coachstudent/index'		.$this->view->sid;
				$coachst2teacher	= $this->view->modulePath.'coachstudent/teacher'	.$this->view->sid;
					$naviData = array(
									array('name'=>'TOP'				,'url'=>$top2index ),
									array('name'=>'学生指導'	,'url'=>$coachst2index ),
									array('name'=>'教員選択'	,'url'=>$coachst2teacher )
									);
				setNaviToPlacefolder('navi',$this->view,$naviData);


				$urlNon						= '#';
			switch( $this->view->userLevel ){
				case 'admin':
				case 'master':
				case 'manager':
				case 'chief':
				case 'teacher':
				case 'user':
				case 'staff':
				case 'guest':
				default:
					$actionData = array(
									);
					break;
				}
				setActionmenuToPlacefolder('actionMenu',$this->view,$actionData);


    }




    /**-------------------------------------------------------------------------------------------
     * addteacherアクション
     */
    public function addteacherAction()
    {

				if( $this->getRequest()->isPost() ) {
						
						$coachst	 		= $this->getRequest()->getParam('coachst');
						$userArray	= $this->getRequest()->getParam('user_id');
				}
				
				if( count($userArray) == 0 ){
		        $targetUrl = '/coachstudent/teacher/error/1/sid/'.$this->_sid;
		        return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				}
				else if( count($userArray) >= 1 ){
						
						$teacherArray = $this->_userspace->search['coachst']['teacherLists'];
						if( $teacherArray == null )
								$teacherArray = array();	
						foreach( $userArray as $idx )
						{
							if( array_search( $idx, $teacherArray )===false )
								array_push( $teacherArray, $idx );
						}
						$this->_userspace->search['coachst']['teacherLists'] = $teacherArray;
						
				}
				
				
			  // ビュースクリプトが表示されます
			  $targetUrl = '/coachstudent/index/sid/'.$this->_sid;
			  return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
    }


    /**-------------------------------------------------------------------------------------------
     * delstudentアクション
     */
    public function delstudentAction()
    {
				
				$this->_userspace->search['coachst']['studentLists'] = array();
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/coachstudent/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
		}


    /**-------------------------------------------------------------------------------------------
     * delstudent2アクション
     */
    public function delstudent2Action()
    {
				
				$this->_userspace->search['coachst4']['studentLists'] = array();
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/coachstudent/new/mode/1/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
		}

    /**-------------------------------------------------------------------------------------------
     * delteacherアクション
     */
    public function delteacherAction()
    {
				
				
				$this->_userspace->search['coachst']['teacherLists'] = array();
				
				// ビュースクリプトが表示されます
			  $targetUrl = '/coachstudent/index/sid/'.$this->_sid;
				return $this->_redirect($targetUrl);		//DebugMessage 表示不可
				
		}













    /**-------------------------------------------------------------------------------------------
     * listアクション
     */
    public function listAction()
    {
        // ビュースクリプトが表示されます
    }
}
