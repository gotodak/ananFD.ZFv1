<?php
/**
 * エンプロイモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Controller_Action');
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Db'); 
Zend_Loader::loadClass('Zend_File_Transfer'); 
Zend_Loader::loadClass('Zend_Debug'); 
Zend_Loader::loadClass('Zend_Paginator'); // 追加する


// モジュールをロードする
require_once '../application/lib/anandef.php';




class employModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        //$this->_db = Zend_Db::factory( 'Mysqli', $params);
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * 就職先情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    public function getEmployPage( $find, $delDisp=false )
    {
				
        // ユーザ情報を取得する
				$select = $this->_db->select();
				
				$column = array( 't1.name', 't1.kana', 't1.area', 't1.url'  );
				$table  = array( 't1' => 'm_employment' );
				$select->from( $table, $column );
				
				$column = array( 't2.employ', 't2.group_id', 't2.modified_date'  );
				$table  = array( 't2' => 't_employgroup' );
				$select->joinLeft( $table, 't1.employ = t2.employ', $column );
				
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
        if ($find != null)
				{
        // 検索項目が指定されていれば条件指定
						
						
						if( $find['s_group'] !='0' )
								$select->where( 't2.group_id  = ?', $find['s_group'] );

						if( $find['s_area'] !='0' ){
								
								$area = strtolower($find['s_area']);
								if( substr_count( $area, '-')==1 )
								{
									$res	= explode("-", $area);		//split
									$select->where( 't1.area >= ?', $res[0] );
									$select->where( 't1.area <= ?', $res[1] );
								}else{
									$select->where( 't1.area  = ?', $find['s_area'] );
								}
						}

						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='name' || $find['s_field'] =='comments' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else
								$select->where( 't1.name LIKE ?',   "%{$find['s_keyword']}%" );
						}
								
						
						$strReg = getRegStr($find['s_kana']);
						if( $strReg != '' ) {
								$select->where( 't1.kana REGEXP ?', $strReg );		// AND
								$select->order( 't1.kana' );
						}

						
						
        }
				
				
				
				$select->order( 't1.kana' );
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				$userInfo = $select;
				
				
				return $userInfo;
		}




    /**-------------------------------------------------------------------------------------------
     * 就職先情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getEmployId( $employId )
    {
        // ユーザ情報を取得する
        if ($employId == null) {
						$select = $this->_db->select()->from( 'm_employment' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 'm_employment' );
						$select->where( 'employ  = ?', $employId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された就職先に属するグループ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedGroupId($employId)
    {
        // ユーザ情報を取得する
        if ($employId === null) {
						$select = $this->_db->select()->from( 't_employgroup', 'group_id' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 't_employgroup', 'group_id' );
						$select->where( 'employ  = ?', $employId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo = $this->_db->fetchAll($select);
        }
				
				
        return $userInfo;
				
    }





    /**-------------------------------------------------------------------------------------------
     * 就職先情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registEmploy( $info, $groupId, $employ, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['employ_name'] == "" ){
            return $lastId;
        }
				
       	// 重複チェック
        if ($this->isRegisteredEmployname($info['employ_name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array(
											'name'				=> $info['employ_name'],
											'kana'				=> $info['employ_kana'],
											
											'url'					=> $info['url'],
											'area'				=> $info['area'],
											'comments'		=> $info['comments'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_employment', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された 就職先情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無 
     */
    public function isRegisteredEmploy( $name  )
    {
				
				$sql = $this->_db->select()->from( 'm_employment', 'employ' );
				$sql->where( 'name  = ?', $name );
        $ret = $this->_db->fetchOne($sql);
        return ($ret != null) ? false : true;
        
		}




    /**-------------------------------------------------------------------------------------------
     * 就職先情報2をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registEmploy2( $info, $groupId, $employ, $deleteType )
    {
				$lastId = 0;
				
 				if( $employ == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array(
											'employ'			=> $employ,
											'group_id'		=> $groupId,	
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('t_employgroup', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }



    /**-------------------------------------------------------------------------------------------
     * 指定された 就職先情報2が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無 
     */
    public function isRegisteredEmploy2( $groupId, $employId  )
    {
				
				$sql = $this->_db->select()->from( 't_employgroup', 'id' );
				$sql->where( 'employ  = ?', $employId );
				$sql->where( 'group_id  = ?', $groupId );
        $ret = $this->_db->fetchOne($sql);
        return ($ret == null) ? true : false;
        
		}




    /**-------------------------------------------------------------------------------------------
     * 就職先情報を新規登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registEmployNew( $info, $groupArray, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['name'] == "" ){
            return $lastId;
        }

       	// 重複チェック
        if ($this->isRegisteredEmployname($info['name']) == true)
				{
						echo '重複文字列がありましたのでキャンセルしました1。';
            return $lastId;
//復活させて、更新が必要
				
        }
				
        // 登録データを連想配列にする
				
        $data = array(
											'name'				=> $info['name'],
											'kana'				=> $info['kana'],
											'area'				=> $info['area'],
											'url'					=> $info['url'],
											
											'comments'		=> $info['comments'],
											'delete_flg'	=> $deleteType
                );
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_employment', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									foreach( $groupArray as $group ){
									
							        // 登録データを連想配列にする
							        $subgroup = array(
																		'employ'			=> $lastId,
																		'group_id'		=> $group,		//+1,	
																		'delete_flg'	=> $deleteType
							                );
											$this->_db->insert('t_employgroup', $subgroup );
									}
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました1。';
					}
					
	        return $lastId;
		
    }





    /**-------------------------------------------------------------------------------------------
     * ★☆就職先情報を更新する★☆
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateEmploy( $info, $employ, $groupArray, $deleteType)
    {

				$lastId = 0;
				
 				if( $info['employ'] == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
				
        $data = array(
											'name'				=> $info['name'],
											'kana'				=> $info['kana'],
											
											'url'					=> $info['url'],
											'area'				=> $info['area'],
											'comments'		=> $info['comments'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						$target = array(
													'employ = ' . $employ
										);
	        	// データを更新する
   					$this->_db->update( 'm_employment', $data, $target );
						
						
						
						$this->checkEmploygroup( $info, $employ, $groupArray );
						
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;


		
    }





    /**-------------------------------------------------------------------------------------------
     * 就職先情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteEmploy($employ)
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
					         // 更新データを連想配列にする
					        $data = array(
					                      'delete_flg'	=> '1'
					                );
									$target = array(
																'employ = ' . $employ 
													);
									
					        // データを更新する
					        $this->_db->update( 'm_employment', $data, $target );
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				

   }





    /**-------------------------------------------------------------------------------------------
     * 指定された就職先ＩＤが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function isRegisteredEmployId($employ)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_employment', 'COUNT(*) AS cnt' );
				$select->where( 'employ  = ?', $employ );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * 指定された就職先情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredEmployname($name)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_employment', 'COUNT(*) AS cnt' );
				$select->where( 'name  = ?', $name );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された就職先情報に属するグループが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredEmploygroup( $employ,$groupId )
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 't_employgroup', 'COUNT(*) AS cnt' );
				$select->where( 'employ  = ?', $employ );
				$select->where( 'group_id  = ?', $groupId );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された就職先情報に属するグループの削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredEmploygroupDeleteFlg( $employ,$groupId )
    {
				
				$select = $this->_db->select()->from( 't_employgroup', 'delete_flg' );
				$select->where( 'employ  = ?', $employ );
				$select->where( 'group_id  = ?', $groupId );
        $result = $this->_db->fetchRow($select);
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }







    /**-------------------------------------------------------------------------------------------
     * 指定された就職先情報に属するグループ情報をリセットする（未使用）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function resetEmploygroup( $employ )
    {
				$groupArray = array( '1', '2', '3','4', '5' );
				
				foreach( $groupArray as $group ){
				
       			// 有無チェック
						if( $this->isRegisteredEmploygroup( $employ,$group ) == true )
						{
								
								if( $this->isRegisteredEmploygroupDeleteFlg( $employ,$group ) == false )
								{	
										
						         // 更新データを連想配列にする
						        $data = array(
						                      'delete_flg'	=> '1'
						                );
										$target = array(
																	'employ = ' . $employ ,
																	'group_id = ' . $group
														);
						        // データを更新する
						        $this->_db->update( 't_employgroup', $data, $target );
										
								}
						}
				
				}
			}





    /**-------------------------------------------------------------------------------------------
     * 指定された就職先情報に属するグループが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function checkEmploygroup( $info, $employ, $groupArray )
    {
				$groupScan = array(  '1', '2', '3','4','5' );
				$idx = 0;
				
				foreach( $groupScan as $scan )
				{
					
					foreach( $groupArray as $group )
					{
						if( $group == $scan )
						{
								
		       			// 有無チェック
								//if( $this->isRegisteredEmploygroup( $employ,($scan+1) ) == true )
								if( $this->isRegisteredEmploygroup( $employ,($scan) ) == true )
								{
										
										
								    // 登録データを連想配列にする
								    $subgroup = array(
																			'delete_flg'	=> '0'
										            );
									  $data = array(
									                'delete_flg'	=> '0'
									          );
										$target = array(
																			'employ = ' . $employ ,
																			'group_id = ' . ($scan)		//+1)
																	);
										$this->_db->update('t_employgroup', $subgroup, $target );
								}else
								{
								    // 登録データを連想配列にする
								    $subgroup = array(
																			'employ'			=> $info['employ'],
																			'group_id'		=> ($scan),		//+1),	
																			'delete_flg'	=> '0'
											            );
										$this->_db->insert('t_employgroup', $subgroup );
								}
								break;
						}else
						{
								
		       			// 有無チェック
								if( $this->isRegisteredEmploygroup( $employ,($scan) ) == true )
								{
									   // 更新データを連想配列にする
									  $data = array(
									                'delete_flg'	=> '1'
									          );
										$target = array(
																	'employ = ' . $employ ,
																	'group_id = ' . ($scan)		//+1)
														);
									  // データを更新する
									  $this->_db->update( 't_employgroup', $data, $target );
										
								}
						}
					}
				}
				
			}







    /**-------------------------------------------------------------------------------------------
     * 就職先ＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getEmploymentId($name)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_employment', 'employ' );
				$select->where( 'name  = ?', $name );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;				//error
				
				
    }

    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getEmployName($employId)
    {


        // グループ名称を取得する
        if ($employId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						
						$groupName = '';
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_employment', 'name' );
						$sql->where( 'employ  = ?', $employId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserName($userId)
    {


        // グループ名称を取得する
        if ($userId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						$sql->where( 'user_id  = ?', $userId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }



    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($groupName)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_group', 'group_id' );
				$select->where( 'group_name  = ?', $groupName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : STAFF_ID;				//staff
				
				
    }



    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
				
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }





}

