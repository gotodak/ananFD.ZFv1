<?php
/**
 * メンバーモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

class groupModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }




    /**-------------------------------------------------------------------------------------------
     * グループ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getGroupPage( $find, $delDisp=false )
    {
				
        // ユーザ情報を取得する
        //if ($find == null)
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select = $select->from( 'm_group' );
						if( $delDisp==false )
							$select->where( 'delete_flg  = ?', '0' );
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
						
								// Zend_Db_Selectオブジェクトを作成する
								$select = $this->_db->select();
								// from() メソッドを追加する
								$select = $select->from( 'm_group' );
						if( $delDisp==false )
							$select->where( 'delete_flg  = ?', '0' );
						
						if( $find['s_styear'] !='0' &&  $find['s_edyear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$edyear = $find['s_edyear'].'-04-01';
								$select->where( 'start_year <= ?', $edyear );
								$select->where( 'end_year >= ?', $styear );
						}
						else if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$select->where( 'end_year >= ?', $styear );
						}
						else if( $find['s_edyear'] !='0' ){
								$edyear = $find['s_edyear'].'-04-01';
								$select->where( 'start_year <= ?', $edyear );
						}
						
						if( $find['s_keyword'] !='' )
								$select->where( 'group_name LIKE ?',   '%'.$find['s_keyword'].'%' );
						
						
						$userInfo = $select;
						
        }	
				
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $userInfo = $this->_db->fetchAll($userInfo);
				
				return $userInfo;
			

		}



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getGroupId($groupId)
    {
        // ユーザ情報を取得する
        if ($groupId === null) {
						$select = $this->_db->select()->from( 'm_group' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 'm_group' );
						$select->where( 'group_id  = ?', $groupId );
		        $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registGroup( $info, $groupId, $classId, $grade, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['group_name'] == '' ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredGroup($info['group_name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('group_name' 	=> $info['group_name'],
                      'group_kind'	=> $info['group_kind'],
                      'start_year'  => $info['start_year'],
                      'end_year'    => $info['end_year'],
                      'delete_flg'	=> $deleteType
                );
				
				
				// ユーザ情報を登録する
				$this->_db->insert('m_group', $data );
			  // 登録したデータの user_id を取得する
				$lastId = $this->_db->lastInsertId();
				
	      return $lastId;
		
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateGroup( $info, $groupId, $groupId, $jobId, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array('group_name' 	=> $info['group_name'],
                      'group_kind'	=> $info['group_kind'],
                      'start_year'  => $info['start_year'],
                      'end_year'    => $info['end_year'],
                      'delete_flg'	=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 'm_group', $data, 'group_id = ' . $groupId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteGroup($groupId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 'm_group', $data, 'user_id = ' . $userId );
				
   }








    /**-------------------------------------------------------------------------------------------
     * 指定されたフィードURLが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredGroup($groupName)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_group', 'COUNT(*) AS cnt' );
				$select->where( 'group_name  = ?', $groupName );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }







}
