<?php
/**
 * サポート（支援）モデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

class supportModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);
				
				
				
    }






    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する（各授業科目の度数）
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
		 *
     */
    public function getSupport2Page( $find, $userId=0 )
    {
				
        // ユーザ情報を取得する
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						$column = array( 't2.subject_id', 't2.date', 't2.modified_date', 't2.group_id', 'COUNT(t2.subject_id) AS count' );
						$table  = array( 't2' => 't_learnsupport' );
						$select->from( $table, $column );
						
						$column = array( 't1.code', 't1.name', 't1.units', 't1.grade', 't1.term', 't1.require', 't1.start_year' );
						$table  = array( 't1' => 'm_subject' );
						$select->joinLeft( $table, 't1.code = t2.subject_id', $column );
						
						if( $userId !='0' ){
								$column = array( 't3.user_id' );
								$table  = array( 't3' => 't_subuser' );
								$select->joinLeft( $table, 't1.code = t3.code', $column );
								
								$select->where( 't3.user_id  = ?', $userId );
						}

						$select->group( 't2.subject_id' );
						$select->group( 't2.group_id' );
						
						$select->where( 't2.delete_flg  = ?', '0' );
						
						$select->order( 't2.subject_id' );
						$select->order( 'count DESC' );
						
						
						
        } else {
        // 検索項目が指定されていれば条件指定
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						$column = array( 't2.subject_id', 't2.date', 't2.modified_date', 't2.group_id', 'COUNT( t2.subject_id) AS count'  );
						$table  = array( 't2' => 't_learnsupport' );
						$select->from( $table, $column );
						
						$column = array( 't1.code', 't1.name', 't1.units', 't1.grade', 't1.term', 't1.require', 't1.start_year' );
						$table  = array( 't1' => 'm_subject' );
						$select->joinLeft( $table, 't1.code = t2.subject_id', $column );
						
						if( $userId !='0' ){
								$column = array( 't3.user_id' );
								$table  = array( 't3' => 't_subuser' );
								$select->joinLeft( $table, 't1.code = t3.code', $column );
								
								$select->where( 't3.user_id  = ?', $userId );
						}

						if( $find['s_student'] != null ){
							
							$select->where( 't2.member_id IN (?)', $find['s_student'] );
						}

						if( $find['s_teacher'] != null ){
								$column = array( 't3.user_id' );
								$table  = array( 't3' => 't_subuser' );
								$select->joinLeft( $table, 't1.code = t3.code', $column );
								
								$select->where( 't3.user_id IN (?)', $find['s_teacher'] );
						}

						
						$select->group( 't2.subject_id' );
						$select->group( 't2.group_id' );
						
						$select->where( 't2.delete_flg  = ?', '0' );
						
							
							if( $find['s_group'] !='0' )
									$select->where( 't2.group_id  = ?', $find['s_group'] );
							if( $find['s_grade'] !='0' )
									$select->where( 't1.grade  = ?', $find['s_grade'] );
							if( $find['s_term'] !='0' )
									$select->where( 't1.term  = ?', $find['s_term'] );
							if( $find['s_req'] !='0' ){
									$select->where( 't1.require = ?', $find['s_req'] );
							}
									
						if( $find['s_styear'] !='0' && $find['s_edyear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$edyear = $find['s_edyear'].'-03-31';
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d)$/', $edyear, $m)) {
										$m[1] +=1;
										$edyear = $m[1] .'-'. $m[2] .'-'. $m[3] ;
								}
								$select->where( 't2.date >= ?', $styear );
								$select->where( 't2.date <= ?', $edyear );
						}
						else if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$edyear = $find['s_styear'].'-03-31';
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d)$/', $edyear, $m)) {
										$m[1] +=1;
										$edyear = $m[1] .'-'. $m[2] .'-'. $m[3] ;
								}
								$select->where( 't2.date >= ?', $styear );
								$select->where( 't2.date <= ?', $edyear );
						}
						
						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='code' || $find['s_field'] =='name' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else
								$select->where( 't1.name LIKE ?',   "%{$find['s_keyword']}%" );
						}
						
						
						$select->order( 't2.subject_id' );
						$select->order( 'count DESC' );
						
        }
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
				$userInfo = $select;
				
				return $userInfo;
		}





    /**-------------------------------------------------------------------------------------------
     * グループ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getSupportPage( $subjectId, $groupId, $find, $delDisp=false )
    {
				
        // ユーザ情報を取得する
        //if ($find == null)
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						$column = array( 't1.member_name', 't1.group_id', 't1.class_id', 't1.grade', 't1.kind', 't1.start_year' );
						$table  = array( 't1' => 'm_member' );
						$select->from( $table, $column );
						
						$column = array( 't2.id', 't2.subject_id', 't2.date', 't2.member_id', 't2.grade_at', 't2.modified_date', 't2.user_id', 't2.status', 't2.memo', 't2.learn_id' );
						$table  = array( 't2' => 't_learnsupport' );
						$select->joinLeft( $table, 't2.member_id = t1.member_id', $column );
						
		        if ($subjectId != null)
							$select->where( 't2.subject_id  = ?', $subjectId );
		        if ($groupId != null)
							$select->where( 't2.group_id  = ?', $groupId );
						
						if( $delDisp==false )
							$select->where( 't2.delete_flg  = ?', '0' );
						
						$select->order( 't1.member_id' );
						
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						$column = array( 't1.member_name', 't1.group_id', 't1.class_id', 't1.grade', 't1.kind', 't1.start_year' );
						$table  = array( 't1' => 'm_member' );
						$select->from( $table, $column );
						
						$column = array( 't2.id', 't2.subject_id', 't2.date', 't2.member_id', 't2.grade_at', 't2.modified_date', 't2.user_id', 't2.status', 't2.memo', 't2.learn_id' );
						$table  = array( 't2' => 't_learnsupport' );
						$select->joinLeft( $table, 't2.member_id = t1.member_id', $column );
						
		        if ($subjectId != null)
							$select->where( 't2.subject_id  = ?', $subjectId );
		        if ($groupId != null)
							$select->where( 't2.group_id  = ?', $groupId );
						
						
						if( $delDisp==false )
							$select->where( 't2.delete_flg  = ?', '0' );

						
						if( $find['s_group'] !='0' )
								$select->where( 't1.group_id  = ?', $find['s_group'] );
						if( $find['s_grade'] !='0' )
								$select->where( 't1.grade  = ?',   $find['s_grade'] );
						if( $find['s_class'] !='0' )
								$select->where( 't1.class_id  = ?',   $find['s_class'] );
						if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$select->where( 't1.start_year = ?', $styear );
						}
						
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='member_name' || $find['s_field'] =='member_kana' )
									$select->where( 't1.'.$find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							}
						
						$strReg = getRegStr($find['s_kana']);
						if( $strReg != '' ) {
								$select->where( 't1.member_kana REGEXP ?', $strReg );		// AND
								$select->order( 'member_kana' );
						}
						
						if( $find['styear'] !='0' && $find['edyear'] !='0' 
							 && $find['styear'] !='' && $find['edyear'] !='' ){
								$styear = $find['styear'].'-04-01';
								$edyear = $find['edyear'].'-03-31';
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d)$/', $edyear, $m)) {
										$m[1] +=1;
										$edyear = $m[1] .'-'. $m[2] .'-'. $m[3] ;
								}
								$select->where( 't2.date >= ?', $styear );
								$select->where( 't2.date <= ?', $edyear );
						}
						else if( $find['styear'] !='0' && $find['styear'] !='' ){
								$styear = $find['styear'].'-04-01';
								$edyear = $find['styear'].'-03-31';
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d)$/', $edyear, $m)) {
										$m[1] +=1;
										$edyear = $m[1] .'-'. $m[2] .'-'. $m[3] ;
								}
								$select->where( 't2.date >= ?', $styear );
								$select->where( 't2.date <= ?', $edyear );
						}
						
						
						$select->order( 'member_id' );
						
						
        }	
				
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
						$userInfo = $select;
						
				
				
				return $userInfo;
			

		}



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getSupportId($supportId)
    {
        // ユーザ情報を取得する
        if ($supportId === null) {
						$select = $this->_db->select()->from( 't_learnsupport' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						$column = array( 't1.member_id', 't1.member_name', 't1.group_id', 't1.class_id', 't1.grade', 't1.start_year' );
						$table  = array( 't1' => 'm_member' );
						$select->from( $table, $column );
						
						$column = array( 't2.id', 't2.subject_id', 't2.date', 't2.member_id', 't2.modified_date', 't2.user_id', 't2.status', 't2.memo', 't2.learn_id' );
						$table  = array( 't2' => 't_learnsupport' );
						$select->joinLeft( $table, 't1.member_id = t2.member_id', $column );
						
						$column = array( 't3.user_name' );
						$table  = array( 't3' => 'm_user' );
						$select->joinLeft( $table, 't2.user_id = t3.user_id', $column );
						
						$column = array( 't4.name' );
						$table  = array( 't4' => 'm_subject' );
						$select->joinLeft( $table, 't2.subject_id = t4.code', $column );
						
						
		        if ($supportId != null)
							$select->where( 't2.id  = ?', $supportId );
						
            $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registSupport( $info, $commId, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['comm_name'] == '' ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredComm($info['comm_name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('comm_name' 	=> $info['comm_name'],
                      'comm_kind'		=> $info['comm_kind'],
                      'delete_flg'	=> $deleteType
                );
				
				
				// ユーザ情報を登録する
				$this->_db->insert('t_learnsupport', $data );
			  // 登録したデータの user_id を取得する
				$lastId = $this->_db->lastInsertId();
				
	      return $lastId;
		
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateSupport( $info, $supportId, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array('status'			=> $info['status'],
                      'memo'				=> $info['memo'],
                      'user_id'			=> $info['user'],
                      'delete_flg'	=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 't_learnsupport', $data, 'id = ' . $supportId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteSupport($supportId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 't_learnsupport', $data, 'id = ' . $supportId );
				
   }








    /**-------------------------------------------------------------------------------------------
     * 指定されたフィードURLが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSupport($commName)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 't_learnsupport', 'COUNT(*) AS cnt' );
				$select->where( 'comm_name  = ?', $commName );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }









}
