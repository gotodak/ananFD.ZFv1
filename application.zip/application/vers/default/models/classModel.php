<?php
/**
 * メンバーモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';


class classModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * クラス情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		クラス情報
     */
    public function getClassPage( $find, $delDisp=false )
    {
				
        // ユーザ情報を取得する
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select = $select->from( 'm_class' );
						if( $delDisp==false )
							$select->where( 'delete_flg  = ?', '0' );
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
						
								// Zend_Db_Selectオブジェクトを作成する
								$select = $this->_db->select();
								// from() メソッドを追加する
								$select = $select->from( 'm_class' );
						if( $delDisp==false )
								$select->where( 'delete_flg  = ?', '0' );				// AND
						
						if( $find['s_group'] !='0' )
								$select->where( 'group_id  = ?', $find['s_group'] );
						if( $find['s_grade'] !='0' )
								$select->where( 'grade  = ?',   $find['s_grade'] );
						if( $find['s_keyword'] !='' )
								$select->where( 'class_name LIKE ?',   '%'.$find['s_keyword'].'%');
								
						$userInfo = $select;
						
        }	
			
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
				
				return $userInfo;
			

		}



    /**-------------------------------------------------------------------------------------------
     * クラス情報を取得する
     *
     * @param  string $classId		クラスＩＤ
     * @return array	$result			クラス情報
     */
    public function getClassId($classId)
    {
        // ユーザ情報を取得する
        if ($classId === null) {
						$select = $this->_db->select()->from( 'm_class' );
		        $userInfo = $this->_db->fetchAll($select);
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 'm_class' );
						$select->where( 'class_id  = ?', $classId );
		        $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }


    /**-------------------------------------------------------------------------------------------
     * クラス情報をを登録する
     *
     * @param array  $info  	 クラス情報
     * @param int    $groupId  グループID
     * @param int    $grade		 グループID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registClass( $info, $groupId, $grade, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['class_name'] == '' ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredClass($info['class_name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('class_name' 	=> $info['class_name'],
                      'group_id' 		=> $info['group_id'],
                      'grade'       => $info['grade'],
                      'delete_flg'	=> $deleteType
                );
				
				
				// ユーザ情報を登録する
				$this->_db->insert('m_class', $data );
			  // 登録したデータの class_id を取得する
				$lastId = $this->_db->lastInsertId();
				
	      return $lastId;
		
    }


    /**-------------------------------------------------------------------------------------------
     * クラス情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateClass( $info, $classId, $groupId, $grade, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array('class_name' 	=> $info['class_name'],
                      'group_id'  	=> $info['group_id'],
                      'grade' 	 		=> $info['grade'],
                      'delete_flg'	=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 'm_class', $data, 'class_id = ' . $classId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * クラス情報を削除する
     *
     * @param int $classId クラスID
     * @return void
     */
    public function deleteClass($classId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 'm_class', $data, 'class_id = ' . $classId );
				
   }








    /**-------------------------------------------------------------------------------------------
     * 指定されたフィードURLが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredClass($className)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_class', 'COUNT(*) AS cnt' );
				$select->where( 'class_name  = ?', $className );
        $result = $this->_db->fetchRow($select);
				

       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * ユーザ認証を行う（未使用）
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isAuthValid( $userId, $password )
    {
				
				$sql = $this->_db->select()->from( 't_user', 'role' );
				$sql->where( 'user_id  = ?', $userId );
				$sql->where( 'password  = ?', $password );
				$sql->where( 'delete_flg  = ?', '0' );
        $ret = $this->_db->fetchOne($sql);
        return ($ret != null) ? $ret : false;
        
    }



    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getClassId2( $grade,$groupId )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_class', 'class_id' );
				$select->where( 'group_id  = ?', $groupId );
				$select->where( 'grade  = ?', $grade );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
			
    }





    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する（未使用）
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     * 　主に、memberModel のみを使用
     */
    public function getGroupId($className)
    {
				
				$groupId = STAFF_ID;				//staff
				switch( $className ){
					case 'M':
						$groupId = 2;		break;
					case 'E':
						$groupId = 3;		break;
					case 'S':
						$groupId = 4;		break;
					case 'C':
						$groupId = 5;		break;
					default:
						$groupId = 1;		break;
				}
				return $groupId;
			
    }



    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }






    /**-------------------------------------------------------------------------------------------
     * 職名ＩＤを取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getJobId($jobName)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 'm_job', 'job_id' );
				$select->where( 'job_name  = ?', $jobName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }


    /**-------------------------------------------------------------------------------------------
     * 職名を取得する
     *
     * @param	 int		$jobId			職名ＩＤ
     * @return string $jobName		職名
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getJobName($jobId)
    {
				
				
        // 職名を取得する
        if ($jobId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_job', 'job_name' );
						$jobName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_job', 'job_name' );
						$sql->where( 'job_id  = ?', $jobId );
        		$jobName = $this->_db->fetchOne($sql);
						
        }
        return $jobName;
				
    }








}