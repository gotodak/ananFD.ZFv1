<?php
/**
 * ユーザモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';




class subjectModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    public function getSubjectPage( $find )
    {
				
        // ユーザ情報を取得する
				$select = $this->_db->select();
				
				$column = array( 't1.code', 't1.name', 't1.units', 't1.grade', 't1.term', 't1.require', 't1.start_year', 't1.end_year', 't1.modified_date', 't1.file' );
				$table  = array( 't1' => 'm_subject' );
				$select->from( $table, $column );
				
				$column = array( 't2.group_id' );
				$table  = array( 't2' => 't_subgroup' );
				$select->joinLeft( $table, 't1.code = t2.code', $column );
				
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
        if ($find != null)
				{
        // 検索項目が指定されていれば条件指定
						
						
						if( $find['s_group'] !='0' )
								$select->where( 't2.group_id  = ?', $find['s_group'] );
						if( $find['s_grade'] !='0' )
								$select->where( 't1.grade  = ?', $find['s_grade'] );
						if( $find['s_req'] !='0' )
								$select->where( 't1.require = ?', $find['s_req'] );
						if( $find['s_term'] !='0' )
								$select->where( 't1.term = ?', $find['s_term'] );
						if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$select->where( 't1.start_year <= ?', $styear );
								$select->where( 't1.end_year > ?', $styear );
						}
						
						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='code' || $find['s_field'] =='name' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else
								$select->where( 't1.name LIKE ?',   "%{$find['s_keyword']}%" );
						}
						
        }
				
				
				
				$select->order( 'code' );		// DESC
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				$userInfo = $select;
				
				
				return $userInfo;
		}




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getSubjectId($subjectId)
    {
        // ユーザ情報を取得する
        if ($subjectId === null) {
						$select = $this->_db->select()->from( 'm_subject' );
		        $userInfo = $this->_db->fetchAll($select);
						
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 'm_subject' );
						$select->where( 'code  = ?', $subjectId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo = $this->_db->fetchRow($select);
        }
				
				
        return $userInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedGroupId($subjectId)
    {
        // ユーザ情報を取得する
        if ($subjectId === null) {
						
 					 $select = $this->_db->select()->from( 't_subgroup', 'group_id' );
           $userInfo = $this->_db->fetchAll($select);
				
        // IDが指定されていれば条件指定
        } else {
						$select = $this->_db->select()->from( 't_subgroup', 'group_id' );
						$select->where( 'code  = ?', $subjectId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo	= $this->_db->fetchAll($select);
        }
				
				
        return $userInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedUserId($subjectId)
    {
        // ユーザ情報を取得する
        if ($subjectId === null) {
						
 						$select = $this->_db->select()->from( 't_subuser', 'user_id' );
		        $userInfo = $this->_db->fetchAll($select);
					
       // IDが指定されていれば条件指定
        } else {
 						$select = $this->_db->select()->from( 't_subuser', 'user_id' );
						$select->where( 'code  = ?', $subjectId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo = $this->_db->fetchAll($select);
        }
				
				
        return $userInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registSubject( $info, $groupId, $req, $term, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['subject_code'] == "" ){
            return $lastId;
        }

       	// 重複チェック
        if ($this->isRegisteredSubject($info['subject_code']) == true)
				{
            return $lastId;
        }

				
        // 登録データを連想配列にする
				
        $data = array(
											'code'		=> $info['subject_code'],
											'name'		=> $info['subject_name'],
											'units'		=> $info['subject_units'],

											'grade'				=> $info['adapted_grade'],
											'require'			=> $req,
											'term'				=> $term,
											'start_year'	=> $info['start_year'],
											'end_year'		=> $info['end_year'],
											'file'				=> $info['file'],
											'delete_flg'			=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_subject', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報の適応グループ情報を登録する（アップロード）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registSubjectGroup( $info, $groupId, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['subject_code'] == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array(
											'code'				=> $info['subject_code'],
											'group_id'		=> $groupId,	
											'start_year'	=> $info['start_year'],
											'end_year'		=> $info['end_year'],
											'delete_flg'	=> $deleteType

                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('t_subgroup', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する（授業科目の担当ユーザのみ）
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
		 *
     */
    public function getUser2Page( $find )
    {
				
        // ユーザ情報を取得する
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						$column = array( 't1.user_id', 't1.user_name', 't1.user_kana', 't1.group_id', 't1.job_id', 't1.tel', 't1.kind', 't1.modified_date', 'COUNT(t2.code) AS count'   );
						$table  = array( 't1' => 'm_user' );
						$select->from( $table, $column );
						
						$column = array( 't2.code'  );
						$table  = array( 't2' => 't_subuser' );
						$select->joinLeft( $table, 't1.user_id = t2.user_id', $column );
						
						
						$select->group( 't2.user_id' );
						$select->group( 't1.user_name' );
						
						$select->where( 't1.kind  = ?', '1' );
						$select->where( 't1.delete_flg  = ?', '0' );
						
						$select->order( 'count DESC' );
						
						
						
        } else {
        // 検索項目が指定されていれば条件指定
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						
						if( $find['s_comm'] =='0' )					///×SubjectControllerでも使用
						{
							
							$column = array( 't1.user_id', 't1.user_name', 't1.user_kana', 't1.group_id', 't1.job_id', 't1.tel', 't1.kind', 't1.modified_date', 'COUNT(t2.code) AS count'   );
							$table  = array( 't1' => 'm_user' );
							$select->from( $table, $column );
							
							$column = array( 't2.code'  );
							$table  = array( 't2' => 't_subuser' );
							$select->joinLeft( $table, 't1.user_id = t2.user_id', $column );
							
							
							$select->group( 't2.user_id' );
							$select->group( 't1.user_name' );
							
							$select->where( 't1.kind  = ?', '1' );
							$select->where( 't1.delete_flg  = ?', '0' );
							
							if( $find['s_group'] !='0' )
									$select->where( 't1.group_id  = ?', $find['s_group'] );
							if( $find['s_job'] !='0' )
									$select->where( 't1.job_id  = ?',   $find['s_job'] );
									
							$strReg = getRegStr($find['s_kana']);
							if( $strReg != '' ) {
									$select->where( 't1.user_kana REGEXP ?', $strReg );		// AND
							}
							
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='user_name' || $find['s_field'] =='user_kana' )
									$select->where(  't1.' . $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							}
							

						if( $find['styear'] !='0' &&  $find['edyear'] !='0' ){
								$styear = $find['styear'].'-04-01';
								$edyear = $find['edyear'].'-04-01';
								$select->where( 't2.start_year <= ?', $edyear );
								$select->where( 't2.end_year >= ?', $styear );
						}
						else if( $find['styear'] !='0' ){
								$styear = $find['styear'].'-04-01';
								$select->where( 't2.end_year >= ?', $styear );
						}
						else if( $find['edyear'] !='0' ){
								$edyear = $find['edyear'].'-04-01';
								$select->where( 't2.start_year <= ?', $edyear );
						}
						
							
							$select->order( 'count DESC' );
							
						}
/**/
						else{
							
							$column = array( 't1.user_id', 't1.user_name', 't1.user_kana', 't1.group_id', 't1.job_id', 't1.tel', 't1.kind', 't1.modified_date', 'COUNT(t2.code) AS count'   );
							$table  = array( 't1' => 'm_user' );
							$select->from( $table, $column );
							
							$column = array( 't3.comm_id'  );
							$table  = array( 't3' => 't_commuser' );
							$select->joinLeft( $table, 't1.user_id = t3.user_id', $column );
							
							$column = array( 't2.code'  );
							$table  = array( 't2' => 't_subuser' );
							$select->joinLeft( $table, 't3.user_id = t2.user_id', $column );
							
							$select->group( 't3.user_id' );
							$select->group( 't1.user_name' );
							
							$select->where( 't1.kind  = ?', '1' );
							$select->where( 't1.delete_flg  = ?', '0' );
							$select->where( 't2.delete_flg  = ?', '0' );
							$select->where( 't3.delete_flg  = ?', '0' );
							
							if( $find['s_comm'] !='0' )
									$select->where( 't3.comm_id  = ?', $find['s_comm'] );
							
							
							if( $find['s_group'] !='0' )
									$select->where( 't1.group_id  = ?', $find['s_group'] );
							if( $find['s_job'] !='0' )
									$select->where( 't1.job_id  = ?',   $find['s_job'] );
									
							$strReg = getRegStr($find['s_kana']);
							if( $strReg != '' ) {
									$select->where( 't1.user_kana REGEXP ?', $strReg );		// AND
							}
							
							if( $find['s_keyword'] !='' ){
								if( $find['s_field'] =='user_name' || $find['s_field'] =='user_kana' )
									$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							}

						if( $find['styear'] !='0' &&  $find['edyear'] !='0' ){
								$styear = $find['styear'].'-04-01';
								$edyear = $find['edyear'].'-04-01';
								$select->where( 't2.start_year <= ?', $edyear );
								$select->where( 't2.end_year >= ?', $styear );
						}
						else if( $find['styear'] !='0' ){
								$styear = $find['styear'].'-04-01';
								$select->where( 't2.end_year >= ?', $styear );
						}
						else if( $find['edyear'] !='0' ){
								$edyear = $find['edyear'].'-04-01';
								$select->where( 't2.start_year <= ?', $edyear );
						}


						}
/**/
						
						$select->order( 'count DESC' );
						
        }
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
				$userInfo = $select;
				
				return $userInfo;
		}






    /**-------------------------------------------------------------------------------------------
     * 授業科目ユーザ情報を取得する（tp）
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    //public function getSubjectUserPage( $userId, $find )
    public function getSubjectUserPage( $userId, $find, $styear, $edyear )
    {
				
        // ユーザ情報を取得する
				$select = $this->_db->select();
				
        // ユーザ情報を取得する
        if ($find == null)
				{
					$column = array( 't1.code', 't1.name', 't1.units', 't1.grade', 't1.term', 't1.require', 't1.start_year', 't1.file' );
					$table  = array( 't1' => 'm_subject' );
					$select->from( $table, $column );
					
					$column = array( 't2.user_id', 't2.modified_date'   );
					$table  = array( 't2' => 't_subuser' );
					$select->joinLeft( $table, 't1.code = t2.code', $column );
					
					$select->where( 't1.delete_flg  = ?', '0' );
					$select->where( 't2.delete_flg  = ?', '0' );

					if( $userId !='0' )
							$select->where( 't2.user_id  = ?', $userId );

					if( $styear !='0' &&  $edyear !='0' && $styear !=NULL &&  $edyear !=NULL ){
							$styear = $styear.'-04-01';
							$edyear = $edyear.'-04-01';
							$select->where( 't1.start_year <= ?', $edyear );
							$select->where( 't1.end_year >= ?', $styear );
					}
					else if( $styear !='0' && $styear !=NULL ){
							$styear = $styear.'-04-01';
							$select->where( 't1.end_year >= ?', $styear );
					}
					else if( $edyear !='0' && $edyear !=NULL ){
							$edyear = $edyear.'-04-01';
							$select->where( 't1.start_year <= ?', $edyear );
					}

        } else {			//if ($find != null)
        // 検索項目が指定されていれば条件指定


					$column = array( 't1.code', 't1.name', 't1.units', 't1.grade', 't1.term', 't1.require', 't1.start_year', 't1.file' );
					$table  = array( 't1' => 'm_subject' );
					$select->from( $table, $column );
					
					$column = array( 't2.user_id', 't2.modified_date'   );
					$table  = array( 't2' => 't_subuser' );
					$select->joinLeft( $table, 't1.code = t2.code', $column );
					
								
					$select->where( 't1.delete_flg  = ?', '0' );
					$select->where( 't2.delete_flg  = ?', '0' );

					if( $userId !='0' )
							$select->where( 't2.user_id  = ?', $userId );

					if( $styear !='0' &&  $edyear !='0' && $styear !=NULL &&  $edyear !=NULL ){
							$styear = $styear.'-04-01';
							$edyear = $edyear.'-04-01';
							$select->where( 't1.start_year <= ?', $edyear );
							$select->where( 't1.end_year >= ?', $styear );
					}
					else if( $styear !='0' && $styear !=NULL ){
							$styear = $styear.'-04-01';
							$select->where( 't1.end_year >= ?', $styear );
					}
					else if( $edyear !='0' && $edyear !=NULL ){
							$edyear = $edyear.'-04-01';
							$select->where( 't1.start_year <= ?', $edyear );
					}
						
						if( $find['s_req'] !='0' )
								$select->where( 't1.require = ?', $find['s_req'] );
						if( $find['s_grade'] !='0' )
								$select->where( 't1.grade  = ?', $find['s_grade'] );
						if( $find['s_term'] !='0' )
								$select->where( 't1.term  = ?', $find['s_term'] );
						
						if( $find['s_styear'] !='0' && $find['s_styear'] != NULL ){
								$styear2 = $find['s_styear'].'-04-01';
								$select->where( 't1.start_year <= ?', $styear2 );
								$select->where( 't1.end_year > ?', $styear2 );
						}
						
						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='code' || $find['s_field'] =='name' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else
								$select->where( 't1.name LIKE ?',   "%{$find['s_keyword']}%" );
						}
						
        }
				
				
				
				$select->order( 'code' );		// DESC
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				$userInfo = $select;
				
				
				return $userInfo;
		}






    /**-------------------------------------------------------------------------------------------
     * 授業科目情報3をを登録する（未使用：upload3Action()）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registSubjectUser( $info, $groupId, $req, $term, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['subject_code'] == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array(
											'code'				=> $info['subject_code'],
											'user_id'			=> $term,
											'start_year'	=> $info['start_year'],
											'end_year'		=> $info['end_year'],
											'delete_flg'	=> $deleteType

                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('t_subuser', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }





    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を新規登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registSubjectNew( $info, $groupArray, $userArray, $term, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['code'] == "" ){
            return $lastId;
        }

       	// 重複チェック
        if ($this->isRegisteredSubject($info['code']) == true)
				{
            return $lastId;
        }

				
        // 登録データを連想配列にする
				
        $data = array(
											'code'				=> $info['code'],
											'name'				=> $info['name'],
											'units'				=> $info['units'],
											
											'grade'				=> $info['grade'],
											'require'			=> $info['require'],
											'term'				=> $info['term'],				//$term,
											'start_year'	=> $info['start_year'],
											'end_year'		=> $info['end_year'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_subject', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									foreach( $groupArray as $group ){
									
							        // 登録データを連想配列にする
							        $subgroup = array(
																		'code'				=> $info['code'],
																		'group_id'		=> $group,	//+1,	
																		'start_year'	=> $info['start_year'],
																		'end_year'		=> $info['end_year'],
																		'delete_flg'	=> $deleteType
							                );
											$this->_db->insert('t_subgroup', $subgroup );
									}

									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }





    /**-------------------------------------------------------------------------------------------
     * ★☆授業科目情報を更新する★☆
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateSubject( $info, $code, $groupArray, $grade, $deleteType)
    {

				$lastId = 0;
				
 				if( $info['code'] == "" ){
            return $lastId;
        }

				
        // 登録データを連想配列にする
				
        $data = array(
											'code'				=> $info['code'],
											'name'				=> $info['name'],
											'units'				=> $info['units'],
											
											'grade'				=> $info['grade'],
											'require'			=> $info['require'],
											'term'				=> $info['term'],				//$term,
											'start_year'	=> $info['start_year'],
											'end_year'		=> $info['end_year'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						$target = array(
													'code = ' . $code
										);
	        	// データを更新する
   					$this->_db->update( 'm_subject', $data, $target );
						
						
						
						$this->checkSubgroup( $info, $code,$groupArray );
						
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;


		
    }





    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteSubject($code)
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
					         // 更新データを連想配列にする
					        $data = array(
					                      'delete_flg'	=> '1'
					                );
									$target = array(
																'code = ' . $code 
													);
									
					        // データを更新する
					        $this->_db->update( 'm_subject', $data, $target );
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				

   }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateSubjectAdduser( $info, $code, $userArray, $styear, $deleteType)
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									foreach( $userArray as $user ){
									
       								// 重複チェック
											if( $this->isRegisteredSubuser( $code,$user ) == true )
											{
													
													if( $this->isRegisteredSubuserDeleteFlg( $code,$user ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'code = ' . $code ,
																						'user_id = ' . $user
																			);
															
											        // データを更新する
											        $this->_db->update( 't_subuser', $data, $target );
															
													}
											}else
											{
											        // 登録データを連想配列にする
											        $subuser = array(
																						'code'				=> $code,
																						'user_id'			=> $user,	
																						
																						'start_year'	=> $styear,
																						'end_year'		=> '9999-04-01',
																						'delete_flg'	=> $deleteType
											                );
															$this->_db->insert('t_subuser', $subuser );
											}
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateSubjectDeluser( $info, $code, $userId, $styear, $deleteType)
    {
				
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				$target = array(
											'code = ' . $code ,
											'user_id = ' . $userId
								);
				
        // データを更新する
        $this->_db->update( 't_subuser', $data, $target );

		
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubject($code)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_subject', 'COUNT(*) AS cnt' );
				$select->where( 'code  = ?', $code );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubuser( $code,$userId )
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 't_subuser', 'COUNT(*) AS cnt' );
				$select->where( 'code  = ?', $code );
				$select->where( 'user_id  = ?', $userId );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubuserDeleteFlg( $code,$userId )
    {
						
				$select = $this->_db->select()->from( 't_subuser', 'delete_flg' );
				$select->where( 'code  = ?', $code );
				$select->where( 'user_id  = ?', $userId );
        $result = $this->_db->fetchRow($select);
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubgroup( $code,$groupId )
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 't_subgroup', 'COUNT(*) AS cnt' );
				$select->where( 'code  = ?', $code );
				$select->where( 'group_id  = ?', $groupId );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報に削除フラグが設定されているかチェックする（未使用）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubgroupDeleteFlg( $code,$groupId )
    {
						
				$select = $this->_db->select()->from( 't_subgroup', 'delete_flg' );
				$select->where( 'code  = ?', $code );
				$select->where( 'group_id  = ?', $groupId );
        $result = $this->_db->fetchRow($select);
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }






    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報をリセットする（未使用）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function resetSubgroup( $code )
    {
				$groupArray = array( '1', '2', '3','4', '5' );
				
				foreach( $groupArray as $group ){
				
       			// 有無チェック
						if( $this->isRegisteredSubgroup( $code,$group ) == true )
						{
								
								if( $this->isRegisteredSubgroupDeleteFlg( $code,$group ) == false )
								{	
										
						         // 更新データを連想配列にする
						        $data = array(
						                      'delete_flg'	=> '1'
						                );
										$target = array(
																	'code = ' . $code ,
																	'group_id = ' . $group
														);
						        // データを更新する
						        $this->_db->update( 't_subgroup', $data, $target );
										
								}
						}
				
				}
			}





    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function checkSubgroup( $info, $code, $groupArray )
    {
				$groupScan = array( '1', '2', '3','4','5'  );
				$idx = 0;
				
				foreach( $groupScan as $scan )
				{
					
					$bFind =false;
					foreach( $groupArray as $group )
					{
						if( $group == $scan )
						{
								$bFind =true;
								break;
						}
					}
					
					
					if( $bFind )
					{
	       			// 有無チェック
							if( $this->isRegisteredSubgroup( $code,$scan ) == true )
							{
							    // 登録データを連想配列にする
							    $subgroup = array(
																		'start_year'	=> $info['start_year'],
																		'end_year'		=> $info['end_year'],
																		'delete_flg'	=> '0'
									            );
								  $data = array(
										                'delete_flg'	=> '0'
								          );
									$target = array(
																		'code = ' 		. $code ,
																		'group_id = ' . $scan
																);
									$this->_db->update('t_subgroup', $subgroup, $target );
							}else
							{
							    // 登録データを連想配列にする
							    $subgroup = array(
																		'code'				=> $info['code'],
																		'group_id'		=> $scan,		
																		'start_year'	=> $info['start_year'],
																		'end_year'		=> $info['end_year'],
																		'delete_flg'	=> '0'
										            );
									$this->_db->insert('t_subgroup', $subgroup );
							}
					}else 
					{
		     			// 有無チェック
							if( $this->isRegisteredSubgroup( $code,$scan ) == true )
							{
								   // 更新データを連想配列にする
								  $data = array(
								                'delete_flg'	=> '1'
								          );
									$target = array(
																'code = ' 		. $code ,
																'group_id = ' . $scan
													);
								  // データを更新する
								  $this->_db->update( 't_subgroup', $data, $target );
									
							}
					}
					
					
					
				}
				
			}






    /**-------------------------------------------------------------------------------------------
     * 指定されたシラバスに属するシラバス情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedSyllabus($subjectId)
    {
        // ユーザ情報を取得する
        if ($subjectId === null) {
						
 						$select  	= $this->_db->select()->from( 't_subfile', array('year','file','id') );
		        $userInfo	= $this->_db->fetchAll($select);
						
        // IDが指定されていれば条件指定
        } else {
						
 						$select = $this->_db->select()->from( 't_subfile', array('year','file','id') );
						$select->where( 'code  = ?', $subjectId );
						$select->where( 'delete_flg  = ?', '0' );
		        $userInfo	= $this->_db->fetchAll($select);
						
        }
				
				
        return $userInfo;
				
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getFileName($year)
    {


        // グループ名称を取得する
        if ($year === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 't_subfile', 'file' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 't_subfile', 'file' );
						$sql->where( 'year  = ?', $year );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するシラバス情報を追加する
     *
     * @param array  $info  	 シラバス情報
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateSubjectAddsyllabus( $info, $deleteType)
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									//foreach( $userArray as $user )
									$code = $info['code'];
									$year = $info['year'];
									$file = $info['file'];
									{
									
       								// 重複チェック
											if( $this->isRegisteredSubsyllabus( $code,$year ) == true )
											{
													// 削除済みなら復活更新
													if( $this->isRegisteredSubsyllabusDeleteFlg( $code,$year ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
																						'file'				=> $file,
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'code = ' . $code ,
																						'year = ' . $year
																			);
															
											        // データを更新する
											        $this->_db->update( 't_subfile', $data, $target );
															
													}
											}else
											{
											        // 登録データを連想配列にする
											        $subfile = array(
																						'code'				=> $code,
																						'year'				=> $year,	
																						
																						'file'				=> $file,
																						'delete_flg'	=> $deleteType
											                );
															$this->_db->insert('t_subfile', $subfile );
											}
									
									
					        $data = array(
																'file'				=> $year .'/'. $file
					                );
									$target = array(
																'code = ' . $code
													);
				        	// データを更新する
			   					$this->_db->update( 'm_subject', $data, $target );
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				
    }

    /**-------------------------------------------------------------------------------------------
     * 指定されたシラバスに属する情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubsyllabus( $code,$year )
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 't_subfile', 'COUNT(*) AS cnt' );
				$select->where( 'code  = ?', $code );
				$select->where( 'year  = ?', $year );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定されたシラバス情報の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredSubsyllabusDeleteFlg( $code,$year )
    {
 				
				$select = $this->_db->select()->from( 't_subfile', 'delete_flg' );
				$select->where( 'code  = ?', $code );
				$select->where( 'year  = ?', $year );
        $result = $this->_db->fetchRow($select);
      	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }



    /**-------------------------------------------------------------------------------------------
     * シラバス情報に属するシラバス情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateSubjectDelsyllabus( $info, $code, $file, $deleteType )
    {
				
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				$target = array(
											'code = ' . $info['code'],
											'id  = '  . $info['id']
								);
				
        // データを更新する
        $this->_db->update( 't_subfile', $data, $target );
		
    }










    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getSubjectName($subjectId)
    {


        // グループ名称を取得する
        if ($subjectId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_subject', 'name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_subject', 'name' );
						$sql->where( 'code  = ?', $subjectId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserName($userId)
    {


        // グループ名称を取得する
        if ($userId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						$sql->where( 'user_id  = ?', $userId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }



    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($groupName)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_group', 'group_id' );
				$select->where( 'group_name  = ?', $groupName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : STAFF_ID;				//staff

    }



    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;

    }










}