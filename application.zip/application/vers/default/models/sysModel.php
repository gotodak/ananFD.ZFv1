<?php
/**
 * システムモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Config_Ini');
Zend_Loader::loadClass('Zend_Config_Writer_Ini');

class sysModel
{
    //private $_db;  					// データベースアダプタのハンドル
    private $_config;    			// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param  string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= new Zend_Config_Ini('../application/lib/config.ini', null, array('allowModifications' => true) );
				
    }



    /**-------------------------------------------------------------------------------------------
     * 設定情報リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getConfigData( )
    {
				
				
				$listArray = array();
				
				$listArray['basePath'] 	= $this->_config->global->basePath;
				$listArray['modulePath']= $this->_config->global->modulePath;
				$listArray['session'] 	= $this->_config->global->sessionSec;
				$listArray['count'] 		= $this->_config->view->countPerPage;
				$listArray['range'] 		= $this->_config->view->pageRange;
				$listArray['database']	= $this->_config->datasource->database->name;
				if( $this->_config->global->debugOn )
					$listArray['debug']			= 'true';
				else
					$listArray['debug']			= 'false';
				
				
        return $listArray;
    }

    /**-------------------------------------------------------------------------------------------
     * 設定情報リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function setConfigData( $listArray )
    {
				
				$this->_config->global->sessionSec	= $listArray['session'] 	;
				$this->_config->view->countPerPage	= $listArray['count'] 		;
				$this->_config->view->pageRange			= $listArray['range'] 		;
				$this->_config->global->debugOn			= $listArray['debug']			;
				
				
				
				$file = '../application/lib/config.ini';

				
			{
					$config = new Zend_Config( array(),1 );
					
					$config->global = array();
					$config->global->basePath			= '/ananfd/';
					$config->global->modulePath		= '/ananfd/';
					$config->global->sessionSec		= $listArray['session'];
					$config->global->debugOn			= false;
					
					$config->view = array();
					$config->view->countPerPage		= $listArray['count'];
					$config->view->pageRange			= $listArray['range'];
					
					$config->datasource = array();
					$config->datasource->database = array();
					$config->datasource->database->type			= 'pdo_mysql';
					$config->datasource->database->host			= 'localhost';
					$config->datasource->database->username	= 'gotoda';
					$config->datasource->database->password	= 'gotoda';
					$config->datasource->database->name			= $listArray['database'];
					
					$writer = new Zend_Config_Writer_Ini();
					$writer->write( $file, $config );
			}

    }



}