<?php
/**
 * menuモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';


class menuModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);
				
				
    }



    /**-------------------------------------------------------------------------------------------
     * 指導場所選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getPlaceList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '指導教員室';
				$listArray['2'] = '教員室';
				$listArray['3'] = '教室';
				$listArray['4'] = '廊下';
				$listArray['5'] = '正門';
				$listArray['6'] = '通用門';
				$listArray['7'] = '駐輪場';
				$listArray['8'] = '駐車場';
				$listArray['9'] = '学校校舎内';
				$listArray['10'] = '学校校舎外';
				$listArray['11'] = '学校敷地外';
				$listArray['12'] = '実験室';
				$listArray['13'] = '演習室';
				$listArray['14'] = '製図室';
				$listArray['15'] = '会議室';
				$listArray['16'] = 'セミナー室';
				$listArray['17'] = '処理演習室';
				$listArray['18'] = '総合情報処理室';
				$listArray['19'] = '男子便所';
				$listArray['20'] = '女子便所';
				$listArray['21'] = '男子更衣室';
				$listArray['22'] = '女子更衣室';
				$listArray['23'] = '学生寮';
				$listArray['24'] = '寮生食堂';
				$listArray['25'] = '売店';
				$listArray['26'] = '学生食堂';
				$listArray['27'] = '学生休憩室';
				$listArray['28'] = 'オーディオルーム';
				$listArray['29'] = '和室';
				$listArray['30'] = '研修室';
				$listArray['31'] = '視聴覚教室';
				$listArray['32'] = '保健室';
				$listArray['23'] = '事務室';
				$listArray['34'] = 'キャリア支援室';
				$listArray['35'] = '学生相談室';
				$listArray['36'] = '国際交流室';
				$listArray['37'] = '図書館';
				$listArray['38'] = '実験実習工場';
				$listArray['39'] = '内燃機関実験室';
				$listArray['40'] = 'テニスコート';
				$listArray['41'] = '学生集会所';
				$listArray['42'] = '第１体育館';
				$listArray['43'] = '第２体育館';
				$listArray['44'] = '体育器具庫';
				$listArray['45'] = '武道場';
				$listArray['46'] = 'プール';
				$listArray['47'] = '陸上競技場';
				$listArray['48'] = '野球場';
				$listArray['49'] = '合宿研修所';
				$listArray['50'] = '弓道場';
				
        return $listArray;
    }









    /**-------------------------------------------------------------------------------------------
     * 指導内容選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getCoachKindList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				

				$listArray['1'] = '身だしなみ';
				$listArray['2'] = '冬服規定';
				$listArray['3'] = '自転車二人乗り';
				$listArray['4'] = '無施錠';
				$listArray['5'] = '駐車・駐輪違反';
				$listArray['6'] = '信号無視';
				$listArray['7'] = '道路の斜行横断';
				$listArray['8'] = '無灯火';
				$listArray['9'] = '傘差し';
				$listArray['10'] = 'イヤホン装着';
				$listArray['11'] = '教室施錠';
				$listArray['12'] = '挨拶';
				$listArray['13'] = 'マナー全般';
				$listArray['14'] = '通学';
				$listArray['15'] = '学習態度';
				$listArray['16'] = 'カンニング';
				$listArray['17'] = '迷惑行為';
				$listArray['18'] = 'セクハラ';
				$listArray['19'] = 'いじめ';
				$listArray['20'] = '飲酒';
				$listArray['21'] = '喫煙';
				$listArray['22'] = '薬物乱用';
				$listArray['23'] = '粗暴行為';
				$listArray['24'] = '刃物等所持';
				$listArray['25'] = '金品不正要求';
				$listArray['26'] = '刃物等所持';
				$listArray['27'] = '性的いたずら';
				$listArray['28'] = '暴走行為';
				$listArray['29'] = '家出';
				$listArray['30'] = '無断外泊';
				$listArray['31'] = '深夜徘徊';
				$listArray['32'] = '怠学';
				$listArray['33'] = '不健全性的行為';
				$listArray['34'] = '不良交友';
				$listArray['35'] = '不健全娯楽';
				$listArray['36'] = 'その他不良行為';
				$listArray['37'] = '無免許・飲酒運転';
				$listArray['38'] = '交通違反';
				$listArray['39'] = '交通事故';
				$listArray['40'] = '無許可車両通学';
				$listArray['41'] = '暴言';
				$listArray['42'] = '差別的言動';
				$listArray['43'] = '盗撮';
				$listArray['44'] = '懲戒指導';
				$listArray['45'] = '注意';
				$listArray['46'] = '訓告';
				$listArray['47'] = '登校謹慎';
				$listArray['48'] = '自宅謹慎';
				$listArray['49'] = '停学';
				$listArray['50'] = '退学';
/*
				$listArray['51'] = '不登校';
				$listArray['52'] = 'けんか';
				$listArray['53'] = '逃亡・失踪';
				$listArray['54'] = '万引き';
				$listArray['55'] = '器物破損';
				$listArray['56'] = '窃盗・盗撮';
				$listArray['57'] = '暴行・傷害';
				$listArray['58'] = '懲戒指導';
				$listArray['59'] = 'その他';
				$listArray['60'] = '強盗';
				$listArray['61'] = '詐欺';
				$listArray['62'] = '恐喝';
				$listArray['63'] = '横領';
				$listArray['64'] = '売春';
				$listArray['65'] = '援助交際';
				$listArray['66'] = '自殺・殺人';
*/
				
        return $listArray;
    }






    /**-------------------------------------------------------------------------------------------
     * 面接時間リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getHoursList( $mode, $find )
    {
				
				$listArray = array( 	
														'0' =>   '0',
														'1' =>   '0:30',
														'2' =>   '1:00',
														'3' =>   '1:30',
														'4' =>   '2:00',
														'5' =>   '2:30',
														'6' =>   '3:00',
														'7' =>   '3:30',
														'8' =>   '4:00',
														'9' =>   '4:30',
														'a' =>   '5:00',
														'b' =>   '5:30',
														'c' =>   '6:00',
														'b' =>   '6:30',
														'e' =>   '7:00',
														'f' =>   '7:30'
										);
				
        return $listArray;
    }



    /**-------------------------------------------------------------------------------------------
     * 学習時間リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getStudyList( $mode, $find )
    {
				
				$listArray = array( 	
														'0' =>   '0',
														'1' =>   '0:30',
														'2' =>   '1:00',
														'3' =>   '1:30',
														'4' =>   '2:00',
														'5' =>   '2:30',
														'6' =>   '3:00',
														'7' =>   '3:30',
														'8' =>   '4:00',
														'9' =>   '4:30',
														'a' =>   '5:00',
														'b' =>   '5:30',
														'c' =>   '6:00',
														'b' =>   '6:30',
														'e' =>   '7:00',
														'f' =>   '7:30'
										);
				
        return $listArray;
    }



    /**-------------------------------------------------------------------------------------------
     * 出席状況リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getStatusList( $mode, $find )
    {
				
				$listArray = array( 	
														'0' =>   'なし',
														'1' =>   '注意',
														'2' =>   '警告',
														'3' =>   '危険',
														'4' =>   'アウト'
										);
				
        return $listArray;
    }


    /**-------------------------------------------------------------------------------------------
     * 学習支援ステータスリストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getStatus2List( $mode, $find )
    {
				
				$listArray = array( 	
														'0' =>   '未対応',
														'1' =>   '対応済'
										);
				
        return $listArray;
    }


    /**-------------------------------------------------------------------------------------------
     * 生活指導リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getCoachList( $mode, $find )
    {

				$listArray = array( 	
														'0' =>   'なし',
														'1' =>   '注意',
														'2' =>   '警告',
														'3' =>   '危険',
														'4' =>   'アウト'
										);
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 削除設定リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getDeleteList( $mode, $find )
    {
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '停止';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 地域リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getAreaList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
			
        if ($mode !== null)	{
	        if ($mode == '' )	$listArray['-1'] 		= '(四国)';
						else						$listArray['36-39'] = '四国';
				}
				$listArray['36'] = '　徳島';	//県';
				$listArray['37'] = '　香川';	//県';
				$listArray['38'] = '　愛媛';	//県';
				$listArray['39'] = '　高知';	//県';
				
        if ($mode !== null)	{
        if ($mode == '' )	$listArray['-2'] 		= '(近畿)';
					else						$listArray['26-30'] = '近畿';
					
				}
				$listArray['25'] = '　滋賀';	//県';
				$listArray['26'] = '　京都';	//府';
				$listArray['27'] = '　大阪';	//府';
				$listArray['28'] = '　兵庫';	//県';
				$listArray['29'] = '　奈良';	//県';
				$listArray['30'] = '　和歌山';	//県';
				
        if ($mode !== null)	{
        if ($mode == '' )	$listArray['-3'] 		= '(中国)';
					else						$listArray['31-35'] = '中国';
				}
				$listArray['31'] = '　鳥取';	//県';
				$listArray['32'] = '　島根';	//府';
				$listArray['33'] = '　岡山';	//府';
				$listArray['34'] = '　広島';	//県';
				$listArray['35'] = '　山口';	//県';
				
        if ($mode !== null)	{
        if ($mode == '' )	$listArray['-4'] 	 = '(関東)';
					else						$listArray['8-14'] = '関東';
				}
				$listArray['8']  = '　茨城';	//県';
				$listArray['9']  = '　栃木';	//県';
				$listArray['10'] = '　群馬';	//県';
				$listArray['11'] = '　埼玉';	//県';
				$listArray['12'] = '　千葉';	//県';
				$listArray['13'] = '　東京';	//都';
				$listArray['14'] = '　神奈川';	//県';
				
        if ($mode !== null)	{
        if ($mode == '' )	$listArray['-5'] 	  = '(九州・沖縄)';
					else						$listArray['40-47'] = '九州・沖縄';
				}
				$listArray['40'] = '　福岡';	//県';
				$listArray['41'] = '　佐賀';	//県';
				$listArray['42'] = '　長崎';	//県';
				$listArray['43'] = '　熊本';	//県';
				$listArray['44'] = '　大分';	//県';
				$listArray['45'] = '　宮崎';	//県';
				$listArray['46'] = '　鹿児島';	//県';
				$listArray['47'] = '　沖縄';	//県';
				
        if ($mode !== null)	{
        if ($mode == '' )	$listArray['-6'] 		= '(中部)';
					else						$listArray['15-24'] = '中部';
				}
				$listArray['15'] = '　新潟';	//県';
				$listArray['16'] = '　富山';	//県';
				$listArray['17'] = '　石川';	//県';
				$listArray['18'] = '　福井';	//県';
				$listArray['19'] = '　山梨';	//県';
				$listArray['20'] = '　長野';	//県';
				$listArray['21'] = '　岐阜';	//県';
				$listArray['22'] = '　静岡';	//県';
				$listArray['23'] = '　愛知';	//県';
				$listArray['24'] = '　三重';	//県';
				
        if ($mode !== null)	{
        if ($mode == '' )	$listArray['-7']  = '(北海道・東北)';
					else						$listArray['1-7'] = '北海道・東北';
				}
				$listArray['1'] = '　北海道';
				$listArray['2'] = '　青森';	//県';
				$listArray['3'] = '　岩手';	//県';
				$listArray['4'] = '　宮城';	//県';
				$listArray['5'] = '　秋田';	//県';
				$listArray['6'] = '　山形';	//県';
				$listArray['7'] = '　福島';	//県';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 検索対象リストを取得する（就職先管理）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getFieldList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['name'] = '名称';
				$listArray['comments'] = 'メモ';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 検索対象リストを取得する（学習支援）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getLearnList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['support'] = 'サポート';
				$listArray['require'] = '要望';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 検索対象リストを取得する（授業科目管理）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getField2List( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['code'] = '科目コード';
				$listArray['name'] = '授業科目名';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 検索対象リストを取得する（ユーザ）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getField3List( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['user_name'] = '氏名';
				$listArray['user_kana'] = 'ふりがな';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 検索対象リストを取得する（メンバー）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getField4List( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['member_name'] = '氏名';
				$listArray['member_kana'] = 'ふりがな';
				$listArray['member_id'] = '学籍番号';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 検索対象リストを取得する（メンバー）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getField5List( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['comments']  = '指導内容';
				$listArray['member'] 		= '学籍番号';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * ふりがなリストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getKanaList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['あ'] = 'あ行';
				$listArray['か'] = 'か行';
				$listArray['さ'] = 'さ行';
				$listArray['た'] = 'た行';
				$listArray['な'] = 'な行';
				$listArray['は'] = 'は行';
				$listArray['ま'] = 'ま行';
				$listArray['や'] = 'や行';
				$listArray['ら'] = 'ら行';
				$listArray['わ'] = 'わ行';
				$listArray['abc'] = '英数字';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 必修選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getReqList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '必修';
				$listArray['2'] = '選択';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 性別選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getSexList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '男';
				$listArray['2'] = '女';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 生息状態選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getConditionList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '在学';
				$listArray['2'] = '就学';
				$listArray['3'] = '就職';
				$listArray['4'] = '無職';
				$listArray['5'] = '消息不明';
				$listArray['6'] = '逝去';
				$listArray['7'] = '退学';
				$listArray['8'] = '除籍';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 前期後期選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getTermList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '通年';
				$listArray['2'] = '前期';
				$listArray['3'] = '後期';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 前期後期選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getUnitsList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] 	= '1';
				$listArray['2'] 	= '2';
				$listArray['3'] 	= '3';
				$listArray['4'] 	= '4';
				$listArray['10'] 	= '10';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * IRアンケート種別選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getIrKindList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '授業評価';
				$listArray['2'] = '学生実態';
				$listArray['3'] = '入学生';
				$listArray['4'] = '卒業生';
				$listArray['5'] = '企業';
				$listArray['6'] = '授業参観';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * クラブ種別選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getClubKindList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '体育局';
				$listArray['2'] = '文化局';
				$listArray['3'] = '同好会';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * グループ種別選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getGroupKindList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = 'クラス';
				$listArray['2'] = '非クラス';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 委員会（役職）の主任種別選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getChiefTypeList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				$listArray['1'] = '学科主任';
				$listArray['2'] = '学年主任';
				$listArray['3'] = '学級担任';
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 委員会リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getCommitteeList( $mode, $commArray )
    {
				
				$select = $this->_db->select();
				$column = array( 'comm_name', 'comm_id' );
				$select->from( 'm_committee', $column );
				$select->where( 'delete_flg  = ?', '0' );
        if ( $commArray != null )
				{
						 if ( count($commArray) )
								$select->where( 'comm_kind IN (?)', $commArray );
				}
				
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
					foreach( $result as $row ){
						$listArray[$row['comm_id']] = $row['comm_name'];
					}
				
        return $listArray;
    }



    /**-------------------------------------------------------------------------------------------
     * 委員会種別選択リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getCommitteeKindList( $mode, $find )
    {
				
				
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
        if ($find === null)
				{
						$listArray['1'] = '専門委員会';
						$listArray['2'] = '役職';
						$listArray['3'] = '委員会';
				} else {
						$listArray['3'] = '委員会';
					
				}
				
        return $listArray;
    }





    /**-------------------------------------------------------------------------------------------
     * ロール権限リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getRoleList( $mode, $find )
    {
				
				
        if ($find !== null)
				{
					$result = 'guest';
					if( $find['s_role'] !='0' ){
						switch( $find['s_role'] ){
							case '2':		$result = 'staff';		break;
							case '1':		$result = 'teacher';	break;
							default:  break;
						}
					}
	        return $result;
				}
				else{
					$listArray = array();
	        if ($mode !== null)
					{
							$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
					}
					
					$listArray['1'] = '教員';
					$listArray['2'] = '職員';
					
					
	        return $listArray;
				}
				
    }




    /**-------------------------------------------------------------------------------------------
     * 年度リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getYearList( $mode, $find, $ext = null )
    {
				
				
				$listArray = array();
				
        if ($find !== null)
				{
						if( $find['s_year'] =='-1' ){
							$listArray['0'] = 'すべて';	// 'すべて'=>search, ''=>select
						}else{
							$y = $find['s_year'];
							$listArray[$y] = ($y) .'年度';
						}
					
				}else{
					
	        if ($mode !== null)
					{
							$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
					}
					
					$dt = getdate();
					$y	= $dt['year'];
					$m	= $dt['mon'];
					for( $i=0; $i<10; $i++ ){ 
						$listArray[$y-$i] = ($y-$i) .'年度';
					}
					
	        if ($ext !== null)
					{
							$listArray['9999'] = '－';	// マスタ設定 > 組織管理 > グループ管理
					}
				}
        
        return $listArray;
    }


    /**-------------------------------------------------------------------------------------------
     * 学年リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getGradeList( $mode, $find )
    {
				
				$listArray = array();
	      if ($mode !== null)
				{
							$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
        if ($find !== null)
				{
						if( $find['s_grade'] !='0' ){
							switch( $find['s_grade'] ){
								case '1':
									$listArray['1'] = '１学年';	break;
								case '2':
									$listArray['2'] = '２学年';	break;
								case '3':
									$listArray['3'] = '３学年';	break;
								case '4':
									$listArray['4'] = '４学年';	break;
								case '5':
									$listArray['5'] = '５学年';	break;
								default:
									break;
							}
						}else{
									$listArray['1'] = '１学年';
									$listArray['2'] = '２学年';
									$listArray['3'] = '３学年';
									$listArray['4'] = '４学年';
									$listArray['5'] = '５学年';
						}
	        	if ($mode !== null)
						{
							$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
						}
				}
				else{
					$listArray['1'] = '１学年';
					$listArray['2'] = '２学年';
					$listArray['3'] = '３学年';
					$listArray['4'] = '４学年';
					$listArray['5'] = '５学年';
				}
        return $listArray;
				
    }


    /**-------------------------------------------------------------------------------------------
     * グループリストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getGroupList( $mode, $find, $delDisp=false )
    {
				
				$select = $this->_db->select();
				$column = array( 'group_name', 'group_id' );
				$select->from( 'm_group', $column );
				if( $delDisp==false )
						$select->where( 'delete_flg  = ?', '0' );
        if ($find !== null)
				{
						if( $find['s_kind'] !='0' )
								$select->where( 'group_kind  = ?', $find['s_kind'] );
						if( $find['s_group'] !='0' )
								$select->where( 'group_id  = ?', $find['s_group'] );
				}
				
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
					foreach( $result as $row ){
						$listArray[$row['group_id']] = $row['group_name'];
					}
				
        return $listArray;
    }



    /**-------------------------------------------------------------------------------------------
     * 職名リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getJobList( $mode, $find )
    {
				
				$select = $this->_db->select();
				$column = array( 'job_name', 'job_id' );
				$select->from( 'm_job', $column );
				$select->where( 'delete_flg  = ?', '0' );
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
					foreach( $result as $row ){
						$listArray[$row['job_id']] = $row['job_name'];
					}
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * クラブリストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getClubList( $mode, $find )
    {
				
				$select = $this->_db->select();
				$column = array( 'club_name', 'club_id' );
				$select->from( 'm_club', $column );
				$select->where( 'delete_flg  = ?', '0' );
        if ($find !== null)
				{
						if( $find['s_kind'] !='0' )
								$select->where( 'kind  = ?', $find['s_kind'] );
				}
				
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
					foreach( $result as $row ){
						$listArray[$row['club_id']] = $row['club_name'];
					}
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 就職先リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getEmployList( $mode, $find )
    {
				
        // 就職先情報を取得する
				$select = $this->_db->select();
				
				$column = array( 't1.name', 't1.employ' );
				$table  = array( 't1' => 'm_employment' );
				$select->from( $table, $column );
				
				$column = array( 't2.group_id' );
				$table  = array( 't2' => 't_employgroup' );
				$select->joinLeft( $table, 't1.employ = t2.employ', $column );
				
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
        if ($find !== null)
				{
						if( $find['s_group'] !='0' )
								$select->where( 't2.group_id  = ?', $find['s_group'] );
				}
				
				$select->order( 't1.kana' );
				
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
					foreach( $result as $row ){
						$listArray[$row['employ']] = $row['name'];
					}
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目リストを取得する（未使用）
     *
     * @param  string $mode			モード
     * @return array	$result		グループリスト
     */
    public function getSubjectList( $mode, $find )
    {
				
        // 就職先情報を取得する
				$select = $this->_db->select();
				
				$column = array( 't1.name' );
				$table  = array( 't1' => 'm_subject' );
				$select->from( $table, $column );
				
				$column = array( 't2.code' );
				$table  = array( 't2' => 't_subgroup' );
				$select->joinLeft( $table, 't1.code = t2.code', $column );
				
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
        if ($find !== null)
				{
						if( $find['s_group'] !='0' ){
								$select->where( 't2.group_id  = ?', $find['s_group'] );
						}
						if( $find['s_grade'] !='0' ){
								$select->where( 't1.grade  = ?', $find['s_grade'] );
						}
						if( $find['s_req'] !='0' ){
								$select->where( 't1.require = ?', $find['s_req'] );
						}
						if( $find['s_styear'] !='0' ){
								$styear = $find['s_styear'].'-04-01';
								$select->where( 't1.start_year <= ?', $styear );
								$select->where( 't1.end_year > ?', $styear );
						}
				}
				
				$select->order( 'code' );		// DESC
				
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
					foreach( $result as $row ){
						$listArray[$row['code']] = $row['name'];
					}
				
        return $listArray;
    }




    /**-------------------------------------------------------------------------------------------
     * クラス名称リストを取得する
     *
     * @param  string $mode			モード
     * @return array	$result		クラス名称リスト
     */
    public function getClassList( $mode, $find )
    {
				
				$select = $this->_db->select();
				$column = array( 'class_name', 'class_id' );
				$select->from( 'm_class', $column );
				$select->where( 'delete_flg  = ?', '0' );
        if ($find !== null)
				{
						if( $find['s_class'] !='0' )
								$select->where( 'class_id  = ?', $find['s_class'] );
				}
				
				// 全レコードの取得
				$result = $this->_db->fetchAll($select);
				$listArray = array();
        if ($mode !== null)
				{
						$listArray['0'] = $mode;	// 'すべて'=>search, ''=>select
				}
				
				foreach( $result as $row ){
						$listArray[$row['class_id']] = $row['class_name'];
				}
				
        return $listArray;
		}








}
