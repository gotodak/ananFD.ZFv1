<?php
/**
 * ラーニングモデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

// モジュールをロードする
require_once '../application/lib/anandef.php';




class graduateModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * 卒業生情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    public function getGraduatePage( $memberId, $find, $bGraduate = true )
    {
				
        // ユーザ情報を取得する
				$select = $this->_db->select();
				
				$column = array( 't1.member_id', 't1.member_name', 't1.member_kana', 't1.group_id', 't1.start_year', 't1.end_year', 't1.school_name', 't1.sex', 't1.kind', 't1.modified_date' );
				$table  = array( 't1' => 'm_member' );
				$select->from( $table, $column );
				
				$column = array( 't2.graduate_id', 't2.state', 't2.employName', 't2.employKana', 't2.employUrl', 't2.employArea', 't2.contact_1', 't2.contact_2', 't2.address', 't2.familyName', 't2.comments', 't2.modified_date'  );
				$table  = array( 't2' => 'm_graduate' );
				$select->joinLeft( $table, 't1.member_id = t2.member_id', $column );
				
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				if( $bGraduate )
						$select->where( 't1.kind = ?', '1' );				// AND
				else
						$select->where( 't1.kind = ?', '0' );				// AND
				
        if ($find != null)
						{
				        // 検索項目が指定されていれば条件指定
								
								if( $find['s_group'] !='0' )
										$select->where( 't1.group_id  = ?', $find['s_group'] );
								if( $find['s_styear'] !='0' ){
										$styear = $find['s_styear'].'-04-01';
										$edyear = $styear +1;
										$edyear = $edyear.'-03-31';
										$select->where( 't1.start_year >= ?', $styear );
										$select->where( 't1.start_year <= ?', $edyear );
										//$select->where( 't1.end_year >= ?', $edyear );
								}
								if( $find['s_edyear'] !='0' ){
										$styear = $find['s_edyear'];
										$styear = $styear.'-04-01';
										$edyear = $find['s_edyear'] +1;
										$edyear = $edyear.'-03-31';
										$select->where( 't1.end_year >= ?', $styear );
										$select->where( 't1.end_year <= ?', $edyear );
								}
								
								if( $find['s_keyword'] !='' ){
									if( $find['s_field'] =='code' || $find['s_field'] =='name' )
										$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
									else
										$select->where( 't1.name LIKE ?',   "%{$find['s_keyword']}%" );
								}
								
								$strReg = getRegStr($find['s_kana']);
								if( $strReg != '' ) {
										$select->where( 't1.member_kana REGEXP ?', $strReg );		// AND
										$select->order( 't1.member_kana' );
								}
								if( isset($find['s_state']) && $find['s_state'] !='0' ){
										$select->where( 't2.state = ?', $find['s_state'] );
								}
								
								$select->order( 't1.member_id' );		// DESC
				}
				
				
				
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				$userInfo = $select;
				
				
				return $userInfo;
		}




    /**-------------------------------------------------------------------------------------------
     * 卒業生情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getGraduateId( $graduateId )
    {
				
        if ($graduateId === null) {
					$graduateInfo = array();
					$graduateInfo['graduate_id'] = 0;
					$graduateInfo['member_id'] = 99;
					
				}
				else {
		        // ユーザ情報を取得する
						$select = $this->_db->select();
						
						$column = array( 't1.member_id', 't1.member_name', 't1.member_kana', 't1.group_id', 't1.start_year', 't1.end_year', 't1.school_name', 't1.sex', 't1.kind', 't1.modified_date' );
						$table  = array( 't1' => 'm_member' );
						$select->from( $table, $column );
						
						$column = array( 't2.graduate_id', 't2.employ_id', 't2.state', 't2.employName', 't2.employKana', 't2.employUrl', 't2.employArea', 't2.contact_1', 't2.contact_2', 't2.address', 't2.familyName', 't2.comments', 't2.modified_date'  );
						$table  = array( 't2' => 'm_graduate' );
						$select->joinLeft( $table, 't1.member_id = t2.member_id', $column );
						
						$select->where( 't1.delete_flg  = ?', '0' );
						$select->where( 't2.delete_flg  = ?', '0' );
						$select->where( 't1.kind = ?', '1' );				// AND
						
						$select->where( 't2.graduate_id  = ?', $graduateId );
						
	        	$graduateInfo = $this->_db->fetchRow( $select );
					
				}
				
        return $graduateInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 卒業生情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registGraduate( $info,  $memberArray, $deleteType )
    {
				$count = 0;
				
 				if( $memberArray === null ){
            return $count;
        }
				
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						foreach( $memberArray as $member ){
							
	       				//重複チェック
	        			$graduate = $this->getRegisteredGraduate($member); 
	        			if ( $graduate != 0 ) 
								{
	            			
										$data2 = array(
																'member_id'		=> $member,
																'state'				=> $info['state'],
																'delete_flg'	=> $deleteType
									        );
										$target = array(
																'graduate_id = '	 . $graduate
													);
										// データを更新する
										$this->_db->update( 'm_graduate', $data2, $target );
	        			}
								else 
								{
										
					        	// 登録データを連想配列にする
					        	$data = array(
																'member_id'		=> $member,
																'state'				=> $info['state'],
																
																'delete_flg'	=> $deleteType
					                );
										// ユーザ情報を登録する
										$this->_db->insert('m_graduate', $data );
								}
								
								
								$data2 = array(
		                     			  'end_year'  	=> $info['end_year'],
									              'kind'				=> $info['kind'],		
									              'grade'				=> $info['grade'],	
									              'conditions'	=> $info['state'] 	
									        );
								$target = array(
																'member_id = '	 . $member
													);
								// データを更新する
								$this->_db->update( 'm_member', $data2, $target );
								
								$count++;
						}
									
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $count;
		
    }






    /**-------------------------------------------------------------------------------------------
     * ★☆卒業生情報を更新する★☆
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateGraduate( $info, $graduateId, $deleteType)
    {
				
				$lastId = 0;
				
 				if( $graduateId == "" ){
            return $lastId;
        }
        // 登録データを連想配列にする
				
        $data = array(
											'state'				=> $info['state'],
											'employName'	=> $info['employ_name'],
											
											'contact_1'		=> $info['contact_1'],
											'contact_2'		=> $info['contact_2'],
											'familyName'	=> $info['family_name'],
											'comments'		=> $info['comments'],
											
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						$target = array(
													'graduate_id = ' . $graduateId
										);
	        	// データを更新する
   					$this->_db->update( 'm_graduate', $data, $target );
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
					
    }



    /**-------------------------------------------------------------------------------------------
     * 指定された卒業生情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function getRegisteredGraduate($member)
    {
				$select = $this->_db->select()->from( 'm_graduate', 'COUNT(*) AS cnt' );
				$select->where( 'member_id  = ?', $member );
				$select->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_graduate', 'graduate_id' );
						$sql->where( 'member_id  = ?', $member );
						$sql->where( 'delete_flg  = ?', '0' );
        		$graduateId = $this->_db->fetchOne($sql);
						
            return $graduateId;
        } else {
            return 0;
        }
    }







    /**-------------------------------------------------------------------------------------------
     * 卒業生情報に属する就職先情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateGraduateAddemploy( $graduateId, $employArray )
    {
				
				$lastId = 0;
				
 				if( $graduateId == "" ){
            return $lastId;
        }
       	// 重複チェック
 				if( count($employArray) != 1 )
				{
            return $lastId;
        }
				$employ = $employArray[0];
				{
				
        	// 登録データを連想配列にする
					
        		$data = array(
											'employ_id'			=> $employ
                );
						
						
						
						// トランザクションの開始する
						$this->_db->beginTransaction();
						// トランザクション内での処理内容を定義する
						try {
								
								$target = array(
															'graduate_id = ' . $graduateId
												);
			        	// データを更新する
		   					$this->_db->update( 'm_graduate', $data, $target );
								
								// 成功したらコミットする
								$this->_db->commit();
											
							// エラーが発生したらロールバックする
							} catch (Exception $e ) {
										$this->_db->rollBack();
										echo '処理が失敗したのでキャンセルしました。';
							}
							
			        return $lastId;
				}
				
    }














    /**-------------------------------------------------------------------------------------------
     * 指定された学習支援に属するリクエスト情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredLearnemploy( $learn,$employ )
    {
				
        // 登録済みかチェックする
				$select = $this->_db->select();
				$select->from( 't_learnemploy', 'COUNT(*) AS cnt' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'employ_id  = ?', $employ );
        $result = $this->_db->fetchRow($select);
				
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 追加教員１を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getLearnUser1($learn)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_learning', 'user_1' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 面接学年を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getLearnGrade($learn)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_learning', 'grade' );
				$select->where( 'learn_id  = ?', $learn );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 0;
				
    }




    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserName($userId)
    {
				
        // グループ名称を取得する
        if ($userId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						$sql->where( 'user_id  = ?', $userId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
		
    }




    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザが登録されているかチェックする
     * 
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isAllowLearnuser( $userId, $result )
    {
				
 				if( $result == null || $userId == null ){
            return false;
        }
            return true;
				
    }




    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId($groupName)
    {
			
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_group', 'group_id' );
				$select->where( 'group_name  = ?', $groupName );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : STAFF_ID;				//staff
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * グループ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getGroupName($groupId)
    {
				
        // グループ名称を取得する
        if ($groupId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_group', 'group_name' );
						$sql->where( 'group_id  = ?', $groupId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }


    /**-------------------------------------------------------------------------------------------
     * クラス名を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getClassName($classId)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 'm_class', 'class_name' );
				$select->where( 'class_id  = ?', $classId );
				$select->where( 'delete_flg  = ?', '0' );		// AND
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : null;
				
    }



    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getClassId( $grade,$groupId )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 'm_class', 'class_id' );
				$select->where( 'group_id  = ?', $groupId );
				$select->where( 'grade  = ?', $grade );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
				
			
    }









}