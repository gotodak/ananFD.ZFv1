<?php
/**
 * ACLモデル
 *
 * ※フロントコントローラ(index.html)で使用
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Db');
Zend_Loader::loadClass('Zend_Registry');
Zend_Loader::loadClass('Zend_Controller_Action');

Zend_Loader::loadClass('Zend_Config_Ini');

class aclModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param  string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);
    }




    /**-------------------------------------------------------------------------------------------
     * ACL情報を取得する
     *
     * @param  string $controller コントローラ名
     * @param  string $action     アクション名
     * @param  string $module     モジュール名
     * @return string             リソース名
     */
    public function get($controller, $action, $module = 'default')
    {
				$select = $this->_db->select()->from( 'm_acl', 'resource' );
				$select->where( 'module  = ?', $module );
				$select->where( 'controller  = ?', $controller );
				$select->where( 'action  = ?', $action );
				$select->where( 'delete_flg  = ?', '0' );
        $ret = $this->_db->fetchOne($select);
        if (!$ret) {
            throw new Zend_Exception(__FILE__ . '(' . __LINE__ . '): ' . 'リソース情報が見つかりません。('. $controller .'/' . $action . ')'. $ret );
				
        }
				
        return ($ret == null) ? false : $ret;
    }



    /**-------------------------------------------------------------------------------------------
     * 多重ログインのチェックを行う
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isLoginUser($userId)
    {
				$select = $this->_db->select()->from( 't_login', 'modified_date' );
				$select->where( 'user_id  = ?', $userId );
        $time = $this->_db->fetchOne($select);
				if( $time == null )	return false;
				
				$now	 = time();
				$login = strtotime($time);	//strtotime('2011-08-18 11:54:11)'
				$sec   = ( $now - $login );
if( $this->_config->global->debugOn ){
	var_dump('time:');
	var_dump($now);
	var_dump('login:');
	var_dump($login);
	var_dump('=>');
	var_dump($sec);
}
				if( $sec > $this->_config->global->sessionSec )
				{
						$this->deleteLoginUser($userId);
						return false;
				}
				
				return true;
        
    }




    /**-------------------------------------------------------------------------------------------
     * ログインユーザ情報を登録する
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function registLoginUser($userId)
    {
				$lastId = 0;
				$deleteType = '0';
				
 				if( $userId === null ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isLoginUser($userId) != false)
				{
					 $this->updateLoginUser($userId);
           return $lastId;
        }
				else{
					
	        // 登録データを連想配列にする
	        $data = array('user_id'    => $userId,
	                      'delete_flg' => $deleteType
	                );
					
					// ユーザ情報を登録する
					$this->_db->insert('t_login', $data );
				  // 登録したデータの member_id を取得する
					$lastId = $this->_db->lastInsertId('user_id');
					
		      return $lastId;
				}
    }

    /**-------------------------------------------------------------------------------------------
     * ログインユーザ情報を更新する
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function updateLoginUser($userId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '0'
                );
				
        // データを更新する
        $this->_db->update( 't_login', $data, 'user_id = ' . $userId );
				
    }

    /**-------------------------------------------------------------------------------------------
     * ログインユーザ情報を削除する
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function deleteLoginUser($userId)
    {
				
       // ゆーざ情報を削除する
       $this->_db->delete('t_login', 'user_id = ' . $userId);
if( $this->_debugOn ){
			var_dump('user_id = ');
			var_dump($userId);
}

    }






}