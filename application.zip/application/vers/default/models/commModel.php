<?php
/**
 * コミッティー（委員会）モデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */



// コンポーネントをロードする
Zend_Loader::loadClass('Zend_Db');
Zend_Loader::loadClass('Zend_Registry'); 
Zend_Loader::loadClass('Zend_Config_Ini'); 

// モデルをロードする

// モジュールをロードする
require_once '../application/lib/anandef.php';




class commModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }




    /**-------------------------------------------------------------------------------------------
     * グループ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getCommPage( $find, $delDisp=false )
    {
				
        // ユーザ情報を取得する
        if ($find == null)
				{
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select = $select->from( 'm_committee' );
						if( $delDisp==false )
							$select->where( 'delete_flg  = ?', '0' );
						$userInfo = $select;
						
        } else {
        // 検索項目が指定されていれば条件指定
						
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						// from() メソッドを追加する
						$select = $select->from( 'm_committee' );
						//$select->where( 'group_id  = ?', '2' );
						if( $delDisp==false )
								$select->where( 'delete_flg  = ?', '0' );				// AND
						
						if( $find['s_keyword'] !='' )
								$select->where( 'comm_name LIKE ?',   '%'.$find['s_keyword'].'%' );
						
						if( $find['s_kind'] !='0' )
								$select->where( 'comm_kind  = ?', $find['s_kind'] );
						
						
						$select->order( 'comm_id' );
						$userInfo = $select;
						
        }	
				
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $userInfo = $this->_db->fetchAll( $userInfo );
				
				return $userInfo;
			

		}



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getCommId( $commId )
    {
				
 				if( $commId == null ){
            return null;
        }
				
				$sql = $this->_db->select()->from( 'm_committee' );
				$sql->where( 'comm_id  = ?', $commId );
				//$sql->where( 'delete_flg  = ?', '0' );
        $userInfo = $this->_db->fetchRow($sql);
        return $userInfo;
        
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registComm( $info, $commId, $session )
    {
				$lastId = 0;
				
 				if( $info['comm_name'] == '' ){
            return $lastId;
        }
       	// 重複チェック
        if ($this->isRegisteredComm($info['comm_name']) == true)
				{
            return $lastId;
        }
				
        // 登録データを連想配列にする
        $data = array('comm_name' 	=> $info['comm_name'],
                      'comm_kind'		=> $info['comm_kind'],
                      'delete_flg'	=> '0'
                );
				
				
				// ユーザ情報を登録する
				$this->_db->insert('m_committee', $data );
			  // 登録したデータの user_id を取得する
				$lastId = $this->_db->lastInsertId();


/**/
				if( !is_null($session) ){
						$user2Array = array();
								array_push( $user2Array, 
														$session->userId );
						$this->updateCommAdduser( $lastId, $user2Array, $session );
				}
/**/

				
	      return $lastId;
		
    }


    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateComm( $info, $commId, $deleteType)
    {
        // 更新データを連想配列にする
        $data = array('comm_name' 	=> $info['comm_name'],
                      'comm_kind'		=> $info['comm_kind'],
                      'delete_flg'	=> $deleteType
                );
				
        // データを更新する
        $this->_db->update( 'm_committee', $data, 'comm_id = ' . $commId );
		
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteComm($commId)
    {
         // 更新データを連想配列にする
        $data = array(
                      'delete_flg'	=> '1'
                );
				
        // データを更新する
        $this->_db->update( 'm_committee', $data, 'comm_id = ' . $commId );
				
   }





    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCommAdduser( $commId, $userArray, $session )
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
									foreach( $userArray as $user ){
									
       								// 重複チェック
											if( $this->isRegisteredCommuser( $commId,$user ) == true )
											{
													
													if( $this->isRegisteredCommuserDeleteFlg( $commId,$user ) == true )
													{	
															
											         // 更新データを連想配列にする
											        $data = array(
											                      'delete_flg'	=> '0'
											                );
															$target = array(
																						'comm_id = ' . $commId ,
																						'user_id = ' . $user
																			);
											        // データを更新する
											        $this->_db->update( 't_commuser', $data, $target );
															
													}
											}else
											{
															//$deleteType = '0';
										        // 登録データを連想配列にする
											        $commuser = array(
																						'comm_id'			=> $commId,
																						'user_id'			=> $user,	
																						
																						'delete_flg'	=> '0'
											                );
															$this->_db->insert('t_commuser', $commuser );
											}
										
/**/
										if( $user >= USER_ID ){
												$role = $this->getCommuserMaxlevel( $user, $commId, false, $session );
												if( $role != null ){
														// 更新データを連想配列にする
														$data = array(
																					'role' 		=> $role
														        );
														// データを更新する
														$this->_db->update( 't_user', $data, 'user_id = ' . $user );
												}
										}
/**/
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				return $role;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCommDeluser( $commId, $userId, $session )
    {
				$role = null;
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						if( $this->getCountCommuser( $commId,$userId ) > 1 ){
						
				         // 更新データを連想配列にする
				        $data = array(
				                      'delete_flg'	=> '1'
				                );
								$target = array(
															'comm_id = ' . $commId ,
															'user_id = ' . $userId
												);
								
				        // データを更新する
				        $this->_db->update( 't_commuser', $data, $target );
								
/**/						
								if( $userId >= USER_ID ){
										$role = $this->getCommuserMaxlevel( $userId, $commId, true, $session );
										if( $role != null ){
												// 更新データを連想配列にする
												$data2 = array(
																			'role' 		=> $role
												        );
												// データを更新する
												$this->_db->update( 't_user', $data2, 'user_id = ' . $userId );
										}
								}
/**/
								
						}
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				return $role;
				
    }

    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザが属する委員会の最大レベルを取得するする（指定された委員会を除いた）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function getCommuserMaxlevel( $userId, $commId, $bDel = false, $session =null )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$column = array( 'MAX(t1.comm_level) AS max', 'COUNT(*) AS cnt' );
				$table  = array( 't1' => 'm_committee' );
				$select->from( $table, $column );
				/**/
				$column = array( 't2.user_id' );
				$table  = array( 't2' => 't_commuser' );
				$select->joinLeft( $table, 't1.comm_id = t2.comm_id', $column );
				/**/
				
				$select->where( 't2.user_id  = ?', $userId );
				
				if( $bDel ) {
						$select->where( 't1.comm_id NOT IN (?)', $commId );
				}
				
				$select->where( 't1.delete_flg  = ?', '0' );
				$select->where( 't2.delete_flg  = ?', '0' );
				
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $result = $this->_db->fetchRow( $select );			//$result['cnt']
				
				$level	= 0;
				if( $result['cnt'] > 0 ){				// 委員会設定無し $result['max']=NULL
						$level = $result['max'];
				}
				
				if( $bDel == false ){
						$level2	= $this->getCommLevel( $commId );
						if( $level < $level2 ){
								$level = $level2;
						}
				}


				$role = 'guest';
				switch( $level ){
					case COMM_LEVLE_GUEST:
						$sql = $this->_db->select()->from( 'm_user', 'kind' );
						$sql->where( 'user_id  = ?', $userId );
						$kind = $this->_db->fetchOne($sql);
						if( $kind==USER_KIND_TEACHER )	$role = 'teacher';
								else												$role = 'staff';
						break;
					case COMM_LEVLE_STAFF:		$role = 'staff';		break;
					case COMM_LEVLE_USER:			$role = 'user';			break;
					case COMM_LEVLE_TEACHER:	$role = 'teacher';	break;
					case COMM_LEVLE_CHIEF:		$role = 'chief';		break;
					case COMM_LEVLE_MANAGER:	$role = 'manager';	break;
					case COMM_LEVLE_MASTER:		$role = 'master';		break;
					case COMM_LEVLE_ADMIN:		$role = 'admin';		break;
					default:
						break;
				}

				if( !is_null($session) ){
						if( $session->userId == $userId ) {
					  		$session->userLevel	= $role;
						}
				}

				return $role;
    }



    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に属するユーザ登録数を取得する
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function getCountCommuser( $commId,$userId )
    {
				

 				if( $commId == null || $userId == null ){
            return 0;
        }
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 'm_committee', 'comm_kind' );
				$select->where( 'comm_id  = ?', $commId );
				$select->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchOne( $select );
       	if ( $result == COMM_KIND_USER ) {
            return 2;
        }
				
				$sql = $this->_db->select()->from( 't_commuser', 'COUNT(*) AS cnt' );
				$sql->where( 'comm_id  = ?', $commId );
				$sql->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchRow($sql);
       	return $result['cnt'];

				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に属するユーザ登録数を取得する
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function getCommLevel( $commId )
    {
				

 				if( $commId == null ){
            return 0;
        }
				
				$sql = $this->_db->select()->from( 'm_committee', 'comm_level' );
				$sql->where( 'comm_id  = ?', $commId );
        $result = $this->_db->fetchOne($sql);
       	return $result;

				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された権限の委員会に属するユーザが登録されているかチェックする
     *  （原則、COMM_KIND_USER は、チェックしない）
     *  主に表示アクションコマンドの利用有無を調べる
     * 
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isAllowCommuser( $userId, $commId )
    {
				
 				if( $commId == null || $userId == null ){
            return false;
        }
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 'm_committee', 'comm_kind' );
				$select->where( 'comm_id  = ?', $commId );
				$select->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchOne( $select );
       	if ( $result == COMM_KIND_USER ) {				// ユーザ委員会はチェックしない
            return true;
        }
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 't_commuser', 'id' );
				$select->where( 'comm_id  = ?', $commId );
				$select->where( 'user_id  = ?', $userId );
				$select->where( 'delete_flg  = ?', '0' );
        $result = $this->_db->fetchOne( $select );
       	if ( $result == null) {
            return false;
        } else {
            return true;
        }
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された権限の委員会に属するユーザが登録されているかチェックする
     * 
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isAllowCommUsers( $userId, $commArray )
    {
				
 				if( $commArray == null || $userId == null ){
            return false;
        }
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 't_commuser', 'id' );
				$select->where( 'comm_id IN (?)', $commArray );
				$select->where( 'user_id  = ?', $userId );
				$select->where( 'delete_flg  = ?', '0' );
				$result = $this->_db->fetchCol( $select );
				if ( count($result)  ) {
				   	return true;
				} else {
						return false;
				}
    }




    /**-------------------------------------------------------------------------------------------
     *  指定された権限の委員会に属するメンバーかどうかチェックする
     *
     * @param  string $mail     メールアドレス
     * @param  string $password パスワード
     * @return stirng|boolean   成功の場合ロール、失敗ならfalse
     */
    public function isAllowCommLevelUsers( $userId, $commArray )
    {
				
 				if( $commArray == null || $userId == null ){
            return false;
        }
				

				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 'm_committee', 'comm_id' );
				$select->where( 'comm_level IN (?)', $commArray );
				$select->where( 'delete_flg  = ?', '0' );
		    $comm2Array = $this->_db->fetchCol( $select );
				if( is_array($comm2Array) ){
						// Zend_Db_Selectオブジェクトを作成する
						$select = $this->_db->select();
						$select->from( 't_commuser', 'id' );
						$select->where( 'user_id  = ?', $userId );
						$select->where( 'comm_id IN (?)', $comm2Array );
						$select->where( 'delete_flg  = ?', '0' );
				    $result = $this->_db->fetchCol( $select );
				   	if ( count($result)  ) {
				    		return true;
				    }
				}
				
				return false;

		}



    /**-------------------------------------------------------------------------------------------
     * 指定されたユーザが同種役職に登録されているかチェックする
     * 
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isDuplicateCommuser( $commId, $userArray )
    {
				
				if( $commId <=9 ){
					$minId = $commId;
					$maxId = $commId;
				}elseif( $commId <=14 ){
					$minId = 10;
					$maxId = 14;
				}elseif( $commId <=19 ){
					$minId = 15;
					$maxId = 19;
				}elseif( $commId <=39 ){
					$minId = 20;
					$maxId = 39;
				}else{
					return false;
				}

				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				$select->from( 't_commuser', 'id' );
				$select->where( 'user_id IN (?)', $userArray );
				$select->where( 'comm_id >= ?', $minId );
				$select->where( 'comm_id <= ?', $maxId );
				$select->where( 'delete_flg  = ?', '0' );
		    $result = $this->_db->fetchCol( $select );
		   	if ( count($result)  ) {
		    		return true;
		    }

				
				return false;
				
				
				return false;
				
    }






    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に属するユーザが登録されているかチェックする（削除済みも入れる）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCommuser( $commId,$userId )
    {
				
        // 登録済みかチェックする
				$sql = $this->_db->select();
				$sql->from( 't_commuser', 'COUNT(*) AS cnt' );
				$sql->where( 'comm_id  = ?', $commId );
				$sql->where( 'user_id  = ?', $userId );
        $result = $this->_db->fetchRow($sql);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
        
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCommuserDeleteFlg( $commId,$userId )
    {
				
				$sql = $this->_db->select();
				$sql->from( 't_commuser', 'delete_flg' );
				$sql->where( 'comm_id  = ?', $commId );
				$sql->where( 'user_id  = ?', $userId );
        $result = $this->_db->fetchRow($sql);
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
        
    }




















    /**-------------------------------------------------------------------------------------------
     * 指定された委員会名称が登録されているかチェックする（削除済みも入れる）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredComm($commName)
    {
				
        // 登録済みかチェックする
				$sql = $this->_db->select()->from( 'm_committee', 'COUNT(*) AS cnt' );
				$sql->where( 'comm_name  = ?', $commName );
        $result = $this->_db->fetchRow($sql);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
        
    }




    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getCommName( $commId )
    {


        // グループ名称を取得する
        if ($commId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_committee', 'comm_name' );
						
						$commName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_committee', 'comm_name' );
						$sql->where( 'comm_id  = ?', $commId );
						
        		$commName = $this->_db->fetchOne( $sql );
						
        }
        return $commName;
				
    }




    /**-------------------------------------------------------------------------------------------
     * ユーザ情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getCommUserId( $commId )
    {
				
 				if( $commId == null ){
            return null;
        }
				
				$sql = $this->_db->select()->from( 't_commuser' );
				$sql->where( 'comm_id  = ?', $commId );
				//$sql->where( 'delete_flg  = ?', '0' );
        $userInfo = $this->_db->fetchRow($sql);
        return $userInfo;
        
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に属するユーザ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedUserId($commId)
    {
 				
 				if( $commId == null ){
            return null;
            //return array();
        }
				
        // ユーザ情報を取得する
				$sql = $this->_db->select()->from( 't_commuser', 'user_id' );
				$sql->where( 'comm_id  = ?', $commId );
				$sql->where( 'delete_flg  = ?', '0' );
 				$sql->order( 'comm_id' );			//ASC,DESC
 				$sql->order( 'user_id' );			//ASC,DESC
				
        $userInfo = $this->_db->fetchAll($sql);				//array[0]["user_id"]
        return $userInfo;
        
				
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserName($userId)
    {


        // グループ名称を取得する
        if ($userId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_user', 'user_name' );
						$sql->where( 'user_id  = ?', $userId );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }



    /**-------------------------------------------------------------------------------------------
     * メンバー情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getMemberIds( $find )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$select = $select->from( 'm_member', 'member_id' );
				$select->where( 'delete_flg  = ?', '0' );				// AND
				
				if( $find['s_group'] !='0' )
						$select->where( 'group_id  = ?', $find['s_group'] );
				if( $find['s_grade'] !='0' )
						$select->where( 'grade  = ?',   $find['s_grade'] );
				if( $find['s_class'] !='0' )
						$select->where( 'class_id  = ?',   $find['s_class'] );
				
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $userInfo = $this->_db->fetchAll($select);
				
				return $userInfo;
			
		}





    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に属するグループ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     * @return false	$result		失敗
     */
    public function getCommGroupId($commId)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$select = $select->from( 't_commgroup', array('comm_id','chief_type','chief_id') );
				$select->where( 'delete_flg  = ?', '0' );	
				$select->where( 'comm_id  = ?', $commId );
				
        $groupInfo = $this->_db->fetchRow( $select );
				
				return $groupInfo;
				
		}





    /**-------------------------------------------------------------------------------------------
     * 委員会のグループ情報を更新する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCommGroup( $info, $commId )
    {
        // 更新データを連想配列にする
        $data = array('chief_type' 	=> $info['chief_type'],
                      'chief_id'		=> $info['chief_id']
                );
				
        // データを更新する
        $this->_db->update( 't_commgroup', $data, 'comm_id = ' . $commId );
		
    }








    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報配列を取得する（未使用）
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedGroupId($commId)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$select = $select->from( 't_commgroup', array('class_id')  );
				$select->where( 'delete_flg  = ?', '0' );	
				$select->where( 'comm_id  = ?', $commId );
				
        $userInfo = $this->_db->fetchAll( $select );
				
				return $userInfo;
			
			
    }




    /**-------------------------------------------------------------------------------------------
     * 委員会情報に属するクラス情報を追加する（未使用）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCommAddclass( $info, $classArray, $deleteType )
    {
				$classScan = array(  '1', '2', '3', '4', '5', '6', '7', '8', '9','10', 
														'11','12','13','14','15','16','17','18','19','20'  );
				
				$findArray = array( 	's_group'		=>  '0',
															's_grade'		=>  '0',
															's_class'		=>  '0' 
														);
				
				foreach( $classScan as $scan )
				{
					
					$bFind =false;
					$memberArray = array();
					foreach( $classArray as $class )
					{
						if( $class == $scan )
						{
								$bFind =true;
								$findArray['s_class'] = $class;
								$memberArray = $this->getMemberIds( $findArray );
								break;
						}
					}
					
					$data = array( 
											'comm_id'			=> $info['comm_id'],
											'class'				=> $scan,
											'delete_flg'	=> '0',
											'create_date'	=> NULL
												);
   				$this->checkCommgroup( $data, $memberArray, $bFind );
					
					
				}
		}



    /**-------------------------------------------------------------------------------------------
     * 委員会情報に属するクラス情報を追加する（未使用）
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     * 
     * １グループの登録・解除を行う。
     * クラス・学生個人の登録・解除も行う。
     */
    private function checkCommgroup( $info, $memberArray, $bRegist )
    {
				
				$commId	= $info['comm_id'];
				$class	= $info['class'];	
				
				if( $bRegist )
				{
					// トランザクションの開始する
					$this->_db->beginTransaction();
					// トランザクション内での処理内容を定義する
					try {
							
							if( $this->isRegisteredCommgroup( $commId, $class ) == false ){
									
									// グループ未登録
									$data = array(
								              'comm_id'			=> $commId,
								              'class_id'		=> $class,
								              'delete_flg'	=> '0'
								        );
									// グループ情報を登録する
									$this->_db->insert('t_commgroup', $data );
		      				// 登録したデータの group_id を取得する
									$group	= $this->_db->lastInsertId();
									
									
							}else{
									
									$group	= $this->getCommGroupId2( $commId, $class );
								  // グループ登録済みデータあり
									$data = array(
										                'delete_flg'	=> '0'
									        );
									$target = array(
																		'comm_id = ' 	. $commId,
																		'class_id = ' . $class
																);
									$this->_db->update('t_commgroup', $data, $target );
									
									
							}
							
						
						// 成功したらコミットする
						$this->_db->commit();
						
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				}
				else{	//抹消
					
					// トランザクションの開始する
					$this->_db->beginTransaction();
					// トランザクション内での処理内容を定義する
					try {
							
							$isGroup	= $this->isRegisteredCommgroup( $commId, $class );
							if( $isGroup == true ){
									
				     			// 有無チェック
									{
										   // 更新データを連想配列にする
										  $data = array(
										                'delete_flg'	=> '1'
										          );
											$target = array(
																		'comm_id = ' 	. $commId ,
																		'class_id = ' . $class
															);
										  // データを更新する
										  $this->_db->update( 't_commgroup', $data, $target );
											
									}
									
							}else{
									
									// グループ未登録>>nothing
							}
						
						// 成功したらコミットする
						$this->_db->commit();
						
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				}
				
			
    }


    /**-------------------------------------------------------------------------------------------
     * 指定された委員会に属するグループ情報が登録されているかチェックする（削除済みも入れる）（未使用）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function isRegisteredCommgroup( $commId,$classId )
    {
				
        // 登録済みかチェックする
				$sql = $this->_db->select()->from( 't_commgroup', 'COUNT(*) AS cnt' );
				$sql->where( 'comm_id  = ?', $commId );
				$sql->where( 'user_id  = ?', $userId );
        $result = $this->_db->fetchRow($sql);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
        
    }


    /**-------------------------------------------------------------------------------------------
     * 指定された委員会の削除フラグが設定されているかチェックする（未使用）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    private function isRegisteredCommgroupDeleteFlg( $commId,$classId )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_commgroup', 'delete_flg' );
				$select->where( 'comm_id  = ?', $commId );
				$select->where( 'class_id  = ?', $classId );
				
		    $result = $this->_db->fetchRow( $select );
				
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }



    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する(未使用)
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getCommGroupId2( $commId, $classId )
    {
			//登録済みのループＩＤを取得する
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_commgroup', 'id' );
				$select->where( 'comm_id  = ?', $commId );
				$select->where( 'class_id  = ?', $classId );
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return $ret;
        //return ($ret != null) ? $ret : null;				//staff
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された種類の委員会のＩＤを取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getCommKindId( $commKind )
    {
 				if( $commKind == null ){
            return null;
        }
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_committee', 'comm_id' );
				$select->where( 'comm_kind  = ?', $commKind );
				$select->where( 'delete_flg  = ?', '0' );
				
				// 抽出を実行する
        $result = $this->_db->fetchAll( $select );		//$result[0]['comm_id']
        return $result;
				
    }


    /**-------------------------------------------------------------------------------------------
     * 指定された種類の委員会のＩＤの合計数を取得する
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getCommKindMaxId( $commKind )
    {
			//登録済みのループＩＤを取得する
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_committee', 'COUNT(*) AS cnt' );
				$select->where( 'comm_kind  = ?', $commKind );
				$select->where( 'delete_flg  = ?', '0' );
				
				// 抽出を実行する
        $result = $this->_db->fetchRow( $select );			//$result['cnt']
        return $result['cnt'];
				
    }







}
