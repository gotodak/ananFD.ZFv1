<?php
/**
 * 学生指導モデル
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Db.php';
require_once 'Zend/Registry.php';

require_once 'Zend/Config/Ini.php';

class coachstModel
{
    private $_db;  					// データベースアダプタのハンドル
    private $_config;    		// システム設定情報
		private $_debugOn;			
    
    /**-------------------------------------------------------------------------------------------
     * コンストラクタ
     *
     * @param string $database データベース名
     * @return void
     */
    public function __construct($database)
    {
				
        // 設定情報をロードする
        $this->_config 	= Zend_Registry::get('config');
				$this->_debugOn	= $this->_config->global->debugOn;
				
        // データベース関連の設定をレジストリに登録する
        Zend_Registry::set('database', $this->_config->datasource->database->toArray());
				
        // レジストリからデータを取得する
        if (Zend_Registry::isRegistered('database')) {
            $database = Zend_Registry::get('database');
        }
				
         // データベースの接続パラメータを定義する
        $params = array('host'     => $database['host'],
                        'username' => $database['username'],
                        'password' => $database['password'],
                        'dbname'   => $database['name']
                  );
				
        // データベースアダプタを作成する
        $this->_db = Zend_Db::factory($database['type'], $params);
				
        // 文字コードを UTF-8 に設定する
        $this->_db->query("set names 'utf8'");
				
        // データ取得形式を設定する
        $this->_db->setFetchMode(Zend_Db::FETCH_ASSOC);



    }



    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    public function getCoachstPage( $find )
    {
				
        // ユーザ情報を取得する
				
        if ($find == null)
				{
						$select = $this->_db->select();
						
						$select = $this->_db->select();
						
						$column = array( 't1.coachst_id', 't1.date', 't1.hours', 't1.place', 't1.placeS', 'SUBSTRING(t1.comments,1,20) AS title', 't1.comments', 't1.type', 't1.user_1', 't1.modified_date', 'COUNT(t1.coachst_id) AS count', 'CONCAT("詳細で","確認可") AS member_name' );
						$table  = array( 't1' => 'm_coachst' );
						$select->from( $table, $column );
						
		/**/
						$column = array( 't2.member' );
						$table  = array( 't2' => 't_coachstmember' );
						$select->joinLeft( $table, 't1.coachst_id = t2.coachst', $column );
						
						$column = array( 't3.member_name', 't3.group_id', 't3.grade', 't3.class_id', 't3.member_kana' );
						$table  = array( 't3' => 'm_member' );
						$select->joinLeft( $table, 't2.member = t3.member_id', $column );
						
		/**/
						
						$select->group( 't1.coachst_id' );
						
						$select->where( 't1.delete_flg  = ?', '0' );
						$select->where( 't2.delete_flg  = ?', '0' );
						
 						$select->order( 't2.member' );
						
        }
				else {
		        // 検索項目が指定されていれば条件指定
						
						$select = $this->_db->select();
						
						$column = array( 't1.coachst_id', 't1.date', 't1.hours', 't1.place', 't1.placeS', 'SUBSTRING(t1.comments,1,20) AS title', 't1.comments', 't1.type', 't1.user_1', 't1.modified_date', 'COUNT(t1.coachst_id) AS count', 'CONCAT("詳細で","確認可") AS member_name' );
						$table  = array( 't1' => 'm_coachst' );
						$select->from( $table, $column );
						
		/**/
						$column = array( 't2.member' );
						$table  = array( 't2' => 't_coachstmember' );
						$select->joinLeft( $table, 't1.coachst_id = t2.coachst', $column );
						
						$column = array( 't3.member_name', 't3.group_id', 't3.grade', 't3.class_id', 't3.member_kana' );
						$table  = array( 't3' => 'm_member' );
						$select->joinLeft( $table, 't2.member = t3.member_id', $column );
						
		/**/
						
						$select->group( 't1.coachst_id' );
						
/**/
						//先頭に
						if( $find['s_teacher'] != null ){
							
							//$select->where( 't1.user_1 IN (?)', $find['s_teacher'] );
							$select->orWhere( 't1.user_1 IN (?)', $find['s_teacher'] );
							$select->orWhere( 't1.user_2 IN (?)', $find['s_teacher'] );
						}
/**/
						$select->where( 't1.delete_flg  = ?', '0' );
						$select->where( 't2.delete_flg  = ?', '0' );
						
						
						if( $find['s_grade'] !='0' )
								$select->where( 't3.grade  = ?', $find['s_grade'] );
						
						if( $find['s_group'] !='0' )
								$select->where( 't3.group_id  = ?', $find['s_group'] );
						
						if( $find['s_class'] !='0' )
								$select->where( 't3.class_id  = ?', $find['s_class'] );
						
						if( $find['s_type'] !='0' )
								$select->where( 't1.type  = ?', $find['s_type'] );
						

						if( $find['s_stdate'] !='' ){
								//$stdate = $find['s_styear'].'-04-01';
								$stdate = $find['s_stdate'];
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $stdate, $m)) {
									$stdate = $m[1] .'-'. $m[2] .'-'. $m[3] .' 00:00:00' ;
								}
								$select->where( 't1.date >= ?', $stdate );
						}
						
						if( $find['s_eddate'] !='' ){
								//$eddate = $find['s_edyear'].'-04-01';
								$eddate = $find['s_eddate'];
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $eddate, $m)) {
									$eddate = $m[1] .'-'. $m[2] .'-'. $m[3] .' 23:59:59' ;
								}
								$select->where( 't1.date <= ?', $eddate );
						}

						
						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='comments'  )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else if( $find['s_field'] =='placeS' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else if( $find['s_field'] =='member' )
									$select->where( 't2.'. $find['s_field'] .' = ?',   $find['s_keyword'] );
						}
						
						if( $find['s_student'] != null ){
							
							$select->where( 't2.member IN (?)', $find['s_student'] );
						}
						
						
						
 						$select->order( 't2.member' );
      	}
				
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
				$userInfo = $select;
				
				return $userInfo;
		}




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する（指導学生、指導クラスが設定無い場合の対応版）
     *
     * @param  array  $find			絞り込み情報
     * @return array	$result		ユーザ情報
     */
    public function getCoachstPage0( $find )
    {
				
        // ユーザ情報を取得する
				
        if ($find == null)
				{
						$select = $this->_db->select();
						
						$column = array( 't1.coachst_id', 't1.date', 't1.hours', 't1.place', 't1.placeS', 'SUBSTRING(t1.comments,1,20) AS title', 't1.comments', 't1.type', 't1.user_1', 't1.modified_date', 'COUNT(t1.coachst_id) AS count', 'CONCAT("詳細で","確認可") AS member_name' );
						$table  = array( 't1' => 'm_coachst' );
						$select->from( $table, $column );
						
						$select->group( 't1.coachst_id' );
						
						$select->where( 't1.delete_flg  = ?', '0' );
						
						
        }
				 elseif ( $find['s_grade'] =='0' 
								&& $find['s_group'] =='0' 
								&& $find['s_class'] =='0' 
								&& $find['s_field'] !='member' 
								&& $find['s_student'] == null	
						) {
		        // 検索項目が指定されていれば条件指定
						
						$select = $this->_db->select();
						
						$column = array( 't1.coachst_id', 't1.date', 't1.hours', 't1.place', 't1.placeS', 'SUBSTRING(t1.comments,1,20) AS title', 't1.comments', 't1.type', 't1.user_1', 't1.modified_date', 'COUNT(t1.coachst_id) AS count', 'CONCAT("詳細で","確認可") AS member_name' );
						$table  = array( 't1' => 'm_coachst' );
						$select->from( $table, $column );
						
						
						$select->group( 't1.coachst_id' );
						
/**/
						//先頭に
						if( $find['s_teacher'] != null ){
							
							$select->orWhere( 't1.user_1 IN (?)', $find['s_teacher'] );
							$select->orWhere( 't1.user_2 IN (?)', $find['s_teacher'] );
							
						}
/**/
						$select->where( 't1.delete_flg  = ?', '0' );
						
						if( $find['s_type'] !='0' )
								$select->where( 't1.type  = ?', $find['s_type'] );
						
						if( $find['s_stdate'] !='' ){
								//$stdate = $find['s_styear'].'-04-01';
								$stdate = $find['s_stdate'];
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $stdate, $m)) {
									$stdate = $m[1] .'-'. $m[2] .'-'. $m[3] .' 00:00:00' ;
								}
								$select->where( 't1.date >= ?', $stdate );
						}
						
						if( $find['s_eddate'] !='' ){
								//$eddate = $find['s_edyear'].'-04-01';
								$eddate = $find['s_eddate'];
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $eddate, $m)) {
									$eddate = $m[1] .'-'. $m[2] .'-'. $m[3] .' 23:59:59' ;
								}
								$select->where( 't1.date <= ?', $eddate );
						}

						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='comments'  )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else if( $find['s_field'] =='placeS' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
						}
						
						
        } 
				else {
		        // 検索項目が指定されていれば条件指定
						
						$select = $this->_db->select();
						
						$column = array( 't1.coachst_id', 't1.date', 't1.hours', 't1.place', 't1.placeS', 'SUBSTRING(t1.comments,1,20) AS title', 't1.comments', 't1.type', 't1.user_1', 't1.modified_date', 'COUNT(t1.coachst_id) AS count', 'CONCAT("詳細で","確認可") AS member_name' );
						$table  = array( 't1' => 'm_coachst' );
						$select->from( $table, $column );
						
		/**/
						$column = array( 't2.member' );
						$table  = array( 't2' => 't_coachstmember' );
						$select->joinLeft( $table, 't1.coachst_id = t2.coachst', $column );
						
						$column = array( 't3.member_name', 't3.group_id', 't3.grade', 't3.class_id', 't3.member_kana' );
						$table  = array( 't3' => 'm_member' );
						$select->joinLeft( $table, 't2.member = t3.member_id', $column );
						
		/**/
						
						$select->group( 't1.coachst_id' );
						
/**/
						//先頭に
						if( $find['s_teacher'] != null ){
							
							//$select->where( 't1.user_1 IN (?)', $find['s_teacher'] );
							$select->orWhere( 't1.user_1 IN (?)', $find['s_teacher'] );
							$select->orWhere( 't1.user_2 IN (?)', $find['s_teacher'] );
						}
/**/
						$select->where( 't1.delete_flg  = ?', '0' );
						$select->where( 't2.delete_flg  = ?', '0' );
						
						
						if( $find['s_grade'] !='0' )
								$select->where( 't3.grade  = ?', $find['s_grade'] );
						
						if( $find['s_group'] !='0' )
								$select->where( 't3.group_id  = ?', $find['s_group'] );
						
						if( $find['s_class'] !='0' )
								$select->where( 't3.class_id  = ?', $find['s_class'] );
						
						if( $find['s_type'] !='0' )
								$select->where( 't1.type  = ?', $find['s_type'] );
						

						if( $find['s_stdate'] !='' ){
								$stdate = $find['s_stdate'];
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $stdate, $m)) {
									$stdate = $m[1] .'-'. $m[2] .'-'. $m[3] .' 00:00:00' ;
								}
								$select->where( 't1.date >= ?', $stdate );
						}
						
						if( $find['s_eddate'] !='' ){
								$eddate = $find['s_eddate'];
								if (preg_match('/^(\d\d\d\d)\-(\d\d)\-(\d\d) (\d\d):(\d\d)$/', $eddate, $m)) {
									$eddate = $m[1] .'-'. $m[2] .'-'. $m[3] .' 23:59:59' ;
								}
								$select->where( 't1.date <= ?', $eddate );
						}

						
						if( $find['s_keyword'] !='' ){
							if( $find['s_field'] =='comments'  )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else if( $find['s_field'] =='placeS' )
								$select->where( 't1.'. $find['s_field'] .' LIKE ?',   "%{$find['s_keyword']}%" );
							else if( $find['s_field'] =='member' )
									$select->where( 't2.'. $find['s_field'] .' = ?',   $find['s_keyword'] );
						}
						
						if( $find['s_student'] != null ){
							
							$select->where( 't2.member IN (?)', $find['s_student'] );
						}
						
						
						
 						$select->order( 't2.member' );
      	}
				
				
				// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
				$userInfo = $select;
				
				return $userInfo;
		}




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getCoachstId( $coachst, $userId = null)
    {
				
        if ($coachst === null) {
					$userInfo = array();
					$userInfo['coachst_id'] = 0;
					
				}
				else{
					// Zend_Db_Selectオブジェクトを作成する
					$select = $this->_db->select();
					// from() メソッドを追加する
					$select = $select->from( 'm_coachst' );
					$select->where( 'delete_flg  = ?', '0' );	
					$select->where( 'coachst_id  = ?', $coachst );
	        $userInfo = $this->_db->fetchRow($select);
					
					if( $userId != null ){
						if( $userId != $userInfo['user_1'] &&
								$userId != $userInfo['user_2'] ){
									$userInfo['coachst_id'] = -1;
						}
					}
				}
				
        return $userInfo;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedMemberId($coachst)
    {
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$select = $select->from( 't_coachstmember', 'member' );
				$select->where( 'delete_flg  = ?', '0' );	
				$select->where( 'group_id  = ?', '0' );
				
				$select->where( 'coachst  = ?', $coachst );
				
        $userInfo = $this->_db->fetchAll($select);
				
				return $userInfo;
			
			
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報配列を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function chargedGroupId($coachst)
    {

				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$select = $select->from( 't_coachstgroup', array('class_id', 'year')  );
				$select->where( 'delete_flg  = ?', '0' );	
				
				$select->where( 'coachst  = ?', $coachst );
				
        $userInfo = $this->_db->fetchAll($select);
				
				return $userInfo;
			
			
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報をを登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registCoachst( $info, $deleteType )
    {
				$lastId = 0;
				
 				if( $info['date'] == "" ){
            return $lastId;
        }
				
        // 登録データを連想配列にする
				
        $data = array(
											'date'				=> $info['date'],
											'hours'				=> $info['hours'],
											'place'				=> $info['place'],
											'placeS'			=> $info['placeS'],
											
											'group_type'	=> $info['group_type'],
											//'comments'		=> $this->_db->quote($info['comments']),
											'comments'		=> $info['comments'],
											'type'				=> $info['type'],
											'user_1'			=> $info['user1'],
											'user_2'			=> $info['user2'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_coachst', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }






    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を新規登録する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function registCoachstNew( $info, $memberArray, $deleteType )
    {
				$lastId = 0;
				
 				
        // 登録データを連想配列にする
				
        $data = array(
											'date'				=> $info['date'],
											'hours'				=> $info['hours'],
											'place'				=> $info['place'],
											'placeS'			=> $info['placeS'],
											
											//'comments'		=> $this->_db->quote($info['comments']),
											'comments'		=> $info['comments'],
											'type'				=> $info['type'],
											'user_1'			=> $info['user1'],
											//'user_2'			=> $info['user2'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									// ユーザ情報を登録する
									$this->_db->insert('m_coachst', $data );
        				  // 登録したデータの user_id を取得する
									$lastId = $this->_db->lastInsertId();
									
						
						if( count($memberArray) >= 1 ){
								
								
								$coachst= $lastId;
								$group			= '0';
								$deleteType = '0';
								
								foreach( $memberArray as $member ){
								
										{
										    // 登録データを連想配列にする
										    $coachenmember = array(
																			'coachst'			=> $coachst,	
																			'member'			=> $member,	
																			'group_id'		=> $group,	
																			
																			'delete_flg'	=> $deleteType
										             );
												$this->_db->insert('t_coachstmember', $coachenmember );
												
										}
								}
						}
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;
		
    }





    /**-------------------------------------------------------------------------------------------
     * ★☆授業科目情報を更新する★☆
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCoachst( $info, $deleteType)
    {

				$lastId = 0;
				
 				if( $info['coachst'] == "" ){
            return $lastId;
        }
				
				
        // 登録データを連想配列にする
				
        $data = array(
											'date'				=> $info['date'],
											'hours'				=> $info['hours'],
											'place'				=> $info['place'],
											'placeS'			=> $info['placeS'],
											
											//'comments'		=> $this->_db->quote($info['comments']),
											'comments'		=> $info['comments'],
											'type'				=> $info['type'],
											'user_1'			=> $info['user1'],
											//'user_2'			=> $info['user2'],
											'delete_flg'	=> $deleteType
                );
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
						
						$target = array(
													'coachst_id = ' . $info['coachst']
										);
	        	// データを更新する
   					$this->_db->update( 'm_coachst', $data, $target );
						
						
						
						// 成功したらコミットする
						$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
					
	        return $lastId;


		
    }





    /**-------------------------------------------------------------------------------------------
     * 授業科目情報を削除する
     *
     * @param int $userId ユーザID
     * @return void
     */
    public function deleteCoachst( $coachst, $userId=null )
    {
				$retval = 0;
				
				if( $userId != null ){
					
					// Zend_Db_Selectオブジェクトを作成する
					$select = $this->_db->select();
					// from() メソッドを追加する
					$select = $select->from( 'm_coachst' );
					$select->where( 'delete_flg  = ?', '0' );	
					$select->where( 'coachst_id  = ?', $coachst );
	        $learnInfo = $this->_db->fetchRow( $select );
					
					
					if( $userId != $learnInfo['user_1'] ){
								$retval = -1;
								return $retval;
					}
				}
				
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									
					         // 更新データを連想配列にする
					        $data = array(
					                      'delete_flg'	=> '1'
					                );
									$target = array(
																'coachst_id = ' . $coachst 
													);
									
					        // データを更新する
					        $this->_db->update( 'm_coachst', $data, $target );
					        //$this->_db->delete('m_subject', $target );
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				return $retval;
				

   }




    /**-------------------------------------------------------------------------------------------
     * 学生指導情報に属する教員情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCoachstAdduser( $coachst, $userArray )
    {
				
				$lastId = 0;
				
 				if( $coachst == "" ){
            return $lastId;
        }
       	// 重複チェック
 				if( count($userArray) != 1 )
				{
            return $lastId;
        }
				$user = $userArray[0];
				{
				
        	// 登録データを連想配列にする
					
        		$data = array(
											'user_2'			=> $user
                );
						
						
						
						// トランザクションの開始する
						$this->_db->beginTransaction();
						// トランザクション内での処理内容を定義する
						try {
								
								$target = array(
															'coachst_id = ' . $coachst
												);
			        	// データを更新する
		   					$this->_db->update( 'm_coachst', $data, $target );
								
								// 成功したらコミットする
								$this->_db->commit();
											
							// エラーが発生したらロールバックする
							} catch (Exception $e ) {
										$this->_db->rollBack();
										echo '処理が失敗したのでキャンセルしました。';
							}
							
			        return $lastId;
				}
				
				
    }







    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCoachstAddmember( $info, $memberArray, $deleteType )
    {
				
				// トランザクションの開始する
				$this->_db->beginTransaction();
				// トランザクション内での処理内容を定義する
				try {
									$coachst= $info['coachst'];
									$group	= '0';	
									
									foreach( $memberArray as $member ){
									
       								// 重複チェック
											$isRegist	= $this->isRegisteredCoachstmember( $coachst,$member );
											if( $isRegist == false )
											{
											    // 登録データを連想配列にする
											    $coachstmember = array(
																				'coachst'			=> $coachst,	
																				'member'			=> $member,	
																				'group_id'		=> $group,	
																				
																				'delete_flg'	=> $deleteType
											             );
													$this->_db->insert('t_coachstmember', $coachstmember );
													
											}else
											{
													//登録済み（個人登録優先）
													
												  $data = array(
												                'group_id'	=> '0',
												                'delete_flg'	=> '0'
												          );
													$target = array(
																				'coachst = ' . $coachst ,
																				'member = ' . $member
																	);
													
												  // データを更新する
												  $this->_db->update( 't_coachstmember', $data, $target );
													
													
											}
									
									}
									
									
									// 成功したらコミットする
									$this->_db->commit();
									
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
    }




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を削除する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCoachstDelmember( $info, $deleteType)
    {
				
				// 個人登録のグループは、０であるが、
        // 個人削除時にグループ登録されていれば、グループ属性にして登録する
				$class 	= $this->getClassId( $info['member'] );
				$group	= $this->getGroupId( $info['coachst'], $class );
				if( $group != null ){
						
						
		        $data = array(
													'group_id' 		=> $group ,
		                      'delete_flg'	=> '0'
		                );
						
						$target = array(
													'coachst = ' 	. $info['coachst'] ,
													'member = ' 	. $info['member']
										);
						
		        // データを更新する
		        $this->_db->update( 't_coachstmember', $data, $target );
				}
				else {
		        $data = array(
													//'group_id' 		=> $group ,
		                      'delete_flg'	=> '1'
		                );

						$target = array(
													'coachst = ' 	. $info['coachst'] ,
													//'group_id = ' . $info['group'] ,
													'member = ' 	. $info['member']
										);
						
		        // データを更新する
		        $this->_db->update( 't_coachstmember', $data, $target );
				}
		
    }







    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     */
    public function updateCoachstAddclass( $info, $classArray, $deleteType )
    {
				$classScan = array(  '1', '2', '3', '4', '5', '6', '7', '8', '9','10', 
														'11','12','13','14','15','16','17','18','19','20'  );
				
				$findArray = array( 	's_group'		=>  '0',
															's_grade'		=>  '0',
															's_class'		=>  '0' 
														);
				
				foreach( $classScan as $scan )
				{
					
					$bFind =false;
					$memberArray = array();
					foreach( $classArray as $class )
					{
						if( $class == $scan )
						{
								$bFind =true;
								$findArray['s_class'] = $class;
								$memberArray = $this->getMemberIds( $findArray );
								break;
						}
					}
					
					$data = array( 
											'coachst'			=> $info['coachst'],
											'year'				=> $info['year'],
											'class'				=> $scan,
											'delete_flg'	=> '0',
											'create_date'	=> NULL
												);
   				$this->checkCoachstgroup( $data, $memberArray, $bFind );
					
					
				}
		}




    /**-------------------------------------------------------------------------------------------
     * 授業科目情報に属するユーザ情報を追加する
     *
     * @param array  $info  	 ユーザ情報
     * @param int    $userId   フィードID
     * @param int    $groupId  グループID
     * @param int    $jobId    職名ID
     * @param string $deleteType 削除フラグ種別
     * @return void
     * 
     * １グループの登録・解除を行う。
     * クラス・学生個人の登録・解除も行う。
     */
    public function checkCoachstgroup( $info, $memberArray, $bRegist )
    {
				
				$coachst= $info['coachst'];
				$class	= $info['class'];	
				$year		= $info['year'];	
				
				if( $bRegist )
				{
					// トランザクションの開始する
					$this->_db->beginTransaction();
					// トランザクション内での処理内容を定義する
					try {
							
							if( $this->isRegisteredCoachstgroup( $coachst, $class ) == false ){
									
									// グループ未登録
									$data = array(
								              'coachst'			=> $coachst,
								              'class_id'		=> $class,
								              'year'				=> $year,
								              'delete_flg'	=> '0'
								        );
									// グループ情報を登録する
									$this->_db->insert('t_coachstgroup', $data );
		      				// 登録したデータの group_id を取得する
									$group	= $this->_db->lastInsertId();
									
									foreach( $memberArray as $row ){
										
											$member	= $row['member_id'];
			       					// 重複チェック
											if( $this->isRegisteredCoachstmember( $coachst,$member ) == false )
											{
													//削除中
									        // 登録データを連想配列にする
									        $data = array(
																				'coachst'			=> $coachst,	
																				'member'			=> $member,	
																				'group_id'		=> $group,	
																				
																				'delete_flg'	=> '0'
									                );
													$this->_db->insert('t_coachstmember', $data );
											}
											else{
													
													 // 1個ずつ更新（個人利用優先）
													
											}
									}
									
							}else{
									
									$group	= $this->getGroupId( $coachst, $class );
								  // グループ登録済みデータあり
									$data = array(
										                'delete_flg'	=> '0'
									        );
									$target = array(
																		'coachst = ' 	. $coachst,
																		'class_id = ' . $class
																);
									$this->_db->update('t_coachstgroup', $data, $target );
									
									// 同じグループ利用のメンバーを一括復活する
									$data = array(
									              'delete_flg'	=> '0'
									        );
									$target = array(
																'coachst = ' . $coachst ,
																//'member = '	 . $member,	
																'group_id  = ' . $group 
													);
									// データを更新する
									$this->_db->update( 't_coachstmember', $data, $target );
									
/**/
									//個人削除チェック
									foreach( $memberArray as $row )
									{
											
											$member	= $row['member_id'];
			       					// 削除チェック
											if( $this->isRegisteredCoachstmemberDeleteFlg( $coachst,$member ) == true )
											{
													$data = array(
													              'group_id'		=> $group,
													              'delete_flg'	=> '0'
													        );
													$target = array(
																				'coachst = ' 		. $coachst ,
																				'group_id = ' 	. '0' ,
																				'member = '	 		. $member	,
																				'delete_flg = '	. '1'	
																	);
													// データを更新する
													$this->_db->update( 't_coachstmember', $data, $target );
											}
									}
/**/
									
							}
							
						
						// 成功したらコミットする
						$this->_db->commit();
						
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				}
				else{	//抹消
					
					// トランザクションの開始する
					$this->_db->beginTransaction();
					// トランザクション内での処理内容を定義する
					try {
							
							$isGroup	= $this->isRegisteredCoachstgroup( $coachst, $class );
							if( $isGroup == true ){
									
									{
										   // 更新データを連想配列にする
										  $data = array(
										                'delete_flg'	=> '1'
										          );
											$target = array(
																		'coachst = ' 	. $coachst ,
																		'class_id = ' . $class
															);
										  // データを更新する
										  $this->_db->update( 't_coachstgroup', $data, $target );
											
											// 同じグループのメンバーを一括削除する
											$group	= $this->getGroupId( $coachst, $class );
											$data = array(
											              'delete_flg'	=> '1'
											        );
											$target = array(
																		'coachst = ' . $coachst ,
																		'group_id  = ' . $group 
															);
											// データを更新する
											$this->_db->update( 't_coachstmember', $data, $target );
									}
									
							}else{
									
									// グループ未登録>>nothing
							}
						
						// 成功したらコミットする
						$this->_db->commit();
						
					// エラーが発生したらロールバックする
					} catch (Exception $e ) {
								$this->_db->rollBack();
								echo '処理が失敗したのでキャンセルしました。';
					}
				
				}
				
			
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目が登録されているかチェックする（未使用）
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCoachst($id)
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 'm_coachst', 'COUNT(*) AS cnt' );
				$select->where( 'coachst_id  = ?', $id );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
        } else {
            return false;
        }
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCoachstmember( $coachst,$memberId )
    {
        // 登録済みかチェックする
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_coachstmember', 'id'  );
				$select->where( 'coachst  = ?', $coachst );
				$select->where( 'member  = ?', $memberId );
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? true : false;
				
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するユーザが登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isGroupedCoachstmember( $coachst,$memberId )
    {
        // 登録済みかチェックする
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_coachstmember', 'group_id'  );
				$select->where( 'coachst  = ?', $coachst );
				$select->where( 'member  = ?', $memberId );
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != '0') ? true : false;
				
    }




    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCoachstmemberDeleteFlg( $coachst,$memberId )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_coachstmember', 'delete_flg' );
				$select->where( 'coachst  = ?', $coachst );
				$select->where( 'member  = ?', $memberId );
				
		    $result = $this->_db->fetchRow( $select );
				
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }





    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目に属するグループ情報が登録されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCoachstgroup( $coachst,$classId )
    {
        // 登録済みかチェックする
				$select = $this->_db->select()->from( 't_coachstgroup', 'COUNT(*) AS cnt' );
				$select->where( 'coachst  = ?', $coachst );
				$select->where( 'class_id  = ?', $classId );
        $result = $this->_db->fetchRow($select);
       	if ($result['cnt'] > 0) {
            return true;
						
        } else {
            return false;
        }
    }


    /**-------------------------------------------------------------------------------------------
     * 指定された授業科目の削除フラグが設定されているかチェックする
     *
     * @param  string 	$email   メールアドレス
     * @return boolean 	存在有無
     */
    public function isRegisteredCoachstgroupDeleteFlg( $coachst,$classId )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_coachstgroup', 'delete_flg' );
				$select->where( 'coachst  = ?', $coachst );
				$select->where( 'class_id  = ?', $classId );
				
		    $result = $this->_db->fetchRow( $select );
				
       	if ( $result['delete_flg'] == '0' ) {
            return false;
        } else {
            return true;
        }
    }





















    /**-------------------------------------------------------------------------------------------
     * メンバー情報を取得する
     *
     * @param  string $userId		ユーザＩＤ
     * @return array	$result		ユーザ情報
     */
    public function getMemberIds( $find )
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				// from() メソッドを追加する
				$select = $select->from( 'm_member', 'member_id' );
				$select->where( 'delete_flg  = ?', '0' );				// AND
				
				if( $find['s_group'] !='0' )
						$select->where( 'group_id  = ?', $find['s_group'] );
				if( $find['s_grade'] !='0' )
						$select->where( 'grade  = ?',   $find['s_grade'] );
				if( $find['s_class'] !='0' )
						$select->where( 'class_id  = ?',   $find['s_class'] );
				
						// 生成されたクエリを表示する
if( $this->_config->global->debugOn ){
						echo '<br/>'.$select->__toString().'<br/>';
}
				
        $userInfo = $this->_db->fetchAll($select);
				
				return $userInfo;
			
		}






    /**-------------------------------------------------------------------------------------------
     * 追加教員１を取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getCoachstUser1($coachst)
    {
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_coachst', 'user_1' );
				$select->where( 'coachst_id  = ?', $coachst );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }




    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getCoachstDate($id)
    {


        // グループ名称を取得する
        if ($id === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_coachst', 'date' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_coachst', 'date' );
						$sql->where( 'coachst_id  = ?', $id );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }



    /**-------------------------------------------------------------------------------------------
     * ユーザ名称を取得する
     *
     * @param	 int		$groupId			グループID
     * @return string $groupName		グループ名称
     *
     *	※ユーザ一覧表示・編集時に使用
     */
    public function getUserName($id)
    {


        // グループ名称を取得する
        if ($userId === null) {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_coachst', 'user_name' );
						
						$groupName = $this->_db->fetchAll($sql);
						
        // IDが指定されていれば条件指定
        } else {
						
						// Zend_Db_Selectオブジェクトを作成する
						$sql = $this->_db->select()->from( 'm_coachst', 'user_name' );
						$sql->where( 'coachst_id  = ?', $id );
						
        		$groupName = $this->_db->fetchOne($sql);
						
        }
        return $groupName;
				
    }







    /**-------------------------------------------------------------------------------------------
     * クラスＩＤを取得する
     *
     * @param  string $jobName		職名
     * @return int		$jobId			職名ＩＤ
     */
    public function getClassId($memberId)
    {
				
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 'm_member', 'class_id' );
				$select->where( 'member_id  = ?', $memberId );
				$select->where( 'delete_flg  = ?', '0' );		// AND
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return ($ret != null) ? $ret : 1;
				
    }






    /**-------------------------------------------------------------------------------------------
     * グループＩＤを取得する(××)
     *
     * @param  string $groupName		グループ名称
     * @return int		$groupId			グループID
     */
    public function getGroupId( $coachst, $classId )
    {
			//登録済みのループＩＤを取得する
				
				// Zend_Db_Selectオブジェクトを作成する
				$select = $this->_db->select();
				
				// from() メソッドを追加する
				$select->from( 't_coachstgroup', 'id' );
				$select->where( 'coachst  = ?', $coachst );
				$select->where( 'class_id  = ?', $classId );
				
				// 抽出を実行する
        $ret = $this->_db->fetchOne($select);
        return $ret;
        //return ($ret != null) ? $ret : null;				//staff
				
    }








}