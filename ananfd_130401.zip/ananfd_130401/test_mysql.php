<?php
if (!$conn = mysql_connect('mysql704.xserver.jp', 'awamosaic_fd', 'gotoda')) {
    die('MySQL Failed');
}
echo 'MySQL Successed';
mysql_close($conn);