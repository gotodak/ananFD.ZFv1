<?php
/**
 * フロントコントローラ
 * 
 * @copyright 2011 Koji GOTODA (GOTODAK)
 * @license   GNU General Public License Version3
 * @version   1.0.0
 * @since     File available since Release 1.0.0
 */

// コンポーネントをロードする
require_once 'Zend/Controller/Front.php';
require_once 'Zend/Acl.php';
require_once 'Zend/Acl/Role.php';
require_once 'Zend/Acl/Resource.php';
require_once 'Zend/Session.php';
require_once 'Zend/Registry.php';

// モデルをロードする
require_once '../application/vers/default/models/aclModel.php';

// モジュールをロードする
require_once '../application/lib/TimeAssertion.class.php';




// セッションをスタートする
Zend_Session::start();

class AclPlugin extends Zend_Controller_Plugin_Abstract
{
    //private $_config;    			// システム設定情報
    private $_sid;
    private $_namespace;
    private $_userspace;
		
    /**
     * preDispatch
     * アクセス制御を行う
     */
    public function preDispatch(Zend_Controller_Request_Abstract $request)
    {

        // 設定情報をロードする
        $config = new Zend_Config_Ini('../application/lib/config.ini', null);
				
        // 設定情報をレジストリに登録する
        Zend_Registry::set('config', $config);
				
        // セッションIDを取得する
        $sessionId = $request->getParam('sid', '');

        // ユーザモデルのインスタンスを生成する
        $this->_acl		 = new aclModel('../application/lib/user.db');

        // セッションIDをレジストリに登録する
        Zend_Registry::set('sessionId', $sessionId);

        // Zend_Aclのインスタンスを生成する
        $acl = new Zend_Acl();


        // ロールを定義する
        $acl->addRole(new Zend_Acl_Role('guest'));							
        $acl->addRole(new Zend_Acl_Role('staff')		,'guest'	);
        $acl->addRole(new Zend_Acl_Role('user')			,'staff'	);
        $acl->addRole(new Zend_Acl_Role('teacher')	,'user'		);
        $acl->addRole(new Zend_Acl_Role('chief')		,'teacher');
        $acl->addRole(new Zend_Acl_Role('manager')	,'chief'	);
        $acl->addRole(new Zend_Acl_Role('master')		,'manager');
        $acl->addRole(new Zend_Acl_Role('admin')		,'master'	);

        // リソースを定義する
        $acl->add(new Zend_Acl_Resource('anonPage'));		
        $acl->add(new Zend_Acl_Resource('staffPage'));	
        $acl->add(new Zend_Acl_Resource('userPage'));		
        $acl->add(new Zend_Acl_Resource('teacherPage'));
        $acl->add(new Zend_Acl_Resource('chiefPage'));	
        $acl->add(new Zend_Acl_Resource('managerPage'));
        $acl->add(new Zend_Acl_Resource('masterPage'));	
        $acl->add(new Zend_Acl_Resource('adminPage'));	
				

        // リソースへのアクセス権限を設定する
				//$acl->allow('guest',   'anonPage' , null, new TimeAssertion());
				//$acl->allow('staff',   'staffPage', null, new TimeAssertion());
				//$acl->allow('user',    'userPage' , null, new TimeAssertion());
        $acl->allow('guest'		,'anonPage'  	,null	,null);		
        $acl->allow('staff'		,'staffPage' 	,null	,null);		
        $acl->allow('user'		,'userPage'  	,null	,null);		
        $acl->allow('teacher'	,'teacherPage',null	,null);		
        $acl->allow('chief'		,'chiefPage'	,null	,null);		
        $acl->allow('manager'	,'managerPage',null	,null);		
        $acl->allow('master'	,'masterPage' ,null	,null);		
        $acl->allow('admin'		,'adminPage'  ,null	,null);		
				//$acl->allow('admin', 'masterPage' , null, new TimeAssertion());

        // ユーザーレベルを取得する
        $session = new Zend_Session_Namespace('global');
        $userLevel = 'guest';
        $userLevel = $session->userLevel;

				if( $this->getRequest()->isGet() ) {
						
		        $this->_sid		= $this->getRequest()->getParam('sid');
						if( isset($this->_sid) ){
							if( Zend_Session::namespaceIsset($this->_sid) ){			// $session != null 
								
				      		$session = new Zend_Session_Namespace( $this->_sid );
									$session->setExpirationSeconds( $config->global->sessionSec );	// 再延長
					        $userLevel = $session->userLevel;																//FD高度化推進室　システム管理者
									
									// ログインユーザ情報の更新
									$this->_acl->updateLoginUser($session->userId);

									Zend_Session::regenerateId();
									$sid = 's'.Zend_Session::getId();								// 'Session namespace must not start with a number'
					        $session2 = new Zend_Session_Namespace($sid);
									$session2->setExpirationSeconds( $config->global->sessionSec );			
					        $session2->userId    = $session->userId    ;
					        $session2->userLevel = $session->userLevel ;
									$session2->userName  = $session->userName  ;
									//
										$session2->search['student']	=	$session->search['student'];
										$session2->search['student2']	=	$session->search['student2'];
										$session2->search['club']			=	$session->search['club'];		
										$session2->search['job']			=	$session->search['job'];		
										$session2->search['subject']	=	$session->search['subject'];
										$session2->search['subject2']	=	$session->search['subject2'];
										$session2->search['user']			=	$session->search['user'];		
										$session2->search['user2']		=	$session->search['user2'];		
										$session2->search['class']		=	$session->search['class'];	
										$session2->search['group']		=	$session->search['group'];	
										$session2->search['comm']			=	$session->search['comm'];		
										$session2->search['support']	=	$session->search['support'];
										$session2->search['support2']	=	$session->search['support2'];
										$session2->search['support3']	=	$session->search['support3'];
										$session2->search['support4']	=	$session->search['support4'];
										$session2->search['require']	=	$session->search['require'];
										$session2->search['require2']	=	$session->search['require2'];
										$session2->search['require3']	=	$session->search['require3'];
										$session2->search['require4']	=	$session->search['require4'];
										$session2->search['tp']				=	$session->search['tp'];
										$session2->search['tp2']			=	$session->search['tp2'];
										
										$session2->search['learning']	=	$session->search['learning'];
										$session2->search['learning2']=	$session->search['learning2'];
										$session2->search['learning3']=	$session->search['learning3'];
										$session2->search['learning4']=	$session->search['learning4'];
										$session2->search['coachst']	=	$session->search['coachst'];
										$session2->search['coachst2']	=	$session->search['coachst2'];
										$session2->search['coachst3']	=	$session->search['coachst3'];
										$session2->search['coachst4']	=	$session->search['coachst4'];
										$session2->search['coachst5']	=	$session->search['coachst5'];
										$session2->search['coachen']	=	$session->search['coachen'];
										$session2->search['coachen2']	=	$session->search['coachen2'];
										$session2->search['coachen3']	=	$session->search['coachen3'];
										$session2->search['coachen4']	=	$session->search['coachen4'];
										$session2->search['coachen5']	=	$session->search['coachen5'];
										$session2->search['role']			=	$session->search['role'];
										$session2->search['role2']		=	$session->search['role2'];
										$session2->search['top']			=	$session->search['top'];

        					Zend_Registry::set('sessionId', $sid);
									
									$this->_sid = $sid;
									$session = $session2;
									
									$this->_sessionId	= $sid;
									$this->_sid 			= $sid;
									

									
							}
						}
				}
				

        // ユーザーレベルが「user」か「admin」でなければ「guest」に設定する
		    if (   $userLevel != 'user' 		&& $userLevel != 'admin' 	
		        && $userLevel != 'teacher' 	&& $userLevel != 'staff'	&& $userLevel != 'chief'	
		        && $userLevel != 'manager' 	&& $userLevel != 'master'	) {
						
            $session->userLevel  = 'guest';
        }

				
        // リクエスト情報を取得する
        // アクション名を取得する
        $module     = strtolower($request->getModuleName());
        $controller = strtolower($request->getControllerName());
        $action     = strtolower($request->getActionName());


        // リクエストに対するリソース情報を取得する
        $aclResource = $this->_acl->get($controller, $action, $module);

        // アクセス権限がなければログインコントローラへ転送する
        if (!$acl->isAllowed($userLevel, $aclResource)) {
						
						$request->setParam('accessError', 'アクセス禁止です。('. $userLevel .')');
            $request->setControllerName('Error');
            $request->setActionName('error');
						
        }
				
        // ベースパスをセッションに登録する
        $session->basePath = '/ananfd/';
    }



    /**
     * postDispatch
     * アクセス制御を行う
     */
    public function postDispatch(Zend_Controller_Request_Abstract $request)
    {
				
        $lastPg = new Zend_Session_Namespace('history');
        $lastPg->lastController = $request->getControllerName(); 
        $lastPg->lastAction     = $request->getActionName(); 
				
		}
}



////////////////////////////////////////////////
// フロントコントローラのインスタンスを取得する
$front = Zend_Controller_Front::getInstance();

// モジュールのディレクトリを設定する
$front->addModuleDirectory('../application/vers');


// プラグインを登録する
$front->registerPlugin(new AclPlugin());

// ディスパッチする
$front->dispatch();
