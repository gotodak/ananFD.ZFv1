<?php
require 'Zend/Version.php';
echo Zend_Version::VERSION;
?>
